# Crônicas de Aurora (Aurora RPG) — v0.4 (Godot 4.4.1 / GDScript)

RPG de fantasia estilo GBA, top-down, 100% offline. Uma base de código para PC e Android.
Arte e áudio são **procedurais** (gerados por código) — não há arquivos de imagem/som.

## Novidades da v0.4
- **Heróis redesenhados** (44x44 px) com animações completas: idle, ataque, habilidade, dano e morte, ligadas à batalha (ataque físico usa a animação de ataque; magias/buffs usam a de habilidade). Sprites de andar na ilha com capa, escudo e faixa por classe.
- **Monstros por bioma** com sprites próprios: Escorpião, Serpente das Dunas, Sapo do Brejo, Lodo Vivo, Lobo Glacial, Golem de Gelo, Yeti, Diabrete, Cão Infernal (+ 3 minions). **54 monstros espalhados pela ilha** por região (nível pela região), longe das cidades e das estradas.
- **4 chefes regionais**: Rei Escorpião (Dunas), Senhor do Brejo (Pântano), Yeti Ancestral (Montanha Glacial) e **Azrakhel, Lorde Demoníaco** (diante do Castelo Sombrio), cada um com fases, habilidades e itens próprios.
- **História em pt-BR**: missão principal "A Luz Vermelha" → 3 selos (chefes regionais) → Azrakhel → epílogo. **12 missões locais** entregues por moradores das cidades (Aurora, Pinheiral, Porto, Nevasca, Ferro, Pescador, Vigia). A prova do Rank SS agora é derrotar Azrakhel.
- **Lojas com estoques diferentes** por cidade (6 perfis).
- **4 grutas/criptas** (Gruta dos Escorpiões, Caverna Cristalina, Gruta do Brejo, Cripta Infernal) com monstros do bioma, baús e guardião; entradas geradas na ilha.
- **8 habilidades avançadas** (níveis 8 e 11), duas por classe.
- **Música composta por código** (melodia + baixo + acordes + percussão) com faixas por região e batalha/chefe/chefe final, gerada em segundo plano.
- Preset de exportação **Android** (arm64) adicionado; versão 0.4.0; tela de Créditos; testes de integridade de dados (inimigos, missões, grutas, lojas, áudio).
- (v0.3) Biomas deserto e pântano, árvores altas com copa sobre o jogador, água/lava animadas, ruínas com baú.

## Testes da v0.4 (executados neste ambiente)
- `test_logic`: **412 verificações, 0 falhas** (inclui ilha, monstros/chefes, grutas, lojas, missões/história, áudio).
- `ui_flow`: **54 verificações, 0 falhas** (novo jogo, menus, viagem pela ilha, NPCs que entregam missão, loja por cidade, gruta, batalhas por bot, chefe, save/load, toque, 5 resoluções). Rodado várias vezes seguidas sem falhas após corrigir uma condição de corrida entre batalha e interface.
- Capturas inspecionadas: título, batalha, ilha (floresta), gruta, folha de sprites dos heróis e dos monstros.
- **NÃO testado**: aparelho Android real (sem SDK aqui), desempenho em hardware real, gamepad físico, as 4 classes jogadas inteiras (o bot de UI usa o Mago; as demais são cobertas pela lógica), todos os chefes em combate real (só o Rei Slime foi lutado pelo bot; os novos chefes têm dados validados por teste, mas **não foram balanceados em partida**).

## Ainda NÃO feito / limites honestos
- Arte e música são **procedurais** (originais, mas sintetizadas por código): não são pixel art desenhada à mão nem trilhas gravadas. Para qualidade final de lançamento, vale trocar por assets próprios ou licenciados.
- O mapa continua em grade ASCII renderizada em blocos (não TileMapLayer); colisões e profundidade funcionam, mas editar no editor do Godot não é possível.
- O interior do Castelo Sombrio não existe (portões selados; Azrakhel é enfrentado do lado de fora). A cidade "Valthera" não foi criada, a pedido (o hub é Vila Aurora).
- Balanceamento dos novos chefes/monstros e das 8 novas habilidades **não foi jogado**; ajuste números em `enemy_db.gd`, `skill_db.gd`.
- APK Android: o preset existe, mas não foi exportado nem testado.
- Animações de ataque dos monstros inimigos são simples (tremor/avanço); só os heróis têm animação por quadros.

## Licenças
Todo o conteúdo (código, arte, música) é original gerado neste projeto. Motor: Godot 4.4.1 (MIT). Fonte padrão do tema do Godot (Open Sans, Apache 2.0).

## Como rodar
1. Instale o Godot 4.4.1 (padrão, sem .NET). 2. Abra a pasta do projeto (`project.godot`). 3. F5.
Teclado: setas/WASD mover · Z/Enter/Espaço/E confirmar · X/Esc cancelar · Tab/M/I menu · Shift correr. Gamepad e toque (controles virtuais em Opções → Toque) também funcionam.

## Testes
- Lógica (headless): `godot --headless --path . res://tests/test_logic.tscn` → 412 checagens.
- Fluxo de UI (precisa de display, ex. xvfb): `xvfb-run -a godot --path . --rendering-driver opengl3 --audio-driver Dummy res://tests/ui_flow.tscn` → 54 checagens + capturas em /tmp/shots.

## Exportar
`export_presets.cfg` tem Linux, Windows e Android (arm64). Instale os export templates 4.4.1 e use
`godot --headless --path . --export-release "Linux"` / `"Windows Desktop"` (saída em ../build).
Android: configure Android SDK + JDK + keystore em Editor Settings e exporte o preset "Android" (APK). Não testado neste ambiente.

## Ilha de Aurora (mapa-mundi) — novo na v0.2
Mapa único de **192 x 144 tiles** (3072 x 2304 px) que substitui a antiga vila pequena:
- **6 cidades** (cada uma com Pousada e Loja próprias): **Vila Aurora** (centro, Guilda e início do jogo), **Pinheiral** (floresta, oeste), **Porto Marisa** (porto com cais, sudoeste), **Nevasca** (neve, noroeste), **Pedralta** (serra, leste) e **Solmar** (praia, sudeste). Mais o **Acampamento Vigia** (cristal de descanso) antes do castelo.
- **10 florestas** nomeadas (Sussurrante, Pinhal Antigo, Mata Escura, Gélida, Bosque Carmesim, do Vale, das Brumas, do Sul, Verdejante, Nebuloso) com mais de 4.400 árvores, clareiras e trilhas. O nome da região aparece ao entrar nela.
- **Castelo Demoníaco** no canto nordeste, atrás de um fosso de lava com ponte. O portão está **selado** (interagir mostra uma mensagem) — o interior fica para uma versão futura.
- Rios com pontes, lagos, montanhas, neve com rochas de gelo, terras de cinzas e lava, 34 baús, 46 ervas, 11 cristais de descanso, placas e NPCs conversáveis.
- Menu → **Mapa** mostra a ilha inteira com a sua posição.
- A **Floresta de Treino** continua igual (entrada ao sul de Vila Aurora, a oeste da estrada de Solmar).

**Monstros da ilha:** ligados por padrão (`ILHA_MONSTERS` em `scripts/world/map_db.gd`); a tabela de quem aparece em cada região é `EnemyDB.REGION_POOLS`.

**Editar o mapa:** `scripts/world/ilha_data.gd` é GERADO por `python3 tools/gerar_ilha.py` (a partir da pasta do projeto; `--png` salva `tools/ilha_preview.png`). Para mudar cidades, florestas, lagos e rios edite as listas no topo do script e rode de novo. Letras do mapa: `.` grama, `s` areia, `n` neve, `k` cinzas, `P/Q/A` pinheiros, `M` montanha, `I` gelo, `w/~` água, `l` lava, `B` ponte, `p` estrada, `q` calçada.
Arte dos tiles: `scripts/core/island_art.gd` (bordas e transições automáticas). Teste visual: `godot --headless --path . res://tests/render_island.tscn` (salva PNGs em $OUT_DIR).

## Conteúdo
Menu (Novo Jogo/Continuar), 4 classes com 4 habilidades cada, ilha com 6 cidades (guilda, lojas, estalagens, NPCs), floresta de treino, Floresta Esquecida de 20 andares com chefes nos andares 5/10/15/20, baús, pontos de descanso, 9 inimigos comuns + 4 chefes, combate por turnos iniciado ao tocar o monstro no mapa (sem encontros aleatórios), status, fraquezas elementais, críticos, fuga, itens/equipamentos com raridade que alteram atributos, loja compra/venda, missões e ranks D→SS (reputação separada do nível), save/load validado com backup, opções de volume.
Subclasses e classes especiais: apenas arquitetura/dados (não jogáveis).

## Relatório de testes (honesto)
Passou (automatizado): 356 checagens de lógica (fórmulas, combate, recompensas sem duplicação, level up, equipamento, loja, missões, rank, masmorra/chefes, save/load e saves corrompidos); 36 checagens de UI (novo jogo, menu, loja, guilda, batalha por bot, monstro no mapa, floresta, andar 5 + chefe + escada + recompensa, save/continuar, toque, 4 resoluções + capturas inspecionadas).
Passou (manual por captura): título, seleção de classe, menus, loja, guilda, batalha, controles de toque.
Executável Linux exportado abriu e fechou sem erros de script (aviso de vazamento de objetos na saída, inofensivo).
**Não executado / limites do ambiente:** APK Android (sem Android SDK; download bloqueado); build Windows exportado mas não executado; teste em dispositivo/tela de toque real; as 4 classes foram jogadas via UI só como Mago (as outras 3 cobertas pela lógica headless); andares 10/15/20 testados por lógica/bot, não por captura; checagem de múltiplas resoluções só visual em 5 tamanhos.
## Limitações
Arte/áudio placeholder procedural; monstros do chefe final difíceis para Mago/Assassino com bot ingênuo; só 1 dungeon (as outras 5 do plano não existem); em telas ultralargas há barras laterais (aspect keep); nome do local sobrepõe o botão MENU no modo toque.
