class_name MapData
extends RefCounted
## Dados de um mapa: terreno (grade de caracteres) e entidades. Gerado por MapDB.

const BLOCKED := "TwWR#fcboSFdtgG~PQAMIvjzlUZKOXYCVEem=uy"
const WALKABLE_OBJ_TYPES := []

var id: String = ""
var display_name: String = ""
var kind: String = "town"      # town | forest | interior | dungeon | overworld
var w: int = 0
var h: int = 0
var rows: Array = []            # Array[String]
var portals: Array = []         # {x,y,to,tx,ty,dir,label}
var npcs: Array = []            # {id,name,x,y,dir,look,role}
var monsters: Array = []        # {id,x,y,group[{enemy,level}],boss}
var objects: Array = []         # {id,type,x,y,...}
var areas: Array = []           # {id,x,y,w,h,name}
var start: Vector2i = Vector2i.ZERO
var tint: Color = Color(1, 1, 1)
var music: String = "town"
var floor_n: int = 0
var bg_kind: String = "field"   # fundo da batalha
var up_spawn: Vector2i = Vector2i.ZERO     # celula de chegada ao descer (ao lado de "<")
var down_spawn: Vector2i = Vector2i.ZERO   # celula de chegada ao subir (ao lado de ">")
var seal_pos: Vector2i = Vector2i(-1, -1)  # escada selada (andares de chefe)
var regions: Array = []         # {id,name,tier,forest,bg} (so no mapa-mundi)
var region_rows: Array = []     # Array[String]: uma letra por celula = indice em regions
var region_chars: String = ""

func tile_at(x: int, y: int) -> String:
	if x < 0 or y < 0 or x >= w or y >= h:
		return "T"
	return rows[y][x]

func set_tile(x: int, y: int, ch: String) -> void:
	if x < 0 or y < 0 or x >= w or y >= h:
		return
	rows[y] = rows[y].substr(0, x) + ch + rows[y].substr(x + 1)

func tile_blocked(x: int, y: int) -> bool:
	return BLOCKED.contains(tile_at(x, y))

func object_at(x: int, y: int) -> Dictionary:
	for o in objects:
		if o["x"] == x and o["y"] == y:
			return o
	return {}

func npc_at(x: int, y: int) -> Dictionary:
	for n in npcs:
		if n["x"] == x and n["y"] == y:
			return n
	return {}

func portal_at(x: int, y: int) -> Dictionary:
	for p in portals:
		if p["x"] == x and p["y"] == y:
			return p
	return {}

## Celula livre para andar (terreno + objetos + NPCs; ignora monstros).
func cell_free(x: int, y: int) -> bool:
	if tile_blocked(x, y):
		return false
	if not object_at(x, y).is_empty() or not npc_at(x, y).is_empty():
		return false
	return true

func area_at(x: int, y: int) -> Dictionary:
	for a in areas:
		if x >= a["x"] and x < a["x"] + a["w"] and y >= a["y"] and y < a["y"] + a["h"]:
			return a
	return region_at(x, y)

## Regiao nomeada (floresta, cidade, terras sombrias...) de uma celula do mapa-mundi.
func region_at(x: int, y: int) -> Dictionary:
	if region_rows.is_empty() or x < 0 or y < 0 or x >= w or y >= h:
		return {}
	var c: String = region_rows[y][x]
	var i := region_chars.find(c)
	if c == "." or i < 0 or i >= regions.size():
		return {}
	return regions[i]

## BFS de celulas alcancaveis a partir de "from" (portais contam como andaveis).
func reachable(from: Vector2i) -> Dictionary:
	var seen := {from: true}
	var q: Array = [from]
	var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	while q.size() > 0:
		var c: Vector2i = q.pop_front()
		for d in dirs:
			var n: Vector2i = c + d
			if seen.has(n):
				continue
			if not cell_free(n.x, n.y):
				continue
			seen[n] = true
			q.append(n)
	return seen
