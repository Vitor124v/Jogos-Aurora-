class_name MapDB
extends RefCounted
## Gera os mapas (cidade, interiores, floresta e os 20 andares da masmorra) por codigo.
## Layouts sao deterministicos (semente fixa por andar) para que ids de baus/monstros sejam estaveis.

const HUB := "ilha"                      # mapa-mundi (Ilha de Aurora)
const TOWN_START := IlhaData.START       # inicio do jogo: praca de Vila Aurora
const TOWN_RESPAWN := IlhaData.RESPAWN   # volta aqui ao perder uma batalha
const DUNGEON_ID := "floresta_esquecida"
## Liga/desliga os monstros e chefes espalhados pela ilha.
static var _cave_info: Dictionary = {}     # id -> {x, y, ret}
const ILHA_MONSTERS := true

# ----------------------------------------------------------------- utilitarios
static func _grid(w: int, h: int, ch: String) -> Array:
	var g: Array = []
	for y in range(h):
		var row: Array = []
		for x in range(w):
			row.append(ch)
		g.append(row)
	return g

static func _rows(g: Array) -> Array:
	var out: Array = []
	for row in g:
		out.append("".join(row))
	return out

static func _fill(g: Array, x: int, y: int, w: int, h: int, ch: String) -> void:
	for yy in range(y, y + h):
		for xx in range(x, x + w):
			if yy >= 0 and yy < g.size() and xx >= 0 and xx < g[0].size():
				g[yy][xx] = ch

static func _hash(x: int, y: int, salt: int) -> int:
	return absi((x * 73856093) ^ (y * 19349663) ^ (salt * 83492791)) % 100

## Casa 4 de altura: 2 linhas de telhado, 2 de parede; porta na ultima linha.
static func _house(g: Array, x: int, y: int, w: int, door_dx: int) -> Vector2i:
	_fill(g, x, y, w, 2, "R")
	_fill(g, x, y + 2, w, 2, "W")
	g[y + 3][x + door_dx] = "D"
	return Vector2i(x + door_dx, y + 3)

static func get_map(id: String) -> MapData:
	if CaveDB.exists(id):
		return _build_cave(id)
	if id.begins_with("dg_"):
		return build_floor(int(id.substr(3)))
	if id == HUB or id == "town":      # "town" = nome antigo (saves antigos)
		return _build_ilha()
	if id == "forest":
		return _build_forest()
	if IlhaData.INTERIORS.has(id):
		return _build_interior(id)
	return null

static func all_map_ids() -> Array:
	var out: Array = [HUB, "forest"]
	for k in IlhaData.INTERIORS:
		out.append(k)
	for f in range(1, Balance.DUNGEON_FLOORS + 1):
		out.append("dg_%d" % f)
	return out

# ----------------------------------------------------------------- ilha (mapa-mundi)
static func _build_ilha() -> MapData:
	var m := MapData.new()
	m.id = HUB
	m.display_name = "Ilha de Aurora"
	m.kind = "overworld"
	m.w = IlhaData.W
	m.h = IlhaData.H
	m.music = "town"
	m.bg_kind = "field"
	m.rows = IlhaData.ROWS.duplicate()
	m.region_rows = IlhaData.REGION_ROWS
	m.region_chars = IlhaData.REGION_CHARS
	m.regions = IlhaData.REGIONS
	m.portals = IlhaData.PORTALS.duplicate(true)
	m.npcs = IlhaData.NPCS.duplicate(true)
	m.objects = IlhaData.OBJECTS.duplicate(true)
	m.start = IlhaData.START
	if ILHA_MONSTERS:
		_spawn_island_monsters(m)
	return m

## Monstros da ilha: pools por regiao (EnemyDB.REGION_POOLS), longe das cidades e das estradas,
## mais os chefes regionais e o Lorde Demoníaco diante do castelo.
static func _reach(m: MapData, start: Vector2i) -> Dictionary:
	var seen := {start: true}
	var q: Array = [start]
	var qi := 0
	while qi < q.size():
		var c: Vector2i = q[qi]
		qi += 1
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var n: Vector2i = c + d
			if seen.has(n) or not m.cell_free(n.x, n.y):
				continue
			seen[n] = true
			q.append(n)
	return seen

static func _near_free(cands: Dictionary, target: Vector2i) -> Vector2i:
	var best := Vector2i(-1, -1)
	var bd := 1.0e9
	for c in cands:
		var d := float((c.x - target.x) * (c.x - target.x) + (c.y - target.y) * (c.y - target.y))
		if d < bd:
			bd = d
			best = c
	return best

static func _spawn_island_monsters(m: MapData) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 777
	var reach := _reach(m, m.start)
	var by_region := {}
	var ok_cells := {}
	for c in reach:
		var ch: String = m.tile_at(c.x, c.y)
		if "pqB".contains(ch) or not m.portal_at(c.x, c.y).is_empty():
			continue
		if abs(c.x - m.start.x) + abs(c.y - m.start.y) < 20:
			continue
		var near_city := false
		for ct in IlhaData.CITIES:
			var lim := 7 if String(ct["id"]) == "castelo" else 16
			if abs(c.x - int(ct["x"])) + abs(c.y - int(ct["y"])) < lim and abs(c.x - int(ct["plaza_x"])) + abs(c.y - int(ct["plaza_y"])) < lim + 6:
				near_city = true
				break
		if near_city:
			continue
		var rid := String(m.region_at(c.x, c.y).get("id", ""))
		if EnemyDB.pool_for_region(rid).is_empty():
			continue
		ok_cells[c] = rid
		if not by_region.has(rid):
			by_region[rid] = []
		by_region[rid].append(c)
	_place_caves(m, by_region, rng)
	var placed: Array = []
	var idx := 0
	var ids: Array = by_region.keys()
	ids.sort()
	for rid in ids:
		var cells: Array = by_region[rid]
		var want := clampi(cells.size() / 70, 2, 40)
		var info: Dictionary = {}
		for r in IlhaData.REGIONS:
			if r["id"] == rid:
				info = r
		var tier := int(info.get("tier", 2))
		var lvl := clampi(int(round(1.0 + float(tier - 1) * 1.6)), 1, 9)
		var pool := EnemyDB.pool_for_region(rid)
		var tries := 0
		var n := 0
		while n < want and tries < want * 40:
			tries += 1
			var c: Vector2i = cells[rng.randi() % cells.size()]
			var far := true
			for pc in placed:
				if abs(pc.x - c.x) + abs(pc.y - c.y) < 5:
					far = false
					break
			if not far:
				continue
			var grp: Array = [{"enemy": pool[rng.randi() % pool.size()], "level": lvl}]
			if tier >= 4 and rng.randf() < 0.25:
				grp.append({"enemy": pool[rng.randi() % pool.size()], "level": lvl})
			m.monsters.append({"id": "il_m%d" % idx, "x": c.x, "y": c.y, "boss": false, "bg": String(info.get("bg", "forest")), "group": grp})
			placed.append(c)
			idx += 1
			n += 1
	# chefes regionais
	var spots := {
		"boss_scorpion_king": [["dunas"], Vector2i(96, 134)],
		"boss_toad_king": [["pantano"], Vector2i(62, 101)],
		"boss_yeti_king": [["geladas", "gelida"], Vector2i(25, 47)],
		"boss_demon_lord": [["castelo", "sombrias"], Vector2i(IlhaData.CASTLE_GATE.x, IlhaData.CASTLE_GATE.y + 6)],
	}
	for bid in EnemyDB.OVERWORLD_BOSSES:
		if Game.boss_defeated(bid):
			continue
		var sp: Array = spots[bid]
		var target: Vector2i = sp[1]
		var avail := {}
		for c in reach:
			if "pqB".contains(m.tile_at(c.x, c.y)) or not m.portal_at(c.x, c.y).is_empty():
				continue
			if abs(c.x - target.x) + abs(c.y - target.y) > 14:
				continue
			avail[c] = true
		var pos := _near_free(avail, target)
		if pos.x < 0:
			continue
		var reg := m.region_at(pos.x, pos.y)
		m.monsters.append({"id": bid, "x": pos.x, "y": pos.y, "boss": true, "bg": "dungeon" if bid == "boss_demon_lord" else String(reg.get("bg", "field")),
			"group": [{"enemy": bid, "level": int(EnemyDB.get_enemy(bid)["level"])}]})

## Coloca a entrada de cada gruta (tile "h" + portal) numa celula alcancavel da regiao.
static func _place_caves(m: MapData, by_region: Dictionary, rng: RandomNumberGenerator) -> void:
	_cave_info.clear()
	var order: Array = CaveDB.ids()
	order.sort()
	for cid in order:
		var info: Dictionary = CaveDB.CAVES[cid]
		var cells: Array = []
		for rid in info["regions"]:
			cells.append_array(by_region.get(rid, []))
		if cells.is_empty():
			continue
		var pos := Vector2i(-1, -1)
		var ret := Vector2i(-1, -1)
		for k in range(200):
			var c: Vector2i = cells[rng.randi() % cells.size()]
			var below := c + Vector2i(0, 1)
			if not m.cell_free(below.x, below.y) or "pqB".contains(m.tile_at(below.x, below.y)):
				continue
			if not m.portal_at(c.x, c.y).is_empty() or not m.portal_at(below.x, below.y).is_empty():
				continue
			var near_other := false
			for oid in _cave_info:
				var o: Dictionary = _cave_info[oid]
				if abs(o["x"] - c.x) + abs(o["y"] - c.y) < 12:
					near_other = true
			if near_other:
				continue
			pos = c
			ret = below
			break
		if pos.x < 0:
			continue
		var row: String = m.rows[pos.y]
		m.rows[pos.y] = row.substr(0, pos.x) + "h" + row.substr(pos.x + 1)
		m.portals.append({"x": pos.x, "y": pos.y, "to": cid, "tx": 0, "ty": 0, "dir": "up", "arrive": "up", "label": String(info["name"])})
		_cave_info[cid] = {"x": pos.x, "y": pos.y, "ret": ret}

static func cave_entrance(cid: String) -> Dictionary:
	if _cave_info.is_empty():
		_build_ilha()
	return _cave_info.get(cid, {})

static func _build_cave(id: String) -> MapData:
	var info: Dictionary = CaveDB.CAVES[id]
	var ent := cave_entrance(id)
	var f: int = int(info["look"])
	var m := MapData.new()
	m.id = id
	m.display_name = String(info["name"])
	m.kind = "dungeon"
	m.floor_n = f
	m.w = 44
	m.h = 28
	m.music = "dungeon"
	m.bg_kind = "dungeon"
	m.tint = info["tint"]
	var seed_n := 4242
	for ch in id:
		seed_n = (seed_n * 31 + ch.unicode_at(0)) % 1000003
	var rng := RandomNumberGenerator.new()
	rng.seed = seed_n
	var g := _grid(m.w, m.h, "#")
	var rooms: Array = []
	var tries := 0
	while rooms.size() < 8 and tries < 500:
		tries += 1
		var rw := rng.randi_range(5, 9)
		var rh := rng.randi_range(4, 6)
		var r := Rect2i(rng.randi_range(1, m.w - rw - 2), rng.randi_range(1, m.h - rh - 2), rw, rh)
		var ok := true
		for o in rooms:
			if r.grow(2).intersects(o):
				ok = false
				break
		if ok:
			rooms.append(r)
	rooms.sort_custom(func(a, b): return a.position.x < b.position.x)
	for r in rooms:
		_fill(g, r.position.x, r.position.y, r.size.x, r.size.y, ":")
	for i in range(rooms.size() - 1):
		_carve(g, _center(rooms[i]), _center(rooms[i + 1]), i % 2 == 0)
	if rooms.size() > 4:
		_carve(g, _center(rooms[0]), _center(rooms[3]), true)
		_carve(g, _center(rooms[2]), _center(rooms[5]), false)
	var r0: Rect2i = rooms[0]
	var last: Rect2i = rooms[rooms.size() - 1]
	var up := Vector2i(r0.position.x + 1, r0.position.y + 1)
	g[up.y][up.x] = "<"
	m.up_spawn = Vector2i(up.x + 1, up.y)
	m.rows = _rows(g)
	m.start = m.up_spawn
	var ret: Vector2i = ent.get("ret", TOWN_RESPAWN)
	m.portals.append({"x": up.x, "y": up.y, "to": HUB, "tx": ret.x, "ty": ret.y, "dir": "down", "label": "Sair da gruta"})
	m.objects.append({"id": "rest_%s" % id, "type": "rest", "x": r0.position.x + 3, "y": r0.position.y + 1})
	# baus (os dois ultimos andares de sala guardam o melhor tesouro)
	var cf: int = int(info["chest_floor"])
	for i in range(1, rooms.size()):
		if i % 2 == 0 and i != rooms.size() - 1:
			continue
		var rr: Rect2i = rooms[i]
		var is_final := i == rooms.size() - 1
		m.objects.append({"id": "%s_bau%d" % [id, i], "type": "chest", "x": rr.position.x + rr.size.x - 1, "y": rr.position.y + rr.size.y - 1, "floor": cf + (3 if is_final else 0)})
	var reach := m.reachable(m.start)
	var kept: Array = []
	for o in m.objects:
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			if reach.has(Vector2i(o["x"], o["y"]) + d):
				kept.append(o)
				break
	m.objects = kept
	# monstros
	var pool: Array = info["pool"]
	var lvl: int = int(info["level"])
	var mi := 0
	for ri in range(1, rooms.size()):
		var room: Rect2i = rooms[ri]
		var count := rng.randi_range(1, 2) + (1 if ri == rooms.size() - 1 else 0)
		for k in range(count):
			var pos := Vector2i(rng.randi_range(room.position.x + 1, room.position.x + room.size.x - 2), rng.randi_range(room.position.y + 1, room.position.y + room.size.y - 2))
			if not reach.has(pos) or not m.cell_free(pos.x, pos.y) or pos.distance_to(Vector2(m.start)) < 6.0:
				continue
			var taken := false
			for mo in m.monsters:
				if mo["x"] == pos.x and mo["y"] == pos.y:
					taken = true
			for o in m.objects:
				if o["x"] == pos.x and o["y"] == pos.y:
					taken = true
			if taken:
				continue
			var guard := ri == rooms.size() - 1
			var grp: Array = [{"enemy": pool[rng.randi() % pool.size()], "level": lvl + (1 if guard else 0)}]
			if guard or rng.randf() < 0.25:
				grp.append({"enemy": pool[rng.randi() % pool.size()], "level": lvl + (1 if guard else 0)})
			m.monsters.append({"id": "%s_m%d" % [id, mi], "x": pos.x, "y": pos.y, "boss": false, "group": grp})
			mi += 1
	return m

# ----------------------------------------------------------------- interiores
static func _build_interior(id: String) -> MapData:
	var info: Dictionary = IlhaData.INTERIORS[id]
	var kind: String = String(info["kind"])
	var m := MapData.new()
	m.id = id
	m.display_name = String(info["title"])
	m.kind = "interior"
	m.w = 11
	m.h = 8
	m.music = "town"
	m.bg_kind = "field"
	var g := _grid(m.w, m.h, "_")
	_fill(g, 0, 0, 11, 1, "W")
	_fill(g, 0, 1, 11, 1, "W")
	for x in [1, 2, 3, 7, 8, 9]:
		g[1][x] = "b"
	_fill(g, 0, 7, 11, 1, "W")
	for y in range(0, 8):
		g[y][0] = "W"
		g[y][10] = "W"
	g[7][5] = "D"
	_fill(g, 1, 3, 9, 1, "c")
	for y in [4, 5, 6]:
		g[y][5] = "r"
	m.rows = _rows(g)
	m.portals = [{"x": 5, "y": 7, "to": HUB, "tx": int(info["ret_x"]), "ty": int(info["ret_y"]), "dir": "down", "label": "Saída"}]
	m.start = Vector2i(5, 6)
	match kind:
		"guild":
			m.npcs = [
				{"id": "lia", "name": "Recepcionista Lia", "x": 5, "y": 2, "dir": "down", "look": "clerk", "role": "guild"},
				{"id": "ardan", "name": "Mestre Ardan", "x": 8, "y": 5, "dir": "left", "look": "master", "role": "guildmaster"},
			]
			m.objects = [{"id": "board", "type": "board", "x": 2, "y": 5}]
		"shop":
			m.npcs = [{"id": "shop_npc", "name": String(info["npc_name"]), "x": 5, "y": 2, "dir": "down", "look": "shopkeeper", "role": "shop"}]
		"inn":
			m.npcs = [{"id": "inn_npc", "name": String(info["npc_name"]), "x": 5, "y": 2, "dir": "down", "look": "innkeeper", "role": "inn", "place": String(info["place"])}]
	return m

# ----------------------------------------------------------------- floresta de treino
static func _build_forest() -> MapData:
	var m := MapData.new()
	m.id = "forest"
	m.display_name = "Floresta de Treino"
	m.kind = "forest"
	m.w = 40
	m.h = 26
	m.music = "forest"
	m.bg_kind = "forest"
	var g := _grid(m.w, m.h, ".")
	for y in range(m.h):
		for x in range(m.w):
			if _hash(x, y, 11) < 14:
				g[y][x] = ","
	# caminhos
	_fill(g, 0, 12, 21, 2, "p")
	_fill(g, 20, 4, 2, 10, "p")
	_fill(g, 21, 7, 12, 2, "p")
	# clareira (area de exploracao)
	_fill(g, 30, 3, 9, 7, ",")
	for y in range(3, 10):
		for x in range(30, 39):
			if _hash(x, y, 4) < 25:
				g[y][x] = "."
	_fill(g, 33, 6, 3, 2, "p")
	# mascara livre: nao colocar arvores perto dos caminhos
	var keep := {}
	for y in range(m.h):
		for x in range(m.w):
			if g[y][x] == "p":
				for dy in range(-1, 2):
					for dx in range(-1, 2):
						keep[Vector2i(x + dx, y + dy)] = true
	for y in range(3, 10):
		for x in range(29, 39):
			keep[Vector2i(x, y)] = true
	# lagoa
	_fill(g, 7, 17, 6, 4, "w")
	g[17][7] = ","
	g[20][12] = ","
	for x in range(m.w):
		for y in [0, 1, m.h - 1, m.h - 2]:
			g[y][x] = "T"
	for y in range(m.h):
		for x in [0, m.w - 1, m.w - 2]:
			g[y][x] = "T"
	for y in range(2, m.h - 2):
		for x in range(1, m.w - 2):
			if g[y][x] in [".", ","] and not keep.has(Vector2i(x, y)) and _hash(x, y, 5) < 15:
				g[y][x] = "T"
	# entrada para a gruta (portal)
	g[3][20] = "h"
	g[3][21] = "h"
	g[3][19] = "o"
	g[3][22] = "o"
	g[2][20] = "T"
	g[2][21] = "T"
	g[12][0] = "p"
	g[13][0] = "p"
	m.rows = _rows(g)
	m.portals = [
		{"x": 0, "y": 12, "to": HUB, "tx": IlhaData.TRAIN_PORTAL.x - 2, "ty": IlhaData.TRAIN_PORTAL.y, "dir": "left", "label": "Ilha de Aurora"},
		{"x": 0, "y": 13, "to": HUB, "tx": IlhaData.TRAIN_PORTAL.x - 2, "ty": IlhaData.TRAIN_PORTAL.y + 1, "dir": "left", "label": "Ilha de Aurora"},
		{"x": 20, "y": 3, "to": "dg_1", "arrive": "up", "dir": "down", "label": "Floresta Esquecida"},
		{"x": 21, "y": 3, "to": "dg_1", "arrive": "up", "dir": "down", "label": "Floresta Esquecida"},
	]
	m.objects = [
		{"id": "stone_forest", "type": "stone", "x": 19, "y": 5},
		{"id": "sign_forest", "type": "sign", "x": 22, "y": 5, "text": "Floresta Esquecida (20 andares)\nNível recomendado: 1–8\nChefes nos andares 5, 10, 15 e 20."},
		{"id": "sign_clearing", "type": "sign", "x": 32, "y": 8, "text": "Clareira Antiga\nRuínas de um antigo acampamento de caçadores."},
	]
	m.areas = [{"id": "clareira", "x": 31, "y": 4, "w": 7, "h": 5, "name": "Clareira Antiga"}]
	m.npcs = []
	m.start = Vector2i(1, 12)
	# ervas e monstros em celulas alcancaveis (sorteio deterministico)
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var reach := m.reachable(m.start)
	var cells: Array = []
	for c in reach:
		var t := m.tile_at(c.x, c.y)
		if (t == "." or t == ",") and c.distance_to(Vector2(m.start)) > 5.0 and c.y > 3:
			cells.append(c)
	cells.sort_custom(func(a, b): return a.x * 100 + a.y < b.x * 100 + b.y)
	_shuffle(cells, rng)
	var used: Array = []
	var idx := 0
	var herb_i := 0
	while herb_i < 7 and idx < cells.size():
		var c: Vector2i = cells[idx]
		idx += 1
		if _too_close(c, used, 4.0):
			continue
		used.append(c)
		m.objects.append({"id": "herb_%d" % herb_i, "type": "bush", "x": c.x, "y": c.y})
		herb_i += 1
	var mon_i := 0
	var kinds := ["slime", "slime", "morcego", "slime", "morcego", "slime", "slime", "morcego", "slime", "slime"]
	while mon_i < kinds.size() and idx < cells.size():
		var c2: Vector2i = cells[idx]
		idx += 1
		if _too_close(c2, used, 3.0):
			continue
		used.append(c2)
		var lv := 1 if mon_i % 3 != 2 else 2
		m.monsters.append({"id": "fm_%d" % mon_i, "x": c2.x, "y": c2.y, "boss": false, "group": [{"enemy": kinds[mon_i], "level": lv}]})
		mon_i += 1
	return m

static func _too_close(c: Vector2i, used: Array, dist: float) -> bool:
	for u in used:
		if Vector2(c).distance_to(Vector2(u)) < dist:
			return true
	return false

static func _shuffle(arr: Array, rng: RandomNumberGenerator) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var t = arr[i]
		arr[i] = arr[j]
		arr[j] = t

# ----------------------------------------------------------------- masmorra (20 andares)
static func has_rest_point(f: int) -> bool:
	return (f % 5) in [0, 1, 4]

static func build_floor(f: int) -> MapData:
	var m := MapData.new()
	m.id = "dg_%d" % f
	m.display_name = "Floresta Esquecida — Andar %d" % f
	m.kind = "dungeon"
	m.floor_n = f
	m.w = 38
	m.h = 24
	m.music = "boss" if f in Balance.BOSS_FLOORS else "dungeon"
	m.bg_kind = "dungeon"
	var tier := Balance.floor_tier(f)
	m.tint = [Color(0.86, 1.0, 0.86), Color(1.0, 0.93, 0.8), Color(0.88, 0.82, 1.0), Color(0.78, 0.92, 1.0)][tier]
	var rng := RandomNumberGenerator.new()
	rng.seed = 90210 + f * 7919
	var g := _grid(m.w, m.h, "#")
	var is_boss := f in Balance.BOSS_FLOORS
	var arena := Rect2i()
	var rooms: Array = []
	if is_boss:
		arena = Rect2i(24, 7, 11, 9)
	var wanted := 6 + (f % 3)
	var tries := 0
	while rooms.size() < wanted and tries < 400:
		tries += 1
		var rw := rng.randi_range(5, 9)
		var rh := rng.randi_range(4, 6)
		var rx := rng.randi_range(1, m.w - rw - 2)
		var ry := rng.randi_range(1, m.h - rh - 2)
		var r := Rect2i(rx, ry, rw, rh)
		var ok := true
		if is_boss and r.grow(2).intersects(arena.grow(1)):
			ok = false
		for o in rooms:
			if r.grow(2).intersects(o):
				ok = false
				break
		if ok:
			rooms.append(r)
	rooms.sort_custom(func(a, b): return a.position.x < b.position.x)
	if is_boss:
		rooms.append(arena)
	for i in range(rooms.size()):
		var r: Rect2i = rooms[i]
		_fill(g, r.position.x, r.position.y, r.size.x, r.size.y, "x" if (is_boss and i == rooms.size() - 1) else ":")
	for i in range(rooms.size() - 1):
		_carve(g, _center(rooms[i]), _center(rooms[i + 1]), false)
	if rooms.size() > 3:
		_carve(g, _center(rooms[0]), _center(rooms[2]), true)
	if rooms.size() > 5:
		_carve(g, _center(rooms[1]), _center(rooms[4]), true)
	var r0: Rect2i = rooms[0]
	var last: Rect2i = rooms[rooms.size() - 1]
	# escadas
	var up := Vector2i(r0.position.x + 1, r0.position.y + 1)
	g[up.y][up.x] = "<"
	m.up_spawn = Vector2i(up.x + 1, up.y)
	var down := Vector2i.ZERO
	if is_boss:
		# canto superior direito da arena (o corredor de entrada chega pelo centro)
		down = Vector2i(last.position.x + last.size.x - 1, last.position.y)
		m.down_spawn = Vector2i(down.x - 1, down.y)
		g[down.y][down.x] = ">" if Game.floor_boss_defeated(f) else "S"
		m.seal_pos = down
	else:
		down = Vector2i(last.position.x + last.size.x - 2, last.position.y + 1)
		m.down_spawn = Vector2i(down.x - 1, down.y)
		g[down.y][down.x] = ">"
	m.rows = _rows(g)
	m.start = m.up_spawn
	# portais de escada
	if f == 1:
		m.portals.append({"x": up.x, "y": up.y, "to": "forest", "tx": 20, "ty": 4, "dir": "down", "label": "Sair da masmorra"})
	else:
		m.portals.append({"x": up.x, "y": up.y, "to": "dg_%d" % (f - 1), "arrive": "down", "dir": "left", "label": "Subir"})
	if f < Balance.DUNGEON_FLOORS:
		m.portals.append({"x": down.x, "y": down.y, "to": "dg_%d" % (f + 1), "arrive": "up", "dir": "right", "label": "Descer"})
	else:
		m.portals.append({"x": down.x, "y": down.y, "to": HUB, "tx": TOWN_RESPAWN.x, "ty": TOWN_RESPAWN.y, "dir": "down", "label": "Saída final", "dungeon_exit": true})
	# ponto de descanso
	if has_rest_point(f):
		m.objects.append({"id": "rest_%d" % f, "type": "rest", "x": r0.position.x + 3, "y": r0.position.y + 1})
	# baus
	var chest_rooms: Array = []
	for i in range(1, rooms.size() - (1 if is_boss else 0)):
		chest_rooms.append(i)
	_shuffle(chest_rooms, rng)
	var n_chests := 1 + (1 if f % 2 == 0 else 0)
	for ci in range(mini(n_chests, chest_rooms.size())):
		var rr: Rect2i = rooms[chest_rooms[ci]]
		m.objects.append({"id": "f%d_c%d" % [f, ci], "type": "chest", "x": rr.position.x + rr.size.x - 1, "y": rr.position.y + rr.size.y - 1, "floor": f})
	if is_boss:
		m.objects.append({"id": "f%d_cb" % f, "type": "chest", "x": last.position.x + last.size.x - 1, "y": last.position.y + last.size.y - 1, "floor": f, "boss_chest": true})
	# garante que objetos nao bloqueiem o caminho
	var reach := m.reachable(m.start)
	var kept: Array = []
	for o in m.objects:
		var adj_ok := false
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			if reach.has(Vector2i(o["x"], o["y"]) + d):
				adj_ok = true
		if adj_ok:
			kept.append(o)
	m.objects = kept
	reach = m.reachable(m.start)
	# monstros comuns
	var pool := EnemyDB.pool_for_floor(f)
	var lvl := Balance.monster_level_for_floor(f)
	var mi := 0
	for ri in range(1, rooms.size() - (1 if is_boss else 0)):
		var room: Rect2i = rooms[ri]
		var count := rng.randi_range(1, 2) + (1 if f >= 10 and rng.randf() < 0.5 else 0)
		for k in range(count):
			var pos := Vector2i(rng.randi_range(room.position.x + 1, room.position.x + room.size.x - 2), rng.randi_range(room.position.y + 1, room.position.y + room.size.y - 2))
			if not reach.has(pos) or not m.cell_free(pos.x, pos.y) or pos.distance_to(Vector2(m.start)) < 6.0:
				continue
			var taken := false
			for mo in m.monsters:
				if mo["x"] == pos.x and mo["y"] == pos.y:
					taken = true
			if taken:
				continue
			var grp: Array = [{"enemy": pool[rng.randi() % pool.size()], "level": lvl}]
			if f >= 8 and rng.randf() < 0.25:
				grp.append({"enemy": pool[rng.randi() % pool.size()], "level": lvl})
			m.monsters.append({"id": "f%d_m%d" % [f, mi], "x": pos.x, "y": pos.y, "boss": false, "group": grp})
			mi += 1
	if is_boss:
		var bid: String = EnemyDB.BOSS_BY_FLOOR[f]
		if not Game.boss_defeated(bid):
			m.monsters.append({"id": bid, "x": last.position.x + last.size.x / 2, "y": last.position.y + last.size.y / 2, "boss": true, "group": [{"enemy": bid, "level": int(EnemyDB.get_enemy(bid)["level"])}]})
	return m

static func _center(r: Rect2i) -> Vector2i:
	return Vector2i(r.position.x + r.size.x / 2, r.position.y + r.size.y / 2)

static func _carve(g: Array, a: Vector2i, b: Vector2i, vertical_first: bool) -> void:
	var x := a.x
	var y := a.y
	if vertical_first:
		while y != b.y:
			_carve_cell(g, x, y)
			y += 1 if b.y > y else -1
		while x != b.x:
			_carve_cell(g, x, y)
			x += 1 if b.x > x else -1
	else:
		while x != b.x:
			_carve_cell(g, x, y)
			x += 1 if b.x > x else -1
		while y != b.y:
			_carve_cell(g, x, y)
			y += 1 if b.y > y else -1
	_carve_cell(g, x, y)

static func _carve_cell(g: Array, x: int, y: int) -> void:
	if g[y][x] == "#":
		g[y][x] = ":"
