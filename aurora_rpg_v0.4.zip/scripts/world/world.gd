class_name World
extends Node2D
## Mundo de exploracao: mapa em tiles, jogador, monstros visiveis, NPCs, objetos, portais e batalhas.

class Mob:
	var def: Dictionary
	var node: Node2D
	var spr: Sprite2D
	var grid: Vector2i
	var home: Vector2i
	var from_pos: Vector2
	var to_pos: Vector2
	var to_grid: Vector2i
	var t: float = 1.0
	var moving: bool = false
	var timer: float = 1.0
	var boss: bool = false
	var behavior: String = "wander"
	var immune_until: float = 0.0
	var radius: float = 12.0

const BOSS_CHESTS := {
	5: {"gold": 120, "items": {"amuleto_de_vida": 1, "pocao": 2}},
	10: {"gold": 250, "items": {"bracelete_da_sorte": 1, "pocao_grande": 2, "eter_grande": 1}},
	15: {"gold": 450, "items": {"colar_do_guardiao": 1, "elixir": 1}},
	20: {"gold": 900, "items": {"anel_do_rei": 1, "coroa_antiga": 1, "elixir": 2}},
}

var ui: UIRoot
var map: MapData
var active: bool = false
var busy: bool = false
var player: Node2D
var psprite: Sprite2D
var pframes: Dictionary = {}
var pgrid: Vector2i = Vector2i.ZERO
var pfacing: String = "down"
var pmoving: bool = false
var pfrom: Vector2 = Vector2.ZERO
var pto: Vector2 = Vector2.ZERO
var pto_grid: Vector2i = Vector2i.ZERO
var pt: float = 1.0
var step_parity: int = 0
var cam: Camera2D
var map_sprite: Node2D          # contem os blocos (Sprite2D) do mapa
var _cur_area: String = ""
var _anim_sprites: Array = []
var _anim_frame: int = 0
var _anim_clock: float = 0.0
var ents: Node2D
var canvas_mod: CanvasModulate
var backdrop: ColorRect
var mobs: Array = []
var obj_nodes: Dictionary = {}
var npc_nodes: Dictionary = {}
var hint: Sprite2D
var immunity_until: float = 0.0
var _timer_slow: float = 0.0
var _arrived_at: float = 0.0
var _last_confirm_frame: int = -1

func _ready() -> void:
	backdrop = ColorRect.new()
	backdrop.color = Color(0.03, 0.03, 0.06)
	backdrop.position = Vector2(-2000, -2000)
	backdrop.size = Vector2(5000, 5000)
	backdrop.z_index = -10
	add_child(backdrop)
	map_sprite = Node2D.new()
	add_child(map_sprite)
	ents = Node2D.new()
	ents.y_sort_enabled = true
	add_child(ents)
	player = Node2D.new()
	psprite = Sprite2D.new()
	psprite.centered = false
	psprite.offset = Vector2(0, -24)
	psprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	player.add_child(psprite)
	hint = Sprite2D.new()
	hint.texture = PixelArt.object_texture("exclaim")
	hint.centered = false
	hint.position = Vector2(4, -34)
	hint.visible = false
	hint.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	player.add_child(hint)
	cam = Camera2D.new()
	cam.zoom = Vector2(2, 2)
	cam.position = Vector2(8, -8)
	cam.position_smoothing_enabled = false
	player.add_child(cam)
	ents.add_child(player)
	canvas_mod = CanvasModulate.new()
	add_child(canvas_mod)
	Controls.confirm_pressed.connect(_on_confirm)
	Controls.menu_pressed.connect(_on_menu)
	Controls.cancel_pressed.connect(_on_cancel)
	set_process(false)
	set_physics_process(false)

func set_active(on: bool) -> void:
	active = on
	visible = on
	set_physics_process(on)
	cam.enabled = on
	if on:
		cam.make_current()

static func now() -> float:
	return float(Time.get_ticks_msec()) / 1000.0

func cell_pos(c: Vector2i) -> Vector2:
	return Vector2(c.x * 16, c.y * 16 + 16)

# ================================================================= carregar mapa
func start_from_save() -> void:
	var w: Dictionary = Game.s["world"]
	await go_to_map(String(w["map"]), Vector2i(int(w["x"]), int(w["y"])), "down", "", true)

func go_to_map(map_id: String, spawn: Vector2i, face: String = "down", arrive: String = "", instant: bool = false) -> void:
	busy = true
	if not instant:
		await ui.fade(1.0, 0.22)
	_load_map(map_id, spawn, face, arrive)
	await ui.fade(0.0, 0.22)
	busy = false

func _load_map(map_id: String, spawn: Vector2i, face: String, arrive: String) -> void:
	var m := MapDB.get_map(map_id)
	if m == null:
		m = MapDB.get_map("ilha")
		spawn = m.start
	map = m
	for c in ents.get_children():
		if c != player:
			c.queue_free()
	mobs.clear()
	obj_nodes.clear()
	npc_nodes.clear()
	_set_map_texture()
	_cur_area = ""
	canvas_mod.color = map.tint
	var sp := spawn
	if arrive == "up":
		sp = map.up_spawn
	elif arrive == "down":
		sp = map.down_spawn
	if not map.cell_free(sp.x, sp.y) or not map.npc_at(sp.x, sp.y).is_empty():
		sp = map.start
	pgrid = sp
	pto_grid = sp
	pmoving = false
	pt = 1.0
	pfacing = face
	player.position = cell_pos(pgrid)
	var look := PixelArt.look_for(String(HeroDB.get_class_data(String(Game.s["class_id"]))["look"]))
	pframes = PixelArt.char_frames(look)
	_set_player_frame(0)
	_build_entities()
	_apply_camera_limits()
	if map.kind == "dungeon":
		Game.enter_floor(map.floor_n)
	_save_position()
	Audio.play_music(_area_music())
	ui.hud.set_location(map.display_name)
	ui.hud.show_banner(map.display_name)
	immunity_until = now() + 1.0
	_on_arrive(true)

## Desenha o mapa em blocos de 1024x1024 (mapas grandes nao cabem numa textura so em celulares).
## Blocos com agua/lava tem 2 quadros; as copas das arvores ficam numa camada acima do jogador.
func _set_map_texture() -> void:
	for c in map_sprite.get_children():
		c.queue_free()
	_anim_sprites.clear()
	_anim_frame = 0
	for ch in PixelArt.map_chunks(map):
		var sp := Sprite2D.new()
		sp.centered = false
		sp.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sp.texture = ch["tex"]
		sp.position = ch["pos"]
		map_sprite.add_child(sp)
		if ch.has("tex2"):
			_anim_sprites.append({"sp": sp, "t1": ch["tex"], "t2": ch["tex2"]})
	for ch in PixelArt.map_overlay_chunks(map):
		var op := Sprite2D.new()
		op.centered = false
		op.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		op.texture = ch["tex"]
		op.position = ch["pos"]
		op.z_index = 10
		map_sprite.add_child(op)

## Alterna os quadros da agua e da lava (a cada ~0,6 s).
func _animate_tiles(delta: float) -> void:
	_anim_clock += delta
	var f := int(_anim_clock / 0.6) % 2
	if f == _anim_frame:
		return
	_anim_frame = f
	for e in _anim_sprites:
		e["sp"].texture = e["t2"] if f == 1 else e["t1"]

func _apply_camera_limits() -> void:
	var vw := 320.0
	var vh := 180.0
	var mw := float(map.w * 16)
	var mh := float(map.h * 16)
	var ex := maxf(0.0, (vw - mw) / 2.0)
	var ey := maxf(0.0, (vh - mh) / 2.0)
	cam.limit_left = int(-ex)
	cam.limit_top = int(-ey)
	cam.limit_right = int(mw + ex)
	cam.limit_bottom = int(mh + ey)

func _build_entities() -> void:
	# NPCs
	for n in map.npcs:
		var node := Node2D.new()
		var s := Sprite2D.new()
		s.centered = false
		s.offset = Vector2(0, -24)
		s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		var fr := PixelArt.char_frames(PixelArt.look_for(String(n["look"])))
		s.texture = fr[n["dir"]][0]
		node.add_child(s)
		node.position = cell_pos(Vector2i(n["x"], n["y"]))
		ents.add_child(node)
		npc_nodes[n["id"]] = {"node": node, "spr": s, "frames": fr, "def": n}
	# objetos
	for o in map.objects:
		var node2 := Node2D.new()
		var s2 := Sprite2D.new()
		s2.centered = false
		s2.offset = Vector2(0, -16)
		s2.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		node2.add_child(s2)
		node2.position = cell_pos(Vector2i(o["x"], o["y"]))
		ents.add_child(node2)
		obj_nodes[o["id"]] = {"node": node2, "spr": s2, "def": o}
		_refresh_object(o["id"])
	# monstros
	for d in map.monsters:
		_spawn_mob(d)

func _refresh_object(id: String) -> void:
	var e: Dictionary = obj_nodes[id]
	var o: Dictionary = e["def"]
	var spr: Sprite2D = e["spr"]
	match String(o["type"]):
		"chest":
			spr.texture = PixelArt.object_texture("chest", "open" if Game.s["opened"].has(id) else "")
		"bush":
			var t: float = float(Game.s["gathered"].get(id, -99999.0))
			var empty: bool = float(Game.s["play_time"]) - t < Balance.BUSH_RESPAWN_SECONDS
			spr.texture = PixelArt.object_texture("bush", "empty" if empty else "")
		_:
			spr.texture = PixelArt.object_texture(String(o["type"]))

func _spawn_mob(d: Dictionary) -> void:
	var boss: bool = d.get("boss", false)
	if boss and Game.boss_defeated(String(d["id"])):
		return
	if not boss and Game.is_defeated(map.id, String(d["id"])):
		return
	for m in mobs:
		if m.def["id"] == d["id"]:
			return
	var mob := Mob.new()
	mob.def = d
	mob.boss = boss
	mob.grid = Vector2i(d["x"], d["y"])
	mob.home = mob.grid
	var first_enemy: String = String(d["group"][0]["enemy"])
	var ed := EnemyDB.get_enemy(first_enemy)
	mob.behavior = "static" if boss else String(ed.get("behavior", "wander"))
	var px := 48 if boss else 24
	var node := Node2D.new()
	var s := Sprite2D.new()
	s.centered = false
	s.texture = PixelArt.enemy_texture(String(ed["sprite"]), ed["color"], px)
	s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	s.offset = Vector2(-(px - 16) / 2.0, -float(px) + (4.0 if not boss else 6.0))
	node.add_child(s)
	node.position = cell_pos(mob.grid)
	ents.add_child(node)
	mob.node = node
	mob.spr = s
	mob.radius = 18.0 if boss else 12.0
	mob.timer = randf_range(0.4, 1.4)
	mobs.append(mob)
	if not boss:
		var tw := s.create_tween().set_loops()
		tw.tween_property(s, "offset:y", s.offset.y - 1.0, 0.45)
		tw.tween_property(s, "offset:y", s.offset.y, 0.45)

func _save_position() -> void:
	Game.s["world"] = {"map": map.id, "x": pgrid.x, "y": pgrid.y}

# ================================================================= loop
func _physics_process(delta: float) -> void:
	if not active or map == null:
		return
	_animate_tiles(delta)
	Game.active_play = not busy
	if busy:
		return
	_update_player(delta)
	_update_mobs(delta)
	_timer_slow += delta
	if _timer_slow > 4.0:
		_timer_slow = 0.0
		_periodic()
	if not busy and now() > immunity_until:
		for m in mobs:
			if now() < m.immune_until:
				continue
			if player.position.distance_to(m.node.position) < m.radius:
				call_deferred("_encounter", m)
				break

func _update_player(delta: float) -> void:
	if Game.ui_lock > 0:
		if not pmoving:
			return
	if pmoving:
		var st := Balance.STEP_SECONDS * (0.7 if Controls.is_running() else 1.0)
		pt += delta / st
		if pt >= 1.0:
			pt = 1.0
			pmoving = false
			pgrid = pto_grid
			player.position = pto
			_set_player_frame(0)
			step_parity += 1
			_save_position()
			_on_arrive(false)
			# encadeia o proximo passo sem pausa
			if not busy and Game.ui_lock == 0:
				_try_walk(Controls.get_dir())
		else:
			player.position = pfrom.lerp(pto, pt)
			_set_player_frame(1 + (step_parity % 2) if pt < 0.5 else 0)
		return
	_try_walk(Controls.get_dir())

func _try_walk(d: Vector2i) -> void:
	if d == Vector2i.ZERO or pmoving or busy:
		return
	if d.x > 0:
		pfacing = "right"
	elif d.x < 0:
		pfacing = "left"
	elif d.y > 0:
		pfacing = "down"
	else:
		pfacing = "up"
	_set_player_frame(0)
	var target := pgrid + d
	if not map.cell_free(target.x, target.y):
		_update_hint()
		return
	pmoving = true
	pt = 0.0
	pfrom = cell_pos(pgrid)
	pto = cell_pos(target)
	pto_grid = target
	hint.visible = false

func _set_player_frame(i: int) -> void:
	psprite.texture = pframes[pfacing][i]

func _on_arrive(first: bool) -> void:
	var a := map.area_at(pgrid.x, pgrid.y)
	if not a.is_empty():
		var was_new: bool = not Game.s["explored"].has(a["id"])
		Game.visit_area(String(a["id"]))
		if was_new:
			Game.say("Área explorada: %s" % a["name"], UIKit.C_GOLD)
			Audio.sfx("confirm")
		if map.kind == "overworld" and String(a["id"]) != _cur_area:
			_cur_area = String(a["id"])
			ui.hud.set_location(String(a["name"]))
			ui.hud.show_banner(String(a["name"]))
			Audio.play_music(_area_music())
	_update_hint()
	var p := map.portal_at(pgrid.x, pgrid.y)
	if not p.is_empty() and not first:
		call_deferred("_use_portal", p)

## Musica da regiao atual (ilha) ou da propria mapa (interiores e masmorras).
func _area_music() -> String:
	if map.kind == "overworld":
		return Audio.music_for_region(String(map.region_at(pgrid.x, pgrid.y).get("id", "")))
	return map.music

func _use_portal(p: Dictionary) -> void:
	if busy:
		return
	var to: String = String(p["to"])
	if to.begins_with("dg_") and map.kind == "dungeon":
		var target_floor := int(to.substr(3))
		if target_floor > map.floor_n and not Game.can_descend_from(map.floor_n):
			Game.say("A passagem está selada. Derrote o chefe!", UIKit.C_BAD)
			return
	if p.get("dungeon_exit", false) and Game.s["dungeon"]["completed"]:
		busy = true
		await ui.dialog.say("", ["Você derrotou o Guardião Ancião e completou a Floresta Esquecida!", "A luz da superfície o recebe. Parabéns, herói!"])
		busy = false
	Audio.sfx("stairs")
	var arrive := String(p.get("arrive", ""))
	var spawn := Vector2i(int(p.get("tx", 0)), int(p.get("ty", 0)))
	await go_to_map(to, spawn, String(p.get("dir", "down")), arrive)

func _periodic() -> void:
	# respawn de monstros comuns (por tempo de jogo) e de ervas
	for d in map.monsters:
		if d.get("boss", false):
			continue
		var present := false
		for m in mobs:
			if m.def["id"] == d["id"]:
				present = true
		if present or Game.is_defeated(map.id, String(d["id"])):
			continue
		var gp := Vector2i(d["x"], d["y"])
		if abs(gp.x - pgrid.x) + abs(gp.y - pgrid.y) > 6:
			_spawn_mob(d)
	for id in obj_nodes:
		if obj_nodes[id]["def"]["type"] == "bush":
			_refresh_object(id)

# ================================================================= monstros
func _update_mobs(delta: float) -> void:
	for m in mobs:
		if m.boss:
			continue
		if m.moving:
			var stime: float = 0.7 if m.behavior == "slow" else (0.32 if m.behavior == "chase" else 0.46)
			m.t += delta / stime
			if m.t >= 1.0:
				m.t = 1.0
				m.moving = false
				m.grid = m.to_grid
				m.node.position = m.to_pos
			else:
				m.node.position = m.from_pos.lerp(m.to_pos, m.t)
			continue
		m.timer -= delta
		if m.timer > 0.0:
			continue
		m.timer = randf_range(Balance.MONSTER_STEP_MIN, Balance.MONSTER_STEP_MAX) * (1.6 if m.behavior == "slow" else 1.0)
		var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
		var choice := Vector2i.ZERO
		var dist: int = abs(pgrid.x - m.grid.x) + abs(pgrid.y - m.grid.y)
		if m.behavior == "chase" and dist <= Balance.CHASE_RANGE and now() >= m.immune_until and now() > immunity_until:
			var dx: int = pgrid.x - m.grid.x
			var dy: int = pgrid.y - m.grid.y
			var opts: Array = []
			if abs(dx) >= abs(dy):
				opts = [Vector2i(signi(dx), 0), Vector2i(0, signi(dy))]
			else:
				opts = [Vector2i(0, signi(dy)), Vector2i(signi(dx), 0)]
			for o in opts:
				if o != Vector2i.ZERO and _mob_can_step(m, m.grid + o, false):
					choice = o
					break
			m.timer = 0.12
		else:
			dirs.shuffle()
			for dv in dirs:
				if _mob_can_step(m, m.grid + dv, true):
					choice = dv
					break
		if choice != Vector2i.ZERO:
			m.moving = true
			m.t = 0.0
			m.from_pos = m.node.position
			m.to_grid = m.grid + choice
			m.to_pos = cell_pos(m.to_grid)
			if choice.x != 0:
				m.spr.flip_h = choice.x < 0

func _mob_can_step(m: Mob, c: Vector2i, limit_home: bool) -> bool:
	if not map.cell_free(c.x, c.y):
		return false
	if not map.portal_at(c.x, c.y).is_empty():
		return false
	if limit_home and (abs(c.x - m.home.x) > 3 or abs(c.y - m.home.y) > 3):
		return false
	for o in mobs:
		if o != m and (o.grid == c or (o.moving and o.to_grid == c)):
			return false
	return true

func _encounter(m: Mob) -> void:
	if busy or not mobs.has(m) or Game.in_battle:
		return
	busy = true
	pmoving = false
	player.position = cell_pos(pgrid) if not pmoving else player.position
	Audio.sfx("encounter")
	var ex := Sprite2D.new()
	ex.texture = PixelArt.object_texture("exclaim")
	ex.position = Vector2(m.node.position.x + 4, m.node.position.y - 38)
	ex.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	ex.z_index = 20
	add_child(ex)
	await get_tree().create_timer(0.4).timeout
	ex.queue_free()
	var ctx := {"bg": String(m.def.get("bg", map.bg_kind)), "floor": map.floor_n, "can_flee": true}
	var outcome: Dictionary = await ui.battle.start(m.def["group"], ctx)
	await _after_battle(m, outcome)

func _after_battle(m: Mob, outcome: Dictionary) -> void:
	var res: String = String(outcome["result"])
	Audio.play_music(_area_music())
	if res == "victory":
		mobs.erase(m)
		if is_instance_valid(m.node):
			m.node.queue_free()
		if not m.boss:
			Game.mark_defeated(map.id, String(m.def["id"]))
		elif String(m.def["id"]) == "boss_demon_lord":
			Game.set_flag("story_complete", true)
			await ui.dialog.say("", StoryDB.EPILOGUE)
		elif map.seal_pos.x >= 0:
			_open_seal()
	elif res == "fled":
		m.immune_until = now() + Balance.FLEE_IMMUNITY_SECONDS
		immunity_until = now() + 1.2
	elif res == "defeat":
		busy = false
		await go_to_map("ilha", MapDB.TOWN_RESPAWN, "down")
		Game.emit_changed()
		return
	immunity_until = now() + 0.8
	Game.emit_changed()
	busy = false

func _open_seal() -> void:
	var fresh := MapDB.get_map(map.id)
	if fresh != null:
		map.rows = fresh.rows
		_set_map_texture()
		Game.say("A escada selada se abriu!", UIKit.C_GOLD)

# ================================================================= interacao
func _on_confirm() -> void:
	if not active or busy or Game.ui_lock > 0 or pmoving or Game.in_battle:
		return
	if Engine.get_process_frames() == _last_confirm_frame:
		return
	_last_confirm_frame = Engine.get_process_frames()
	_interact()

func _on_menu() -> void:
	if not active or busy or Game.ui_lock > 0 or Game.in_battle or Game.ui_closed_frame == Engine.get_process_frames():
		return
	_open_pause()

func _on_cancel() -> void:
	if not active or busy or Game.ui_lock > 0 or Game.in_battle or Game.ui_closed_frame == Engine.get_process_frames():
		return
	_open_pause()

func _open_pause() -> void:
	ui.pause.in_dungeon = map.kind == "dungeon" or map.id == "forest"
	await ui.pause.run()

func facing_vec() -> Vector2i:
	match pfacing:
		"up": return Vector2i(0, -1)
		"down": return Vector2i(0, 1)
		"left": return Vector2i(-1, 0)
	return Vector2i(1, 0)

func _update_hint() -> void:
	var t := pgrid + facing_vec()
	hint.visible = not map.npc_at(t.x, t.y).is_empty() or (not map.object_at(t.x, t.y).is_empty())

func _interact() -> void:
	var t := pgrid + facing_vec()
	var npc := map.npc_at(t.x, t.y)
	if not npc.is_empty():
		busy = true
		_face_npc(npc)
		await _talk(npc)
		busy = false
		Game.ui_closed_frame = Engine.get_process_frames()
		return
	var obj := map.object_at(t.x, t.y)
	if not obj.is_empty():
		busy = true
		await _use_object(obj)
		busy = false
		Game.ui_closed_frame = Engine.get_process_frames()

func _face_npc(npc: Dictionary) -> void:
	var e: Dictionary = npc_nodes.get(npc["id"], {})
	if e.is_empty():
		return
	var opp: String = {"up": "down", "down": "up", "left": "right", "right": "left"}[pfacing]
	e["spr"].texture = e["frames"][opp][0]

func _use_object(o: Dictionary) -> void:
	var id: String = String(o["id"])
	match String(o["type"]):
		"sign", "seal", "well":
			await ui.dialog.say("", String(o["text"]).split("\n"))
		"brazier":
			pass
		"board":
			await ui.guild.run()
		"chest":
			await _open_chest(o)
		"bush":
			var last: float = float(Game.s["gathered"].get(id, -99999.0))
			if float(Game.s["play_time"]) - last < Balance.BUSH_RESPAWN_SECONDS:
				await ui.dialog.say("", ["Você já colheu aqui. Volte mais tarde."])
			else:
				Game.s["gathered"][id] = float(Game.s["play_time"])
				var n := 1 + (1 if Game.rng.randf() < 0.35 else 0)
				var added := Game.add_item("erva_curativa", n)
				_refresh_object(id)
				Audio.sfx("confirm")
				if added > 0:
					await ui.dialog.say("", ["Você colheu %d Erva Curativa!" % added])
				else:
					await ui.dialog.say("", ["Seu inventário está cheio!"])
					Game.s["gathered"].erase(id)
					_refresh_object(id)
		"rest", "stone":
			await _rest_point()

func _open_chest(o: Dictionary) -> void:
	var id: String = String(o["id"])
	if Game.s["opened"].has(id):
		await ui.dialog.say("", ["O baú está vazio."])
		return
	Game.s["opened"][id] = true   # marca ANTES de pagar (anti-duplicacao)
	_refresh_object(id)
	Audio.sfx("chest")
	var loot: Dictionary
	if o.get("boss_chest", false):
		loot = BOSS_CHESTS.get(int(o["floor"]), {"gold": 100, "items": {"pocao": 1}}).duplicate(true)
	else:
		loot = LootTable.roll_chest(Game.rng, int(o.get("floor", 1)), String(Game.s["class_id"]))
	var msgs := Game.grant_rewards({"gold": int(loot["gold"]), "items": loot["items"]})
	var lines: Array = ["Você abriu o baú!"]
	lines.append(", ".join(msgs))
	await ui.dialog.say("", lines)

func _rest_point() -> void:
	var idx := await ui.dialog.choose(["Descansar e salvar", "Só salvar", "Sair"], "Cristal de descanso", true)
	if idx == 0:
		Game.rest_full()
		var r := Game.save_game()
		Audio.sfx("heal")
		await ui.dialog.say("", ["HP e MP restaurados.", "Jogo salvo." if r["ok"] else "Falha ao salvar: %s" % r["error"]])
	elif idx == 1:
		var r2 := Game.save_game()
		Audio.sfx("confirm")
		await ui.dialog.say("", ["Jogo salvo." if r2["ok"] else "Falha ao salvar: %s" % r2["error"]])

# ================================================================= NPCs
## Missoes entregues por NPC (StoryDB.NPC_QUESTS). Retorna true se o NPC tratou a conversa.
func _npc_quest(npc: Dictionary) -> bool:
	var list: Array = StoryDB.NPC_QUESTS.get(String(npc["id"]), [])
	var name: String = String(npc["name"])
	var hero: String = String(Game.s["hero_name"])
	for entry in list:
		var qid: String = String(entry["quest"])
		var req_ok := true
		for r in entry.get("requires", []):
			if QuestSystem.state_of(String(r)) != "completed":
				req_ok = false
		if not req_ok:
			continue
		var st := QuestSystem.state_of(qid)
		if st == "completed" or st == "locked":
			continue
		if st == "available":
			var lines: Array = []
			for l in entry["offer"]:
				lines.append(String(l) % hero if "%s" in String(l) else String(l))
			await ui.dialog.say(name, lines)
			var q: Dictionary = QuestDB.QUESTS[qid]
			var pick := await ui.dialog.choose(["Aceitar: %s" % q["name"], "Agora não"], name, true)
			if pick == 0:
				var r := QuestSystem.accept(qid)
				await ui.dialog.say("", [String(r["msg"])])
			else:
				await ui.dialog.say(name, ["Tudo bem. Volte quando estiver pronto."])
			return true
		if st == "active":
			if QuestSystem.is_ready(qid):
				var rl: Array = []
				for l2 in entry["ready"]:
					rl.append(String(l2) % hero if "%s" in String(l2) else String(l2))
				await ui.dialog.say(name, rl)
				var res := QuestSystem.turn_in(qid)
				if res["ok"]:
					Audio.sfx("heal")
					var out: Array = [String(res["msg"])]
					out.append_array(res["messages"])
					await ui.dialog.say("", out)
				else:
					await ui.dialog.say(name, [String(res["msg"])])
			else:
				var wl: Array = entry["waiting"].duplicate()
				wl.append(QuestSystem.progress_text(qid))
				await ui.dialog.say(name, wl)
			return true
	return false

func _talk(npc: Dictionary) -> void:
	var name: String = String(npc["name"])
	if String(npc["role"]) != "elder" and StoryDB.NPC_QUESTS.has(String(npc["id"])):
		if await _npc_quest(npc):
			return
	match String(npc["role"]):
		"guild":
			await ui.dialog.say(name, ["Bem-vindo à Guilda dos Aventureiros, %s!" % Game.s["hero_name"], "Rank atual: %s. Posso ajudar com missões e promoções." % GuildSystem.rank()])
			var ready := QuestSystem.ready_ids().size()
			if ready > 0:
				await ui.dialog.say(name, ["Você tem %d missão(ões) pronta(s) para entregar!" % ready])
			while true:
				var i := await ui.dialog.choose(["Quadro de missões", "Minhas missões", "Rank e promoção", "Sair"], name, true)
				if i == 0:
					ui.guild.initial_tab = "board"
				elif i == 1:
					ui.guild.initial_tab = "mine"
				elif i == 2:
					ui.guild.initial_tab = "rank"
				else:
					break
				await ui.guild.run()
			await ui.dialog.say(name, ["Boa sorte lá fora!"])
		"guildmaster":
			var r := GuildSystem.rank()
			var lines: Array = []
			match r:
				"D": lines = ["Eu sou Ardan, mestre da guilda.", "Todo herói começa no Rank D. Cumpra missões, ganhe reputação e prove seu valor para subir de rank."]
				"C": lines = ["Rank C... você já mostrou coragem. A próxima prova será nas profundezas da Floresta Esquecida."]
				"B": lines = ["Rank B! Poucos chegam tão longe. A Matriarca Aranha já ficou para trás..."]
				"A": lines = ["Rank A. O Guardião Ancião aguarda no 20º andar. Só quem o vencer será reconhecido como Herói."]
				_: lines = ["Um herói de rank %s. A guilda se orgulha de você. Grutas e criptas escondidas esperam pelos corajosos." % r]
			await ui.dialog.say(name, lines)
			var q := await ui.dialog.choose(["Ver promoção de rank", "Sair"], name, true)
			if q == 0:
				ui.guild.initial_tab = "rank"
				await ui.guild.run()
		"shop":
			await ui.dialog.say(name, ["Bem-vindo à minha loja! Compro e vendo de tudo um pouco."])
			ui.shop.profile = String(map.id).trim_prefix("shop_")
			ui.shop.shop_name = String(npc.get("place", "Loja"))
			ui.shop.title_lbl.text = ui.shop.shop_name
			await ui.shop.run()
			await ui.dialog.say(name, ["Volte sempre!"])
		"inn":
			await ui.dialog.say(name, ["Bem-vindo à %s! Uma noite custa 15 de ouro." % String(npc.get("place", "Pousada da Aurora"))])
			while true:
				var i2 := await ui.dialog.choose(["Descansar (15 ouro)", "Salvar jogo", "Sair"], name, true)
				if i2 == 0:
					if int(Game.s["gold"]) < 15:
						await ui.dialog.say(name, ["Hm, parece que você não tem ouro suficiente."])
					else:
						Game.s["gold"] = int(Game.s["gold"]) - 15
						Game.rest_full()
						Game.save_game()
						Audio.sfx("heal")
						await ui.dialog.say(name, ["Você dormiu muito bem. HP e MP restaurados!", "(Jogo salvo)"])
				elif i2 == 1:
					var r3 := Game.save_game()
					await ui.dialog.say(name, ["Pronto, registrei seu progresso." if r3["ok"] else "Algo deu errado: %s" % r3["error"]])
				else:
					break
		"elder":
			if not Game.flag("met_elder"):
				Game.set_flag("met_elder", true)
				await ui.dialog.say(name, ["Ah, um novo aventureiro! Eu sou Orin, ancião de Vila Aurora.", "Esta é a Ilha de Aurora: seis cidades, florestas sem fim e, no canto nordeste, um castelo demoníaco de portões selados.", "Ao sul fica a Floresta de Treino. Lá, monstros vagam à vista — encoste neles para lutar.", "Dentro dela há uma gruta: a Floresta Esquecida, com 20 andares e quatro chefes.", "Fale com a Guilda para pegar missões, e visite a Loja do Borin para se equipar.", "Cristais azuis espalhados pela ilha curam e salvam seu jogo. Abra o MENU e veja a aba Mapa!"])
				await _npc_quest(npc)
			else:
				var hint_text := "Ainda não visitou a Guilda? Lá você encontra missões."
				if Game.s["quests"].size() > 0:
					hint_text = "Continue com suas missões. Cada rank de guilda exige reputação e uma prova."
				if Game.boss_defeated("boss_slime_king"):
					hint_text = "Você derrotou o Rei Slime! Mas ainda há muito a descobrir nas profundezas."
				if Game.boss_defeated("boss_demon_lord"):
					hint_text = "Você salvou a ilha, %s! Aurora jamais esquecerá." % Game.s["hero_name"]
				elif Game.boss_defeated("boss_scorpion_king") or Game.boss_defeated("boss_toad_king") or Game.boss_defeated("boss_yeti_king"):
					hint_text = "Ouvi dizer que um dos selos já foi restaurado. Restaure os três para enfrentar Azrakhel."
				if await _npc_quest(npc):
					return
				await ui.dialog.say(name, [hint_text, "Dica: monstros têm fraquezas elementais. Experimente fogo contra slimes!"])
		"villager1":
			await ui.dialog.say(name, ["Dizem que os morcegos da floresta ficam mais agressivos à noite.", "Ervas curativas crescem nos arbustos da floresta. A guilda paga bem por elas!"])
		"villager2":
			await ui.dialog.say(name, ["Se o seu inventário encher, venda materiais na loja.", "Cada classe luta de um jeito: o Mago é frágil, mas tem fogo e gelo!"])
		"guard":
			await ui.dialog.say(name, ["A estrada leste leva à Floresta de Treino.", "Cuidado com os goblins nos andares mais fundos da masmorra."])
		_:
			await ui.dialog.say(name, npc.get("lines", ["..."]))

func intro() -> void:
	busy = true
	var touch := Controls.touch_enabled
	await ui.dialog.say("", ["Bem-vindo a Crônicas de Aurora!", ("Use o direcional à esquerda para andar, A para interagir e MENU para o menu." if touch else "Setas/WASD para andar, Z ou Enter para interagir, Tab para o menu."), "Fale com o Ancião Orin no centro da vila para começar sua jornada."])
	busy = false
