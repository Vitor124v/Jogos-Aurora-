extends Node
## Audio procedural (sem arquivos externos): efeitos e musica simples gerados em codigo.

const RATE := 22050
var _sfx_players: Array = []
var _music_player: AudioStreamPlayer
var _cache: Dictionary = {}
var _current_music := ""
var _composed: Dictionary = {}          # faixa -> AudioStreamWAV (pronta)
var _mutex := Mutex.new()
var _thread: Thread
var _quit := false
var _using_composed := false

## Faixas compostas proceduralmente (melodia + baixo + acordes + percussao), geradas em segundo plano.
const TRACKS := {
	"menu": {"root": 60, "scale": "major", "bpm": 84, "prog": [0, 5, 3, 4], "lead": "tri", "drums": 0, "mood": "calm", "seed": 11},
	"town": {"root": 55, "scale": "major", "bpm": 104, "prog": [0, 4, 5, 3], "lead": "square", "drums": 1, "mood": "happy", "seed": 21},
	"forest": {"root": 50, "scale": "dorian", "bpm": 92, "prog": [0, 6, 3, 6], "lead": "tri", "drums": 0, "mood": "calm", "seed": 31},
	"snow": {"root": 57, "scale": "minor", "bpm": 72, "prog": [0, 5, 2, 6], "lead": "sine", "drums": 0, "mood": "calm", "seed": 41},
	"desert": {"root": 52, "scale": "phrygian_dom", "bpm": 98, "prog": [0, 1, 0, 6], "lead": "square", "drums": 2, "mood": "tense", "seed": 51},
	"swamp": {"root": 45, "scale": "phrygian", "bpm": 68, "prog": [0, 1, 0, 4], "lead": "tri", "drums": 0, "mood": "dark", "seed": 61},
	"volcano": {"root": 50, "scale": "harm_minor", "bpm": 112, "prog": [0, 5, 6, 4], "lead": "square", "drums": 2, "mood": "dark", "seed": 71},
	"dungeon": {"root": 43, "scale": "minor", "bpm": 76, "prog": [0, 0, 5, 4], "lead": "tri", "drums": 0, "mood": "dark", "seed": 81},
	"battle": {"root": 57, "scale": "minor", "bpm": 150, "prog": [0, 5, 3, 4], "lead": "square", "drums": 3, "mood": "tense", "seed": 91},
	"boss": {"root": 52, "scale": "harm_minor", "bpm": 162, "prog": [0, 5, 0, 4], "lead": "square", "drums": 3, "mood": "tense", "seed": 101},
	"final": {"root": 50, "scale": "phrygian_dom", "bpm": 172, "prog": [0, 1, 5, 4], "lead": "square", "drums": 3, "mood": "tense", "seed": 111},
}
const SCALES := {
	"major": [0, 2, 4, 5, 7, 9, 11], "minor": [0, 2, 3, 5, 7, 8, 10], "dorian": [0, 2, 3, 5, 7, 9, 10],
	"phrygian": [0, 1, 3, 5, 7, 8, 10], "phrygian_dom": [0, 1, 4, 5, 7, 8, 10], "harm_minor": [0, 2, 3, 5, 7, 8, 11],
}
const REGION_MUSIC := {
	"aurora": "town", "pinheiral": "town", "porto": "town", "pedralta": "town", "solmar": "town", "vigia": "town",
	"nevasca": "snow", "gelida": "snow", "geladas": "snow",
	"campos": "town", "costa": "town", "verdejante": "forest", "vale": "forest", "sussurrante": "forest", "pinhal": "forest",
	"brumas": "forest", "nebuloso": "forest", "mata_escura": "dungeon",
	"dunas": "desert", "pantano": "swamp", "serra": "dungeon",
	"carmesim": "volcano", "sombrias": "volcano", "castelo": "volcano",
}

func _ready() -> void:
	_thread = Thread.new()
	_thread.start(_compose_all)
	for i in range(6):
		var p := AudioStreamPlayer.new()
		add_child(p)
		_sfx_players.append(p)
	_music_player = AudioStreamPlayer.new()
	add_child(_music_player)

func _wave(freqs: Array, dur: float, kind: String = "square", vol: float = 0.5, slide: float = 0.0) -> AudioStreamWAV:
	var n := int(RATE * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var seg := maxi(1, n / maxi(1, freqs.size()))
	var phase := 0.0
	for i in range(n):
		var f := float(freqs[mini(i / seg, freqs.size() - 1)]) + slide * float(i) / float(n)
		phase += f / float(RATE)
		var t := float(i) / float(n)
		var env := minf(1.0, t * 40.0) * pow(1.0 - t, 1.5)
		var v := 0.0
		match kind:
			"square":
				v = 1.0 if fmod(phase, 1.0) < 0.5 else -1.0
			"tri":
				v = absf(fmod(phase, 1.0) * 4.0 - 2.0) - 1.0
			"noise":
				v = rng.randf_range(-1.0, 1.0)
			_:
				v = sin(phase * TAU)
		var s := int(clampf(v * env * vol, -1.0, 1.0) * 32000.0)
		data[i * 2] = s & 0xFF
		data[i * 2 + 1] = (s >> 8) & 0xFF
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.data = data
	return w

func _sfx_stream(name: String) -> AudioStreamWAV:
	if _cache.has(name):
		return _cache[name]
	var w: AudioStreamWAV
	match name:
		"select": w = _wave([660, 880], 0.07, "square", 0.3)
		"move": w = _wave([440], 0.03, "tri", 0.2)
		"confirm": w = _wave([523, 659, 784], 0.14, "square", 0.3)
		"cancel": w = _wave([392, 294], 0.1, "square", 0.3)
		"hit": w = _wave([180], 0.12, "noise", 0.5)
		"crit": w = _wave([300, 150], 0.2, "noise", 0.6)
		"miss": w = _wave([300, 200], 0.1, "tri", 0.25)
		"magic": w = _wave([500, 700, 900, 1100], 0.3, "sine", 0.35, 400)
		"heal": w = _wave([523, 659, 784, 1046], 0.35, "sine", 0.35)
		"coin": w = _wave([988, 1318], 0.14, "square", 0.25)
		"levelup": w = _wave([523, 659, 784, 1046, 784, 1046, 1318], 0.7, "square", 0.3)
		"victory": w = _wave([523, 523, 523, 659, 784], 0.8, "square", 0.3)
		"defeat": w = _wave([392, 349, 330, 262], 0.9, "tri", 0.4)
		"encounter": w = _wave([200, 300, 200, 300, 400], 0.4, "square", 0.3)
		"chest": w = _wave([440, 554, 659, 880], 0.35, "square", 0.3)
		"stairs": w = _wave([300, 250, 200], 0.25, "tri", 0.3)
		_: w = _wave([440], 0.05, "square", 0.2)
	_cache[name] = w
	return w

func sfx(name: String) -> void:
	var vol := float(Game.settings.get("sfx", 0.8))
	if vol <= 0.001:
		return
	for p in _sfx_players:
		if not p.playing:
			p.stream = _sfx_stream(name)
			p.volume_db = linear_to_db(vol)
			p.play()
			return

func _music_stream(track: String) -> AudioStreamWAV:
	var key := "m_" + track
	if _cache.has(key):
		return _cache[key]
	var notes := {
		"town": [262, 330, 392, 330, 294, 349, 440, 349, 262, 330, 392, 523, 440, 392, 349, 294],
		"forest": [220, 262, 330, 262, 247, 294, 370, 294, 220, 262, 330, 440, 370, 330, 294, 247],
		"dungeon": [147, 0, 175, 0, 165, 0, 196, 0, 147, 0, 175, 0, 131, 0, 165, 0],
		"boss": [196, 196, 233, 196, 262, 233, 196, 175, 196, 196, 233, 196, 311, 262, 233, 196],
		"battle": [330, 392, 330, 440, 330, 494, 440, 392, 294, 349, 294, 392, 294, 440, 392, 349],
		"menu": [262, 330, 392, 523, 392, 330, 262, 330],
	}
	var seq: Array = notes.get(track, notes["town"])
	var step := 0.22 if track != "boss" else 0.16
	var n_step := int(RATE * step)
	var total := n_step * seq.size()
	var data := PackedByteArray()
	data.resize(total * 2)
	var phase := 0.0
	for si in range(seq.size()):
		var f := float(seq[si])
		for i in range(n_step):
			var idx := si * n_step + i
			var t := float(i) / float(n_step)
			var env := minf(1.0, t * 30.0) * (1.0 - t * 0.6)
			var v := 0.0
			if f > 0.0:
				phase += f / float(RATE)
				v = (1.0 if fmod(phase, 1.0) < 0.5 else -1.0) * 0.5 if track in ["battle", "boss"] else (absf(fmod(phase, 1.0) * 4.0 - 2.0) - 1.0)
			var s := int(v * env * 5000.0)
			data[idx * 2] = s & 0xFF
			data[idx * 2 + 1] = (s >> 8) & 0xFF
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.data = data
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = total
	_cache[key] = w
	return w

func play_music(track: String) -> void:
	if track == _current_music and _music_player.playing:
		_apply_volume()
		return
	_current_music = track
	_mutex.lock()
	var comp: AudioStreamWAV = _composed.get(track)
	_mutex.unlock()
	_music_player.stream = comp if comp != null else _music_stream(track)
	_using_composed = comp != null
	_apply_volume()
	_music_player.play()

func stop_music() -> void:
	_current_music = ""
	_music_player.stop()

func _apply_volume() -> void:
	var v := float(Game.settings.get("music", 0.6))
	_music_player.volume_db = linear_to_db(maxf(v, 0.0001)) if v > 0.001 else -80.0

func set_music_volume(v: float) -> void:
	Game.settings["music"] = clampf(v, 0.0, 1.0)
	_apply_volume()

func set_sfx_volume(v: float) -> void:
	Game.settings["sfx"] = clampf(v, 0.0, 1.0)

func _process(_delta: float) -> void:
	# troca a musica simples (provisoria) pela composta assim que ela ficar pronta
	if _current_music != "" and not _using_composed and is_composed(_current_music) and _music_player.playing:
		_mutex.lock()
		var comp: AudioStreamWAV = _composed.get(_current_music)
		_mutex.unlock()
		if comp != null:
			_music_player.stream = comp
			_using_composed = true
			_music_player.play()

func _exit_tree() -> void:
	_quit = true
	if _thread != null and _thread.is_started():
		_thread.wait_to_finish()

## Faixa de musica para uma regiao da ilha.
func music_for_region(region_id: String) -> String:
	return String(REGION_MUSIC.get(region_id, "town"))

func is_composed(track: String) -> bool:
	_mutex.lock()
	var ok := _composed.has(track)
	_mutex.unlock()
	return ok

func _compose_all() -> void:
	for name in TRACKS:
		if _quit:
			return
		var w := _compose(String(name))
		_mutex.lock()
		_composed[name] = w
		_mutex.unlock()

static func _freq(root: int, scale: Array, degree: int) -> float:
	var octave: int = int(floorf(float(degree) / 7.0))
	var idx := ((degree % 7) + 7) % 7
	var midi := root + int(scale[idx]) + 12 * octave
	return 440.0 * pow(2.0, float(midi - 69) / 12.0)

static func _osc(kind: String, ph: float) -> float:
	var f: float = ph - floorf(ph)
	match kind:
		"square":
			return 1.0 if f < 0.5 else -1.0
		"tri":
			return absf(f * 4.0 - 2.0) - 1.0
		"saw":
			return f * 2.0 - 1.0
		_:
			return sin(ph * TAU)

func _add_note(buf: PackedFloat32Array, start: int, length: int, freq: float, kind: String, vol: float, decay: float) -> void:
	var total := buf.size()
	var ph := 0.0
	var inc := freq / float(RATE)
	for i in range(length):
		var idx := start + i
		if idx >= total:
			idx -= total       # dobra para o inicio: laco sem emenda
		var t := float(i) / float(length)
		var env := minf(1.0, float(i) / 60.0) * pow(1.0 - t, decay)
		ph += inc
		buf[idx] += _osc(kind, ph) * env * vol

func _add_drum(buf: PackedFloat32Array, start: int, kind: String, vol: float, rng: RandomNumberGenerator) -> void:
	var total := buf.size()
	var n := 0
	match kind:
		"kick":
			n = int(RATE * 0.16)
		"snare":
			n = int(RATE * 0.12)
		_:
			n = int(RATE * 0.04)
	var ph := 0.0
	for i in range(n):
		var idx := (start + i) % total
		var t := float(i) / float(n)
		var env := pow(1.0 - t, 2.0)
		var v := 0.0
		match kind:
			"kick":
				ph += (110.0 - 80.0 * t) / float(RATE)
				v = sin(ph * TAU)
			"snare":
				v = rng.randf_range(-1.0, 1.0) * 0.8 + sin(float(i) * 0.12) * 0.2
			_:
				v = rng.randf_range(-1.0, 1.0) * 0.5
		buf[idx] += v * env * vol

func _compose(track: String) -> AudioStreamWAV:
	var d: Dictionary = TRACKS[track]
	var rng := RandomNumberGenerator.new()
	rng.seed = int(d["seed"])
	var scale: Array = SCALES[String(d["scale"])]
	var root: int = int(d["root"])
	var prog: Array = d["prog"]
	var bars := 8
	var step_len := int(float(RATE) * 60.0 / float(d["bpm"]) / 2.0)   # colcheia
	var steps := bars * 8
	var total := step_len * steps
	var buf := PackedFloat32Array()
	buf.resize(total)
	var lead_kind: String = String(d["lead"])
	var mood: String = String(d["mood"])
	var drums: int = int(d["drums"])
	var pos := 4      # grau da melodia (comeca na quinta)
	var s := 0
	while s < steps:
		var bar := s / 8
		var chord_deg: int = int(prog[bar % prog.size()])
		var in_bar := s % 8
		# baixo: raiz nos tempos fortes
		if in_bar == 0 or in_bar == 4 or (drums >= 2 and in_bar == 6):
			_add_note(buf, s * step_len, step_len * (3 if in_bar != 6 else 2), _freq(root - 12, scale, chord_deg), "tri", 0.30, 1.2)
		# acordes em arpejo
		var arp: Array = [0, 2, 4, 2]
		if mood == "calm" or mood == "dark":
			if in_bar % 2 == 0:
				var tone: int = chord_deg + int(arp[(in_bar / 2) % 4])
				_add_note(buf, s * step_len, step_len * 2, _freq(root, scale, tone), "sine", 0.16, 1.0)
		else:
			var tone2: int = chord_deg + int(arp[in_bar % 4])
			_add_note(buf, s * step_len, step_len, _freq(root, scale, tone2), "tri", 0.10, 1.4)
		# melodia: caminhada aleatoria na escala, favorece notas do acorde
		var rest_chance := 0.35 if mood == "calm" else (0.22 if mood == "happy" else 0.18)
		if rng.randf() > rest_chance and not (mood == "dark" and in_bar % 2 == 1):
			var move := rng.randi_range(-2, 2)
			pos = clampi(pos + move, 0, 9)
			if in_bar == 0:
				pos = chord_deg + [0, 2, 4][rng.randi() % 3] + 7
				pos = clampi(pos, 2, 11)
			var dur := 2 if rng.randf() < 0.45 else 1
			if mood == "calm":
				dur = 2 + rng.randi_range(0, 2)
			_add_note(buf, s * step_len, step_len * dur, _freq(root + 12, scale, pos), lead_kind, 0.20 if lead_kind != "sine" else 0.26, 1.1)
		# percussao
		if drums >= 1:
			if in_bar == 0 or (drums >= 3 and in_bar == 4 and false):
				_add_drum(buf, s * step_len, "kick", 0.45, rng)
			if drums >= 2 and in_bar == 4:
				_add_drum(buf, s * step_len, "snare" if drums >= 3 else "hat", 0.30, rng)
			if drums >= 3 and in_bar % 2 == 0 and in_bar != 0:
				_add_drum(buf, s * step_len, "kick" if in_bar == 6 else "hat", 0.30, rng)
			if drums >= 1 and in_bar % 2 == 1:
				_add_drum(buf, s * step_len, "hat", 0.12, rng)
		s += 1
	var data := PackedByteArray()
	data.resize(total * 2)
	for i in range(total):
		var v := clampf(buf[i] * 0.55, -1.0, 1.0)
		var q := int(v * 30000.0)
		data[i * 2] = q & 0xFF
		data[i * 2 + 1] = (q >> 8) & 0xFF
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.data = data
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = total
	return w
