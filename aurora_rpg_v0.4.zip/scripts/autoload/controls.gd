extends Node
## Entrada unificada: teclado, gamepad e controles virtuais de toque.
## Toda a logica do jogo le daqui (get_dir / pressed signals), nunca direto do Input.

signal confirm_pressed
signal cancel_pressed
signal menu_pressed
signal dir_pressed(dir: Vector2i)   # eventos discretos para menus

var touch_dir: Vector2i = Vector2i.ZERO
var touch_run: bool = false
var is_touch_device: bool = false
var touch_enabled: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	is_touch_device = DisplayServer.is_touchscreen_available() or OS.has_feature("android") or OS.has_feature("ios")
	_ensure_actions()
	refresh_touch_setting()

func refresh_touch_setting() -> void:
	var mode := int(Game.settings.get("touch", 0)) if Game != null else 0
	touch_enabled = (mode == 1) or (mode == 0 and is_touch_device)
	if not touch_enabled:
		touch_dir = Vector2i.ZERO

func _ensure_actions() -> void:
	var map := {
		"move_up": [KEY_W, KEY_UP], "move_down": [KEY_S, KEY_DOWN], "move_left": [KEY_A, KEY_LEFT], "move_right": [KEY_D, KEY_RIGHT],
		"confirm": [KEY_ENTER, KEY_KP_ENTER, KEY_SPACE, KEY_Z, KEY_E], "cancel": [KEY_ESCAPE, KEY_X, KEY_BACKSPACE],
		"menu": [KEY_TAB, KEY_M, KEY_I], "run": [KEY_SHIFT],
	}
	for a in map:
		if not InputMap.has_action(a):
			InputMap.add_action(a)
		for k in map[a]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(a, ev)
	var pad := {"move_up": JOY_BUTTON_DPAD_UP, "move_down": JOY_BUTTON_DPAD_DOWN, "move_left": JOY_BUTTON_DPAD_LEFT, "move_right": JOY_BUTTON_DPAD_RIGHT,
		"confirm": JOY_BUTTON_A, "cancel": JOY_BUTTON_B, "menu": JOY_BUTTON_START}
	for a in pad:
		var e := InputEventJoypadButton.new()
		e.button_index = pad[a]
		InputMap.action_add_event(a, e)

## Direcao de movimento corrente (4 direcoes; prioriza o eixo mais recente).
var _last_axis_h := true
func get_dir() -> Vector2i:
	if Game.ui_lock > 0:
		return Vector2i.ZERO
	var d := Vector2i.ZERO
	var h := int(Input.is_action_pressed("move_right")) - int(Input.is_action_pressed("move_left"))
	var v := int(Input.is_action_pressed("move_down")) - int(Input.is_action_pressed("move_up"))
	if touch_dir != Vector2i.ZERO:
		h = touch_dir.x
		v = touch_dir.y
	if h != 0 and v != 0:
		d = Vector2i(h, 0) if _last_axis_h else Vector2i(0, v)
	elif h != 0:
		d = Vector2i(h, 0)
		_last_axis_h = true
	elif v != 0:
		d = Vector2i(0, v)
		_last_axis_h = false
	return d

func is_running() -> bool:
	return Input.is_action_pressed("run") or touch_run

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("confirm"):
		confirm_pressed.emit()
	elif event.is_action_pressed("cancel"):
		cancel_pressed.emit()
	elif event.is_action_pressed("menu"):
		menu_pressed.emit()
	for pair in [["move_up", Vector2i(0, -1)], ["move_down", Vector2i(0, 1)], ["move_left", Vector2i(-1, 0)], ["move_right", Vector2i(1, 0)]]:
		if event.is_action_pressed(pair[0]):
			dir_pressed.emit(pair[1])

## Chamado pelos botoes virtuais.
func virtual_press(action: String) -> void:
	match action:
		"confirm": confirm_pressed.emit()
		"cancel": cancel_pressed.emit()
		"menu": menu_pressed.emit()
