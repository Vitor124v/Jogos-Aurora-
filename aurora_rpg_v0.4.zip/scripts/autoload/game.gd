extends Node
## Estado global do jogo (autoload "Game"): personagem, inventario, progresso e regras.
## O dicionario "s" e exatamente o que e salvo em disco (ver SaveSystem).

signal changed
signal toast(text: String, color: Color)
signal level_up(new_level: int)

const SETTINGS_PATH := "user://settings.json"

var s: Dictionary = {}
var has_game: bool = false
var settings: Dictionary = {"music": 0.6, "sfx": 0.8, "integer_scale": false, "touch": 0}
var in_battle: bool = false
var ui_closed_frame: int = -1
var ui_lock: int = 0
var active_play: bool = false
var last_load_warnings: Array = []
var rng := RandomNumberGenerator.new()
var _stats_cache: Dictionary = {}
var _autosave_cooldown: float = 0.0

func _ready() -> void:
	rng.randomize()
	load_settings()

func _process(delta: float) -> void:
	if has_game and active_play and not in_battle:
		s["play_time"] = float(s["play_time"]) + delta

func emit_changed() -> void:
	_stats_cache.clear()
	changed.emit()

func say(text: String, color: Color = Color.WHITE) -> void:
	toast.emit(text, color)

# ------------------------------------------------------------------ configuracoes
func load_settings() -> void:
	if FileAccess.file_exists(SETTINGS_PATH):
		var f := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
		if f:
			var j := JSON.new()
			if j.parse(f.get_as_text()) == OK and j.data is Dictionary:
				for k in settings:
					if j.data.has(k):
						settings[k] = j.data[k]
	settings["music"] = clampf(float(settings["music"]), 0.0, 1.0)
	settings["sfx"] = clampf(float(settings["sfx"]), 0.0, 1.0)
	settings["touch"] = clampi(int(settings["touch"]), 0, 2)
	settings["integer_scale"] = bool(settings["integer_scale"])

func save_settings() -> void:
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))

# ------------------------------------------------------------------ nova partida / save
func new_game(class_id: String, hero_name: String) -> void:
	s = SaveSystem.default_state()
	s["class_id"] = class_id
	s["hero_name"] = hero_name.strip_edges().substr(0, 14) if hero_name.strip_edges() != "" else "Herói"
	var cd := HeroDB.get_class_data(class_id)
	s["equipment"] = cd["start_equipment"].duplicate()
	s["equipment"]["accessory"] = ""
	s["inventory"] = {"pocao_pequena": 3, "antidoto": 1}
	s["gold"] = Balance.START_GOLD
	s["world"] = {"map": "ilha", "x": MapDB.TOWN_START.x, "y": MapDB.TOWN_START.y}
	_stats_cache.clear()
	s["hp"] = max_hp()
	s["mp"] = max_mp()
	has_game = true
	in_battle = false
	emit_changed()

func save_game() -> Dictionary:
	if not has_game:
		return {"ok": false, "error": "Nenhuma partida ativa."}
	if in_battle:
		return {"ok": false, "error": "Não é possível salvar durante a batalha."}
	return SaveSystem.write(s)

func load_game() -> Dictionary:
	var r := SaveSystem.read()
	if not r["ok"]:
		return r
	s = r["state"]
	last_load_warnings = r["warnings"]
	has_game = true
	in_battle = false
	_stats_cache.clear()
	s["hp"] = clampi(int(s["hp"]), 1, max_hp())
	s["mp"] = clampi(int(s["mp"]), 0, max_mp())
	# estado seguro: sempre retoma no mapa salvo (sem batalha em andamento)
	emit_changed()
	return r

# ------------------------------------------------------------------ atributos
func equipment_bonus() -> Dictionary:
	var b := {}
	for slot in s["equipment"]:
		var id: String = s["equipment"][slot]
		if id != "":
			for k in ItemDB.get_item(id).get("stats", {}):
				b[k] = int(b.get(k, 0)) + int(ItemDB.get_item(id)["stats"][k])
	for k in HeroDB.subclass_bonus(String(s["subclass"])):
		b[k] = int(b.get(k, 0)) + int(HeroDB.subclass_bonus(String(s["subclass"]))[k])
	return b

func stats() -> Dictionary:
	if _stats_cache.is_empty():
		_stats_cache = Formulas.hero_stats(String(s["class_id"]), int(s["level"]), equipment_bonus())
	return _stats_cache

func max_hp() -> int:
	return int(stats()["max_hp"])

func max_mp() -> int:
	return int(stats()["max_mp"])

func level() -> int:
	return int(s["level"])

func skills_known() -> Array:
	return HeroDB.skills_for(String(s["class_id"]), int(s["level"]))

func class_name_text() -> String:
	return String(HeroDB.get_class_data(String(s["class_id"]))["name"])

func exp_progress() -> Vector2i:
	return Vector2i(int(s["exp"]), Formulas.exp_to_next(int(s["level"])))

# ------------------------------------------------------------------ inventario
func item_count(id: String) -> int:
	return int(s["inventory"].get(id, 0))

func can_add_item(id: String, n: int = 1) -> bool:
	var have := item_count(id)
	if have == 0 and s["inventory"].size() >= Balance.INVENTORY_LIMIT:
		return false
	return have + n <= Balance.STACK_LIMIT

## Adiciona ate onde couber. Retorna quantos foram realmente adicionados.
func add_item(id: String, n: int = 1) -> int:
	if n <= 0 or not ItemDB.exists(id):
		return 0
	var have := item_count(id)
	if have == 0 and s["inventory"].size() >= Balance.INVENTORY_LIMIT:
		return 0
	var room := Balance.STACK_LIMIT - have
	var added := mini(n, room)
	if added <= 0:
		return 0
	s["inventory"][id] = have + added
	emit_changed()
	return added

func remove_item(id: String, n: int = 1) -> bool:
	if item_count(id) < n:
		return false
	s["inventory"][id] = item_count(id) - n
	if int(s["inventory"][id]) <= 0:
		s["inventory"].erase(id)
	emit_changed()
	return true

func equip(id: String) -> Dictionary:
	if item_count(id) <= 0:
		return {"ok": false, "msg": "Você não possui este item."}
	var chk := ItemDB.can_equip(id, String(s["class_id"]), int(s["level"]))
	if not chk["ok"]:
		return {"ok": false, "msg": chk["reason"]}
	var slot: String = ItemDB.get_item(id)["slot"]
	var old: String = s["equipment"][slot]
	remove_item(id, 1)
	if old != "":
		s["inventory"][old] = item_count(old) + 1
	s["equipment"][slot] = id
	_clamp_resources()
	emit_changed()
	return {"ok": true, "msg": "%s equipado." % ItemDB.get_item(id)["name"]}

func unequip(slot: String) -> Dictionary:
	var id: String = s["equipment"].get(slot, "")
	if id == "":
		return {"ok": false, "msg": "Nada equipado."}
	if not can_add_item(id, 1):
		return {"ok": false, "msg": "Inventário cheio."}
	s["equipment"][slot] = ""
	s["inventory"][id] = item_count(id) + 1
	_clamp_resources()
	emit_changed()
	return {"ok": true, "msg": "%s removido." % ItemDB.get_item(id)["name"]}

func _clamp_resources() -> void:
	_stats_cache.clear()
	s["hp"] = clampi(int(s["hp"]), 1, max_hp())
	s["mp"] = clampi(int(s["mp"]), 0, max_mp())

## Uso de consumivel fora de batalha. Retorna {ok, msg, action?}
func use_item_field(id: String) -> Dictionary:
	var it := ItemDB.get_item(id)
	if it.is_empty() or it["type"] != "consumable" or item_count(id) <= 0:
		return {"ok": false, "msg": "Não é possível usar."}
	if it.get("battle_only", false):
		return {"ok": false, "msg": "Só pode ser usado em batalha."}
	var use: Dictionary = it["use"]
	if use.get("town_return", false):
		return {"ok": true, "msg": "Você é transportado para a cidade!", "action": "town_return"}
	var did := false
	var parts: Array = []
	if use.has("heal_hp") and int(s["hp"]) < max_hp():
		var before := int(s["hp"])
		s["hp"] = mini(max_hp(), before + int(use["heal_hp"]))
		parts.append("+%d HP" % (int(s["hp"]) - before))
		did = true
	if use.has("heal_mp") and int(s["mp"]) < max_mp():
		var before2 := int(s["mp"])
		s["mp"] = mini(max_mp(), before2 + int(use["heal_mp"]))
		parts.append("+%d MP" % (int(s["mp"]) - before2))
		did = true
	if use.has("cure"):
		did = true
		parts.append("curado")
	if not did:
		return {"ok": false, "msg": "Sem efeito agora."}
	remove_item(id, 1)
	return {"ok": true, "msg": "%s: %s" % [it["name"], ", ".join(parts)]}

# ------------------------------------------------------------------ loja
func buy(id: String, n: int = 1) -> Dictionary:
	var it := ItemDB.get_item(id)
	if it.is_empty():
		return {"ok": false, "msg": "Item inválido."}
	var cost := ItemDB.buy_price(id) * n
	if int(s["gold"]) < cost:
		return {"ok": false, "msg": "Ouro insuficiente."}
	if not can_add_item(id, n):
		return {"ok": false, "msg": "Inventário cheio."}
	s["gold"] = int(s["gold"]) - cost
	add_item(id, n)
	return {"ok": true, "msg": "Comprou %s x%d (-%d ouro)." % [it["name"], n, cost]}

func sell(id: String, n: int = 1) -> Dictionary:
	if item_count(id) < n:
		return {"ok": false, "msg": "Você não tem esta quantidade."}
	var gain := ItemDB.sell_price(id) * n
	remove_item(id, n)
	s["gold"] = int(s["gold"]) + gain
	emit_changed()
	return {"ok": true, "msg": "Vendeu %s x%d (+%d ouro)." % [ItemDB.get_item(id)["name"], n, gain]}

# ------------------------------------------------------------------ experiencia
## Retorna a lista de niveis alcancados.
func add_exp(n: int) -> Array:
	var gained: Array = []
	if n <= 0 or int(s["level"]) >= Balance.MAX_LEVEL:
		return gained
	s["exp"] = int(s["exp"]) + n
	while int(s["level"]) < Balance.MAX_LEVEL and int(s["exp"]) >= Formulas.exp_to_next(int(s["level"])):
		s["exp"] = int(s["exp"]) - Formulas.exp_to_next(int(s["level"]))
		s["level"] = int(s["level"]) + 1
		gained.append(int(s["level"]))
	if int(s["level"]) >= Balance.MAX_LEVEL:
		s["exp"] = 0
	if gained.size() > 0:
		_stats_cache.clear()
		if Balance.LEVEL_UP_FULL_RESTORE:
			s["hp"] = max_hp()
			s["mp"] = max_mp()
		level_up.emit(int(s["level"]))
	emit_changed()
	return gained

## Aplica recompensas {gold, exp, rep, items}. Retorna mensagens legiveis.
func grant_rewards(r: Dictionary, announce: bool = false) -> Array:
	var msgs: Array = []
	var gold := int(r.get("gold", 0))
	if gold > 0:
		s["gold"] = int(s["gold"]) + gold
		msgs.append("+%d ouro" % gold)
	var rep := int(r.get("rep", 0))
	if rep > 0:
		s["guild"]["reputation"] = int(s["guild"]["reputation"]) + rep
		msgs.append("+%d reputação" % rep)
	var xp := int(r.get("exp", 0))
	if xp > 0:
		msgs.append("+%d EXP" % xp)
		for lv in add_exp(xp):
			msgs.append("Subiu para o nível %d!" % int(lv))
	var items: Dictionary = r.get("items", {})
	for id in items:
		var n := int(items[id])
		var added := add_item(String(id), n)
		if added > 0:
			msgs.append("Obteve %s x%d" % [ItemDB.get_item(String(id))["name"], added])
		if added < n:
			var extra := n - added
			var g := ItemDB.sell_price(String(id)) * extra
			s["gold"] = int(s["gold"]) + g
			msgs.append("Inventário cheio: %s x%d vendido (+%d ouro)" % [ItemDB.get_item(String(id))["name"], extra, g])
	emit_changed()
	if announce:
		for m in msgs:
			say(String(m))
	return msgs

# ------------------------------------------------------------------ batalha
func make_hero_combatant() -> Combatant:
	return Battle.make_hero(String(s["class_id"]), int(s["level"]), stats(), String(s["hero_name"]), int(s["hp"]), int(s["mp"]))

## Aplica o resultado de uma batalha ao estado. Idempotente (recompensas pagas uma unica vez).
func finish_battle(b: Battle, hero: Combatant) -> Dictionary:
	var out := {"result": b.result, "messages": [], "rewards": {}, "levels": 0, "bosses": []}
	in_battle = false
	if b.claimed:
		return out
	b.claimed = true
	s["hp"] = clampi(hero.hp, 0, max_hp())
	s["mp"] = clampi(hero.mp, 0, max_mp())
	match b.result:
		"victory":
			s["hp"] = maxi(1, int(s["hp"]))
			var r := b.compute_rewards(int(s["level"]))
			out["rewards"] = r
			var before_level := int(s["level"])
			for id in r["kills"]:
				s["kills"][id] = int(s["kills"].get(id, 0)) + int(r["kills"][id])
				QuestSystem.notify_kill(String(id), int(r["kills"][id]))
			for boss in r["bosses"]:
				s["dungeon"]["bosses"][boss] = true
				out["bosses"].append(boss)
				if boss == "boss_elder_treant":
					s["dungeon"]["completed"] = true
			for u in r["unlocks"]:
				if u.has("class") and not (String(u["class"]) in s["unlocks"]["classes"]):
					s["unlocks"]["classes"].append(String(u["class"]))
			out["messages"] = grant_rewards(r)
			out["levels"] = int(s["level"]) - before_level
		"defeat":
			out["messages"] = apply_defeat()
	emit_changed()
	return out

## Derrota: perde parte do ouro, retorna a cidade com HP/MP restaurados.
func apply_defeat() -> Array:
	var lost := int(floor(float(s["gold"]) * Balance.DEATH_GOLD_PENALTY))
	s["gold"] = int(s["gold"]) - lost
	s["world"] = {"map": "ilha", "x": MapDB.TOWN_RESPAWN.x, "y": MapDB.TOWN_RESPAWN.y}
	s["dungeon"]["current_floor"] = 1
	_stats_cache.clear()
	s["hp"] = max_hp()
	s["mp"] = max_mp()
	var msgs: Array = ["Você desmaiou e foi levado de volta à cidade."]
	if lost > 0:
		msgs.append("Perdeu %d de ouro." % lost)
	return msgs

# ------------------------------------------------------------------ mundo / masmorra
func map_key(map_id: String) -> String:
	return map_id

func is_defeated(mkey: String, monster_id: String) -> bool:
	var d: Dictionary = s["defeated"].get(mkey, {})
	if not d.has(monster_id):
		return false
	if float(s["play_time"]) - float(d[monster_id]) >= Balance.MONSTER_RESPAWN_SECONDS:
		d.erase(monster_id)
		return false
	return true

func mark_defeated(mkey: String, monster_id: String) -> void:
	if not s["defeated"].has(mkey):
		s["defeated"][mkey] = {}
	s["defeated"][mkey][monster_id] = float(s["play_time"])

func clear_defeated(mkey: String) -> void:
	s["defeated"].erase(mkey)

func boss_defeated(boss_id: String) -> bool:
	return s["dungeon"]["bosses"].has(boss_id)

func floor_boss_defeated(floor_n: int) -> bool:
	if not EnemyDB.BOSS_BY_FLOOR.has(floor_n):
		return true
	return boss_defeated(EnemyDB.BOSS_BY_FLOOR[floor_n])

func can_descend_from(floor_n: int) -> bool:
	return floor_boss_defeated(floor_n)

func enter_floor(floor_n: int) -> void:
	s["dungeon"]["current_floor"] = floor_n
	if floor_n > int(s["dungeon"]["max_floor"]):
		s["dungeon"]["max_floor"] = floor_n
	emit_changed()

func rest_full() -> void:
	_stats_cache.clear()
	s["hp"] = max_hp()
	s["mp"] = max_mp()
	emit_changed()

func visit_area(area_id: String) -> bool:
	var first: bool = not s["explored"].has(area_id)
	s["explored"][area_id] = true
	QuestSystem.notify_explore(area_id)
	return first

func unlock_feature(id: String) -> void:
	if not (id in s["unlocks"]["features"]):
		s["unlocks"]["features"].append(id)

func flag(name: String, default_value = false):
	return s["flags"].get(name, default_value)

func set_flag(name: String, value = true) -> void:
	s["flags"][name] = value

func format_play_time() -> String:
	var t := int(float(s.get("play_time", 0.0)))
	return "%02d:%02d:%02d" % [t / 3600, (t / 60) % 60, t % 60]
