class_name GuildSystem
extends RefCounted
## Rank e reputacao da guilda (separados do nivel do personagem).

static func rank() -> String:
	return String(Game.s["guild"]["rank"])

static func reputation() -> int:
	return int(Game.s["guild"]["reputation"])

static func title() -> String:
	return "Rank %s — %s" % [rank(), QuestDB.RANK_TITLES.get(rank(), "")]

## Requisitos para a proxima promocao.
static func requirements() -> Dictionary:
	var target := QuestDB.next_rank(rank())
	if target == "":
		return {"target": "", "max": true}
	var p: Dictionary = QuestDB.PROMOTION[target]
	var qid: String = p["quest"]
	var qstate := QuestSystem.state_of(qid)
	var r := {
		"target": target, "max": false,
		"rep_req": int(p["rep"]), "rep_have": reputation(),
		"level_req": int(p["level"]), "level_have": int(Game.s["level"]),
		"quest_id": qid, "quest_state": qstate,
		"quest_done": qstate == "completed",
		"bonus_gold": int(p["bonus_gold"]),
	}
	r["rep_ok"] = r["rep_have"] >= r["rep_req"]
	r["level_ok"] = r["level_have"] >= r["level_req"]
	r["ok"] = r["rep_ok"] and r["level_ok"] and r["quest_done"]
	return r

static func promote() -> Dictionary:
	var r := requirements()
	if r.get("max", false):
		return {"ok": false, "msg": "Você já está no rank máximo."}
	if not r["ok"]:
		return {"ok": false, "msg": "Requisitos de promoção não cumpridos."}
	Game.s["guild"]["rank"] = r["target"]
	var bonus := int(r["bonus_gold"])
	Game.s["gold"] = int(Game.s["gold"]) + bonus
	Game.emit_changed()
	return {"ok": true, "msg": "Promovido para o Rank %s! (+%d ouro)" % [r["target"], bonus], "rank": r["target"]}
