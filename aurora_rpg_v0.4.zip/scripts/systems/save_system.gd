class_name SaveSystem
extends RefCounted
## Salvamento local em JSON com validacao, hash de integridade, escrita atomica e backup.
## Estados transitorios de combate NUNCA sao salvos: o jogo retoma sempre no mapa.

const PATH := "user://savegame.json"
const BACKUP_PATH := "user://savegame.bak.json"
const TMP_PATH := "user://savegame.tmp.json"

static func default_state() -> Dictionary:
	return {
		"version": Balance.SAVE_VERSION,
		"hero_name": "Herói",
		"class_id": "guerreiro",
		"subclass": "",
		"level": 1, "exp": 0, "hp": 1, "mp": 0, "gold": 0,
		"inventory": {},
		"equipment": {"weapon": "", "armor": "", "accessory": ""},
		"quests": {},               # id -> {state: active|completed, progress: {idx: n}}
		"quest_counts": {},         # id -> vezes concluida
		"guild": {"rank": "D", "reputation": 0},
		"dungeon": {"max_floor": 1, "bosses": {}, "completed": false, "current_floor": 1},
		"unlocks": {"classes": [], "features": []},
		"flags": {},
		"world": {"map": "ilha", "x": 14, "y": 12},
		"defeated": {},             # map_key -> {monster_id: tempo_da_morte}
		"opened": {},               # baus abertos (permanente)
		"gathered": {},             # arbustos colhidos: id -> tempo
		"explored": {},
		"kills": {},
		"play_time": 0.0,
		"saved_at": "",
	}

# ------------------------------------------------------------------ utilitarios
static func _int(v, default_value: int = 0) -> int:
	if v is int:
		return v
	if v is float:
		return int(v)
	if v is String and String(v).is_valid_int():
		return int(v)
	return default_value

static func _dict(v) -> Dictionary:
	return v if v is Dictionary else {}

static func _compute_hash(body: String) -> String:
	return (body + "|aurora-v1").md5_text()

# ------------------------------------------------------------------ validacao
## Converte dados brutos (JSON) em estado valido. Retorna {ok, error, state, warnings}
static func sanitize(raw) -> Dictionary:
	var warnings: Array = []
	if not (raw is Dictionary):
		return {"ok": false, "error": "Formato de save inválido.", "state": {}, "warnings": warnings}
	var d: Dictionary = raw
	var s := default_state()
	var ver := _int(d.get("version", 0))
	if ver < 1 or ver > Balance.SAVE_VERSION:
		return {"ok": false, "error": "Versão de save incompatível (%d)." % ver, "state": {}, "warnings": warnings}
	var cid := String(d.get("class_id", ""))
	if not HeroDB.class_exists(cid):
		return {"ok": false, "error": "Classe inválida no save.", "state": {}, "warnings": warnings}
	s["class_id"] = cid
	s["hero_name"] = String(d.get("hero_name", "Herói")).substr(0, 14)
	var sub := String(d.get("subclass", ""))
	s["subclass"] = sub if HeroDB.SUBCLASSES.has(sub) and HeroDB.SUBCLASSES[sub]["parent"] == cid else ""
	var lvl := clampi(_int(d.get("level", 1), 1), 1, Balance.MAX_LEVEL)
	s["level"] = lvl
	var need := Formulas.exp_to_next(lvl)
	s["exp"] = clampi(_int(d.get("exp", 0)), 0, maxi(0, need - 1) if need > 0 else 0)
	s["gold"] = maxi(0, _int(d.get("gold", 0)))
	# inventario
	var inv := {}
	var raw_inv := _dict(d.get("inventory", {}))
	for id in raw_inv:
		var n := clampi(_int(raw_inv[id]), 0, Balance.STACK_LIMIT)
		if n <= 0:
			continue
		if not ItemDB.exists(String(id)):
			warnings.append("Item desconhecido removido: %s" % id)
			continue
		if inv.size() >= Balance.INVENTORY_LIMIT:
			warnings.append("Inventário excedeu o limite; item descartado: %s" % id)
			continue
		inv[String(id)] = n
	s["inventory"] = inv
	# equipamentos
	var eq := {"weapon": "", "armor": "", "accessory": ""}
	var raw_eq := _dict(d.get("equipment", {}))
	for slot in eq:
		var iid := String(raw_eq.get(slot, ""))
		if iid != "" and ItemDB.exists(iid) and ItemDB.get_item(iid).get("slot", "") == slot:
			eq[slot] = iid
		elif iid != "":
			warnings.append("Equipamento inválido removido: %s" % iid)
	s["equipment"] = eq
	# guilda
	var g := _dict(d.get("guild", {}))
	var rank := String(g.get("rank", "D"))
	s["guild"] = {"rank": rank if rank in QuestDB.RANKS else "D", "reputation": maxi(0, _int(g.get("reputation", 0)))}
	# missoes
	var qs := {}
	var raw_q := _dict(d.get("quests", {}))
	for qid in raw_q:
		if not QuestDB.QUESTS.has(String(qid)):
			continue
		var qe := _dict(raw_q[qid])
		var st := String(qe.get("state", ""))
		if st != "active" and st != "completed":
			continue
		var prog := {}
		var raw_p := _dict(qe.get("progress", {}))
		for k in raw_p:
			prog[String(k)] = maxi(0, _int(raw_p[k]))
		qs[String(qid)] = {"state": st, "progress": prog}
	s["quests"] = qs
	var qc := {}
	for qid in _dict(d.get("quest_counts", {})):
		if QuestDB.QUESTS.has(String(qid)):
			qc[String(qid)] = maxi(0, _int(d["quest_counts"][qid]))
	s["quest_counts"] = qc
	# masmorra
	var dg := _dict(d.get("dungeon", {}))
	var bosses := {}
	for bid in _dict(dg.get("bosses", {})):
		if EnemyDB.exists(String(bid)):
			bosses[String(bid)] = true
	var max_fl := clampi(_int(dg.get("max_floor", 1), 1), 1, Balance.DUNGEON_FLOORS)
	# nao permite andar alem de chefes nao derrotados (consistencia)
	for bf in Balance.BOSS_FLOORS:
		if max_fl > bf and not bosses.has(EnemyDB.BOSS_BY_FLOOR[bf]):
			max_fl = bf
			warnings.append("Progresso de andar corrigido para %d." % bf)
	s["dungeon"] = {"max_floor": max_fl, "bosses": bosses, "completed": bool(dg.get("completed", false)) and bosses.has("boss_elder_treant"),
		"current_floor": clampi(_int(dg.get("current_floor", 1), 1), 1, max_fl)}
	# desbloqueios / flags
	var un := _dict(d.get("unlocks", {}))
	var ucl: Array = []
	for c in un.get("classes", []):
		if HeroDB.SPECIAL_CLASSES.has(String(c)) and not (String(c) in ucl):
			ucl.append(String(c))
	var feats: Array = []
	for f in un.get("features", []):
		feats.append(String(f))
	s["unlocks"] = {"classes": ucl, "features": feats}
	var flags := {}
	for k in _dict(d.get("flags", {})):
		flags[String(k)] = d["flags"][k]
	s["flags"] = flags
	# mundo
	var w := _dict(d.get("world", {}))
	s["world"] = {"map": String(w.get("map", "ilha")), "x": _int(w.get("x", 14)), "y": _int(w.get("y", 12))}
	for key in ["defeated", "gathered"]:
		var out := {}
		for mk in _dict(d.get(key, {})):
			if key == "defeated":
				var inner := {}
				for mid in _dict(d[key][mk]):
					inner[String(mid)] = float(d[key][mk][mid])
				out[String(mk)] = inner
			else:
				out[String(mk)] = float(d[key][mk])
		s[key] = out
	for key in ["opened", "explored"]:
		var o := {}
		for k in _dict(d.get(key, {})):
			o[String(k)] = true
		s[key] = o
	var kills := {}
	for k in _dict(d.get("kills", {})):
		kills[String(k)] = maxi(0, _int(d["kills"][k]))
	s["kills"] = kills
	s["play_time"] = maxf(0.0, float(d.get("play_time", 0.0)))
	s["saved_at"] = String(d.get("saved_at", ""))
	# hp/mp (limitados depois pelo Game conforme atributos)
	s["hp"] = maxi(1, _int(d.get("hp", 1), 1))
	s["mp"] = maxi(0, _int(d.get("mp", 0)))
	return {"ok": true, "error": "", "state": s, "warnings": warnings}

# ------------------------------------------------------------------ disco
static func has_save() -> bool:
	return FileAccess.file_exists(PATH) or FileAccess.file_exists(BACKUP_PATH)

static func serialize(state: Dictionary) -> String:
	var body := JSON.stringify(state)
	return JSON.stringify({"body": body, "hash": _compute_hash(body)})

static func write(state: Dictionary, path: String = PATH) -> Dictionary:
	var s: Dictionary = state.duplicate(true)
	s["saved_at"] = Time.get_datetime_string_from_system()
	var text := serialize(s)
	var tmp := TMP_PATH if path == PATH else path + ".tmp"
	var f := FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		return {"ok": false, "error": "Não foi possível gravar o save (erro %d)." % FileAccess.get_open_error()}
	f.store_string(text)
	f.close()
	# rotaciona backup e troca atomicamente
	if FileAccess.file_exists(path):
		DirAccess.copy_absolute(ProjectSettings.globalize_path(path), ProjectSettings.globalize_path(BACKUP_PATH if path == PATH else path + ".bak"))
	var err := DirAccess.rename_absolute(ProjectSettings.globalize_path(tmp), ProjectSettings.globalize_path(path))
	if err != OK:
		return {"ok": false, "error": "Falha ao finalizar o save (erro %d)." % err}
	return {"ok": true, "error": ""}

static func _read_file(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {"ok": false, "error": "Arquivo de save não encontrado."}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {"ok": false, "error": "Não foi possível abrir o save."}
	var text := f.get_as_text()
	f.close()
	var json := JSON.new()
	if json.parse(text) != OK:
		return {"ok": false, "error": "Save corrompido (JSON inválido)."}
	var wrapper = json.data
	if not (wrapper is Dictionary) or not wrapper.has("body") or not (wrapper["body"] is String):
		return {"ok": false, "error": "Save corrompido (estrutura)."}
	var body: String = wrapper["body"]
	if String(wrapper.get("hash", "")) != _compute_hash(body):
		return {"ok": false, "error": "Save corrompido (verificação de integridade falhou)."}
	var inner := JSON.new()
	if inner.parse(body) != OK:
		return {"ok": false, "error": "Save corrompido (conteúdo)."}
	return sanitize(inner.data)

## Le o save principal; se invalido tenta o backup.
static func read(path: String = PATH) -> Dictionary:
	var r := _read_file(path)
	if r["ok"]:
		return r
	var bak := BACKUP_PATH if path == PATH else path + ".bak"
	if FileAccess.file_exists(bak):
		var rb := _read_file(bak)
		if rb["ok"]:
			rb["warnings"].append("Save principal inválido (%s). Backup carregado." % r["error"])
			return rb
	return r

static func delete_all(path: String = PATH) -> void:
	for p in [path, path + ".tmp", BACKUP_PATH if path == PATH else path + ".bak", TMP_PATH]:
		if FileAccess.file_exists(p):
			DirAccess.remove_absolute(ProjectSettings.globalize_path(p))
