class_name QuestSystem
extends RefCounted
## Logica de missoes. Opera sobre o estado em Game.s. Recompensas so sao pagas uma vez
## (estado "completed" e marcado ANTES de pagar; contratos repetiveis reiniciam depois).

const MAX_ACTIVE := 6

static func entry(qid: String) -> Dictionary:
	return Game.s.get("quests", {}).get(qid, {})

## available | active | completed | locked
static func state_of(qid: String) -> String:
	var q: Dictionary = QuestDB.QUESTS.get(qid, {})
	if q.is_empty():
		return "locked"
	var e := entry(qid)
	if not e.is_empty():
		return String(e["state"])
	var rank_i := QuestDB.rank_index(String(Game.s["guild"]["rank"]))
	if rank_i < QuestDB.rank_index(String(q["rank"])):
		return "locked"
	if q.get("kind", "normal") == "eval":
		var req: Dictionary = QuestDB.PROMOTION.get(String(q["eval_for"]), {})
		if QuestDB.rank_index(String(Game.s["guild"]["rank"])) != QuestDB.rank_index(String(q["eval_for"])) - 1:
			return "locked"
		if int(Game.s["guild"]["reputation"]) < int(req.get("rep", 0)) or int(Game.s["level"]) < int(req.get("level", 1)):
			return "locked"
	return "available"

static func lock_reason(qid: String) -> String:
	var q: Dictionary = QuestDB.QUESTS.get(qid, {})
	if q.is_empty():
		return ""
	if QuestDB.rank_index(String(Game.s["guild"]["rank"])) < QuestDB.rank_index(String(q["rank"])):
		return "Requer rank %s." % q["rank"]
	if q.get("kind", "") == "eval":
		var req: Dictionary = QuestDB.PROMOTION.get(String(q["eval_for"]), {})
		return "Requer Nv %d e %d de reputação." % [int(req.get("level", 1)), int(req.get("rep", 0))]
	return ""

static func active_count() -> int:
	var n := 0
	for qid in Game.s["quests"]:
		if Game.s["quests"][qid]["state"] == "active":
			n += 1
	return n

static func objective_progress(qid: String, idx: int) -> int:
	var q: Dictionary = QuestDB.QUESTS[qid]
	var o: Dictionary = q["objectives"][idx]
	var need := int(o["count"])
	var cur := 0
	match String(o["type"]):
		"kill", "explore":
			var e := entry(qid)
			cur = int(e.get("progress", {}).get(str(idx), 0)) if not e.is_empty() else 0
		"collect":
			cur = Game.item_count(String(o["target"]))
		"boss":
			cur = 1 if Game.s["dungeon"]["bosses"].has(String(o["target"])) else 0
		"reach_floor":
			cur = 1 if int(Game.s["dungeon"]["max_floor"]) >= int(String(o["target"])) else 0
		"dungeon":
			cur = 1 if bool(Game.s["dungeon"]["completed"]) else 0
		"locked":
			cur = 0
	return mini(cur, need)

static func is_ready(qid: String) -> bool:
	if state_of(qid) != "active":
		return false
	var q: Dictionary = QuestDB.QUESTS[qid]
	for i in range(q["objectives"].size()):
		if objective_progress(qid, i) < int(q["objectives"][i]["count"]):
			return false
	return true

static func progress_text(qid: String) -> String:
	var q: Dictionary = QuestDB.QUESTS[qid]
	var parts: Array = []
	for i in range(q["objectives"].size()):
		var o: Dictionary = q["objectives"][i]
		if o["type"] == "locked":
			parts.append("%s (indisponível)" % o["text"])
		else:
			parts.append("%s: %d/%d" % [o["text"], objective_progress(qid, i), int(o["count"])])
	return "\n".join(parts)

static func accept(qid: String) -> Dictionary:
	var st := state_of(qid)
	if st == "active":
		return {"ok": false, "msg": "Você já aceitou esta missão."}
	if st == "completed":
		return {"ok": false, "msg": "Missão já concluída."}
	if st != "available":
		return {"ok": false, "msg": lock_reason(qid)}
	var q: Dictionary = QuestDB.QUESTS[qid]
	for o in q["objectives"]:
		if o["type"] == "locked":
			return {"ok": false, "msg": "Esta missão ainda não está disponível nesta versão."}
	if active_count() >= MAX_ACTIVE:
		return {"ok": false, "msg": "Você já tem %d missões ativas." % MAX_ACTIVE}
	Game.s["quests"][qid] = {"state": "active", "progress": {}}
	Game.emit_changed()
	return {"ok": true, "msg": "Missão aceita: %s" % q["name"]}

static func abandon(qid: String) -> Dictionary:
	if state_of(qid) != "active":
		return {"ok": false, "msg": "Missão não está ativa."}
	Game.s["quests"].erase(qid)
	Game.emit_changed()
	return {"ok": true, "msg": "Missão abandonada."}

## Quantos espacos novos de pilha os itens de recompensa precisam.
static func _reward_fits(items: Dictionary, removing: Dictionary) -> bool:
	var inv: Dictionary = Game.s["inventory"].duplicate()
	for id in removing:
		inv[id] = int(inv.get(id, 0)) - int(removing[id])
		if inv[id] <= 0:
			inv.erase(id)
	for id in items:
		var have := int(inv.get(id, 0))
		if have == 0 and inv.size() >= Balance.INVENTORY_LIMIT:
			return false
		if have + int(items[id]) > Balance.STACK_LIMIT:
			return false
		inv[id] = have + int(items[id])
	return true

static func turn_in(qid: String) -> Dictionary:
	var st := state_of(qid)
	if st == "completed":
		return {"ok": false, "msg": "Recompensa já recebida.", "messages": []}
	if st != "active":
		return {"ok": false, "msg": "Missão não está ativa.", "messages": []}
	if not is_ready(qid):
		return {"ok": false, "msg": "Objetivos ainda incompletos.", "messages": []}
	var q: Dictionary = QuestDB.QUESTS[qid]
	var remove := {}
	for o in q["objectives"]:
		if o["type"] == "collect":
			remove[o["target"]] = int(remove.get(o["target"], 0)) + int(o["count"])
	var rw: Dictionary = q["rewards"]
	if not _reward_fits(rw.get("items", {}), remove):
		return {"ok": false, "msg": "Inventário cheio! Libere espaço antes de receber a recompensa.", "messages": []}
	# marca ANTES de pagar (anti-duplicacao)
	if q.get("kind", "normal") == "repeatable":
		Game.s["quests"].erase(qid)
	else:
		Game.s["quests"][qid]["state"] = "completed"
	Game.s["quest_counts"][qid] = int(Game.s["quest_counts"].get(qid, 0)) + 1
	for id in remove:
		Game.remove_item(id, int(remove[id]))
	var msgs: Array = Game.grant_rewards({"gold": int(rw.get("gold", 0)), "exp": int(rw.get("exp", 0)), "rep": int(rw.get("rep", 0)), "items": rw.get("items", {})}, false)
	Game.emit_changed()
	return {"ok": true, "msg": "Missão concluída: %s" % q["name"], "messages": msgs}

# ------------------------------------------------------------ notificacoes
static func notify_kill(enemy_id: String, n: int = 1) -> void:
	for qid in Game.s["quests"]:
		var e: Dictionary = Game.s["quests"][qid]
		if e["state"] != "active":
			continue
		var q: Dictionary = QuestDB.QUESTS[qid]
		for i in range(q["objectives"].size()):
			var o: Dictionary = q["objectives"][i]
			if o["type"] == "kill" and (o["target"] == enemy_id or o["target"] == "*"):
				var k := str(i)
				e["progress"][k] = mini(int(o["count"]), int(e["progress"].get(k, 0)) + n)

static func notify_explore(area_id: String) -> void:
	for qid in Game.s["quests"]:
		var e: Dictionary = Game.s["quests"][qid]
		if e["state"] != "active":
			continue
		var q: Dictionary = QuestDB.QUESTS[qid]
		for i in range(q["objectives"].size()):
			var o: Dictionary = q["objectives"][i]
			if o["type"] == "explore" and o["target"] == area_id:
				e["progress"][str(i)] = int(o["count"])

## Quests "prontas" para entregar (para o indicador na HUD).
static func ready_ids() -> Array:
	var out: Array = []
	for qid in Game.s["quests"]:
		if is_ready(qid):
			out.append(qid)
	return out
