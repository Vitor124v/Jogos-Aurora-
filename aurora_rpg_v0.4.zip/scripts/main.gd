extends Node
## Raiz do jogo: liga titulo, mundo e interface.

var ui: UIRoot
var world: World
var title: TitleUI

func _ready() -> void:
	get_tree().set_auto_accept_quit(false)
	if bool(Game.settings.get("integer_scale", false)):
		get_window().content_scale_stretch = Window.CONTENT_SCALE_STRETCH_INTEGER
	Audio.set_music_volume(float(Game.settings["music"]))
	DisplayServer.screen_set_keep_on(true)
	world = World.new()
	add_child(world)
	ui = UIRoot.new()
	add_child(ui)
	world.ui = ui
	title = TitleUI.new()
	ui.title_holder.add_child(title)
	title.new_game_requested.connect(_on_new_game)
	title.continue_requested.connect(_on_continue)
	title.quit_requested.connect(_quit)
	ui.pause.request_town.connect(_on_request_town)
	ui.pause.request_title.connect(show_title)
	Game.level_up.connect(func(lv: int): Game.say("Nível %d alcançado!" % lv, UIKit.C_GOLD))
	show_title()

func show_title() -> void:
	world.set_active(false)
	ui.set_game_ui(false)
	Game.has_game = false
	Game.in_battle = false
	Game.ui_lock = 0
	Audio.play_music("menu")
	title.show_menu()
	await ui.fade(0.0, 0.2)

func _on_new_game(class_id: String, hero_name: String) -> void:
	Game.new_game(class_id, hero_name)
	await _begin(true)

func _on_continue() -> void:
	await _begin(false)

func _begin(is_new: bool) -> void:
	await ui.fade(1.0, 0.25)
	title.visible = false
	ui.set_game_ui(true)
	world.set_active(true)
	Game.has_game = true
	await world.start_from_save()
	if is_new:
		await world.intro()
	if not is_new and Game.last_load_warnings.size() > 0:
		Game.say(String(Game.last_load_warnings[0]), UIKit.C_BAD)

func _on_request_town() -> void:
	await world.go_to_map("ilha", MapDB.TOWN_RESPAWN, "down")

func _quit() -> void:
	_autosave()
	get_tree().quit()

func _autosave() -> void:
	if Game.has_game and not Game.in_battle and world.active and world.map != null:
		Game.save_game()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_quit()
	elif what == NOTIFICATION_APPLICATION_PAUSED:
		_autosave()
