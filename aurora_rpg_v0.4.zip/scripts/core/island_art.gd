class_name IslandArt
extends RefCounted
## Arte procedural do mapa-mundi (Ilha de Aurora): agua com espuma, praias, florestas, montanhas,
## gelo, cinzas, lava, casas e o Castelo Demoniaco. Os tiles olham os vizinhos para criar bordas e transicoes.

const BUILD := "RUZKOWgDmYXCVEe"
const CASTLE := "XYCVEe"
const GROUND_CH := ".,spnkia"
const TALL := "PQAFdy"      # arvores altas: 16x24, copa desenhada acima do jogador

static var _cache: Dictionary = {}
static var _frame: int = 0     # quadro da animacao da agua/lava (0 ou 1)

# ============================================================== utilitarios
static func _at(m: MapData, x: int, y: int) -> String:
	if x < 0 or y < 0 or x >= m.w or y >= m.h:
		return "~"
	return m.rows[y][x]

static func _new() -> Image:
	return PixelArt._new(16, 16)

static func _h(x: int, y: int, salt: int) -> int:
	return PixelArt._hash(x, y, salt)

static func _px(img: Image, x: int, y: int, c: Color) -> void:
	PixelArt.px(img, x, y, c)

static func _rect(img: Image, x0: int, y0: int, x1: int, y1: int, c: Color) -> void:
	PixelArt.rect(img, x0, y0, x1, y1, c)

static func _shade(c: Color, f: float) -> Color:
	return PixelArt.shade(c, f)

static func _tri(img: Image, ax: float, ay: float, bx: float, by: float, cx: float, cy: float, col: Color) -> void:
	var minx := int(floor(minf(ax, minf(bx, cx))))
	var maxx := int(ceil(maxf(ax, maxf(bx, cx))))
	var miny := int(floor(minf(ay, minf(by, cy))))
	var maxy := int(ceil(maxf(ay, maxf(by, cy))))
	var den := (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
	if absf(den) < 0.0001:
		return
	for yy in range(miny, maxy + 1):
		for xx in range(minx, maxx + 1):
			var px := float(xx) + 0.5
			var py := float(yy) + 0.5
			var a := ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / den
			var b := ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / den
			var c := 1.0 - a - b
			if a >= 0.0 and b >= 0.0 and c >= 0.0:
				_px(img, xx, yy, col)

static func _side_px(side: int, d: int, i: int) -> Vector2i:
	match side:
		0: return Vector2i(i, d)
		1: return Vector2i(i, 15 - d)
		2: return Vector2i(d, i)
	return Vector2i(15 - d, i)

const DIRS := [Vector2i(0, -1), Vector2i(0, 1), Vector2i(-1, 0), Vector2i(1, 0)]

static func _edge(img: Image, side: int, cols: Array, probs: Array, x: int, y: int, salt: int) -> void:
	for d in range(cols.size()):
		for i in range(16):
			if _h(x * 16 + i + side * 5, y * 16 + d, salt) < int(probs[d] * 1000.0):
				var p := _side_px(side, d, i)
				_px(img, p.x, p.y, cols[d])

# ============================================================== chao
static func _gcat(ch: String) -> String:
	if ch == ",":
		return "."
	return ch

static func ground_color(ch: String) -> Color:
	match ch:
		"s": return Color(0.87, 0.80, 0.55)
		"n": return Color(0.92, 0.95, 0.98)
		"k": return Color(0.22, 0.17, 0.24)
		"p": return Color(0.70, 0.56, 0.36)
		"i": return Color(0.93, 0.80, 0.47)
		"a": return Color(0.30, 0.33, 0.18)
	return Color(0.36, 0.64, 0.30)

static func _ground_base(ch: String, x: int, y: int) -> Image:
	var img := _new()
	match ch:
		".":
			_grass2(img, x, y, false)
		",":
			_grass2(img, x, y, true)
		"i":
			var bd := Color(0.93, 0.80, 0.47)
			img.fill(bd)
			for k in range(3):
				var yy := 3 + k * 5 + (_h(x, y, 500 + k) % 3)
				var x0 := _h(x, y, 510 + k) % 6
				for xx in range(x0, x0 + 9):
					_px(img, xx, yy, _shade(bd, 0.88))
					_px(img, xx, yy + 1, _shade(bd, 1.07))
			for k in range(6):
				var hh4 := _h(x, y, 520 + k)
				_px(img, hh4 % 16, (hh4 / 16) % 16, Color(1.0, 0.92, 0.65) if k % 2 == 0 else Color(0.80, 0.64, 0.34))
		"a":
			var bm := Color(0.30, 0.33, 0.18)
			img.fill(bm)
			for k in range(10):
				var hh5 := _h(x, y, 540 + k)
				_px(img, hh5 % 16, (hh5 / 16) % 16, _shade(bm, 1.25) if k % 2 == 0 else _shade(bm, 0.72))
			var hp := _h(x, y, 560)
			if hp < 200:
				PixelArt.ell(img, 3 + hp % 9, 4 + (hp / 9) % 8, 2.6, 1.5, Color(0.15, 0.30, 0.30))
				_px(img, 3 + hp % 9, 3 + (hp / 9) % 8, Color(0.30, 0.50, 0.48))
			var hr := _h(x, y, 570)
			if hr < 170:
				var rx := 2 + hr % 12
				var ry := 5 + (hr / 12) % 7
				_rect(img, rx, ry, rx, ry + 3, Color(0.36, 0.56, 0.22))
				_px(img, rx, ry - 1, Color(0.55, 0.40, 0.22))
		"p":
			PixelArt._dirt(img, x, y, Color(0.70, 0.56, 0.36))
		"s":
			var b := ground_color("s")
			img.fill(b)
			for i in range(12):
				var hh := _h(x, y, 120 + i)
				_px(img, hh % 16, (hh / 16) % 16, _shade(b, 1.08) if i % 2 == 0 else _shade(b, 0.86))
			var hs := _h(x, y, 140)
			if hs < 40:
				_px(img, 3 + hs % 10, 4 + (hs / 10) % 8, Color(0.95, 0.88, 0.80))
		"n":
			var b2 := ground_color("n")
			img.fill(b2)
			for i in range(10):
				var hh2 := _h(x, y, 160 + i)
				_px(img, hh2 % 16, (hh2 / 16) % 16, Color(0.78, 0.86, 0.96) if i % 2 == 0 else Color(1, 1, 1))
		"k":
			var b3 := ground_color("k")
			img.fill(b3)
			for i in range(12):
				var hh3 := _h(x, y, 180 + i)
				_px(img, hh3 % 16, (hh3 / 16) % 16, Color(0.30, 0.22, 0.30) if i % 2 == 0 else Color(0.14, 0.10, 0.16))
			var he := _h(x, y, 199)
			if he < 55:
				_px(img, he % 16, (he / 16) % 16, Color(0.75, 0.25, 0.12))
		_:
			img.fill(Color(0.36, 0.64, 0.30))
	return img

static func _grass2(img: Image, x: int, y: int, flowers: bool) -> void:
	var base := Color(0.36, 0.64, 0.30) if not flowers else Color(0.33, 0.60, 0.28)
	var tone := 0.97 + 0.06 * float(_h(x, y, 61)) / 1000.0
	base = Color(base.r * tone, base.g * tone, base.b * tone, 1.0)
	img.fill(base)
	for i in range(9):
		var hh := _h(x, y, i)
		_px(img, hh % 16, (hh / 16) % 16, _shade(base, 1.14) if i % 2 == 0 else _shade(base, 0.84))
	for i in range(2):
		var ht := _h(x, y, 70 + i)
		if ht < 520:
			var tx := 2 + ht % 12
			var ty := 4 + (ht / 12) % 9
			_px(img, tx, ty, _shade(base, 0.62))
			_px(img, tx, ty - 1, _shade(base, 1.38))
			_px(img, tx - 1, ty - 1, _shade(base, 1.2))
			_px(img, tx + 1, ty - 1, _shade(base, 1.2))
	if flowers:
		var cols := [Color(1.0, 0.95, 0.5), Color(0.98, 0.55, 0.65), Color(1, 1, 1), Color(0.6, 0.75, 1.0)]
		for i in range(2):
			var hf := _h(x, y, 90 + i)
			if hf < 700:
				var fx := 3 + hf % 10
				var fy := 4 + (hf / 10) % 9
				var c: Color = cols[(hf / 7) % 4]
				_px(img, fx, fy + 1, Color(0.2, 0.45, 0.2))
				_px(img, fx, fy, c)
				_px(img, fx - 1, fy, _shade(c, 0.88))
				_px(img, fx + 1, fy, _shade(c, 0.88))
				_px(img, fx, fy - 1, _shade(c, 1.0))

static func _ground_with_edges(m: MapData, x: int, y: int, ch: String) -> Image:
	var img := _ground_base(ch, x, y)
	var cat := _gcat(ch)
	for side in range(4):
		var nb := _at(m, x + DIRS[side].x, y + DIRS[side].y)
		if nb == "w" or nb == "~" or nb == "=":
			var bank: Array
			match cat:
				"a": bank = [Color(0.16, 0.18, 0.09), Color(0.24, 0.27, 0.13)]
				"i": bank = [Color(0.78, 0.64, 0.36), Color(0.86, 0.72, 0.42)]
				"s": bank = [Color(0.72, 0.64, 0.42), Color(0.80, 0.72, 0.48)]
				"n": bank = [Color(0.62, 0.74, 0.86), Color(0.80, 0.88, 0.96)]
				"k": bank = [Color(0.10, 0.07, 0.12), Color(0.16, 0.12, 0.18)]
				"p": bank = [Color(0.45, 0.34, 0.20), Color(0.58, 0.45, 0.28)]
				_: bank = [Color(0.20, 0.34, 0.18), Color(0.28, 0.46, 0.22)]
			_edge(img, side, bank, [1.0, 0.55], x, y, 210)
		elif cat == "p":
			if GROUND_CH.contains(nb) and nb != "p":
				_edge(img, side, [Color(0.55, 0.42, 0.26)], [0.55], x, y, 220)
		elif GROUND_CH.contains(nb) and nb != "p" and _gcat(nb) != cat:
			_edge(img, side, [ground_color(nb), ground_color(nb), ground_color(nb)], [0.62, 0.34, 0.12], x, y, 230)
	var above := _at(m, x, y - 1)
	if _is_build(above):
		var rows := 4 if CASTLE.contains(above) else 3
		for yy in range(rows):
			var f := 0.70 + 0.09 * float(yy)
			for xx in range(16):
				img.set_pixel(xx, yy, _shade(img.get_pixel(xx, yy), f))
	return img

static func _ground_under(m: MapData, x: int, y: int, ch: String) -> String:
	if ch == "A" or ch == "I":
		return "n"
	if ch == "z":
		return "k"
	var counts := {".": 0, "s": 0, "n": 0, "k": 0, "i": 0, "a": 0}
	for dy in range(-2, 3):
		for dx in range(-2, 3):
			var c := _gcat(_at(m, x + dx, y + dy))
			if counts.has(c):
				counts[c] += 1
	var best := "."
	var bc: int = counts["."]
	for k in ["s", "n", "k", "i", "a"]:
		if counts[k] > bc:
			best = k
			bc = counts[k]
	if ch == "Q" and best == ".":
		return "."
	return best

# ============================================================== agua
static func _is_land(ch: String) -> bool:
	return not (ch == "w" or ch == "~" or ch == "B" or ch == "l" or ch == "=")

static func _water(m: MapData, x: int, y: int, ch: String) -> Image:
	var mask := 0
	for side in range(4):
		if _is_land(_at(m, x + DIRS[side].x, y + DIRS[side].y)):
			mask |= 1 << side
	var corners := 0
	var cd := [Vector2i(-1, -1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(1, 1)]
	for i in range(4):
		if _is_land(_at(m, x + cd[i].x, y + cd[i].y)):
			corners |= 1 << i
	var v := _h(x, y, 300) % 4
	var key := "w|%s|%d|%d|%d|%d" % [ch, mask, corners, v, _frame]
	if _cache.has(key):
		return _cache[key]
	var base := Color(0.27, 0.58, 0.88) if ch == "w" else Color(0.15, 0.40, 0.74)
	var img := _new()
	img.fill(base)
	for i in range(7):
		var hh := _h(v * 31 + i + _frame * 57, i * 7 + v + _frame * 3, 310)
		var wx := hh % 13
		var wy := (hh / 13) % 15
		var hi := _shade(base, 1.22)
		_px(img, wx, wy, hi)
		_px(img, wx + 1, wy, hi)
		_px(img, wx + 2, wy, _shade(base, 1.1))
		_px(img, wx + 3, wy + 1, _shade(base, 0.85))
	var foam_a := Color(0.92, 0.98, 1.0)
	var foam_b := Color(0.62, 0.84, 1.0)
	for side in range(4):
		if mask & (1 << side):
			_edge(img, side, [foam_a, foam_b, _shade(foam_b, 0.95)], [0.85, 0.65, 0.18], v * 3, side * 11 + v, 320)
	var cpos := [Vector2i(0, 0), Vector2i(14, 0), Vector2i(0, 14), Vector2i(14, 14)]
	for i in range(4):
		if corners & (1 << i):
			# so desenha o canto se os dois lados adjacentes forem agua
			var horiz: int = 2 if (i % 2 == 0) else 3
			var vert: int = 0 if i < 2 else 1
			if not (mask & (1 << horiz)) and not (mask & (1 << vert)):
				_rect(img, cpos[i].x, cpos[i].y, cpos[i].x + 1, cpos[i].y + 1, foam_a)
	_cache[key] = img
	return img

static func _swamp_water(m: MapData, x: int, y: int) -> Image:
	var mask := 0
	for side in range(4):
		var nb := _at(m, x + DIRS[side].x, y + DIRS[side].y)
		if not (nb == "=" or nb == "w" or nb == "~" or nb == "B"):
			mask |= 1 << side
	var v := _h(x, y, 900) % 4
	var key := "sw|%d|%d|%d" % [mask, v, _frame]
	if _cache.has(key):
		return _cache[key]
	var base := Color(0.13, 0.27, 0.24)
	var img := _new()
	img.fill(base)
	for i in range(6):
		var hh := _h(v * 17 + i + _frame * 41, i * 5 + v, 910)
		_px(img, hh % 14, (hh / 14) % 15, Color(0.22, 0.40, 0.34))
		_px(img, hh % 14 + 1, (hh / 14) % 15, Color(0.18, 0.34, 0.30))
	if v % 2 == 0:
		PixelArt.ell(img, 4 + v * 2, 6 + v, 2.6, 1.6, Color(0.22, 0.52, 0.24))
		_px(img, 4 + v * 2, 5 + v, Color(0.13, 0.27, 0.24))
		if v == 2:
			_px(img, 5 + v * 2, 5 + v, Color(0.95, 0.55, 0.70))
	if v == 1:
		PixelArt.ell(img, 11, 11, 2.2, 1.4, Color(0.20, 0.46, 0.22))
	for side in range(4):
		if mask & (1 << side):
			_edge(img, side, [Color(0.18, 0.16, 0.08), Color(0.28, 0.26, 0.13)], [1.0, 0.6], x, y, 920)
	_cache[key] = img
	return img

static func _bridge(m: MapData, x: int, y: int) -> Image:
	var up := _at(m, x, y - 1)
	var dn := _at(m, x, y + 1)
	var lf := _at(m, x - 1, y)
	var rt := _at(m, x + 1, y)
	var liquid := "l" if (up == "l" or dn == "l" or lf == "l" or rt == "l") else "w"
	var up_w := up == "w" or up == "~" or up == "l"
	var dn_w := dn == "w" or dn == "~" or dn == "l"
	var lf_w := lf == "w" or lf == "~" or lf == "l"
	var rt_w := rt == "w" or rt == "~" or rt == "l"
	var horizontal := true
	if (lf_w or rt_w) and not (up_w or dn_w):
		horizontal = false
	var key := "b|%s|%s|%d%d%d%d|%d|%d" % [liquid, str(horizontal), int(up_w), int(dn_w), int(lf_w), int(rt_w), (x + y) % 2, _frame]
	if _cache.has(key):
		return _cache[key]
	var img: Image
	if liquid == "l":
		img = _lava_img(0, 0, x, y)
	else:
		img = _new()
		img.fill(Color(0.27, 0.58, 0.88))
		for i in range(5):
			var hh := _h(x + _frame * 5, y, 330 + i)
			_px(img, hh % 14, (hh / 14) % 14, Color(0.5, 0.78, 1.0))
	var wood := Color(0.62, 0.42, 0.22)
	var dark := Color(0.34, 0.21, 0.10)
	var light := Color(0.78, 0.56, 0.32)
	if horizontal:
		var y0 := 1 if up_w else 0
		var y1 := 14 if dn_w else 15
		_rect(img, 0, y0, 15, y1, wood)
		for xx in range(0, 16, 4):
			_rect(img, xx, y0, xx, y1, dark)
			_rect(img, xx + 1, y0, xx + 1, y1, light)
		if up_w:
			_rect(img, 0, 1, 15, 2, dark)
			_rect(img, 0, 3, 15, 3, _shade(wood, 0.8))
		if dn_w:
			_rect(img, 0, 13, 15, 14, dark)
			_rect(img, 0, 12, 15, 12, light)
	else:
		var x0 := 1 if lf_w else 0
		var x1 := 14 if rt_w else 15
		_rect(img, x0, 0, x1, 15, wood)
		for yy in range(0, 16, 4):
			_rect(img, x0, yy, x1, yy, dark)
			_rect(img, x0, yy + 1, x1, yy + 1, light)
		if lf_w:
			_rect(img, 1, 0, 2, 15, dark)
			_rect(img, 3, 0, 3, 15, _shade(wood, 0.8))
		if rt_w:
			_rect(img, 13, 0, 14, 15, dark)
			_rect(img, 12, 0, 12, 15, light)
	_cache[key] = img
	return img

static func _lava_img(mask: int, corners: int, x: int, y: int) -> Image:
	var img := _new()
	var base := Color(0.95, 0.38, 0.08)
	img.fill(base)
	for i in range(9):
		var hh := _h(x + _frame * 13, y + _frame * 7, 340 + i)
		var c := Color(1.0, 0.78, 0.2) if i % 3 == 0 else (Color(0.78, 0.2, 0.05) if i % 3 == 1 else Color(1.0, 0.55, 0.12))
		_px(img, hh % 15, (hh / 15) % 15, c)
		_px(img, (hh % 15) + 1, (hh / 15) % 15, c)
	for side in range(4):
		if mask & (1 << side):
			_edge(img, side, [Color(0.12, 0.05, 0.06), Color(0.38, 0.10, 0.06), Color(0.7, 0.2, 0.06)], [1.0, 0.9, 0.35], x, y, 350)
	return img

static func _lava(m: MapData, x: int, y: int) -> Image:
	var mask := 0
	for side in range(4):
		var nb := _at(m, x + DIRS[side].x, y + DIRS[side].y)
		if nb != "l" and nb != "B":
			mask |= 1 << side
	return _lava_img(mask, 0, x, y)

# ============================================================== rocha e montanha
static func _mountain(m: MapData, x: int, y: int) -> Image:
	var img := _new()
	var warm := _h(x, y, 400) % 3
	var base: Color = [Color(0.47, 0.43, 0.41), Color(0.43, 0.42, 0.44), Color(0.50, 0.45, 0.40)][warm]
	var tone := 0.88 + 0.24 * float(_h(x / 2, y / 2, 460)) / 1000.0
	base = Color(base.r * tone, base.g * tone, base.b * tone, 1.0)
	img.fill(base)
	var up := _at(m, x, y - 1) == "M"
	var dn := _at(m, x, y + 1) == "M"
	var lf := _at(m, x - 1, y) == "M"
	var rt := _at(m, x + 1, y) == "M"
	for i in range(22):
		var hh := _h(x, y, 410 + i)
		_px(img, hh % 16, (hh / 16) % 16, _shade(base, 1.22) if i % 2 == 0 else _shade(base, 0.72))
	for k in range(3):
		var yy := 3 + k * 5 + _h(x, y, 430 + k) % 3
		var x0 := _h(x, y, 440 + k) % 6
		for xx in range(x0, x0 + 9):
			_px(img, xx, yy, _shade(base, 0.68))
			_px(img, xx, yy - 1, _shade(base, 1.18))
	if not up:
		_rect(img, 0, 0, 15, 1, _shade(base, 1.45))
		_rect(img, 0, 2, 15, 2, _shade(base, 1.2))
		for i in range(16):
			if _h(x * 16 + i, y, 450) < 330:
				_px(img, i, 0, Color(0.96, 0.97, 1.0))
	if not dn:
		_rect(img, 0, 13, 15, 15, _shade(base, 0.55))
		_rect(img, 0, 12, 15, 12, _shade(base, 0.8))
	if not lf:
		_rect(img, 0, 0, 0, 15, _shade(base, 0.45))
	if not rt:
		_rect(img, 15, 0, 15, 15, _shade(base, 0.45))
	return img

# ============================================================== arvores e objetos de cenario
static func _overlay(m: MapData, x: int, y: int, ch: String) -> Image:
	var g := _ground_under(m, x, y, ch)
	var img := _ground_base(g, x, y)
	var v := _h(x, y, 31) % 4
	if TALL.contains(ch):
		img.blend_rect(_tall_sprite(ch, v), Rect2i(0, 8, 16, 16), Vector2i.ZERO)
		return img
	var key := "sp|%s|%d" % [ch, v]
	var spr: Image
	if _cache.has(key):
		spr = _cache[key]
	else:
		spr = _sprite(ch, v)
		_cache[key] = spr
	img.blend_rect(spr, Rect2i(0, 0, 16, 16), Vector2i.ZERO)
	return img

static func _sprite(ch: String, v: int) -> Image:
	var img := _new()
	match ch:
		"P", "Q", "A":
			_tree(img, ch, v)
		"v":
			_bush(img, v)
		"o":
			PixelArt.ell(img, 8, 10, 7, 5, Color(0.50, 0.50, 0.52))
			PixelArt.ell(img, 6.5, 8.5, 4, 2.6, Color(0.66, 0.66, 0.68))
			PixelArt.ell(img, 11, 12, 3, 2, Color(0.38, 0.38, 0.40))
			PixelArt.outline(img, Color(0.14, 0.14, 0.18))
		"I":
			_ice(img, v)
		"z":
			_obsidian(img, v)
		"u":
			_cactus(img, v)
		"j":
			_pillar(img, v)
	return img

static func _tree(img: Image, ch: String, v: int) -> void:
	var dark: Color
	var mid: Color
	var light: Color
	match ch:
		"Q":
			dark = Color(0.05, 0.14, 0.18); mid = Color(0.09, 0.24, 0.27); light = Color(0.17, 0.38, 0.38)
		"A":
			dark = Color(0.10, 0.28, 0.28); mid = Color(0.17, 0.42, 0.36); light = Color(0.28, 0.56, 0.46)
		_:
			dark = Color(0.09, 0.30, 0.18); mid = Color(0.15, 0.44, 0.24); light = Color(0.28, 0.60, 0.32)
	var tint := (float(v) - 1.5) * 0.04
	mid = Color(mid.r, clampf(mid.g + tint, 0, 1), mid.b, 1)
	_rect(img, 7, 12, 8, 15, Color(0.38, 0.24, 0.12))
	_rect(img, 8, 12, 8, 15, Color(0.28, 0.17, 0.08))
	var tiers := [[0, 4, 3.2], [3, 5, 4.9], [6, 5, 6.3], [9, 5, 7.3]]
	var yshift := v % 2
	for t in tiers:
		var h: int = t[1]
		for r in range(h):
			var hw: float = 1.0 + (float(t[2]) - 1.0) * float(r) / float(h - 1)
			var yy: int = t[0] + r + (yshift if t[0] > 0 else 0)
			var xa := int(round(8.0 - hw))
			var xb := int(round(8.0 + hw)) - 1
			for xx in range(xa, xb + 1):
				var col := mid
				var rel := float(xx - xa) / maxf(1.0, float(xb - xa))
				if rel < 0.30:
					col = light
				elif rel > 0.72:
					col = dark
				if r == h - 1:
					col = dark if rel > 0.3 else mid
				if ch == "A" and r <= 1:
					col = Color(0.96, 0.98, 1.0) if rel < 0.6 else Color(0.74, 0.84, 0.95)
				_px(img, xx, yy, col)
	for i in range(4):
		var hh := _h(v * 9 + i, i, 500)
		var hx := 3 + hh % 10
		var hy := 3 + (hh / 10) % 9
		if img.get_pixel(hx, hy).a > 0.5 and ch != "A":
			_px(img, hx, hy, light)
	PixelArt.outline(img, Color(0.03, 0.09, 0.07))

static func _bush(img: Image, v: int) -> void:
	PixelArt.ell(img, 8, 10, 6.5, 5, Color(0.16, 0.46, 0.22))
	PixelArt.ell(img, 6, 8, 3.8, 3, Color(0.26, 0.62, 0.30))
	PixelArt.ell(img, 11, 11, 3, 2, Color(0.11, 0.34, 0.17))
	var berry := Color(0.92, 0.22, 0.28) if v % 2 == 0 else Color(0.95, 0.80, 0.25)
	for p in [[5, 7], [10, 9], [8, 6], [11, 7], [7, 11]]:
		if (p[0] + v) % 3 != 0:
			_px(img, p[0], p[1], berry)
	PixelArt.outline(img, Color(0.05, 0.16, 0.08))

static func _ice(img: Image, v: int) -> void:
	var body := Color(0.60, 0.82, 0.96)
	var lite := Color(0.88, 0.97, 1.0)
	var shade := Color(0.34, 0.58, 0.84)
	var ox := (v % 2) * 2
	_tri(img, 6 + ox, 1, 1 + ox, 14, 11 + ox, 14, body)
	_tri(img, 6 + ox, 1, 1 + ox, 14, 6 + ox, 14, lite)
	_tri(img, 6 + ox, 1, 11 + ox, 14, 7 + ox, 14, shade)
	_tri(img, 11 - ox, 6, 7 - ox, 14, 15 - ox, 14, body)
	_tri(img, 11 - ox, 6, 7 - ox, 14, 11 - ox, 14, lite)
	_tri(img, 11 - ox, 6, 15 - ox, 14, 12 - ox, 14, shade)
	_rect(img, 4, 14, 12, 15, Color(0.74, 0.88, 0.97))
	PixelArt.outline(img, Color(0.16, 0.32, 0.58))

static func _cactus(img: Image, v: int) -> void:
	var g := Color(0.22, 0.55, 0.28)
	var gl := Color(0.36, 0.72, 0.38)
	var gd := Color(0.13, 0.38, 0.20)
	PixelArt.ell(img, 8, 14, 5, 1.4, Color(0, 0, 0, 0.25))
	_rect(img, 6, 4, 9, 14, g)
	_rect(img, 6, 4, 6, 14, gl)
	_rect(img, 9, 4, 9, 14, gd)
	if v != 1:
		_rect(img, 3, 8, 5, 9, g)
		_rect(img, 2, 5, 3, 9, g)
		_rect(img, 2, 5, 2, 9, gl)
	if v != 2:
		_rect(img, 10, 7, 12, 8, g)
		_rect(img, 12, 4, 13, 8, g)
		_rect(img, 13, 4, 13, 8, gd)
	for p in [[7, 6], [8, 9], [7, 12], [3, 7], [12, 6]]:
		_px(img, p[0], p[1], Color(0.85, 0.95, 0.75))
	_px(img, 7, 3, Color(0.95, 0.45, 0.60))
	_px(img, 8, 3, Color(0.95, 0.45, 0.60))
	PixelArt.outline(img, Color(0.06, 0.18, 0.10))

static func _pillar(img: Image, v: int) -> void:
	var st := Color(0.64, 0.62, 0.58)
	var sl := Color(0.80, 0.78, 0.72)
	var sd := Color(0.42, 0.40, 0.38)
	PixelArt.ell(img, 8, 14, 6, 1.6, Color(0, 0, 0, 0.25))
	_rect(img, 3, 12, 12, 14, st)
	_rect(img, 3, 12, 12, 12, sl)
	_rect(img, 3, 14, 12, 14, sd)
	var top := 3 + v % 3
	_rect(img, 5, top, 10, 12, st)
	_rect(img, 5, top, 6, 12, sl)
	_rect(img, 9, top, 10, 12, sd)
	_rect(img, 7, top + 1, 7, 11, sd)
	for i in range(6):
		var hh := _h(v + i, i, 640)
		_px(img, 5 + hh % 6, top - (hh / 6) % 2, st if i % 2 == 0 else sd)
	for p in [[5, 11], [6, 12], [10, 10], [4, 13]]:
		_px(img, p[0], p[1], Color(0.34, 0.52, 0.24))
	PixelArt.outline(img, Color(0.16, 0.14, 0.14))

static func _obsidian(img: Image, v: int) -> void:
	var d := Color(0.14, 0.08, 0.20)
	var l := Color(0.34, 0.20, 0.44)
	_tri(img, 5, 1 + v % 2, 1, 14, 9, 14, d)
	_tri(img, 5, 1 + v % 2, 1, 14, 5, 14, l)
	_tri(img, 11, 5, 7, 14, 15, 14, d)
	_tri(img, 11, 5, 7, 14, 11, 14, l)
	_px(img, 5, 8, Color(1.0, 0.3, 0.2))
	_px(img, 5, 9, Color(1.0, 0.3, 0.2))
	_px(img, 11, 10, Color(1.0, 0.3, 0.2))
	PixelArt.outline(img, Color(0.04, 0.02, 0.06))

# ============================================================== arvores altas (16x24)
static func _tall_sprite(ch: String, v: int) -> Image:
	var key := "tall|%s|%d" % [ch, v]
	if _cache.has(key):
		return _cache[key]
	var img := PixelArt._new(16, 24)
	match ch:
		"P", "Q", "A":
			_pine(img, ch, v)
		"F":
			_oak(img, v)
		"d":
			_mangrove(img, v)
		"y":
			_palm(img, v)
	_cache[key] = img
	return img

static func _shadow(img: Image) -> void:
	PixelArt.ell(img, 8, 22, 6.5, 1.8, Color(0, 0, 0, 0.28))

static func _pine(img: Image, ch: String, v: int) -> void:
	var dark: Color
	var mid: Color
	var light: Color
	match ch:
		"Q":
			dark = Color(0.05, 0.14, 0.18); mid = Color(0.09, 0.24, 0.27); light = Color(0.17, 0.38, 0.38)
		"A":
			dark = Color(0.10, 0.28, 0.28); mid = Color(0.17, 0.42, 0.36); light = Color(0.28, 0.56, 0.46)
		_:
			dark = Color(0.09, 0.30, 0.18); mid = Color(0.15, 0.44, 0.24); light = Color(0.28, 0.60, 0.32)
	mid = Color(mid.r, clampf(mid.g + (float(v) - 1.5) * 0.04, 0, 1), mid.b, 1)
	_shadow(img)
	_rect(img, 7, 18, 8, 23, Color(0.38, 0.24, 0.12))
	_rect(img, 8, 18, 8, 23, Color(0.26, 0.16, 0.08))
	_rect(img, 6, 22, 9, 23, Color(0.30, 0.19, 0.09))
	var top := 2 + (v % 2)
	var tiers := [[top, 5, 3.0], [top + 4, 6, 4.6], [top + 8, 6, 6.0], [top + 12, 6, 7.4]]
	for t in tiers:
		var h: int = t[1]
		for r in range(h):
			var hw: float = 1.0 + (float(t[2]) - 1.0) * float(r) / float(h - 1)
			var yy: int = t[0] + r
			var xa := int(round(8.0 - hw))
			var xb := int(round(8.0 + hw)) - 1
			for xx in range(xa, xb + 1):
				var col := mid
				var rel := float(xx - xa) / maxf(1.0, float(xb - xa))
				if rel < 0.30:
					col = light
				elif rel > 0.72:
					col = dark
				if r == h - 1:
					col = dark if rel > 0.3 else mid
				if ch == "A" and r <= 1:
					col = Color(0.96, 0.98, 1.0) if rel < 0.6 else Color(0.74, 0.84, 0.95)
				_px(img, xx, yy, col)
	for i in range(5):
		var hh := _h(v * 9 + i, i, 500)
		var hx := 3 + hh % 10
		var hy := 6 + (hh / 10) % 12
		if img.get_pixel(hx, hy).a > 0.5 and ch != "A":
			_px(img, hx, hy, light)
	PixelArt.outline(img, Color(0.03, 0.09, 0.07))

static func _oak(img: Image, v: int) -> void:
	var dark := Color(0.10, 0.34, 0.16)
	var mid := Color(0.20, 0.52, 0.22)
	var light := Color(0.40, 0.72, 0.30)
	var tint := (float(v) - 1.5) * 0.03
	mid = Color(clampf(mid.r + tint, 0, 1), mid.g, mid.b, 1)
	_shadow(img)
	_rect(img, 7, 15, 8, 23, Color(0.40, 0.26, 0.13))
	_rect(img, 8, 15, 8, 23, Color(0.28, 0.17, 0.08))
	_rect(img, 6, 21, 9, 23, Color(0.32, 0.20, 0.10))
	PixelArt.ell(img, 8, 10, 7.5, 6.5, dark)
	PixelArt.ell(img, 5, 12, 5, 4.5, dark)
	PixelArt.ell(img, 11, 12, 5, 4.5, dark)
	PixelArt.ell(img, 7.5, 9, 6, 5, mid)
	PixelArt.ell(img, 5, 11.5, 3.8, 3.2, mid)
	PixelArt.ell(img, 10.5, 11.5, 3.6, 3.0, mid)
	PixelArt.ell(img, 6, 7.5, 3.5, 2.6, light)
	PixelArt.ell(img, 10, 8, 2, 1.5, light)
	for i in range(7):
		var hh := _h(v * 13 + i, i * 3, 580)
		var hx := 2 + hh % 12
		var hy := 5 + (hh / 12) % 10
		if img.get_pixel(hx, hy).a > 0.5:
			_px(img, hx, hy, light if i % 2 == 0 else dark)
	PixelArt.outline(img, Color(0.04, 0.13, 0.06))

static func _mangrove(img: Image, v: int) -> void:
	var bark := Color(0.34, 0.28, 0.30)
	var bark_l := Color(0.50, 0.43, 0.42)
	var moss := Color(0.32, 0.48, 0.22)
	var fl := v % 2 == 1
	_shadow(img)
	var bx := 8
	PixelArt.line(img, bx, 23, bx, 12, bark, 2)
	PixelArt.line(img, bx, 22, 4 if not fl else 12, 23, bark)
	PixelArt.line(img, bx + 1, 22, 12 if not fl else 4, 23, bark)
	PixelArt.line(img, bx, 14, 3 if not fl else 13, 7, bark)
	PixelArt.line(img, bx, 12, 12 if not fl else 3, 5, bark)
	PixelArt.line(img, bx, 17, 13 if not fl else 2, 11, bark)
	PixelArt.line(img, 3 if not fl else 13, 7, 2 if not fl else 14, 4, bark)
	for p in [[6, 12], [5, 14], [11, 9], [12, 12], [3, 9], [9, 18], [13, 7], [4, 6]]:
		var mx: int = p[0]
		var my: int = p[1]
		_rect(img, mx, my, mx, my + 2 + (mx + v) % 3, moss)
	for i in range(4):
		var hh := _h(v + i, i, 600)
		var hx := 6 + hh % 4
		var hy := 13 + (hh / 4) % 8
		if img.get_pixel(hx, hy).a > 0.5:
			_px(img, hx, hy, bark_l)
	PixelArt.outline(img, Color(0.08, 0.06, 0.09))

static func _palm(img: Image, v: int) -> void:
	var trunk := Color(0.62, 0.44, 0.26)
	var trunk_d := Color(0.40, 0.27, 0.15)
	var leaf := Color(0.18, 0.52, 0.24)
	var leaf_l := Color(0.38, 0.72, 0.32)
	_shadow(img)
	var lean := 1 if v % 2 == 0 else -1
	for y in range(23, 7, -1):
		var t := float(23 - y) / 15.0
		var x := 8 + int(round(sin(t * 1.4) * 2.2 * float(lean)))
		_px(img, x, y, trunk)
		_px(img, x + 1, y, trunk_d)
		if y % 3 == 0:
			_px(img, x, y, trunk_d)
	var tx := 8 + int(round(sin(1.4) * 2.2 * float(lean)))
	var ty := 8
	for e in [[-7, 2], [-5, -3], [-1, -5], [4, -4], [7, 1], [5, 4], [-4, 4]]:
		var ex: int = tx + e[0]
		var ey: int = ty + e[1]
		PixelArt.line(img, tx, ty, ex, ey, leaf)
		PixelArt.line(img, tx, ty - 1, ex, ey - 1, leaf_l)
	_px(img, tx, ty + 1, Color(0.45, 0.30, 0.15))
	_px(img, tx + 1, ty + 1, Color(0.45, 0.30, 0.15))
	PixelArt.outline(img, Color(0.07, 0.15, 0.08))

# ============================================================== cidades
static func _is_build(ch: String) -> bool:
	return BUILD.contains(ch)

static func _roof_colors(ch: String) -> Array:
	match ch:
		"U": return [Color(0.25, 0.45, 0.78), Color(0.13, 0.25, 0.50), Color(0.46, 0.67, 0.96)]
		"Z": return [Color(0.93, 0.95, 0.98), Color(0.66, 0.74, 0.88), Color(1, 1, 1)]
		"K": return [Color(0.40, 0.43, 0.52), Color(0.22, 0.24, 0.32), Color(0.56, 0.60, 0.70)]
		"O": return [Color(0.73, 0.55, 0.28), Color(0.45, 0.31, 0.14), Color(0.90, 0.74, 0.44)]
		"Y": return [Color(0.30, 0.10, 0.34), Color(0.12, 0.03, 0.16), Color(0.66, 0.16, 0.30)]
	return [Color(0.72, 0.28, 0.24), Color(0.46, 0.16, 0.16), Color(0.86, 0.42, 0.34)]

static func _roof(m: MapData, x: int, y: int, ch: String) -> Image:
	var grp := CASTLE if ch == "Y" else BUILD
	var up := _at(m, x, y - 1) == ch
	var lf := _at(m, x - 1, y) == ch
	var rt := _at(m, x + 1, y) == ch
	var below := _at(m, x, y + 1)
	var eave := below != ch and grp.contains(below)
	var key := "r|%s|%d%d%d%d|%d" % [ch, int(up), int(lf), int(rt), int(eave), (x * 3 + y) % 3]
	if _cache.has(key):
		return _cache[key]
	var cols := _roof_colors(ch)
	var base: Color = cols[0]
	var dk: Color = cols[1]
	var lt: Color = cols[2]
	var img := _new()
	img.fill(base)
	for yy in range(0, 16, 4):
		_rect(img, 0, yy + 3, 15, yy + 3, dk)
		var off := 4 if (yy / 4) % 2 == 0 else 0
		for xx in range(off, 16, 8):
			_rect(img, xx, yy, xx, yy + 2, _shade(dk, 1.15))
		_px(img, (yy * 3 + 2) % 16, yy + 1, lt)
		_px(img, (yy * 5 + 9) % 16, yy + 1, lt)
	if not up:
		_rect(img, 0, 0, 15, 0, _shade(dk, 0.6))
		_rect(img, 0, 1, 15, 1, lt)
	if not lf:
		_rect(img, 0, 0, 0, 15, _shade(dk, 0.6))
	if not rt:
		_rect(img, 15, 0, 15, 15, _shade(dk, 0.6))
	if eave:
		_rect(img, 0, 13, 15, 13, dk)
		_rect(img, 0, 14, 15, 15, _shade(dk, 0.55))
	_cache[key] = img
	return img

static func _wall(m: MapData, x: int, y: int, ch: String) -> Image:
	var lf := _is_build(_at(m, x - 1, y))
	var rt := _is_build(_at(m, x + 1, y))
	var below := _at(m, x, y + 1)
	var dn := _is_build(below)
	var stone := ch == "g" or _at(m, x - 1, y) == "g" or _at(m, x + 1, y) == "g"
	var v := _h(x, y, 600) % 3
	var key := "wl|%s|%d%d%d|%d|%d" % [ch, int(lf), int(rt), int(dn), int(stone), v]
	if _cache.has(key):
		return _cache[key]
	var img := _new()
	if stone:
		var sb := Color(0.56, 0.57, 0.62)
		img.fill(sb)
		for yy in range(0, 16, 5):
			_rect(img, 0, yy + 4, 15, yy + 4, Color(0.34, 0.35, 0.40))
			var off := 3 if (yy / 5) % 2 == 0 else 8
			for xx in range(off, 16, 8):
				_rect(img, xx, yy, xx, yy + 3, Color(0.38, 0.39, 0.45))
			_px(img, (yy * 2 + 4) % 16, yy + 1, Color(0.70, 0.71, 0.76))
	else:
		var wb := Color(0.86, 0.78, 0.62)
		img.fill(wb)
		for yy in range(0, 16, 4):
			_rect(img, 0, yy + 3, 15, yy + 3, Color(0.62, 0.52, 0.38))
		for yy in range(0, 16, 8):
			for xx in range(0, 16, 8):
				_px(img, xx + (4 if (yy / 8) % 2 == 0 else 0), yy + 2, Color(0.62, 0.52, 0.38))
	if ch == "m":
		var shut: Color = [Color(0.25, 0.42, 0.62), Color(0.30, 0.50, 0.30), Color(0.58, 0.28, 0.24)][v]
		_rect(img, 3, 3, 12, 12, Color(0.30, 0.19, 0.10))
		_rect(img, 4, 4, 11, 11, Color(0.60, 0.82, 0.96))
		_rect(img, 4, 4, 11, 5, Color(0.80, 0.94, 1.0))
		_rect(img, 7, 4, 8, 11, Color(0.30, 0.19, 0.10))
		_rect(img, 4, 7, 11, 8, Color(0.30, 0.19, 0.10))
		_rect(img, 1, 3, 2, 12, shut)
		_rect(img, 13, 3, 14, 12, shut)
		_rect(img, 3, 13, 12, 13, Color(0.45, 0.30, 0.16))
	elif ch == "D":
		_rect(img, 3, 1, 12, 15, Color(0.30, 0.18, 0.09))
		_rect(img, 4, 2, 11, 15, Color(0.58, 0.38, 0.20))
		_rect(img, 4, 2, 7, 15, Color(0.64, 0.43, 0.24))
		_rect(img, 8, 2, 8, 15, Color(0.36, 0.22, 0.11))
		_rect(img, 4, 2, 11, 3, Color(0.46, 0.30, 0.15))
		_px(img, 10, 9, Color(1.0, 0.85, 0.3))
		_px(img, 10, 10, Color(0.9, 0.7, 0.2))
	var edge := Color(0.18, 0.12, 0.08)
	if not lf:
		_rect(img, 0, 0, 0, 15, edge)
	if not rt:
		_rect(img, 15, 0, 15, 15, edge)
	if not dn:
		_rect(img, 0, 15, 15, 15, edge)
		_rect(img, 0, 14, 15, 14, _shade(Color(0.5, 0.42, 0.32), 0.9))
	_cache[key] = img
	return img

# ============================================================== castelo
static func _castle_wall(m: MapData, x: int, y: int, ch: String) -> Image:
	var lf := CASTLE.contains(_at(m, x - 1, y))
	var rt := CASTLE.contains(_at(m, x + 1, y))
	var dn := CASTLE.contains(_at(m, x, y + 1))
	var up := CASTLE.contains(_at(m, x, y - 1))
	var v := _h(x, y, 700) % 3
	var key := "cw|%s|%d%d%d%d|%d" % [ch, int(lf), int(rt), int(dn), int(up), v]
	if _cache.has(key):
		return _cache[key]
	var img := _new()
	var base := Color(0.30, 0.24, 0.36)
	img.fill(base)
	var mortar := Color(0.16, 0.12, 0.21)
	for yy in range(0, 16, 4):
		_rect(img, 0, yy + 3, 15, yy + 3, mortar)
		var off := 4 if (yy / 4) % 2 == 0 else 0
		for xx in range(off, 16, 8):
			_rect(img, xx, yy, xx, yy + 2, mortar)
		_px(img, (yy * 3 + 1 + v) % 16, yy + 1, Color(0.44, 0.36, 0.52))
	if ch == "C":
		_rect(img, 0, 0, 15, 4, Color(0.09, 0.06, 0.13))
		for mx in [1, 9]:
			_rect(img, mx, 0, mx + 5, 4, base)
			_rect(img, mx, 0, mx + 5, 0, Color(0.50, 0.42, 0.58))
			_rect(img, mx, 4, mx + 5, 4, mortar)
			_rect(img, mx + 5, 0, mx + 5, 4, _shade(base, 0.7))
		_rect(img, 0, 5, 15, 5, Color(0.52, 0.44, 0.60))
	elif ch == "V":
		_rect(img, 5, 1, 10, 13, Color(0.07, 0.02, 0.06))
		_rect(img, 6, 2, 9, 12, Color(0.55, 0.08, 0.10))
		_rect(img, 7, 3, 8, 11, Color(1.0, 0.35, 0.15))
		_rect(img, 7, 5, 8, 8, Color(1.0, 0.85, 0.3))
	var edge := Color(0.06, 0.03, 0.10)
	if not lf:
		_rect(img, 0, 0, 0, 15, edge)
		_rect(img, 1, 0, 1, 15, _shade(base, 0.7))
	if not rt:
		_rect(img, 15, 0, 15, 15, edge)
		_rect(img, 14, 0, 14, 15, _shade(base, 0.7))
	if not dn:
		_rect(img, 0, 15, 15, 15, edge)
		_rect(img, 0, 13, 15, 14, _shade(base, 0.6))
	if not up and ch != "C":
		_rect(img, 0, 0, 15, 0, edge)
	_cache[key] = img
	return img

static func _gate(m: MapData, x: int, y: int, ch: String) -> Image:
	var lf := "Ee".contains(_at(m, x - 1, y))
	var rt := "Ee".contains(_at(m, x + 1, y))
	var key := "gt|%s|%d%d|%d" % [ch, int(lf), int(rt), 1 if _at(m, x, y + 1) == "E" else 0]
	if _cache.has(key):
		return _cache[key]
	var img := _new()
	var stone := Color(0.30, 0.24, 0.36)
	img.fill(stone)
	var door := Color(0.16, 0.03, 0.07)
	var glow := Color(0.60, 0.08, 0.10)
	var top := 6 if ch == "e" else 0
	for yy in range(top, 16):
		for xx in range(0, 16):
			var fx := xx
			var inside := true
			if not lf and xx < 3:
				inside = false
			if not rt and xx > 12:
				inside = false
			if inside:
				var c := door
				if xx % 8 < 2 or yy % 8 < 1:
					c = Color(0.28, 0.28, 0.32)
				elif (xx + yy) % 5 == 0:
					c = glow
				_px(img, xx, yy, c)
	if ch == "e":
		_rect(img, 0, 0, 15, 5, stone)
		_rect(img, 0, 5, 15, 5, Color(0.07, 0.04, 0.11))
		_rect(img, 0, 0, 15, 0, Color(0.52, 0.44, 0.60))
		if not lf or not rt:
			pass
		_px(img, 7, 2, Color(1.0, 0.25, 0.2))
		_px(img, 8, 2, Color(1.0, 0.25, 0.2))
		_px(img, 7, 3, Color(0.6, 0.1, 0.1))
		_px(img, 8, 3, Color(0.6, 0.1, 0.1))
	if not lf:
		_rect(img, 3, top, 3, 15, Color(0.06, 0.03, 0.10))
	if not rt:
		_rect(img, 12, top, 12, 15, Color(0.06, 0.03, 0.10))
	if not lf:
		_rect(img, 0, 0, 0, 15, Color(0.06, 0.03, 0.10))
	if not rt:
		_rect(img, 15, 0, 15, 15, Color(0.06, 0.03, 0.10))
	_cache[key] = img
	return img

# ============================================================== pedra de calcada
static func _cobble(x: int, y: int) -> Image:
	var v := _h(x, y, 800) % 4
	var key := "q|%d" % v
	if _cache.has(key):
		return _cache[key]
	var img := _new()
	var base := Color(0.62, 0.62, 0.64)
	img.fill(base)
	var m := Color(0.40, 0.40, 0.44)
	for yy in range(0, 16, 5):
		_rect(img, 0, yy + 4, 15, yy + 4, m)
		var off := (3 + v * 2) if (yy / 5) % 2 == 0 else 8
		for xx in range(off, 16, 8):
			_rect(img, xx, yy, xx, yy + 3, m)
		_px(img, (yy * 3 + v) % 16, yy + 1, Color(0.78, 0.78, 0.80))
	_cache[key] = img
	return img

# ============================================================== api
static func tile(m: MapData, x: int, y: int) -> Image:
	var ch := _at(m, x, y)
	match ch:
		".", ",", "s", "n", "k", "p", "i", "a":
			return _ground_with_edges(m, x, y, ch)
		"=":
			return _swamp_water(m, x, y)
		"q":
			return _cobble(x, y)
		"w", "~":
			return _water(m, x, y, ch)
		"B":
			return _bridge(m, x, y)
		"l":
			return _lava(m, x, y)
		"M":
			return _mountain(m, x, y)
		"P", "Q", "A", "F", "d", "y", "u", "v", "o", "I", "z", "j":
			return _overlay(m, x, y, ch)
		"R", "U", "Z", "K", "O", "Y":
			return _roof(m, x, y, ch)
		"W", "g", "m", "D":
			return _wall(m, x, y, ch)
		"X", "C", "V":
			return _castle_wall(m, x, y, ch)
		"E", "e":
			return _gate(m, x, y, ch)
	return PixelArt.tile_image(ch, x, y, m.floor_n)

## Copas (8 px superiores) das arvores altas, para desenhar acima do jogador.
static func render_overlay(m: MapData) -> Image:
	var img := PixelArt._new(m.w * 16, m.h * 16)
	for y in range(1, m.h):
		for x in range(m.w):
			var ch: String = m.rows[y][x]
			if TALL.contains(ch):
				img.blend_rect(_tall_sprite(ch, _h(x, y, 31) % 4), Rect2i(0, 0, 16, 8), Vector2i(x * 16, y * 16 - 8))
	return img

static func render_image(m: MapData, frame: int = 0) -> Image:
	_frame = frame
	var img := PixelArt._new(m.w * 16, m.h * 16)
	for y in range(m.h):
		for x in range(m.w):
			img.blit_rect(tile(m, x, y), Rect2i(0, 0, 16, 16), Vector2i(x * 16, y * 16))
	return img

## Mapa em miniatura (1 pixel por tile) para a tela de mapa do menu.
static func minimap_image(m: MapData) -> Image:
	var img := PixelArt._new(m.w, m.h, Color(0.08, 0.20, 0.45))
	var col := {
		"~": Color(0.08, 0.20, 0.45), "w": Color(0.16, 0.40, 0.75), ".": Color(0.33, 0.60, 0.28), ",": Color(0.38, 0.64, 0.30),
		"s": Color(0.87, 0.80, 0.55), "n": Color(0.92, 0.95, 0.98), "k": Color(0.28, 0.20, 0.30), "p": Color(0.68, 0.52, 0.32),
		"q": Color(0.62, 0.62, 0.64), "B": Color(0.50, 0.32, 0.16), "P": Color(0.10, 0.36, 0.18), "Q": Color(0.05, 0.20, 0.22),
		"A": Color(0.45, 0.70, 0.62), "M": Color(0.47, 0.43, 0.41), "I": Color(0.60, 0.82, 0.96), "v": Color(0.20, 0.50, 0.24),
		"o": Color(0.55, 0.55, 0.57), "z": Color(0.14, 0.08, 0.20), "l": Color(0.95, 0.38, 0.08), "R": Color(0.72, 0.28, 0.24),
		"U": Color(0.25, 0.45, 0.78), "Z": Color(0.93, 0.95, 0.98), "K": Color(0.40, 0.43, 0.52), "O": Color(0.73, 0.55, 0.28),
		"W": Color(0.86, 0.78, 0.62), "g": Color(0.56, 0.57, 0.62), "D": Color(0.5, 0.3, 0.15), "m": Color(0.5, 0.6, 0.7),
		"X": Color(0.30, 0.24, 0.36), "Y": Color(0.45, 0.12, 0.38), "C": Color(0.40, 0.32, 0.48), "V": Color(1.0, 0.35, 0.15),
		"E": Color(0.60, 0.08, 0.10), "e": Color(0.45, 0.06, 0.10), "h": Color(0.05, 0.05, 0.08),
		"i": Color(0.93, 0.80, 0.47), "a": Color(0.30, 0.33, 0.18), "=": Color(0.13, 0.27, 0.24), "F": Color(0.20, 0.50, 0.22),
		"d": Color(0.32, 0.28, 0.30), "y": Color(0.30, 0.62, 0.30), "u": Color(0.22, 0.55, 0.28), "j": Color(0.64, 0.62, 0.58),
	}
	for y in range(m.h):
		for x in range(m.w):
			var ch: String = m.rows[y][x]
			if col.has(ch):
				img.set_pixel(x, y, col[ch])
	return img
