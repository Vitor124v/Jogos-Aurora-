class_name HeroArt
extends RefCounted
## Sprites de batalha dos herois (44x44 px, virado para a direita) com animacoes:
## idle, attack, skill, damage, death. Tudo desenhado por codigo (arte original).

const W := 44
const H := 44
const CX := 22                 # eixo do corpo
const GROUND := 40
const ANIMS := {"idle": 4, "attack": 5, "skill": 5, "damage": 2, "death": 4}
const FPS := {"idle": 3.5, "attack": 15.0, "skill": 9.0, "damage": 8.0, "death": 8.0}
const OUTLINE := Color(0.08, 0.06, 0.10, 1)

static var _cache: Dictionary = {}

# ----------------------------------------------------------------- estilo por classe
static func style_for(class_id: String) -> Dictionary:
	var look_name := String(HeroDB.get_class_data(class_id)["look"])
	var st: Dictionary = PixelArt.look_for(look_name).duplicate()
	st["weapon"] = String(st.get("tool", "sword"))
	st["shield"] = false
	st["robe"] = false
	st["cape"] = Color(0, 0, 0, 0)
	st["aura"] = Color(1, 0.8, 0.4)
	st["pads"] = false
	match look_name:
		"warrior":
			st["pads"] = true
			st["aura"] = Color(1.0, 0.55, 0.25)
			st["band"] = Color(0.85, 0.15, 0.15)
		"mage":
			st["robe"] = true
			st["aura"] = Color(0.45, 0.7, 1.0)
			st["cape"] = Color(0.18, 0.25, 0.65)
		"rogue":
			st["aura"] = Color(0.75, 0.35, 0.9)
			st["cape"] = Color(0.14, 0.12, 0.2)
		"paladin":
			st["shield"] = true
			st["pads"] = true
			st["aura"] = Color(1.0, 0.92, 0.5)
			st["cape"] = Color(0.8, 0.2, 0.2)
	return st

# ----------------------------------------------------------------- poses
## dy: sobe/desce corpo, lean: inclina tronco (px), arm/wep: angulos (graus, 0=direita, 90=baixo),
## arm2/wep2: braco de tras, crouch: agacha, aura 0..2, hurt: tinge de vermelho, head: deslocamento da cabeca.
static func pose_for(anim: String, f: int) -> Dictionary:
	var p := {"dy": 0, "lean": 0, "arm": 62, "wep": -58, "arm2": 105, "wep2": 80, "crouch": 0, "aura": 0, "hurt": false, "head": 0, "step": 0, "cast": false, "glow": 0.0}
	match anim:
		"idle":
			var dys := [0, 1, 1, 0]
			p["dy"] = dys[f % 4]
			p["arm"] = [62, 66, 68, 64][f % 4]
			p["wep"] = [-58, -52, -50, -55][f % 4]
		"attack":
			match f:
				0:
					p.merge({"lean": -2, "arm": -125, "wep": -160, "arm2": 120, "step": -1, "head": -1}, true)
				1:
					p.merge({"lean": -1, "arm": -80, "wep": -105, "arm2": 125, "step": 0}, true)
				2:
					p.merge({"lean": 4, "arm": 8, "wep": 12, "arm2": 70, "step": 2, "head": 1}, true)
				3:
					p.merge({"lean": 3, "arm": 28, "wep": 38, "arm2": 80, "step": 2}, true)
				_:
					p.merge({"lean": 1, "arm": 55, "wep": -30, "arm2": 100, "step": 1}, true)
		"skill":
			match f:
				0:
					p.merge({"crouch": 2, "dy": 1, "arm": 40, "wep": -70, "arm2": 70, "aura": 0}, true)
				1:
					p.merge({"lean": -1, "arm": -70, "wep": -90, "arm2": -110, "aura": 1, "cast": true, "glow": 0.5}, true)
				2:
					p.merge({"lean": -1, "dy": -1, "arm": -85, "wep": -90, "arm2": -100, "aura": 2, "cast": true, "glow": 1.0}, true)
				3:
					p.merge({"lean": 2, "arm": -20, "wep": -10, "arm2": -50, "aura": 2, "cast": true, "glow": 1.0}, true)
				_:
					p.merge({"lean": 3, "arm": 5, "wep": 5, "arm2": 40, "aura": 1, "glow": 0.5, "step": 1}, true)
		"damage":
			if f == 0:
				p.merge({"lean": -4, "head": -2, "arm": 100, "wep": 40, "arm2": 135, "hurt": true, "step": -1}, true)
			else:
				p.merge({"lean": -3, "head": -1, "arm": 90, "wep": 20, "arm2": 125, "hurt": true}, true)
		"death":
			match f:
				0:
					p.merge({"lean": -5, "head": -2, "arm": 105, "wep": 60, "arm2": 140, "hurt": true, "step": -1}, true)
				1:
					p.merge({"lean": -4, "crouch": 7, "dy": 3, "head": -2, "arm": 110, "wep": 95, "arm2": 150, "hurt": true}, true)
				_:
					p.merge({"lean": -2, "arm": 100, "wep": 90, "arm2": 120, "hurt": false, "eyes_closed": true}, true)
	return p

# ----------------------------------------------------------------- API
static func frames(class_id: String) -> Dictionary:
	var key := "hero_" + class_id
	if _cache.has(key):
		return _cache[key]
	var st := style_for(class_id)
	var out := {}
	for anim in ANIMS:
		var arr: Array = []
		for f in range(int(ANIMS[anim])):
			arr.append(PixelArt._tex(_image(st, String(anim), f)))
		out[anim] = arr
	_cache[key] = out
	return out

static func image_of(class_id: String, anim: String, f: int) -> Image:
	return _image(style_for(class_id), anim, f)

static func _image(st: Dictionary, anim: String, f: int) -> Image:
	if anim == "death" and f >= 2:
		return _fallen(st, f)
	var p := pose_for(anim, f)
	return _render(st, p)

# corpo caido: gira o corpo em pe 90 graus e apoia no chao
static func _fallen(st: Dictionary, f: int) -> Image:
	var base := _render(st, pose_for("death", 2))
	base.rotate_90(COUNTERCLOCKWISE)
	var used := base.get_used_rect()
	var out := PixelArt._new(W, H)
	PixelArt.ell(out, CX, 41.5, 12, 2, Color(0, 0, 0, 0.3))
	var dst := Vector2i(CX - used.size.x / 2, GROUND + 1 - used.size.y)
	out.blend_rect(base, used, dst)
	if f >= 3:
		for y in range(H):
			for x in range(W):
				var c := out.get_pixel(x, y)
				if c.a > 0.5:
					out.set_pixel(x, y, Color(c.r * 0.78, c.g * 0.74, c.b * 0.74, 1.0))
	return out

# ----------------------------------------------------------------- desenho
static func _dir(a: float, l: float) -> Vector2:
	return Vector2(cos(deg_to_rad(a)), sin(deg_to_rad(a))) * l

static func _l(img: Image, a: Vector2, b: Vector2, c: Color, th: int = 1) -> void:
	PixelArt.line(img, int(round(a.x)), int(round(a.y)), int(round(b.x)), int(round(b.y)), c, th)

static func _render(st: Dictionary, p: Dictionary) -> Image:
	var img := PixelArt._new(W, H)
	var skin: Color = st["skin"]
	var hair: Color = st["hair"]
	var prim: Color = st["primary"]
	var sec: Color = st["secondary"]
	var legs: Color = st["legs"]
	var aura: Color = st["aura"]
	var dy: int = p["dy"]
	var lean: int = p["lean"]
	var crouch: int = p["crouch"]
	var hip_y := 29 + dy + crouch
	var step: int = p["step"]
	var steel := Color(0.88, 0.91, 0.98)
	var wood := Color(0.52, 0.34, 0.17)

	PixelArt.ell(img, CX, 41.5, 9, 2, Color(0, 0, 0, 0.3))
	# aura
	var au: int = p["aura"]
	if au > 0:
		PixelArt.ell(img, CX + lean, 24 + dy, 9 + au * 3, 14 + au * 2, Color(aura.r, aura.g, aura.b, 0.12))
		PixelArt.ell(img, CX + lean, 24 + dy, 6 + au * 2, 11 + au, Color(aura.r, aura.g, aura.b, 0.14))
	var shoulder := Vector2(CX + lean + 1, 19 + dy + crouch)

	# capa (atras de tudo)
	var cape: Color = st["cape"]
	if cape.a > 0.0:
		for y in range(19 + dy + crouch, 36):
			var t := float(y - (19 + dy + crouch)) / 17.0
			var xa := CX - 4 + lean - int(t * 6.0) - int(t * lean * -0.5)
			PixelArt.rect(img, xa, y, CX - 3 + lean, y, PixelArt.shade(cape, 1.0 - t * 0.35))
	# braco de tras
	var arm2: float = float(p["arm2"])
	var sh2 := Vector2(CX + lean - 3, 19 + dy + crouch)
	var hand2 := sh2 + _dir(arm2, 8.0)
	_l(img, sh2, hand2, PixelArt.shade(prim, 0.7), 2)
	PixelArt.rect(img, int(hand2.x), int(hand2.y), int(hand2.x) + 1, int(hand2.y) + 1, PixelArt.shade(skin, 0.85))
	if String(st["weapon"]) == "dagger":
		var w2: float = float(p["wep2"]) + (0.0 if not bool(p["cast"]) else -20.0)
		_l(img, hand2, hand2 + _dir(w2, 7.0), PixelArt.shade(steel, 0.85), 1)
	# pernas
	if bool(st["robe"]):
		for y in range(hip_y - 2, GROUND):
			var t2 := float(y - hip_y) / 11.0
			var half := 5 + int(t2 * 3.0)
			PixelArt.rect(img, CX - half + lean / 2, y, CX + half + lean / 2 - 1, y, PixelArt.shade(prim, 0.9 - t2 * 0.15))
		PixelArt.rect(img, CX - 7 + lean / 2, GROUND - 1, CX + 7 + lean / 2, GROUND - 1, sec)
		PixelArt.rect(img, CX - 4, GROUND, CX - 2, GROUND, Color(0.3, 0.2, 0.12))
		PixelArt.rect(img, CX + 3 + step, GROUND, CX + 5 + step, GROUND, Color(0.3, 0.2, 0.12))
	else:
		var bf := Vector2(CX - 4 - step, GROUND)
		var ff := Vector2(CX + 4 + step, GROUND)
		if crouch > 0:
			bf = Vector2(CX - 6, GROUND)
			ff = Vector2(CX + 6, GROUND)
		_l(img, Vector2(CX - 2, hip_y), bf, PixelArt.shade(legs, 0.8), 3)
		_l(img, Vector2(CX + 2, hip_y), ff, legs, 3)
		PixelArt.rect(img, int(bf.x) - 2, GROUND - 1, int(bf.x) + 1, GROUND, Color(0.22, 0.15, 0.10))
		PixelArt.rect(img, int(ff.x) - 1, GROUND - 1, int(ff.x) + 3, GROUND, Color(0.30, 0.20, 0.12))
	# tronco
	var top_y := 17 + dy + crouch
	for y in range(top_y, hip_y + 1):
		var sh := float(lean) * float(hip_y - y) / 12.0
		var xa2 := int(round(CX - 5 + sh))
		var xb2 := int(round(CX + 4 + sh))
		for x in range(xa2, xb2 + 1):
			var c := prim
			if x <= xa2 + 1:
				c = PixelArt.shade(prim, 1.18)
			elif x >= xb2 - 1:
				c = PixelArt.shade(prim, 0.78)
			if y == top_y:
				c = PixelArt.shade(prim, 1.25)
			PixelArt.px(img, x, y, c)
	var belt_y := hip_y - 2
	PixelArt.rect(img, CX - 5 + lean / 4, belt_y, CX + 4 + lean / 4, belt_y, sec)
	PixelArt.px(img, CX + lean / 4, belt_y, PixelArt.shade(sec, 1.3))
	if bool(st["robe"]):
		PixelArt.rect(img, CX - 1 + lean / 3, top_y + 1, CX + lean / 3, belt_y - 1, sec)
	if String(st["weapon"]) == "mace":
		PixelArt.rect(img, CX - 1 + lean / 3, top_y + 2, CX + lean / 3, top_y + 5, sec)
		PixelArt.rect(img, CX - 3 + lean / 3, top_y + 3, CX + 2 + lean / 3, top_y + 3, sec)
	# cabeca
	var hx := CX + lean + int(p["head"]) + 1
	var hy := 11 + dy + crouch
	PixelArt.ell(img, hx, hy, 5.0, 5.2, skin)
	PixelArt.px(img, hx + 3, hy + 1, PixelArt.shade(skin, 1.15))
	var eye := Color(0.08, 0.08, 0.14)
	var hurt: bool = p["hurt"]
	if hurt or p.get("eyes_closed", false):
		PixelArt.rect(img, hx + 1, hy, hx + 3, hy, eye)
	else:
		PixelArt.rect(img, hx + 2, hy, hx + 2, hy + 1, eye)
		PixelArt.px(img, hx + 3, hy, Color(1, 1, 1))
	PixelArt.px(img, hx + 3, hy + 3, PixelArt.shade(skin, 0.7))
	# cabelo
	PixelArt.ell(img, hx - 1, hy - 2, 5.2, 3.4, hair)
	PixelArt.rect(img, hx - 5, hy - 1, hx - 3, hy + 3, hair)
	PixelArt.rect(img, hx + 1, hy - 4, hx + 4, hy - 3, PixelArt.shade(hair, 1.25))
	match String(st["hat"]):
		"pointy":
			PixelArt.rect(img, hx - 7, hy - 3, hx + 6, hy - 2, prim)
			PixelArt.rect(img, hx - 4, hy - 6, hx + 3, hy - 4, prim)
			PixelArt.rect(img, hx - 3, hy - 9, hx + 1, hy - 7, prim)
			PixelArt.rect(img, hx - 1, hy - 11, hx + 1, hy - 10, prim)
			PixelArt.rect(img, hx - 7, hy - 3, hx + 6, hy - 3, sec)
			PixelArt.px(img, hx + 1, hy - 11, sec)
			PixelArt.rect(img, hx - 8, hy + 1, hx - 5, hy + 6, Color(0.88, 0.88, 0.92))   # barba/cabelo longo
		"hood":
			PixelArt.ell(img, hx - 1, hy - 1, 6.2, 5.8, prim)
			PixelArt.ell(img, hx + 1, hy + 1, 3.8, 3.4, skin)
			PixelArt.rect(img, hx + 1, hy, hx + 3, hy, Color(0.98, 0.9, 0.3))
			PixelArt.rect(img, hx - 5, hy + 3, hx + 5, hy + 5, PixelArt.shade(sec, 0.9))   # lenco
		"helmet":
			PixelArt.rect(img, hx - 5, hy - 5, hx + 5, hy - 1, sec)
		_:
			pass
	if st.has("band"):
		PixelArt.rect(img, hx - 5, hy - 2, hx + 5, hy - 1, st["band"])
		PixelArt.rect(img, hx - 8, hy - 1, hx - 5, hy, st["band"])
	if bool(st["pads"]):
		PixelArt.ell(img, shoulder.x - 1, shoulder.y, 3.2, 2.6, sec)
		PixelArt.px(img, int(shoulder.x) - 2, int(shoulder.y) - 1, PixelArt.shade(sec, 1.3))
	# escudo
	if bool(st["shield"]):
		var sx := CX + lean - 7
		var sy := 21 + dy + crouch
		PixelArt.rect(img, sx, sy, sx + 7, sy + 10, PixelArt.shade(sec, 0.8))
		PixelArt.rect(img, sx + 1, sy + 1, sx + 6, sy + 8, Color(0.93, 0.93, 0.97))
		PixelArt.rect(img, sx + 3, sy + 1, sx + 4, sy + 9, st["cape"])
		PixelArt.rect(img, sx + 1, sy + 4, sx + 6, sy + 5, st["cape"])
		PixelArt.rect(img, sx + 2, sy + 9, sx + 5, sy + 10, PixelArt.shade(sec, 0.8))
		PixelArt.px(img, sx + 3, sy + 4, sec)
	# braco da frente + arma
	var arm: float = float(p["arm"])
	var hand := shoulder + _dir(arm, 8.0)
	_l(img, shoulder, hand, prim, 2)
	_l(img, shoulder + Vector2(0, -1), hand + Vector2(0, -1), PixelArt.shade(prim, 1.2), 1)
	var wa: float = float(p["wep"])
	match String(st["weapon"]):
		"sword":
			var tip := hand + _dir(wa, 15.0)
			_l(img, hand, tip, steel, 2)
			_l(img, hand + _dir(wa - 90.0, 1.0), tip + _dir(wa - 90.0, 1.0), Color(1, 1, 1), 1)
			_l(img, hand + _dir(wa + 90.0, 3.0), hand + _dir(wa - 90.0, 3.0), sec, 1)
			_l(img, hand, hand + _dir(wa + 180.0, 3.0), wood, 2)
			if p["arm"] <= 20 and p["arm"] > -20:
				_l(img, tip + _dir(wa, 1.0), tip + _dir(wa + 60.0, 7.0), Color(1, 1, 1, 0.8), 1)
		"staff":
			var a0 := hand + _dir(wa + 180.0, 8.0)
			var a1 := hand + _dir(wa, 12.0)
			_l(img, a0, a1, wood, 2)
			var gl: float = float(p["glow"])
			var orb := Color(0.40 + 0.5 * gl, 0.85, 1.0)
			PixelArt.ell(img, a1.x, a1.y, 2.6 + gl * 1.4, 2.6 + gl * 1.4, orb)
			PixelArt.px(img, int(a1.x) - 1, int(a1.y) - 1, Color(1, 1, 1))
			if gl > 0.0:
				PixelArt.ell(img, a1.x, a1.y, 5.5 * gl + 1.0, 5.5 * gl + 1.0, Color(orb.r, orb.g, orb.b, 0.25))
		"dagger":
			_l(img, hand, hand + _dir(wa, 8.0), steel, 2)
			_l(img, hand, hand + _dir(wa + 180.0, 2.0), wood, 2)
			_l(img, hand + _dir(wa + 90.0, 2.0), hand + _dir(wa - 90.0, 2.0), sec, 1)
		"mace":
			var h1 := hand + _dir(wa, 10.0)
			_l(img, hand + _dir(wa + 180.0, 3.0), h1, wood, 2)
			PixelArt.ell(img, h1.x, h1.y, 3.4, 3.4, sec)
			PixelArt.px(img, int(h1.x) - 1, int(h1.y) - 1, PixelArt.shade(sec, 1.4))
			_l(img, h1 + _dir(wa + 90.0, 3.0), h1 + _dir(wa - 90.0, 3.0), PixelArt.shade(sec, 0.7), 1)
	PixelArt.rect(img, int(hand.x), int(hand.y), int(hand.x) + 1, int(hand.y) + 1, skin)
	PixelArt.outline(img, OUTLINE)
	if hurt:
		for y in range(H):
			for x in range(W):
				var c2 := img.get_pixel(x, y)
				if c2.a > 0.5:
					img.set_pixel(x, y, Color(minf(1.0, c2.r * 0.85 + 0.22), c2.g * 0.75, c2.b * 0.75, 1.0))
	return img
