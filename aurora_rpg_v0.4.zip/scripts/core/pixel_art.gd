class_name PixelArt
extends RefCounted
## Arte em pixel procedural (provisoria, coerente e sem arquivos externos).
## Tudo e gerado em Image na primeira vez e guardado em cache.

static var _cache: Dictionary = {}

# ============================================================== utilitarios de desenho
static func _hash(x: int, y: int, salt: int = 0) -> int:
	return absi((x * 73856093) ^ (y * 19349663) ^ (salt * 83492791)) % 1000

static func px(img: Image, x: int, y: int, c: Color) -> void:
	if x >= 0 and y >= 0 and x < img.get_width() and y < img.get_height():
		img.set_pixel(x, y, c)

static func rect(img: Image, x0: int, y0: int, x1: int, y1: int, c: Color) -> void:
	for y in range(y0, y1 + 1):
		for x in range(x0, x1 + 1):
			px(img, x, y, c)

static func ell(img: Image, cx: float, cy: float, rx: float, ry: float, c: Color) -> void:
	for y in range(int(floor(cy - ry)), int(ceil(cy + ry)) + 1):
		for x in range(int(floor(cx - rx)), int(ceil(cx + rx)) + 1):
			var dx := (float(x) + 0.5 - cx) / maxf(rx, 0.01)
			var dy := (float(y) + 0.5 - cy) / maxf(ry, 0.01)
			if dx * dx + dy * dy <= 1.0:
				px(img, x, y, c)

static func line(img: Image, x0: int, y0: int, x1: int, y1: int, c: Color, thick: int = 1) -> void:
	var dx := absi(x1 - x0)
	var dy := -absi(y1 - y0)
	var sx := 1 if x0 < x1 else -1
	var sy := 1 if y0 < y1 else -1
	var err := dx + dy
	var x := x0
	var y := y0
	while true:
		if thick <= 1:
			px(img, x, y, c)
		else:
			rect(img, x, y, x + thick - 1, y + thick - 1, c)
		if x == x1 and y == y1:
			break
		var e2 := 2 * err
		if e2 >= dy:
			err += dy
			x += sx
		if e2 <= dx:
			err += dx
			y += sy

static func outline(img: Image, col: Color) -> void:
	var w := img.get_width()
	var h := img.get_height()
	var src := img.duplicate() as Image
	for y in range(h):
		for x in range(w):
			if src.get_pixel(x, y).a > 0.1:
				continue
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				var nx: int = x + d.x
				var ny: int = y + d.y
				if nx >= 0 and ny >= 0 and nx < w and ny < h and src.get_pixel(nx, ny).a > 0.9:
					img.set_pixel(x, y, col)
					break

static func _new(w: int, h: int, fill: Color = Color(0, 0, 0, 0)) -> Image:
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	img.fill(fill)
	return img

static func _tex(img: Image) -> ImageTexture:
	return ImageTexture.create_from_image(img)

static func shade(c: Color, f: float) -> Color:
	return Color(clampf(c.r * f, 0, 1), clampf(c.g * f, 0, 1), clampf(c.b * f, 0, 1), c.a)

# ============================================================== TILES
static func tile_image(ch: String, x: int, y: int, floor_n: int = 0) -> Image:
	var img := _new(16, 16)
	match ch:
		".":
			_grass(img, x, y, Color(0.36, 0.64, 0.30))
		",":
			_grass(img, x, y, Color(0.30, 0.56, 0.27))
			var hsh := _hash(x, y, 3)
			if hsh < 120:
				var fx := 3 + hsh % 10
				var fy := 3 + (hsh / 10) % 10
				px(img, fx, fy, Color(1.0, 0.95, 0.5) if hsh % 2 == 0 else Color(0.95, 0.5, 0.6))
		"p":
			_dirt(img, x, y, Color(0.70, 0.56, 0.36))
		"T":
			_grass(img, x, y, Color(0.30, 0.56, 0.27))
			rect(img, 6, 10, 9, 15, Color(0.42, 0.28, 0.16))
			ell(img, 8, 6.5, 7.2, 6.4, Color(0.15, 0.40, 0.20))
			ell(img, 6.5, 5.0, 4.0, 3.2, Color(0.22, 0.52, 0.27))
			ell(img, 10.5, 8.0, 3.0, 2.4, Color(0.12, 0.33, 0.17))
		"w":
			var wb := Color(0.22, 0.45, 0.80)
			img.fill(wb)
			for i in range(5):
				var hh := _hash(x, y, 20 + i)
				px(img, hh % 14 + 1, (hh / 14) % 14 + 1, Color(0.55, 0.78, 1.0))
				px(img, hh % 14 + 2, (hh / 14) % 14 + 1, Color(0.45, 0.70, 0.95))
		"W":
			img.fill(Color(0.86, 0.78, 0.62))
			for yy in range(0, 16, 4):
				line(img, 0, yy, 15, yy, Color(0.62, 0.52, 0.38))
			for yy in range(0, 16, 8):
				for xx in range(0, 16, 8):
					px(img, xx + (4 if (yy / 8) % 2 == 0 else 0), yy + 2, Color(0.62, 0.52, 0.38))
		"R":
			img.fill(Color(0.72, 0.28, 0.24))
			for yy in range(0, 16, 4):
				line(img, 0, yy + 3, 15, yy + 3, Color(0.46, 0.16, 0.16))
				for xx in range(0, 16, 6):
					px(img, (xx + (yy * 3)) % 16, yy + 1, Color(0.86, 0.42, 0.34))
		"D":
			img.fill(Color(0.86, 0.78, 0.62))
			rect(img, 3, 1, 12, 15, Color(0.45, 0.28, 0.14))
			rect(img, 4, 2, 11, 15, Color(0.58, 0.38, 0.20))
			line(img, 8, 2, 8, 15, Color(0.40, 0.25, 0.12))
			px(img, 10, 9, Color(1.0, 0.85, 0.3))
		"_":
			img.fill(Color(0.64, 0.46, 0.28))
			for yy in range(0, 16, 4):
				line(img, 0, yy, 15, yy, Color(0.50, 0.34, 0.20))
			for yy in range(0, 16, 4):
				px(img, (yy * 5 + x * 3) % 16, yy + 2, Color(0.72, 0.54, 0.34))
		"c":
			img.fill(Color(0.64, 0.46, 0.28))
			rect(img, 0, 3, 15, 13, Color(0.45, 0.28, 0.14))
			rect(img, 0, 3, 15, 5, Color(0.72, 0.50, 0.28))
			rect(img, 0, 13, 15, 14, Color(0.30, 0.18, 0.10))
		"b":
			img.fill(Color(0.40, 0.26, 0.14))
			for shelf in [0, 5, 10]:
				rect(img, 1, shelf + 3, 14, shelf + 4, Color(0.28, 0.17, 0.09))
				for k in range(7):
					var col: Color = [Color(0.8, 0.2, 0.2), Color(0.2, 0.4, 0.8), Color(0.2, 0.7, 0.3), Color(0.9, 0.8, 0.2)][(k + shelf) % 4]
					rect(img, 1 + k * 2, shelf, 1 + k * 2 + 1, shelf + 2, col)
		"r":
			img.fill(Color(0.64, 0.46, 0.28))
			rect(img, 1, 0, 14, 15, Color(0.62, 0.15, 0.18))
			rect(img, 2, 0, 13, 15, Color(0.74, 0.22, 0.24))
			line(img, 2, 7, 13, 7, Color(0.95, 0.80, 0.30))
		"#":
			_dungeon_wall(img, x, y, floor_n)
		":":
			_dungeon_floor(img, x, y, floor_n, false)
		"x":
			_dungeon_floor(img, x, y, floor_n, true)
		"<", ">", "S":
			_dungeon_floor(img, x, y, floor_n, false)
			_stairs(img, ch)
		"h":
			_grass(img, x, y, Color(0.30, 0.56, 0.27))
			rect(img, 1, 3, 14, 15, Color(0.38, 0.36, 0.34))
			ell(img, 8, 9, 6, 6, Color(0.05, 0.05, 0.08))
			rect(img, 2, 9, 13, 15, Color(0.05, 0.05, 0.08))
			for i in range(8):
				var hh := _hash(x, y, 40 + i)
				px(img, 1 + hh % 14, 3 + hh % 5, Color(0.5, 0.48, 0.45))
		"o":
			_grass(img, x, y, Color(0.30, 0.56, 0.27))
			ell(img, 8, 10, 7, 5, Color(0.50, 0.50, 0.52))
			ell(img, 6.5, 8.5, 4, 2.6, Color(0.66, 0.66, 0.68))
			ell(img, 11, 12, 3, 2, Color(0.38, 0.38, 0.40))
		_:
			img.fill(Color(1, 0, 1))
	return img

static func _grass(img: Image, x: int, y: int, base: Color) -> void:
	img.fill(base)
	for i in range(10):
		var hh := _hash(x, y, i)
		var c := shade(base, 1.15) if i % 2 == 0 else shade(base, 0.85)
		px(img, hh % 16, (hh / 16) % 16, c)
	var hb := _hash(x, y, 77)
	if hb < 160:
		var bx := 2 + hb % 12
		var by := 3 + (hb / 12) % 10
		px(img, bx, by, shade(base, 1.3))
		px(img, bx, by - 1, shade(base, 1.3))

static func _dirt(img: Image, x: int, y: int, base: Color) -> void:
	img.fill(base)
	for i in range(14):
		var hh := _hash(x, y, 90 + i)
		px(img, hh % 16, (hh / 16) % 16, shade(base, 1.12) if i % 2 == 0 else shade(base, 0.82))

static func _tier_colors(floor_n: int) -> Dictionary:
	var tier := Balance.floor_tier(floor_n) if floor_n > 0 else 0
	var wall: Color = [Color(0.16, 0.26, 0.18), Color(0.28, 0.24, 0.16), Color(0.22, 0.18, 0.32), Color(0.16, 0.24, 0.34)][tier]
	var floor_c: Color = [Color(0.34, 0.28, 0.20), Color(0.38, 0.30, 0.20), Color(0.30, 0.26, 0.34), Color(0.30, 0.34, 0.40)][tier]
	return {"wall": wall, "floor": floor_c}

static func _dungeon_wall(img: Image, x: int, y: int, floor_n: int) -> void:
	var c: Color = _tier_colors(floor_n)["wall"]
	img.fill(c)
	for i in range(18):
		var hh := _hash(x, y, 200 + i)
		var col := shade(c, 1.35) if i % 3 == 0 else shade(c, 0.7)
		var bx := hh % 16
		var by := (hh / 16) % 16
		px(img, bx, by, col)
		if i % 4 == 0:
			px(img, bx + 1, by, col)
	rect(img, 0, 15, 15, 15, shade(c, 0.55))
	rect(img, 0, 0, 15, 0, shade(c, 1.2))

static func _dungeon_floor(img: Image, x: int, y: int, floor_n: int, arena: bool) -> void:
	var c: Color = _tier_colors(floor_n)["floor"]
	if arena:
		c = shade(c, 0.7)
		c = Color(c.r * 1.1, c.g * 0.9, c.b * 1.25)
	img.fill(c)
	for i in range(12):
		var hh := _hash(x, y, 300 + i)
		var col := shade(c, 1.2) if i % 2 == 0 else shade(c, 0.8)
		px(img, hh % 16, (hh / 16) % 16, col)
	if arena:
		for k in [0, 15]:
			line(img, 0, k, 15, k, shade(c, 1.25))
		var hh2 := _hash(x, y, 400)
		if hh2 < 90:
			px(img, 8, 8, Color(0.75, 0.3, 0.45))
	else:
		var hh3 := _hash(x, y, 410)
		if hh3 < 110:
			var mx := 2 + hh3 % 12
			var my := 2 + (hh3 / 12) % 12
			px(img, mx, my, Color(0.25, 0.5, 0.25))
			px(img, mx + 1, my, Color(0.2, 0.42, 0.2))

static func _stairs(img: Image, ch: String) -> void:
	rect(img, 1, 1, 14, 14, Color(0.20, 0.18, 0.16))
	for i in range(5):
		var yy := 2 + i * 2 + (0 if ch != "<" else 0)
		var shade_v := 0.55 + 0.12 * float(i if ch == ">" else 4 - i)
		rect(img, 2, yy, 13, yy + 1, Color(0.55 * shade_v + 0.2, 0.50 * shade_v + 0.2, 0.45 * shade_v + 0.2))
	var arrow := Color(1.0, 0.9, 0.35)
	if ch == "<":
		line(img, 8, 3, 4, 7, arrow); line(img, 8, 3, 12, 7, arrow); line(img, 8, 3, 8, 12, arrow)
	elif ch == ">":
		line(img, 8, 12, 4, 8, arrow); line(img, 8, 12, 12, 8, arrow); line(img, 8, 3, 8, 12, arrow)
	else:
		rect(img, 1, 1, 14, 14, Color(0.25, 0.08, 0.14))
		rect(img, 2, 2, 13, 13, Color(0.45, 0.12, 0.20))
		line(img, 4, 4, 11, 11, Color(1.0, 0.35, 0.35), 2)
		line(img, 11, 4, 4, 11, Color(1.0, 0.35, 0.35), 2)

## Imagem completa do mapa (todos os tiles combinados). "frame" (0/1) so muda a agua e a lava animadas.
static func map_image(m: MapData, frame: int = 0) -> Image:
	if m.kind == "overworld":
		return IslandArt.render_image(m, frame)
	var img := _new(m.w * 16, m.h * 16)
	for y in range(m.h):
		for x in range(m.w):
			var ch := m.tile_at(x, y)
			var tile := tile_image(ch, x, y, m.floor_n)
			img.blit_rect(tile, Rect2i(0, 0, 16, 16), Vector2i(x * 16, y * 16))
	return img

static func map_texture(m: MapData) -> ImageTexture:
	return _tex(map_image(m))

const CHUNK_PX := 1024

## Mapa dividido em blocos de 1024x1024 px (cabe em GPUs/celulares com limite de textura de 2048).
## Retorna Array de {tex, pos, tex2?}. "tex2" = 2o quadro da animacao (blocos com agua/lava).
static func map_chunks(m: MapData) -> Array:
	var img := map_image(m, 0)
	var img2: Image = null
	if m.kind == "overworld":
		img2 = map_image(m, 1)
	var out: Array = []
	var y0 := 0
	while y0 < img.get_height():
		var x0 := 0
		while x0 < img.get_width():
			var r := Rect2i(x0, y0, mini(CHUNK_PX, img.get_width() - x0), mini(CHUNK_PX, img.get_height() - y0))
			var d := {"tex": _tex(img.get_region(r)), "pos": Vector2(x0, y0)}
			if img2 != null and _chunk_animated(m, r):
				d["tex2"] = _tex(img2.get_region(r))
			out.append(d)
			x0 += CHUNK_PX
		y0 += CHUNK_PX
	return out

static func _chunk_animated(m: MapData, r: Rect2i) -> bool:
	for ty in range(r.position.y / 16, mini(m.h, (r.position.y + r.size.y) / 16)):
		var row: String = m.rows[ty]
		for tx in range(r.position.x / 16, mini(m.w, (r.position.x + r.size.x) / 16)):
			if "w~=lB".contains(row[tx]):
				return true
	return false

## Copas das arvores altas, desenhadas ACIMA do personagem (ele passa por tras das arvores).
static func map_overlay_chunks(m: MapData) -> Array:
	var out: Array = []
	if m.kind != "overworld":
		return out
	var img := IslandArt.render_overlay(m)
	var y0 := 0
	while y0 < img.get_height():
		var x0 := 0
		while x0 < img.get_width():
			var r := Rect2i(x0, y0, mini(CHUNK_PX, img.get_width() - x0), mini(CHUNK_PX, img.get_height() - y0))
			var part := img.get_region(r)
			if not part.is_invisible():
				out.append({"tex": _tex(part), "pos": Vector2(x0, y0)})
			x0 += CHUNK_PX
		y0 += CHUNK_PX
	return out

# ============================================================== PERSONAGENS (16x24, 4 direcoes x 3 frames)
static func look_for(name: String) -> Dictionary:
	var base := {"skin": Color(0.95, 0.74, 0.58), "hair": Color(0.4, 0.26, 0.12), "primary": Color(0.3, 0.5, 0.8), "secondary": Color(0.9, 0.8, 0.3),
		"hat": "none", "tool": "none", "legs": Color(0.3, 0.25, 0.2)}
	var d := base.duplicate()
	match name:
		"warrior": d.merge({"primary": Color(0.78, 0.2, 0.2), "secondary": Color(0.7, 0.7, 0.75), "hat": "none", "tool": "sword", "legs": Color(0.3, 0.3, 0.35), "band": Color(0.85, 0.15, 0.15)}, true)
		"mage": d.merge({"primary": Color(0.25, 0.35, 0.85), "secondary": Color(0.95, 0.85, 0.3), "hair": Color(0.85, 0.85, 0.9), "hat": "pointy", "tool": "staff", "legs": Color(0.2, 0.2, 0.5), "cape": Color(0.18, 0.25, 0.65)}, true)
		"rogue": d.merge({"primary": Color(0.22, 0.2, 0.3), "secondary": Color(0.55, 0.15, 0.55), "hair": Color(0.1, 0.1, 0.12), "hat": "hood", "tool": "dagger", "legs": Color(0.15, 0.14, 0.2), "cape": Color(0.14, 0.12, 0.2)}, true)
		"paladin": d.merge({"primary": Color(0.92, 0.92, 0.95), "secondary": Color(0.95, 0.78, 0.2), "hair": Color(0.85, 0.7, 0.3), "hat": "none", "tool": "mace", "legs": Color(0.6, 0.6, 0.7), "cape": Color(0.8, 0.2, 0.2), "shield": true}, true)
		"elder": d.merge({"primary": Color(0.45, 0.30, 0.55), "hair": Color(0.9, 0.9, 0.9), "hat": "none", "tool": "staff", "legs": Color(0.35, 0.22, 0.45), "secondary": Color(0.8, 0.7, 0.3)}, true)
		"villager_f": d.merge({"primary": Color(0.85, 0.45, 0.55), "hair": Color(0.55, 0.25, 0.12), "secondary": Color(1, 1, 1)}, true)
		"villager_m": d.merge({"primary": Color(0.35, 0.6, 0.35), "hair": Color(0.2, 0.15, 0.1), "secondary": Color(0.9, 0.8, 0.5)}, true)
		"guard": d.merge({"primary": Color(0.45, 0.5, 0.6), "hair": Color(0.3, 0.2, 0.1), "hat": "helmet", "tool": "spear", "secondary": Color(0.8, 0.8, 0.85), "legs": Color(0.3, 0.3, 0.4)}, true)
		"clerk": d.merge({"primary": Color(0.25, 0.45, 0.65), "hair": Color(0.7, 0.4, 0.2), "secondary": Color(0.95, 0.85, 0.4)}, true)
		"master": d.merge({"primary": Color(0.55, 0.15, 0.15), "hair": Color(0.6, 0.6, 0.65), "hat": "none", "tool": "sword", "secondary": Color(0.95, 0.8, 0.3), "legs": Color(0.25, 0.2, 0.2)}, true)
		"shopkeeper": d.merge({"primary": Color(0.35, 0.55, 0.30), "hair": Color(0.45, 0.3, 0.15), "secondary": Color(0.95, 0.95, 0.9), "hat": "cap"}, true)
		"innkeeper": d.merge({"primary": Color(0.85, 0.65, 0.35), "hair": Color(0.5, 0.3, 0.2), "secondary": Color(1, 1, 1), "hat": "cap"}, true)
	return d

static func char_frames(look: Dictionary) -> Dictionary:
	var key := "char_" + str(look.hash())
	if _cache.has(key):
		return _cache[key]
	var out := {}
	for dir in ["down", "up", "left", "right"]:
		var arr: Array = []
		for f in range(3):
			arr.append(_tex(_draw_char(look, dir, f)))
		out[dir] = arr
	_cache[key] = out
	return out

static func _draw_char(look: Dictionary, dir: String, frame: int) -> Image:
	var img := _new(16, 24)
	var skin: Color = look["skin"]
	var hair: Color = look["hair"]
	var prim: Color = look["primary"]
	var sec: Color = look["secondary"]
	var legs: Color = look["legs"]
	var bob := 1 if frame == 1 or frame == 2 else 0
	# sombra
	ell(img, 8, 22, 5, 1.6, Color(0, 0, 0, 0.28))
	# pernas
	var lstep := 0
	if frame == 1:
		lstep = 1
	elif frame == 2:
		lstep = -1
	if dir in ["down", "up"]:
		rect(img, 5, 17, 7, 20 + (lstep if lstep > 0 else 0), legs)
		rect(img, 9, 17, 11, 20 + (-lstep if lstep < 0 else 0), legs)
		rect(img, 5, 20 + (lstep if lstep > 0 else 0), 7, 20 + (lstep if lstep > 0 else 0), shade(legs, 0.6))
		rect(img, 9, 20 + (-lstep if lstep < 0 else 0), 11, 20 + (-lstep if lstep < 0 else 0), shade(legs, 0.6))
	else:
		rect(img, 6 + lstep, 17, 8 + lstep, 20, legs)
		rect(img, 8 - lstep, 17, 10 - lstep, 20, shade(legs, 0.85))
		rect(img, 6 + lstep, 20, 9 + lstep, 20, shade(legs, 0.55))
	var by := -bob
	var cape: Color = look.get("cape", Color(0, 0, 0, 0))
	if cape.a > 0.0 and dir != "up":
		rect(img, 4 if dir != "right" else 3, 12 + by, 11 if dir != "left" else 12, 20 + by + (1 if bob == 0 else 0), shade(cape, 0.8))
	# corpo
	rect(img, 4, 11 + by + 1, 11, 17 + by, prim)
	rect(img, 4, 11 + by + 1, 11, 11 + by + 1, shade(prim, 1.2))
	rect(img, 4, 15 + by, 11, 15 + by, sec)
	# bracos
	if dir in ["down", "up"]:
		rect(img, 3, 12 + by, 3, 16 + by, shade(prim, 0.85))
		rect(img, 12, 12 + by, 12, 16 + by, shade(prim, 0.85))
		px(img, 3, 17 + by, skin)
		px(img, 12, 17 + by, skin)
	elif dir == "left":
		rect(img, 7, 12 + by, 8, 16 + by, shade(prim, 0.8))
		px(img, 7, 17 + by, skin)
	else:
		rect(img, 7, 12 + by, 8, 16 + by, shade(prim, 0.8))
		px(img, 8, 17 + by, skin)
	# ferramenta
	var tool: String = look["tool"]
	if tool != "none":
		_draw_tool(img, tool, dir, by, sec)
	if cape.a > 0.0 and dir == "up":
		rect(img, 4, 11 + by + 1, 11, 20 + by, cape)
		rect(img, 4, 11 + by + 1, 11, 11 + by + 1, shade(cape, 1.25))
	if look.get("shield", false):
		var sxx := 0 if dir != "right" else 10
		if dir == "left":
			sxx = 9
		rect(img, sxx + 1, 12 + by, sxx + 4, 18 + by, Color(0.93, 0.93, 0.97))
		rect(img, sxx + 1, 12 + by, sxx + 4, 12 + by, sec)
		rect(img, sxx + 1, 18 + by, sxx + 4, 18 + by, sec)
		rect(img, sxx + 2, 13 + by, sxx + 3, 17 + by, cape if cape.a > 0.0 else Color(0.8, 0.2, 0.2))
	# cabeca
	ell(img, 8, 7 + by + 1, 4.2, 4.2, skin)
	match dir:
		"down":
			rect(img, 4, 3 + by + 1, 11, 5 + by + 1, hair)
			px(img, 4, 6 + by + 1, hair)
			px(img, 11, 6 + by + 1, hair)
			px(img, 6, 8 + by + 1, Color(0.1, 0.1, 0.15))
			px(img, 10, 8 + by + 1, Color(0.1, 0.1, 0.15))
		"up":
			ell(img, 8, 6 + by + 1, 4.2, 3.8, hair)
			rect(img, 5, 9 + by + 1, 10, 10 + by + 1, skin)
		"left":
			rect(img, 5, 3 + by + 1, 11, 5 + by + 1, hair)
			rect(img, 8, 6 + by + 1, 11, 9 + by + 1, hair)
			px(img, 5, 8 + by + 1, Color(0.1, 0.1, 0.15))
		"right":
			rect(img, 4, 3 + by + 1, 10, 5 + by + 1, hair)
			rect(img, 4, 6 + by + 1, 7, 9 + by + 1, hair)
			px(img, 10, 8 + by + 1, Color(0.1, 0.1, 0.15))
	# chapeu / capacete
	match look["hat"]:
		"pointy":
			rect(img, 3, 4 + by + 1, 12, 4 + by + 1, prim)
			rect(img, 5, 2 + by + 1, 10, 3 + by + 1, prim)
			rect(img, 6, 0 + by + 1, 9, 1 + by + 1, prim)
			px(img, 7, by + 1, sec)
		"hood":
			ell(img, 8, 5 + by + 1, 5, 4, prim)
			rect(img, 5, 6 + by + 1, 10, 9 + by + 1, skin if dir == "down" else prim)
			if dir == "down":
				px(img, 6, 8 + by + 1, Color(0.95, 0.9, 0.3))
				px(img, 10, 8 + by + 1, Color(0.95, 0.9, 0.3))
		"helmet":
			rect(img, 3, 3 + by + 1, 12, 6 + by + 1, sec)
			rect(img, 3, 3 + by + 1, 12, 3 + by + 1, shade(sec, 1.2))
			px(img, 8, 2 + by + 1, Color(0.8, 0.2, 0.2))
		"cap":
			rect(img, 4, 3 + by + 1, 11, 4 + by + 1, sec)
	if look.has("band"):
		rect(img, 4, 5 + by + 1, 11, 5 + by + 1, look["band"])
	outline(img, Color(0.08, 0.06, 0.10, 1))
	return img

static func _draw_tool(img: Image, tool: String, dir: String, by: int, sec: Color) -> void:
	var steel := Color(0.85, 0.88, 0.95)
	var wood := Color(0.55, 0.36, 0.18)
	var tx := 13 if dir != "left" else 2
	if dir == "right":
		tx = 3
	match tool:
		"sword":
			line(img, tx, 17 + by, tx, 9 + by, steel)
			px(img, tx, 8 + by, Color(1, 1, 1))
			rect(img, tx - 1, 17 + by, tx + 1, 17 + by, sec)
			px(img, tx, 18 + by, wood)
		"staff":
			line(img, tx, 20, tx, 7 + by, wood)
			ell(img, tx, 6 + by, 1.6, 1.6, Color(0.4, 0.85, 1.0))
		"dagger":
			line(img, tx, 17 + by, tx, 13 + by, steel)
			px(img, tx, 18 + by, wood)
		"mace":
			line(img, tx, 19, tx, 11 + by, wood)
			ell(img, tx, 10 + by, 2, 2, sec)
		"spear":
			line(img, tx, 20, tx, 5 + by, wood)
			px(img, tx, 4 + by, steel)
			px(img, tx, 3 + by, steel)

# ============================================================== INIMIGOS (desenhados em coordenadas normalizadas)
class Painter:
	var img: Image
	var s: int
	func _init(size: int) -> void:
		s = size
		img = Image.create(size, size, false, Image.FORMAT_RGBA8)
		img.fill(Color(0, 0, 0, 0))
	func ell(cx: float, cy: float, rx: float, ry: float, c: Color) -> void:
		PixelArt.ell(img, cx * s, cy * s, rx * s, ry * s, c)
	func rct(x0: float, y0: float, x1: float, y1: float, c: Color) -> void:
		PixelArt.rect(img, int(x0 * s), int(y0 * s), int(x1 * s), int(y1 * s), c)
	func ln(x0: float, y0: float, x1: float, y1: float, c: Color, th: float = 0.0) -> void:
		PixelArt.line(img, int(x0 * s), int(y0 * s), int(x1 * s), int(y1 * s), c, maxi(1, int(th * s)))
	func dot(x: float, y: float, c: Color) -> void:
		var r := maxf(1.0, float(s) * 0.045)
		PixelArt.ell(img, x * s, y * s, r, r, c)
	func tri(x0: float, y0: float, x1: float, y1: float, x2: float, y2: float, c: Color) -> void:
		var minx := int(minf(minf(x0, x1), x2) * s)
		var maxx := int(maxf(maxf(x0, x1), x2) * s)
		var miny := int(minf(minf(y0, y1), y2) * s)
		var maxy := int(maxf(maxf(y0, y1), y2) * s)
		for y in range(miny, maxy + 1):
			for x in range(minx, maxx + 1):
				var p := Vector2(float(x) + 0.5, float(y) + 0.5) / float(s)
				var a := Vector2(x0, y0)
				var b := Vector2(x1, y1)
				var cc := Vector2(x2, y2)
				var d1 := (p.x - cc.x) * (a.y - cc.y) - (a.x - cc.x) * (p.y - cc.y)
				var d2 := (p.x - cc.x) * (b.y - cc.y) - (b.x - cc.x) * (p.y - cc.y)
				var d3 := (p.x - a.x) * (b.y - a.y) - (b.x - a.x) * (p.y - a.y)
				var neg := d1 < 0 or d2 < 0 or d3 < 0
				var pos := d1 > 0 or d2 > 0 or d3 > 0
				if not (neg and pos):
					PixelArt.px(img, x, y, c)

static func enemy_texture(sprite_id: String, color: Color, size_px: int) -> ImageTexture:
	var key := "en_%s_%s_%d" % [sprite_id, color.to_html(), size_px]
	if _cache.has(key):
		return _cache[key]
	var p := Painter.new(size_px)
	var eye := Color(0.08, 0.06, 0.1)
	var white := Color(1, 1, 1)
	var dk := shade(color, 0.6)
	var lt := shade(color, 1.3)
	match sprite_id:
		"slime", "slime_king":
			var king := sprite_id == "slime_king"
			p.ell(0.5, 0.80, 0.42, 0.07, Color(0, 0, 0, 0.25))
			p.ell(0.5, 0.60, 0.38, 0.30, color)
			p.rct(0.12, 0.60, 0.88, 0.78, color)
			p.ell(0.5, 0.78, 0.38, 0.08, dk)
			p.ell(0.38, 0.46, 0.10, 0.06, lt)
			p.ell(0.38, 0.58, 0.06, 0.08, white)
			p.ell(0.62, 0.58, 0.06, 0.08, white)
			p.dot(0.38, 0.60, eye)
			p.dot(0.62, 0.60, eye)
			p.ln(0.43, 0.70, 0.57, 0.70, eye)
			if king:
				p.rct(0.30, 0.18, 0.70, 0.30, Color(1.0, 0.85, 0.2))
				for cx in [0.30, 0.42, 0.54, 0.66]:
					p.tri(cx, 0.18, cx + 0.06, 0.18, cx + 0.03, 0.06, Color(1.0, 0.85, 0.2))
				p.dot(0.5, 0.24, Color(0.9, 0.2, 0.3))
		"bat":
			p.ell(0.5, 0.55, 0.14, 0.18, color)
			p.tri(0.36, 0.5, 0.02, 0.25, 0.10, 0.70, dk)
			p.tri(0.64, 0.5, 0.98, 0.25, 0.90, 0.70, dk)
			p.tri(0.36, 0.5, 0.12, 0.38, 0.14, 0.62, color)
			p.tri(0.64, 0.5, 0.88, 0.38, 0.86, 0.62, color)
			p.tri(0.42, 0.40, 0.40, 0.28, 0.48, 0.38, color)
			p.tri(0.58, 0.40, 0.60, 0.28, 0.52, 0.38, color)
			p.dot(0.45, 0.52, Color(1, 0.3, 0.3))
			p.dot(0.55, 0.52, Color(1, 0.3, 0.3))
			p.tri(0.46, 0.62, 0.50, 0.70, 0.48, 0.62, white)
		"goblin":
			p.ell(0.5, 0.88, 0.24, 0.05, Color(0, 0, 0, 0.25))
			p.rct(0.34, 0.60, 0.66, 0.84, Color(0.5, 0.35, 0.2))
			p.rct(0.36, 0.84, 0.46, 0.92, dk)
			p.rct(0.54, 0.84, 0.64, 0.92, dk)
			p.ell(0.5, 0.40, 0.20, 0.20, color)
			p.tri(0.30, 0.38, 0.08, 0.28, 0.30, 0.50, color)
			p.tri(0.70, 0.38, 0.92, 0.28, 0.70, 0.50, color)
			p.dot(0.42, 0.38, Color(1, 0.9, 0.2))
			p.dot(0.58, 0.38, Color(1, 0.9, 0.2))
			p.ln(0.42, 0.50, 0.58, 0.50, eye)
			p.ln(0.76, 0.52, 0.86, 0.78, Color(0.5, 0.35, 0.2), 0.04)
			p.ell(0.86, 0.78, 0.06, 0.06, Color(0.4, 0.3, 0.2))
		"mushroom":
			p.ell(0.5, 0.90, 0.22, 0.05, Color(0, 0, 0, 0.25))
			p.rct(0.38, 0.55, 0.62, 0.88, Color(0.95, 0.9, 0.78))
			p.ell(0.5, 0.40, 0.42, 0.28, color)
			p.rct(0.08, 0.40, 0.92, 0.50, color)
			for sp in [[0.28, 0.30], [0.55, 0.22], [0.72, 0.38], [0.42, 0.40]]:
				p.ell(sp[0], sp[1], 0.07, 0.06, Color(0.9, 0.95, 1.0))
			p.dot(0.44, 0.65, eye)
			p.dot(0.56, 0.65, eye)
		"wolf":
			p.ell(0.5, 0.90, 0.36, 0.05, Color(0, 0, 0, 0.25))
			p.ell(0.46, 0.60, 0.30, 0.20, color)
			p.rct(0.24, 0.70, 0.32, 0.88, dk)
			p.rct(0.40, 0.70, 0.48, 0.88, dk)
			p.rct(0.56, 0.70, 0.64, 0.88, dk)
			p.ell(0.76, 0.46, 0.14, 0.13, color)
			p.tri(0.70, 0.38, 0.72, 0.22, 0.78, 0.36, color)
			p.tri(0.80, 0.38, 0.86, 0.24, 0.86, 0.38, color)
			p.rct(0.84, 0.46, 0.96, 0.52, lt)
			p.dot(0.78, 0.44, Color(1, 0.85, 0.2))
			p.ln(0.18, 0.52, 0.06, 0.38, color, 0.07)
			p.tri(0.86, 0.52, 0.88, 0.58, 0.90, 0.52, white)
		"spider", "spider_queen":
			var q := sprite_id == "spider_queen"
			p.ell(0.5, 0.58, 0.20, 0.17, color)
			p.ell(0.5, 0.40, 0.12, 0.10, dk)
			for i in range(4):
				var yy := 0.38 + 0.09 * float(i)
				p.ln(0.38, yy, 0.08, yy - 0.14 + 0.10 * float(i), dk, 0.025)
				p.ln(0.62, yy, 0.92, yy - 0.14 + 0.10 * float(i), dk, 0.025)
			p.dot(0.45, 0.38, Color(1, 0.2, 0.2))
			p.dot(0.55, 0.38, Color(1, 0.2, 0.2))
			p.ell(0.5, 0.64, 0.07, 0.07, Color(0.95, 0.3, 0.3))
			if q:
				p.tri(0.40, 0.30, 0.44, 0.18, 0.48, 0.30, Color(1.0, 0.85, 0.2))
				p.tri(0.48, 0.30, 0.52, 0.14, 0.56, 0.30, Color(1.0, 0.85, 0.2))
				p.tri(0.56, 0.30, 0.60, 0.18, 0.64, 0.30, Color(1.0, 0.85, 0.2))
		"skeleton":
			p.ell(0.5, 0.92, 0.22, 0.04, Color(0, 0, 0, 0.25))
			p.ell(0.5, 0.26, 0.17, 0.17, color)
			p.rct(0.40, 0.36, 0.60, 0.42, color)
			p.ell(0.43, 0.26, 0.05, 0.06, eye)
			p.ell(0.57, 0.26, 0.05, 0.06, eye)
			p.rct(0.46, 0.46, 0.54, 0.74, color)
			for i in range(3):
				p.ln(0.34, 0.50 + 0.07 * float(i), 0.66, 0.50 + 0.07 * float(i), color, 0.025)
			p.ln(0.36, 0.78, 0.40, 0.92, color, 0.04)
			p.ln(0.64, 0.78, 0.60, 0.92, color, 0.04)
			p.ln(0.34, 0.48, 0.24, 0.66, color, 0.04)
			p.ln(0.66, 0.48, 0.80, 0.30, color, 0.04)
			p.ln(0.80, 0.30, 0.80, 0.12, Color(0.8, 0.85, 0.9), 0.04)
		"golem":
			p.ell(0.5, 0.92, 0.32, 0.05, Color(0, 0, 0, 0.25))
			p.rct(0.30, 0.34, 0.70, 0.78, color)
			p.rct(0.30, 0.34, 0.70, 0.40, lt)
			p.rct(0.12, 0.38, 0.30, 0.64, dk)
			p.rct(0.70, 0.38, 0.88, 0.64, dk)
			p.rct(0.34, 0.78, 0.46, 0.92, dk)
			p.rct(0.54, 0.78, 0.66, 0.92, dk)
			p.rct(0.38, 0.14, 0.62, 0.34, shade(color, 1.1))
			p.rct(0.42, 0.22, 0.48, 0.26, Color(1.0, 0.6, 0.2))
			p.rct(0.54, 0.22, 0.60, 0.26, Color(1.0, 0.6, 0.2))
			p.ln(0.40, 0.50, 0.60, 0.58, dk)
			p.ln(0.60, 0.50, 0.50, 0.70, dk)
		"wisp":
			p.ell(0.5, 0.60, 0.22, 0.26, Color(color.r, color.g, color.b, 0.35))
			p.ell(0.5, 0.58, 0.16, 0.20, color)
			p.tri(0.34, 0.52, 0.50, 0.08, 0.66, 0.52, color)
			p.ell(0.5, 0.60, 0.09, 0.12, Color(1, 1, 1))
			p.dot(0.44, 0.58, eye)
			p.dot(0.56, 0.58, eye)
		"sapling":
			p.ell(0.5, 0.92, 0.22, 0.04, Color(0, 0, 0, 0.25))
			p.rct(0.40, 0.45, 0.60, 0.90, Color(0.45, 0.30, 0.16))
			p.ell(0.5, 0.30, 0.28, 0.24, color)
			p.ell(0.38, 0.22, 0.12, 0.10, lt)
			p.ln(0.40, 0.55, 0.14, 0.42, Color(0.45, 0.30, 0.16), 0.04)
			p.ln(0.60, 0.55, 0.86, 0.42, Color(0.45, 0.30, 0.16), 0.04)
			p.dot(0.44, 0.62, Color(1, 0.9, 0.3))
			p.dot(0.56, 0.62, Color(1, 0.9, 0.3))
		"ghost_knight":
			p.ell(0.5, 0.95, 0.30, 0.03, Color(0, 0, 0, 0.2))
			p.tri(0.22, 0.44, 0.78, 0.44, 0.50, 0.98, Color(color.r, color.g, color.b, 0.55))
			p.rct(0.28, 0.40, 0.72, 0.70, color)
			p.rct(0.28, 0.40, 0.72, 0.46, lt)
			p.ell(0.5, 0.24, 0.17, 0.17, shade(color, 1.1))
			p.rct(0.36, 0.24, 0.64, 0.28, Color(0.05, 0.05, 0.15))
			p.dot(0.42, 0.26, Color(1, 0.3, 0.3))
			p.dot(0.58, 0.26, Color(1, 0.3, 0.3))
			p.tri(0.46, 0.08, 0.50, 0.0, 0.54, 0.08, Color(0.9, 0.2, 0.3))
			p.ln(0.80, 0.62, 0.80, 0.08, Color(0.75, 0.85, 1.0), 0.05)
			p.rct(0.74, 0.58, 0.86, 0.62, Color(0.9, 0.8, 0.3))
			p.ell(0.22, 0.56, 0.10, 0.14, dk)
		"treant":
			p.ell(0.5, 0.96, 0.34, 0.03, Color(0, 0, 0, 0.25))
			var bark := Color(0.40, 0.27, 0.15)
			p.rct(0.36, 0.40, 0.64, 0.92, bark)
			p.rct(0.30, 0.82, 0.42, 0.96, shade(bark, 0.8))
			p.rct(0.58, 0.82, 0.70, 0.96, shade(bark, 0.8))
			p.ln(0.36, 0.52, 0.08, 0.38, bark, 0.07)
			p.ln(0.64, 0.52, 0.92, 0.38, bark, 0.07)
			p.ln(0.08, 0.38, 0.04, 0.22, bark, 0.04)
			p.ln(0.92, 0.38, 0.96, 0.22, bark, 0.04)
			p.ell(0.5, 0.24, 0.40, 0.22, color)
			p.ell(0.30, 0.16, 0.16, 0.12, lt)
			p.ell(0.68, 0.20, 0.14, 0.10, dk)
			p.dot(0.44, 0.50, Color(1, 0.85, 0.2))
			p.dot(0.56, 0.50, Color(1, 0.85, 0.2))
			p.ln(0.44, 0.62, 0.56, 0.62, Color(0.12, 0.08, 0.04), 0.03)
			p.ln(0.42, 0.70, 0.58, 0.74, shade(bark, 0.6))
		"scorpion", "scorpion_king":
			var sk := sprite_id == "scorpion_king"
			p.ell(0.5, 0.88, 0.34, 0.05, Color(0, 0, 0, 0.25))
			for lx in [0.34, 0.46, 0.58]:
				p.ln(lx, 0.68, lx - 0.12, 0.86, dk, 0.04)
				p.ln(lx + 0.14, 0.68, lx + 0.26, 0.86, dk, 0.04)
			p.ell(0.46, 0.62, 0.26, 0.15, color)
			p.ell(0.40, 0.58, 0.12, 0.06, lt)
			p.ell(0.22, 0.58, 0.12, 0.10, color)
			p.ln(0.30, 0.56, 0.12, 0.44, dk, 0.05)
			p.ell(0.10, 0.38, 0.09, 0.08, color)
			p.tri(0.04, 0.36, 0.14, 0.30, 0.10, 0.42, Color(0, 0, 0, 0))
			p.ln(0.66, 0.56, 0.84, 0.44, color, 0.06)
			p.ln(0.84, 0.44, 0.80, 0.24, color, 0.06)
			p.ln(0.80, 0.24, 0.60, 0.14, color, 0.06)
			p.tri(0.60, 0.08, 0.60, 0.22, 0.44, 0.18, Color(0.95, 0.85, 0.3))
			p.dot(0.20, 0.56, Color(1, 0.2, 0.2))
			p.dot(0.26, 0.54, Color(1, 0.2, 0.2))
			if sk:
				p.rct(0.14, 0.40, 0.30, 0.46, Color(1.0, 0.85, 0.2))
				for cx in [0.14, 0.20, 0.26]:
					p.tri(cx, 0.40, cx + 0.04, 0.40, cx + 0.02, 0.32, Color(1.0, 0.85, 0.2))
		"snake":
			p.ell(0.5, 0.90, 0.36, 0.04, Color(0, 0, 0, 0.25))
			for c in [[0.30, 0.80], [0.50, 0.82], [0.70, 0.80], [0.66, 0.66], [0.46, 0.60], [0.36, 0.48], [0.46, 0.36]]:
				p.ell(c[0], c[1], 0.14, 0.11, color)
			for c in [[0.30, 0.84], [0.50, 0.86], [0.70, 0.84]]:
				p.ell(c[0], c[1], 0.10, 0.04, lt)
			p.ell(0.56, 0.24, 0.16, 0.13, color)
			p.dot(0.52, 0.20, Color(1, 0.9, 0.2))
			p.dot(0.62, 0.20, Color(1, 0.9, 0.2))
			p.ln(0.70, 0.28, 0.86, 0.30, Color(0.9, 0.15, 0.2), 0.02)
			p.ln(0.86, 0.30, 0.92, 0.26, Color(0.9, 0.15, 0.2), 0.02)
			p.dot(0.30, 0.78, dk)
			p.dot(0.66, 0.64, dk)
		"toad", "toad_king":
			var tk := sprite_id == "toad_king"
			p.ell(0.5, 0.90, 0.36, 0.05, Color(0, 0, 0, 0.25))
			p.ell(0.22, 0.80, 0.12, 0.08, dk)
			p.ell(0.78, 0.80, 0.12, 0.08, dk)
			p.ell(0.5, 0.64, 0.36, 0.26, color)
			p.ell(0.5, 0.74, 0.26, 0.12, lt)
			p.ell(0.32, 0.38, 0.11, 0.11, color)
			p.ell(0.68, 0.38, 0.11, 0.11, color)
			p.ell(0.32, 0.37, 0.07, 0.08, Color(1, 0.95, 0.5))
			p.ell(0.68, 0.37, 0.07, 0.08, Color(1, 0.95, 0.5))
			p.dot(0.33, 0.38, eye)
			p.dot(0.67, 0.38, eye)
			p.ln(0.22, 0.58, 0.78, 0.58, eye, 0.03)
			for w in [[0.30, 0.66], [0.62, 0.70], [0.74, 0.60], [0.44, 0.50]]:
				p.dot(w[0], w[1], dk)
			if tk:
				p.rct(0.34, 0.20, 0.66, 0.28, Color(1.0, 0.85, 0.2))
				for cx in [0.34, 0.44, 0.54, 0.62]:
					p.tri(cx, 0.20, cx + 0.04, 0.20, cx + 0.02, 0.10, Color(1.0, 0.85, 0.2))
				p.dot(0.5, 0.24, Color(0.3, 0.8, 0.4))
		"yeti", "yeti_king":
			var yk := sprite_id == "yeti_king"
			p.ell(0.5, 0.95, 0.30, 0.03, Color(0, 0, 0, 0.25))
			p.ell(0.34, 0.88, 0.12, 0.07, dk)
			p.ell(0.66, 0.88, 0.12, 0.07, dk)
			p.ell(0.5, 0.60, 0.30, 0.32, color)
			p.ell(0.14, 0.60, 0.10, 0.22, color)
			p.ell(0.86, 0.60, 0.10, 0.22, color)
			p.ell(0.14, 0.80, 0.08, 0.06, Color(0.5, 0.65, 0.85))
			p.ell(0.86, 0.80, 0.08, 0.06, Color(0.5, 0.65, 0.85))
			p.ell(0.5, 0.30, 0.20, 0.18, color)
			p.ell(0.5, 0.33, 0.13, 0.11, Color(0.45, 0.62, 0.85))
			p.dot(0.43, 0.30, eye)
			p.dot(0.57, 0.30, eye)
			p.ln(0.43, 0.39, 0.57, 0.39, eye, 0.03)
			p.tri(0.45, 0.39, 0.47, 0.45, 0.49, 0.39, white)
			p.tri(0.51, 0.39, 0.53, 0.45, 0.55, 0.39, white)
			p.ell(0.38, 0.52, 0.08, 0.05, lt)
			if yk:
				p.tri(0.30, 0.20, 0.20, 0.02, 0.38, 0.14, Color(0.7, 0.9, 1.0))
				p.tri(0.70, 0.20, 0.80, 0.02, 0.62, 0.14, Color(0.7, 0.9, 1.0))
				p.tri(0.46, 0.14, 0.50, 0.0, 0.54, 0.14, Color(0.8, 0.95, 1.0))
		"imp":
			p.ell(0.5, 0.92, 0.22, 0.04, Color(0, 0, 0, 0.25))
			p.tri(0.34, 0.50, 0.04, 0.30, 0.22, 0.66, dk)
			p.tri(0.66, 0.50, 0.96, 0.30, 0.78, 0.66, dk)
			p.ell(0.5, 0.64, 0.18, 0.22, color)
			p.rct(0.38, 0.80, 0.46, 0.90, dk)
			p.rct(0.54, 0.80, 0.62, 0.90, dk)
			p.ell(0.5, 0.36, 0.19, 0.17, color)
			p.tri(0.34, 0.26, 0.28, 0.06, 0.42, 0.22, Color(0.95, 0.9, 0.7))
			p.tri(0.66, 0.26, 0.72, 0.06, 0.58, 0.22, Color(0.95, 0.9, 0.7))
			p.dot(0.43, 0.34, Color(1, 0.9, 0.2))
			p.dot(0.57, 0.34, Color(1, 0.9, 0.2))
			p.ln(0.42, 0.44, 0.58, 0.44, eye, 0.03)
			p.tri(0.44, 0.44, 0.47, 0.50, 0.50, 0.44, white)
			p.ln(0.66, 0.78, 0.86, 0.84, dk, 0.04)
			p.tri(0.84, 0.78, 0.96, 0.86, 0.84, 0.90, dk)
		"hellhound":
			p.ell(0.5, 0.90, 0.38, 0.04, Color(0, 0, 0, 0.25))
			for lx in [0.24, 0.36, 0.60, 0.72]:
				p.rct(lx - 0.04, 0.66, lx + 0.04, 0.90, dk)
			p.ell(0.46, 0.58, 0.30, 0.18, color)
			p.ell(0.78, 0.44, 0.15, 0.13, color)
			p.ell(0.92, 0.50, 0.07, 0.06, dk)
			p.tri(0.72, 0.36, 0.74, 0.18, 0.80, 0.34, dk)
			p.dot(0.80, 0.42, Color(1, 0.8, 0.1))
			p.tri(0.84, 0.54, 0.86, 0.62, 0.88, 0.54, white)
			for fx in [0.30, 0.42, 0.54, 0.66]:
				p.tri(fx, 0.42, fx + 0.05, 0.22 + (fx * 0.1), fx + 0.10, 0.42, Color(1.0, 0.55, 0.1))
			p.tri(0.16, 0.54, 0.02, 0.36, 0.14, 0.64, Color(1.0, 0.5, 0.1))
		"demon_lord":
			p.ell(0.5, 0.97, 0.34, 0.03, Color(0, 0, 0, 0.3))
			p.tri(0.34, 0.40, 0.00, 0.10, 0.18, 0.72, dk)
			p.tri(0.66, 0.40, 1.00, 0.10, 0.82, 0.72, dk)
			p.tri(0.30, 0.48, 0.10, 0.28, 0.24, 0.62, shade(color, 0.8))
			p.tri(0.70, 0.48, 0.90, 0.28, 0.76, 0.62, shade(color, 0.8))
			p.rct(0.38, 0.70, 0.62, 0.96, shade(color, 0.55))
			p.rct(0.36, 0.86, 0.46, 0.98, Color(0.15, 0.1, 0.15))
			p.rct(0.54, 0.86, 0.64, 0.98, Color(0.15, 0.1, 0.15))
			p.ell(0.5, 0.52, 0.22, 0.24, color)
			p.rct(0.36, 0.62, 0.64, 0.68, Color(0.9, 0.75, 0.2))
			p.ell(0.5, 0.30, 0.17, 0.16, shade(color, 1.1))
			p.tri(0.36, 0.22, 0.24, 0.0, 0.42, 0.16, Color(0.95, 0.9, 0.75))
			p.tri(0.64, 0.22, 0.76, 0.0, 0.58, 0.16, Color(0.95, 0.9, 0.75))
			p.dot(0.43, 0.30, Color(1, 0.9, 0.2))
			p.dot(0.57, 0.30, Color(1, 0.9, 0.2))
			p.ln(0.43, 0.38, 0.57, 0.38, eye, 0.03)
			p.ln(0.86, 0.80, 0.86, 0.16, Color(0.25, 0.2, 0.28), 0.04)
			p.ell(0.86, 0.12, 0.08, 0.10, Color(1.0, 0.5, 0.1))
			p.ell(0.86, 0.14, 0.04, 0.06, Color(1.0, 0.9, 0.4))
		_:
			p.ell(0.5, 0.5, 0.35, 0.35, color)
			p.dot(0.42, 0.45, eye)
			p.dot(0.58, 0.45, eye)
	outline(p.img, Color(0.06, 0.05, 0.09, 1))
	var t := _tex(p.img)
	_cache[key] = t
	return t

# ============================================================== OBJETOS DE MAPA
static func object_texture(type: String, state: String = "") -> ImageTexture:
	var key := "obj_%s_%s" % [type, state]
	if _cache.has(key):
		return _cache[key]
	var img := _new(16, 16)
	match type:
		"chest":
			var wood := Color(0.60, 0.38, 0.16)
			var gold := Color(1.0, 0.82, 0.25)
			if state == "open":
				rect(img, 2, 8, 13, 14, wood)
				rect(img, 3, 9, 12, 12, Color(0.12, 0.08, 0.05))
				rect(img, 2, 3, 13, 6, shade(wood, 1.15))
				rect(img, 2, 6, 13, 6, shade(wood, 0.7))
				px(img, 6, 11, gold); px(img, 9, 10, gold)
			else:
				rect(img, 2, 6, 13, 14, wood)
				rect(img, 2, 3, 13, 7, shade(wood, 1.2))
				rect(img, 2, 7, 13, 7, shade(wood, 0.6))
				rect(img, 2, 10, 13, 10, shade(wood, 0.7))
				rect(img, 7, 7, 8, 10, gold)
				rect(img, 2, 3, 3, 14, gold)
				rect(img, 12, 3, 13, 14, gold)
		"bush":
			if state == "empty":
				ell(img, 8, 10, 6, 4.5, Color(0.28, 0.42, 0.22))
				ell(img, 7, 9, 3, 2, Color(0.34, 0.50, 0.26))
			else:
				ell(img, 8, 10, 6.5, 5, Color(0.18, 0.50, 0.24))
				ell(img, 6, 8, 3.5, 3, Color(0.26, 0.62, 0.30))
				for p in [[5, 7], [10, 9], [8, 6], [11, 7]]:
					px(img, p[0], p[1], Color(1.0, 0.5, 0.65))
					px(img, p[0], p[1] + 1, Color(0.95, 0.9, 0.3))
		"rest":
			ell(img, 8, 14, 5, 1.5, Color(0, 0, 0, 0.3))
			rect(img, 6, 12, 9, 14, Color(0.4, 0.4, 0.45))
			var cr := Color(0.4, 0.85, 1.0)
			ell(img, 8, 8, 3.2, 5, cr)
			ell(img, 7.2, 6.5, 1.3, 2.2, Color(0.85, 1.0, 1.0))
			rect(img, 7, 3, 9, 3, Color(0.85, 1.0, 1.0))
		"stone":
			ell(img, 8, 14, 5, 1.5, Color(0, 0, 0, 0.3))
			rect(img, 4, 6, 11, 14, Color(0.50, 0.52, 0.56))
			rect(img, 5, 3, 10, 6, Color(0.60, 0.62, 0.66))
			rect(img, 5, 7, 10, 7, Color(0.4, 0.42, 0.46))
			ell(img, 8, 9, 1.6, 2.4, Color(0.4, 0.85, 1.0))
		"sign":
			rect(img, 7, 9, 8, 15, Color(0.45, 0.30, 0.16))
			rect(img, 2, 3, 13, 9, Color(0.72, 0.52, 0.28))
			rect(img, 2, 3, 13, 3, Color(0.85, 0.65, 0.38))
			rect(img, 2, 9, 13, 9, Color(0.5, 0.34, 0.18))
			line(img, 4, 5, 11, 5, Color(0.3, 0.2, 0.1))
			line(img, 4, 7, 9, 7, Color(0.3, 0.2, 0.1))
		"board":
			rect(img, 1, 1, 14, 14, Color(0.40, 0.26, 0.14))
			rect(img, 2, 2, 13, 13, Color(0.62, 0.45, 0.26))
			for n in [[3, 3, 6, 7], [8, 4, 12, 8], [4, 9, 9, 12]]:
				rect(img, n[0], n[1], n[2], n[3], Color(0.96, 0.94, 0.85))
				px(img, n[0] + 1, n[1], Color(0.8, 0.2, 0.2))
		"exclaim":
			rect(img, 7, 1, 8, 8, Color(1.0, 0.9, 0.2))
			rect(img, 7, 10, 8, 11, Color(1.0, 0.9, 0.2))
			outline(img, Color(0.3, 0.2, 0.0))
		"well":
			ell(img, 8, 14, 6, 1.6, Color(0, 0, 0, 0.3))
			rect(img, 3, 2, 4, 9, Color(0.42, 0.28, 0.14))
			rect(img, 11, 2, 12, 9, Color(0.42, 0.28, 0.14))
			rect(img, 1, 1, 14, 3, Color(0.64, 0.28, 0.22))
			rect(img, 1, 1, 14, 1, Color(0.84, 0.44, 0.34))
			rect(img, 2, 9, 13, 14, Color(0.58, 0.58, 0.62))
			rect(img, 2, 9, 13, 9, Color(0.78, 0.78, 0.82))
			rect(img, 4, 10, 11, 12, Color(0.22, 0.52, 0.88))
			rect(img, 5, 10, 7, 10, Color(0.6, 0.85, 1.0))
		"seal":
			ell(img, 8, 8, 7.2, 7.2, Color(0.50, 0.08, 0.30))
			ell(img, 8, 8, 5.8, 5.8, Color(0.10, 0.02, 0.14))
			var rc := Color(1.0, 0.30, 0.35)
			line(img, 8, 2, 4, 13, rc)
			line(img, 8, 2, 12, 13, rc)
			line(img, 3, 6, 13, 6, rc)
			line(img, 3, 6, 12, 13, rc)
			line(img, 13, 6, 4, 13, rc)
			px(img, 8, 8, Color(1.0, 0.85, 0.4))
		"brazier":
			ell(img, 8, 14, 5, 1.4, Color(0, 0, 0, 0.3))
			rect(img, 7, 10, 8, 14, Color(0.28, 0.28, 0.32))
			rect(img, 4, 8, 11, 10, Color(0.44, 0.44, 0.50))
			rect(img, 4, 8, 11, 8, Color(0.62, 0.62, 0.68))
			ell(img, 8, 5, 3.2, 4.6, Color(1.0, 0.45, 0.10))
			ell(img, 8, 6, 1.9, 3.2, Color(1.0, 0.85, 0.30))
		"shadow":
			ell(img, 8, 8, 6, 2.2, Color(0, 0, 0, 0.3))
	if type != "shadow" and type != "exclaim":
		outline(img, Color(0.08, 0.06, 0.10, 1))
	var t := _tex(img)
	_cache[key] = t
	return t

# ============================================================== ICONES DE ITENS (16x16)
static func item_icon(item_id: String) -> ImageTexture:
	var key := "ico_" + item_id
	if _cache.has(key):
		return _cache[key]
	var it := ItemDB.get_item(item_id)
	var img := _new(16, 16)
	var rarity_col := ItemDB.rarity_color(item_id)
	var icon: String = it.get("icon", "")
	var typ: String = it.get("type", "")
	if typ == "weapon":
		_icon_weapon(img, String(it["family"]), rarity_col)
	elif typ == "armor":
		_icon_armor(img, String(it["family"]), rarity_col)
	elif typ == "accessory":
		ell(img, 8, 9, 5, 5, Color(0.9, 0.75, 0.2))
		ell(img, 8, 9, 3, 3, Color(0, 0, 0, 0))
		for yy in range(6, 13):
			for xx in range(5, 12):
				var dx := float(xx) - 7.5
				var dy := float(yy) - 8.5
				if dx * dx + dy * dy < 7.5:
					img.set_pixel(xx, yy, Color(0, 0, 0, 0))
		ell(img, 8, 3.5, 2, 2, rarity_col)
	else:
		match icon:
			"potion_red", "potion_blue", "potion_green", "potion_gold":
				var c: Color = {"potion_red": Color(0.9, 0.2, 0.25), "potion_blue": Color(0.25, 0.4, 0.95), "potion_green": Color(0.3, 0.8, 0.35), "potion_gold": Color(1.0, 0.8, 0.2)}[icon]
				rect(img, 6, 2, 9, 4, Color(0.75, 0.6, 0.4))
				rect(img, 7, 4, 8, 6, Color(0.85, 0.9, 0.95))
				ell(img, 8, 10, 4.5, 4.5, c)
				ell(img, 6.5, 8.5, 1.3, 1.3, Color(1, 1, 1, 0.8))
			"bomb":
				ell(img, 8, 10, 5, 5, Color(0.2, 0.2, 0.25))
				ell(img, 6.5, 8, 1.4, 1.4, Color(0.6, 0.6, 0.7))
				line(img, 10, 5, 12, 2, Color(0.7, 0.5, 0.2))
				px(img, 12, 1, Color(1, 0.7, 0.1)); px(img, 13, 2, Color(1, 0.4, 0.1))
			"scroll":
				rect(img, 3, 4, 12, 12, Color(0.95, 0.9, 0.75))
				rect(img, 2, 3, 3, 13, Color(0.8, 0.7, 0.5))
				rect(img, 12, 3, 13, 13, Color(0.8, 0.7, 0.5))
				line(img, 5, 6, 10, 6, Color(0.5, 0.3, 0.2)); line(img, 5, 8, 10, 8, Color(0.5, 0.3, 0.2)); line(img, 5, 10, 8, 10, Color(0.5, 0.3, 0.2))
			"herb":
				line(img, 8, 14, 8, 6, Color(0.2, 0.6, 0.25))
				ell(img, 5.5, 6, 2.6, 1.6, Color(0.3, 0.75, 0.35)); ell(img, 10.5, 5, 2.6, 1.6, Color(0.3, 0.75, 0.35)); ell(img, 8, 3.5, 1.6, 2.4, Color(0.35, 0.8, 0.4))
			"goo":
				ell(img, 8, 10, 5.5, 4, Color(0.4, 0.85, 0.4)); ell(img, 6.5, 8.5, 1.6, 1.2, Color(0.8, 1, 0.8))
			"wing":
				ell(img, 8, 9, 6, 4, Color(0.4, 0.28, 0.5)); line(img, 3, 9, 13, 9, Color(0.25, 0.15, 0.35)); line(img, 5, 6, 8, 12, Color(0.25, 0.15, 0.35))
			"ear":
				ell(img, 8, 9, 3, 5, Color(0.45, 0.65, 0.25)); ell(img, 8, 9, 1.2, 3, Color(0.7, 0.45, 0.4))
			"mushroom":
				ell(img, 8, 7, 6, 4, Color(0.3, 0.45, 0.9)); rect(img, 6, 8, 9, 13, Color(0.95, 0.9, 0.8)); px(img, 5, 6, Color(1, 1, 1)); px(img, 9, 5, Color(1, 1, 1))
			"fang":
				for i in range(8):
					rect(img, 6 + i / 3, 3 + i, 9 - i / 2, 3 + i, Color(0.95, 0.93, 0.85))
			"bone":
				line(img, 4, 12, 12, 4, Color(0.92, 0.9, 0.82), 2)
				ell(img, 4, 12, 2, 2, Color(0.92, 0.9, 0.82)); ell(img, 12, 4, 2, 2, Color(0.92, 0.9, 0.82))
			"silk":
				for k in range(4):
					line(img, 3, 3 + k * 3, 13, 5 + k * 3, Color(0.92, 0.92, 0.98))
				line(img, 3, 3, 3, 12, Color(0.75, 0.75, 0.85))
			"rune":
				ell(img, 8, 8, 5, 6, Color(0.45, 0.45, 0.55))
				line(img, 8, 4, 8, 12, Color(0.4, 0.9, 1.0)); line(img, 5, 7, 11, 7, Color(0.4, 0.9, 1.0)); line(img, 6, 11, 10, 5, Color(0.4, 0.9, 1.0))
			"essence":
				ell(img, 8, 8, 5, 5, Color(0.5, 0.8, 1.0, 0.7)); ell(img, 8, 8, 3, 3, Color(0.85, 0.95, 1.0)); px(img, 8, 8, Color(1, 1, 1))
			"core":
				ell(img, 8, 8, 6, 6, Color(0.3, 0.8, 0.55)); ell(img, 8, 8, 3.5, 3.5, Color(0.7, 1, 0.85)); px(img, 6, 6, Color(1, 1, 1))
			_:
				ell(img, 8, 8, 5, 5, rarity_col)
	outline(img, Color(0.08, 0.06, 0.10, 1))
	var t := _tex(img)
	_cache[key] = t
	return t

static func _icon_weapon(img: Image, family: String, rc: Color) -> void:
	var steel := Color(0.85, 0.88, 0.95)
	var wood := Color(0.55, 0.36, 0.18)
	match family:
		"guerreiro":
			line(img, 3, 12, 12, 3, steel, 2)
			line(img, 3, 12, 12, 3, Color(1, 1, 1))
			rect(img, 3, 10, 6, 11, rc)
			line(img, 4, 13, 2, 15, wood, 2)
		"mago":
			line(img, 3, 14, 11, 5, wood, 2)
			ell(img, 12, 4, 2.6, 2.6, rc)
			px(img, 11, 3, Color(1, 1, 1))
		"assassino":
			line(img, 4, 11, 11, 4, steel, 2)
			line(img, 3, 12, 5, 10, rc, 2)
			line(img, 2, 14, 4, 12, wood, 2)
		"paladino":
			line(img, 4, 14, 10, 7, wood, 2)
			ell(img, 11, 5, 3.4, 3.4, steel)
			ell(img, 11, 5, 1.6, 1.6, rc)
		_:
			line(img, 3, 12, 12, 3, steel, 2)

static func _icon_armor(img: Image, family: String, rc: Color) -> void:
	var base: Color = {"pesada": Color(0.65, 0.68, 0.75), "leve": Color(0.45, 0.30, 0.18), "manto": Color(0.30, 0.38, 0.85)}.get(family, Color(0.6, 0.6, 0.6))
	rect(img, 4, 4, 11, 13, base)
	rect(img, 1, 3, 4, 6, shade(base, 0.85))
	rect(img, 11, 3, 14, 6, shade(base, 0.85))
	rect(img, 6, 3, 9, 4, Color(0, 0, 0, 0))
	rect(img, 4, 8, 11, 8, rc)
	line(img, 8, 5, 8, 13, shade(base, 0.7))

# ============================================================== UI: retratos e fundos de batalha
static func battle_background(kind: String, w: int = 640, h: int = 250) -> ImageTexture:
	var key := "bg_%s_%d" % [kind, w]
	if _cache.has(key):
		return _cache[key]
	var img := _new(w, h)
	var top: Color
	var bot: Color
	var ground: Color
	match kind:
		"forest":
			top = Color(0.18, 0.34, 0.24); bot = Color(0.30, 0.52, 0.30); ground = Color(0.28, 0.45, 0.2)
		"dungeon":
			top = Color(0.07, 0.08, 0.12); bot = Color(0.16, 0.14, 0.20); ground = Color(0.22, 0.18, 0.20)
		_:
			top = Color(0.35, 0.60, 0.90); bot = Color(0.65, 0.82, 0.95); ground = Color(0.34, 0.62, 0.30)
	var horizon := int(h * 0.55)
	for y in range(horizon):
		var t := float(y) / float(horizon)
		var c := top.lerp(bot, t)
		for x in range(w):
			img.set_pixel(x, y, c)
	for y in range(horizon, h):
		var t2 := float(y - horizon) / float(h - horizon)
		var gc := ground.lerp(shade(ground, 0.7), t2)
		for x in range(w):
			var nz := _hash(x / 2, y / 2, 5)
			var cc := gc
			if nz < 80:
				cc = shade(gc, 1.12)
			elif nz > 930:
				cc = shade(gc, 0.88)
			img.set_pixel(x, y, cc)
	# elementos de fundo
	match kind:
		"forest", "field":
			for i in range(14):
				var tx := (i * 53 + 17) % w
				var ts := 18 + (i * 7) % 16
				var tc := Color(0.12, 0.34, 0.18) if kind == "forest" else Color(0.22, 0.5, 0.26)
				rect(img, tx - 2, horizon - ts / 2, tx + 2, horizon, Color(0.30, 0.2, 0.12))
				ell(img, tx, horizon - ts, float(ts) * 0.6, float(ts) * 0.7, tc)
			if kind == "field":
				ell(img, 90, 40, 26, 14, Color(1, 1, 1, 0.85)); ell(img, 120, 46, 30, 12, Color(1, 1, 1, 0.8))
				ell(img, 480, 60, 30, 12, Color(1, 1, 1, 0.8))
		"dungeon":
			for i in range(8):
				var cx := (i * 91 + 40) % w
				rect(img, cx - 14, 0, cx + 14, horizon, Color(0.11, 0.11, 0.16))
				rect(img, cx - 14, 0, cx - 12, horizon, Color(0.2, 0.2, 0.28))
			for i in range(5):
				var fx := (i * 137 + 60) % w
				ell(img, fx, 70, 5, 6, Color(1.0, 0.6, 0.2))
				ell(img, fx, 70, 14, 16, Color(1.0, 0.6, 0.2, 0.12))
	var t3 := _tex(img)
	_cache[key] = t3
	return t3

static func hero_battle_texture(class_id: String) -> ImageTexture:
	return HeroArt.frames(class_id)["idle"][0]

static func portrait(class_id: String) -> ImageTexture:
	var key := "port_" + class_id
	if _cache.has(key):
		return _cache[key]
	var big := HeroArt.image_of(class_id, "idle", 0)
	var crop := big.get_region(Rect2i(11, 0, 24, 24))
	crop.resize(72, 72, Image.INTERPOLATE_NEAREST)
	var t := _tex(crop)
	_cache[key] = t
	return t
