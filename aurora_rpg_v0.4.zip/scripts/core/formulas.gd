class_name Formulas
extends RefCounted
## Formulas centralizadas de combate e progressao.

const ELEMENTS := ["physical", "fire", "ice", "holy", "dark"]
const STAT_KEYS := ["str", "int", "vit", "agi", "def", "dex", "faith"]

static func exp_to_next(level: int) -> int:
	if level >= Balance.MAX_LEVEL:
		return 0
	return int(floor(Balance.EXP_BASE * pow(float(level), Balance.EXP_POWER)))

static func stat_at_level(base: float, growth: float, level: int) -> int:
	return int(base + floor(growth * float(level - 1)))

## Atributos do heroi: classe + nivel + equipamentos. Retorna Dictionary completo.
static func hero_stats(class_id: String, level: int, equipment_bonus: Dictionary) -> Dictionary:
	var c: Dictionary = HeroDB.get_class_data(class_id)
	var s := {}
	for k in STAT_KEYS:
		s[k] = stat_at_level(float(c["base"].get(k, 0)), float(c["growth"].get(k, 0)), level) + int(equipment_bonus.get(k, 0))
	s["max_hp"] = int(c["hp_base"]) + int(c["hp_level"]) * (level - 1) + int(s["vit"]) * Balance.HP_PER_VIT + int(equipment_bonus.get("hp", 0))
	s["max_mp"] = int(c["mp_base"]) + int(c["mp_level"]) * (level - 1) + int(s["int"]) * Balance.MP_PER_INT + int(s["faith"]) * Balance.MP_PER_FAITH + int(equipment_bonus.get("mp", 0))
	s["mdef"] = int(floor(s["def"] * 0.5 + s["int"] * 0.4 + s["faith"] * 0.4))
	s["crit_bonus"] = float(c.get("crit_bonus", 0.0))
	s["crit_mult"] = float(c.get("crit_mult", Balance.CRIT_MULT))
	return s

## Atributos de inimigo para um nivel (base * (1 + escala*(nivel-1))).
static func enemy_stats(template: Dictionary, level: int) -> Dictionary:
	var f := 1.0 + (Balance.BOSS_STAT_SCALE if template.get("boss", false) else Balance.ENEMY_STAT_SCALE) * float(level - 1)
	var b: Dictionary = template["base"]
	var s := {}
	for k in ["str", "int", "def", "mdef", "agi", "dex", "faith", "vit"]:
		s[k] = int(round(float(b.get(k, 0)) * f))
	s["max_hp"] = int(round(float(b["hp"]) * f))
	s["max_mp"] = int(b.get("mp", 0))
	s["crit_bonus"] = float(template.get("crit_bonus", 0.0))
	s["crit_mult"] = Balance.CRIT_MULT
	return s

static func hit_chance(att_dex: float, def_agi: float, accuracy: float = 1.0, evasion: float = 0.0) -> float:
	var c := (Balance.BASE_HIT + (att_dex - def_agi) * Balance.HIT_PER_POINT) * accuracy - evasion
	return clampf(c, Balance.HIT_MIN * 0.5 if evasion > 0.0 else Balance.HIT_MIN, Balance.HIT_MAX)

static func crit_chance(dex: float, bonus: float = 0.0) -> float:
	return clampf(Balance.CRIT_BASE + dex * Balance.CRIT_PER_DEX + bonus, 0.0, Balance.CRIT_MAX)

## Ataque bruto = soma(atributo * peso) + nivel * bonus
static func raw_attack(stats: Dictionary, weights: Dictionary, level: int) -> float:
	var total := 0.0
	for k in weights:
		total += float(stats.get(k, 0)) * float(weights[k])
	return total + float(level) * Balance.LEVEL_ATK_BONUS

static func mitigate(raw: float, defense: float) -> float:
	return raw * Balance.DEF_K / (Balance.DEF_K + maxf(0.0, defense))

static func element_multiplier(element: String, weak: Array, resist: Array, immune: Array) -> float:
	if element in immune:
		return 0.0
	if element in weak:
		return Balance.WEAK_MULT
	if element in resist:
		return Balance.RESIST_MULT
	return 1.0

static func heal_amount(stats: Dictionary, weights: Dictionary, level: int, power: float) -> int:
	return int(round(raw_attack(stats, weights, level) * power))

static func exp_reward(base_exp: int, enemy_level: int, player_level: int) -> int:
	var scale := 1.0 + Balance.ENEMY_REWARD_SCALE * float(enemy_level - 1)
	var diff := 1.0 + float(enemy_level - player_level) * Balance.EXP_LEVEL_DIFF_STEP
	diff = clampf(diff, Balance.EXP_LEVEL_DIFF_MIN, Balance.EXP_LEVEL_DIFF_MAX)
	return maxi(1, int(round(float(base_exp) * scale * diff)))

static func gold_reward(range_arr: Array, enemy_level: int, rng: RandomNumberGenerator) -> int:
	var scale := 1.0 + Balance.ENEMY_REWARD_SCALE * float(enemy_level - 1)
	return maxi(0, int(round(float(rng.randi_range(int(range_arr[0]), int(range_arr[1]))) * scale)))

static func initiative(agi: float, rng: RandomNumberGenerator) -> float:
	return agi + rng.randf() * agi * Balance.INITIATIVE_RANDOM

static func flee_chance(runner_agi: float, enemy_avg_agi: float) -> float:
	return clampf(Balance.FLEE_BASE + (runner_agi - enemy_avg_agi) * Balance.FLEE_PER_AGI, Balance.FLEE_MIN, Balance.FLEE_MAX)
