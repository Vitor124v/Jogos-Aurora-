class_name StoryDB
extends RefCounted
## Historia e missoes entregues por moradores (NPC_QUESTS) e textos do epilogo.
## Cada NPC tem uma lista ordenada; vale a primeira missao disponivel/ativa cujo "requires" ja foi concluido.

const NPC_QUESTS := {
	"aurora_npc0": [
		{"quest": "q_main_1", "offer": ["Escute, %s. Há quatro luas, luzes vermelhas surgiram no Castelo Sombrio. Os selos que o prendem estão enfraquecendo.", "Vá até o Acampamento Vigia, a leste, e veja o castelo com os próprios olhos. Depois volte e me conte."],
			"waiting": ["O Acampamento Vigia fica a leste, seguindo a estrada além do vale."], "ready": ["Você viu as luzes? Então é pior do que eu temia. Tome isto, vai precisar."]},
		{"quest": "q_main_5", "requires": ["q_main_2", "q_main_3", "q_main_4"], "offer": ["Os três selos foram restaurados, %s! Os portões do castelo tremem e Azrakhel despertou.", "Ele aguarda diante do castelo, no extremo nordeste. Prepare-se bem: leve poções, equipamentos fortes e muita coragem."],
			"waiting": ["Azrakhel espera diante do Castelo Sombrio. Vá com todo o preparo que puder."], "ready": ["Você... você o derrotou? A ilha está salva!"]},
	],
	"vigia_sgt": [
		{"quest": "q_main_2", "requires": ["q_main_1"], "offer": ["O Ancião Orin mandou você? Então ouça: o castelo é mantido por três selos antigos.", "O primeiro, nas Dunas Douradas, ao sul, foi tomado pelo Rei Escorpião. Derrote-o e o selo se restaurará."],
			"waiting": ["As Dunas Douradas ficam ao sul da ilha. Cuidado com o calor e os ferrões."], "ready": ["O selo das dunas brilha de novo! Eu senti daqui."]},
		{"quest": "q_main_3", "requires": ["q_main_2"], "offer": ["O segundo selo está no Pântano Sombrio, a sudoeste. O Senhor do Brejo o apodrece dia após dia.", "Leve antídotos. O ar de lá envenena até os mais fortes."],
			"waiting": ["O Pântano Sombrio fica a sudoeste, perto do Porto Âmbar."], "ready": ["O brejo se acalmou. Resta apenas o último selo."]},
		{"quest": "q_main_4", "requires": ["q_main_3"], "offer": ["O último selo repousa no gelo da Montanha Glacial, a noroeste. O Yeti Ancestral o guarda.", "Leve fogo e roupas quentes. Boa sorte, herói."],
			"waiting": ["A Montanha Glacial fica a noroeste, depois da Vila da Neve."], "ready": ["Os três selos restaurados... agora só falta o próprio Azrakhel. Fale com o Ancião Orin."]},
		{"quest": "q_loc_vigia", "offer": ["Diabretes vêm do castelo e rondam nosso acampamento. Se puder abater quatro deles, eu agradeço.", "Eles sentem medo de poder sagrado e gelo."],
			"waiting": ["Os diabretes costumam andar pelo Bosque Carmesim e perto da região vulcânica."], "ready": ["Bom trabalho! O acampamento respira aliviado."]},
	],
	"vigia_scout": [
		{"quest": "q_loc_kael", "offer": ["Estive espiando as muralhas, mas as luzes vermelhas me assustam. Você consegue chegar mais perto e voltar para contar?"],
			"waiting": ["As muralhas ficam ao norte, passando a ponte sobre a lava."], "ready": ["Então as luzes são reais... Obrigado pela coragem."]},
	],
	"aurora_npc1": [
		{"quest": "q_loc_aurora", "offer": ["Ai, minha horta secou e preciso de ervas curativas para fazer o unguento da vovó.", "Você pode colher 3 nos arbustos da floresta ao sul?"],
			"waiting": ["As ervas crescem nos arbustos da Floresta de Treino, ao sul da vila."], "ready": ["Que alívio! Obrigada, %s."]},
	],
	"pinheiral_npc0": [
		{"quest": "q_loc_pinheiral", "offer": ["Lobos não deixam a gente trabalhar. Derrubar pinheiro com uivo atrás do pescoço é osso!", "Afaste quatro deles da serraria, por favor."],
			"waiting": ["Os lobos andam pela Floresta de Eldar, ao redor da serraria."], "ready": ["Agora dá para trabalhar em paz. Obrigado!"]},
	],
	"pinheiral_npc1": [
		{"quest": "q_loc_lucia", "offer": ["O inverno vem aí e meus fios de lã acabaram. Seda de aranha serve para capas leves e fortes.", "Traga-me 3, e eu pago bem."],
			"waiting": ["Aranhas vivem nas matas mais escuras, como a Mata Escura e o Pinhal Antigo."], "ready": ["Que seda linda! Vou costurar as melhores capas."]},
	],
	"porto_npc0": [
		{"quest": "q_loc_porto", "offer": ["Minhas redes rasgaram de novo. Pele de sapo do pântano é grudenta e resistente, perfeita para remendos.", "Traga 3 peles que eu te recompenso."],
			"waiting": ["O Pântano Sombrio fica a nordeste do porto. Os sapos de lá são grandes!"], "ready": ["Perfeito! As redes ficarão novas em folha."]},
	],
	"nevasca_npc0": [
		{"quest": "q_loc_nevasca", "offer": ["Lobos glaciais rondam a vila toda noite. Já perdi dois cães de caça.", "Derrube cinco deles e a vila agradece."],
			"waiting": ["Os lobos glaciais vivem na Floresta Gélida e na Montanha Glacial."], "ready": ["Que alívio! Pode contar comigo para o que precisar."]},
	],
	"nevasca_npc1": [
		{"quest": "q_loc_sigrid", "offer": ["Estas mãos velhas já não aguentam o frio. O pelo gelado nunca esquenta mas também nunca rasga... bom para cobertores.", "Traga-me 3, querido."],
			"waiting": ["Lobos e yetis soltam pelo gelado nas montanhas ao redor."], "ready": ["Ah, obrigada! Vou tecer algo bem quentinho."]},
	],
	"pedralta_npc1": [
		{"quest": "q_loc_pedralta", "offer": ["Estou forjando uma lâmina com runas, mas faltam pedras rúnicas.", "Golens costumam carregá-las. Traga 2 para mim."],
			"waiting": ["Golens vagam pelas Montanhas da Ruína e pelas dunas."], "ready": ["Estas runas são perfeitas! Vou trabalhar já."]},
	],
	"pedralta_npc0": [
		{"quest": "q_loc_dolf", "offer": ["A mina está tomada por golens. Eu não consigo cavar com essas coisas batendo na parede!", "Derrote 3 deles e a vila volta a ter minério."],
			"waiting": ["Os golens estão nas Montanhas da Ruína, perto da vila."], "ready": ["A mina está livre! Obrigado, herói."]},
	],
	"solmar_npc0": [
		{"quest": "q_loc_solmar", "offer": ["O Bazar das Conchas quer ferrões de escorpião para fazer amuletos.", "Nas Dunas Douradas há muitos. Traga 3!"],
			"waiting": ["As Dunas Douradas ficam a oeste da vila, no sul da ilha."], "ready": ["Massa! Os amuletos vão ficar incríveis."]},
	],
	"solmar_npc1": [
		{"quest": "q_loc_perola", "offer": ["Eu faço joias com escamas de serpente das dunas. Elas brilham dourado ao sol.", "Pode me trazer 4?"],
			"waiting": ["As serpentes vivem nas Dunas Douradas e no pântano."], "ready": ["Lindas! Vou fazer um colar para guardar de lembrança."]},
	],
}

const EPILOGUE := [
	"O corpo de Azrakhel se desfaz em cinzas e as luzes vermelhas do castelo se apagam, uma a uma.",
	"Os portões selados rangem... e então se abrem em silêncio, revelando apenas ruínas antigas.",
	"Em Vila Aurora, o Ancião Orin sorri: a ilha está a salvo.",
	"Mas há muito a explorar: grutas escondidas, tesouros e rankings da guilda ainda esperam por você.",
	"FIM DA PRIMEIRA CRÔNICA — obrigado por jogar Crônicas de Aurora!",
]
