class_name QuestDB
extends RefCounted
## Missoes da guilda, ranks e requisitos de promocao.
## objetivos: kill(target=id ou "*"), collect(item), explore(area), boss(id), reach_floor(n), dungeon(id), locked(futuro)
## kill/explore acumulam enquanto a missao esta ativa; collect/boss/reach_floor/dungeon sao avaliados do estado atual.

const RANKS := ["D", "C", "B", "A", "S", "SS"]
const RANK_TITLES := {"D": "Novato", "C": "Veterano", "B": "Experiente", "A": "Elite", "S": "Herói", "SS": "Lenda"}

## Requisitos para PROMOVER PARA o rank indicado.
const PROMOTION := {
	"C": {"rep": 30, "level": 3, "quest": "eval_c", "bonus_gold": 100},
	"B": {"rep": 90, "level": 6, "quest": "eval_b", "bonus_gold": 250},
	"A": {"rep": 200, "level": 8, "quest": "eval_a", "bonus_gold": 600},
	"S": {"rep": 380, "level": 10, "quest": "eval_s", "bonus_gold": 1500},
	"SS": {"rep": 700, "level": 12, "quest": "eval_ss", "bonus_gold": 5000},
}

const QUESTS := {
	# ---------------- RANK D ----------------
	"q_slimes": {"name": "Praga de Slimes", "rank": "D", "desc": "Slimes estão infestando o campo de treino. Derrote 5 deles.",
		"objectives": [{"type": "kill", "target": "slime", "count": 5, "text": "Derrotar Slimes"}],
		"rewards": {"gold": 60, "exp": 40, "rep": 10, "items": {"pocao_pequena": 2}}},
	"q_ervas": {"name": "Ervas para a Curandeira", "rank": "D", "desc": "Colha 4 Ervas Curativas nos arbustos da floresta e entregue à guilda.",
		"objectives": [{"type": "collect", "target": "erva_curativa", "count": 4, "text": "Coletar Ervas Curativas"}],
		"rewards": {"gold": 50, "exp": 30, "rep": 8, "items": {"antidoto": 2}}},
	"q_clareira": {"name": "Reconhecer a Clareira", "rank": "D", "desc": "Explore a Clareira Antiga, no nordeste da floresta.",
		"objectives": [{"type": "explore", "target": "clareira", "count": 1, "text": "Explorar a Clareira Antiga"}],
		"rewards": {"gold": 40, "exp": 30, "rep": 8, "items": {}}},
	"q_morcegos": {"name": "Morcegos na Entrada", "rank": "D", "desc": "Morcegos Sombrios atacam viajantes. Derrote 4.",
		"objectives": [{"type": "kill", "target": "morcego", "count": 4, "text": "Derrotar Morcegos Sombrios"}],
		"rewards": {"gold": 70, "exp": 45, "rep": 8, "items": {"pocao_pequena": 2}}},
	"eval_c": {"name": "Prova do Rank C", "rank": "D", "kind": "eval", "eval_for": "C", "desc": "Prova de avaliação: derrote o chefe do 5º andar da Floresta Esquecida.",
		"objectives": [{"type": "boss", "target": "boss_slime_king", "count": 1, "text": "Derrotar o Rei Slime (andar 5)"}],
		"rewards": {"gold": 200, "exp": 150, "rep": 20, "items": {"pocao": 2}}},
	# ---------------- RANK C ----------------
	"q_goblins": {"name": "Acampamento Goblin", "rank": "C", "desc": "Goblins saqueiam caravanas. Derrote 8 deles.",
		"objectives": [{"type": "kill", "target": "goblin", "count": 8, "text": "Derrotar Goblins"}],
		"rewards": {"gold": 150, "exp": 120, "rep": 15, "items": {"pocao": 2}}},
	"q_presas": {"name": "Presas para o Ferreiro", "rank": "C", "desc": "Traga 5 Presas de Lobo das profundezas.",
		"objectives": [{"type": "collect", "target": "presa_de_lobo", "count": 5, "text": "Coletar Presas de Lobo"}],
		"rewards": {"gold": 180, "exp": 130, "rep": 15, "items": {"eter": 2}}},
	"q_andar8": {"name": "Rumo ao 8º Andar", "rank": "C", "desc": "Explore a masmorra até alcançar o 8º andar.",
		"objectives": [{"type": "reach_floor", "target": "8", "count": 1, "text": "Alcançar o 8º andar"}],
		"rewards": {"gold": 160, "exp": 140, "rep": 15, "items": {"pocao": 1}}},
	"eval_b": {"name": "Prova do Rank B", "rank": "C", "kind": "eval", "eval_for": "B", "desc": "Prova de avaliação: derrote a Matriarca Aranha, no 10º andar.",
		"objectives": [{"type": "boss", "target": "boss_spider_queen", "count": 1, "text": "Derrotar a Matriarca Aranha (andar 10)"}],
		"rewards": {"gold": 400, "exp": 300, "rep": 40, "items": {"pocao_grande": 2}}},
	# ---------------- RANK B ----------------
	"q_esqueletos": {"name": "Mortos Inquietos", "rank": "B", "desc": "Esqueletos vagam pelas profundezas. Derrote 10.",
		"objectives": [{"type": "kill", "target": "esqueleto", "count": 10, "text": "Derrotar Esqueletos"}],
		"rewards": {"gold": 300, "exp": 250, "rep": 25, "items": {"pocao_grande": 1}}},
	"q_seda": {"name": "Seda para o Alfaiate", "rank": "B", "desc": "Colete 6 Sedas de Aranha.",
		"objectives": [{"type": "collect", "target": "seda_de_aranha", "count": 6, "text": "Coletar Seda de Aranha"}],
		"rewards": {"gold": 280, "exp": 220, "rep": 25, "items": {"eter_grande": 1}}},
	"q_andar13": {"name": "Rumo ao 13º Andar", "rank": "B", "desc": "Alcance o 13º andar da masmorra.",
		"objectives": [{"type": "reach_floor", "target": "13", "count": 1, "text": "Alcançar o 13º andar"}],
		"rewards": {"gold": 300, "exp": 240, "rep": 25, "items": {"pocao_grande": 1}}},
	"eval_a": {"name": "Prova do Rank A", "rank": "B", "kind": "eval", "eval_for": "A", "desc": "Prova de avaliação: derrote o Cavaleiro Espectral, no 15º andar.",
		"objectives": [{"type": "boss", "target": "boss_ghost_knight", "count": 1, "text": "Derrotar o Cavaleiro Espectral (andar 15)"}],
		"rewards": {"gold": 800, "exp": 600, "rep": 80, "items": {"elixir": 1}}},
	# ---------------- RANK A ----------------
	"q_golems": {"name": "Golens Rebeldes", "rank": "A", "desc": "Derrote 6 Golens de Pedra.",
		"objectives": [{"type": "kill", "target": "golem", "count": 6, "text": "Derrotar Golens de Pedra"}],
		"rewards": {"gold": 500, "exp": 400, "rep": 40, "items": {"pocao_grande": 2}}},
	"q_runas": {"name": "Runas Esquecidas", "rank": "A", "desc": "Traga 4 Pedras Rúnicas.",
		"objectives": [{"type": "collect", "target": "pedra_runica", "count": 4, "text": "Coletar Pedras Rúnicas"}],
		"rewards": {"gold": 480, "exp": 380, "rep": 40, "items": {"eter_grande": 2}}},
	"q_fogos": {"name": "Luzes nas Profundezas", "rank": "A", "desc": "Extinga 5 Fogos-Fátuos.",
		"objectives": [{"type": "kill", "target": "fogo_fatuo", "count": 5, "text": "Derrotar Fogos-Fátuos"}],
		"rewards": {"gold": 450, "exp": 380, "rep": 40, "items": {"eter_grande": 2}}},
	"eval_s": {"name": "Prova do Rank S", "rank": "A", "kind": "eval", "eval_for": "S", "desc": "Prova de avaliação: complete a Floresta Esquecida derrotando o Guardião Ancião no 20º andar.",
		"objectives": [{"type": "dungeon", "target": "floresta_esquecida", "count": 1, "text": "Completar a Floresta Esquecida"}],
		"rewards": {"gold": 1500, "exp": 1000, "rep": 150, "items": {"elixir": 2}}},
	# ---------------- RANK S ----------------
	"q_s_fatuos": {"name": "Caçada nas Sombras", "rank": "S", "desc": "Derrote 10 Fogos-Fátuos.",
		"objectives": [{"type": "kill", "target": "fogo_fatuo", "count": 10, "text": "Derrotar Fogos-Fátuos"}],
		"rewards": {"gold": 900, "exp": 700, "rep": 60, "items": {"elixir": 1}}},
	"q_s_golems": {"name": "Muralha de Pedra", "rank": "S", "desc": "Derrote 12 Golens de Pedra.",
		"objectives": [{"type": "kill", "target": "golem", "count": 12, "text": "Derrotar Golens de Pedra"}],
		"rewards": {"gold": 900, "exp": 700, "rep": 60, "items": {"elixir": 1}}},
	"q_s_materiais": {"name": "Suprimentos do Mestre", "rank": "S", "desc": "Entregue 6 Essências Etéreas e 10 Ossos Antigos.",
		"objectives": [{"type": "collect", "target": "essencia_eterea", "count": 6, "text": "Coletar Essências Etéreas"}, {"type": "collect", "target": "osso_antigo", "count": 10, "text": "Coletar Ossos Antigos"}],
		"rewards": {"gold": 1000, "exp": 700, "rep": 60, "items": {"elixir": 1}}},
	"eval_ss": {"name": "Prova do Rank SS", "rank": "S", "kind": "eval", "eval_for": "SS", "desc": "A prova final da guilda: derrote Azrakhel, o Lorde Demoníaco do Castelo Sombrio.",
		"objectives": [{"type": "boss", "target": "boss_demon_lord", "count": 1, "text": "Derrotar Azrakhel, Lorde Demoníaco"}],
		"rewards": {"gold": 5000, "exp": 3000, "rep": 300, "items": {"elixir": 3}}},
	# ---------------- HISTORIA PRINCIPAL (entregue por NPCs; "npc": true = nao aparece no quadro) ----------------
	"q_main_1": {"name": "A Luz Vermelha", "rank": "D", "kind": "main", "npc": true,
		"desc": "O Ancião Orin pediu que você vá até o Acampamento Vigia, ao leste, e veja com os próprios olhos as luzes do Castelo Sombrio.",
		"objectives": [{"type": "explore", "target": "vigia", "count": 1, "text": "Chegar ao Acampamento Vigia"}],
		"rewards": {"gold": 120, "exp": 100, "rep": 10, "items": {"pocao": 3, "pergaminho_retorno": 1}}},
	"q_main_2": {"name": "Selo das Dunas", "rank": "D", "kind": "main", "npc": true,
		"desc": "O primeiro dos selos que prendem Azrakhel foi corrompido pelo Rei Escorpião nas Dunas Douradas. (Recomendado: Nv 7+)",
		"objectives": [{"type": "boss", "target": "boss_scorpion_king", "count": 1, "text": "Derrotar o Rei Escorpião (Dunas Douradas)"}],
		"rewards": {"gold": 500, "exp": 500, "rep": 40, "items": {"pocao_grande": 2}}},
	"q_main_3": {"name": "Selo do Brejo", "rank": "D", "kind": "main", "npc": true,
		"desc": "O segundo selo apodrece no Pântano Sombrio, sob o domínio do Senhor do Brejo. (Recomendado: Nv 8+)",
		"objectives": [{"type": "boss", "target": "boss_toad_king", "count": 1, "text": "Derrotar o Senhor do Brejo (Pântano Sombrio)"}],
		"rewards": {"gold": 600, "exp": 600, "rep": 50, "items": {"eter_grande": 2}}},
	"q_main_4": {"name": "Selo da Montanha", "rank": "D", "kind": "main", "npc": true,
		"desc": "O terceiro selo está congelado no coração da Montanha Glacial, guardado pelo Yeti Ancestral. (Recomendado: Nv 8+)",
		"objectives": [{"type": "boss", "target": "boss_yeti_king", "count": 1, "text": "Derrotar o Yeti Ancestral (Montanha Glacial)"}],
		"rewards": {"gold": 650, "exp": 650, "rep": 50, "items": {"elixir": 1}}},
	"q_main_5": {"name": "Azrakhel, o Lorde Sombrio", "rank": "D", "kind": "main", "npc": true,
		"desc": "Com os três selos restaurados, os portões do Castelo Sombrio tremem. Enfrente Azrakhel diante do castelo e acabe com a ameaça. (Recomendado: Nv 10+)",
		"objectives": [{"type": "boss", "target": "boss_demon_lord", "count": 1, "text": "Derrotar Azrakhel, Lorde Demoníaco"}],
		"rewards": {"gold": 3000, "exp": 4000, "rep": 200, "items": {"elixir": 3}}},
	# ---------------- MISSOES LOCAIS (dadas por moradores das cidades) ----------------
	"q_loc_aurora": {"name": "Ervas para Marta", "rank": "D", "kind": "local", "npc": true,
		"desc": "Marta, de Vila Aurora, precisa de 3 Ervas Curativas dos arbustos da floresta.",
		"objectives": [{"type": "collect", "target": "erva_curativa", "count": 3, "text": "Coletar Ervas Curativas"}],
		"rewards": {"gold": 45, "exp": 30, "rep": 5, "items": {"antidoto": 2}}},
	"q_loc_pinheiral": {"name": "Lobos na Serraria", "rank": "D", "kind": "local", "npc": true,
		"desc": "Lobos rondam a serraria de Pinheiral. O Lenhador Gus quer 4 deles longe dali.",
		"objectives": [{"type": "kill", "target": "lobo", "count": 4, "text": "Derrotar Lobos Cinzentos"}],
		"rewards": {"gold": 90, "exp": 80, "rep": 8, "items": {"pocao": 2}}},
	"q_loc_lucia": {"name": "Fios para a Costureira", "rank": "D", "kind": "local", "npc": true,
		"desc": "Dona Lúcia, de Pinheiral, precisa de 3 Sedas de Aranha para costurar capas de inverno.",
		"objectives": [{"type": "collect", "target": "seda_de_aranha", "count": 3, "text": "Coletar Seda de Aranha"}],
		"rewards": {"gold": 110, "exp": 90, "rep": 8, "items": {"eter": 2}}},
	"q_loc_porto": {"name": "A Rede do Zeca", "rank": "D", "kind": "local", "npc": true,
		"desc": "O Pescador Zeca quer 3 Peles de Sapo do pântano para remendar suas redes no Porto Âmbar.",
		"objectives": [{"type": "collect", "target": "pele_de_sapo", "count": 3, "text": "Coletar Peles de Sapo"}],
		"rewards": {"gold": 120, "exp": 100, "rep": 8, "items": {"antidoto": 2}}},
	"q_loc_nevasca": {"name": "Caça aos Lobos Glaciais", "rank": "D", "kind": "local", "npc": true,
		"desc": "Caçador Ragnar, da Vila da Neve, pede que você derrube 5 Lobos Glaciais que ameaçam a vila.",
		"objectives": [{"type": "kill", "target": "lobo_gelido", "count": 5, "text": "Derrotar Lobos Glaciais"}],
		"rewards": {"gold": 160, "exp": 140, "rep": 10, "items": {"pocao_grande": 1}}},
	"q_loc_sigrid": {"name": "Pelo para o Inverno", "rank": "D", "kind": "local", "npc": true,
		"desc": "A Velha Sigrid precisa de 3 Pelos Gelados para tecer cobertores.",
		"objectives": [{"type": "collect", "target": "pelo_gelado", "count": 3, "text": "Coletar Pelos Gelados"}],
		"rewards": {"gold": 150, "exp": 120, "rep": 10, "items": {"eter": 2}}},
	"q_loc_pedralta": {"name": "Pedras para a Forja", "rank": "D", "kind": "local", "npc": true,
		"desc": "A Ferreira Hanna, da Vila do Ferro, precisa de 2 Pedras Rúnicas para forjar uma lâmina especial.",
		"objectives": [{"type": "collect", "target": "pedra_runica", "count": 2, "text": "Coletar Pedras Rúnicas"}],
		"rewards": {"gold": 200, "exp": 150, "rep": 10, "items": {"pocao_grande": 1}}},
	"q_loc_dolf": {"name": "Golens na Mina", "rank": "D", "kind": "local", "npc": true,
		"desc": "O Mineiro Dolf não consegue trabalhar: golens bloqueiam a mina. Derrote 3.",
		"objectives": [{"type": "kill", "target": "golem", "count": 3, "text": "Derrotar Golens de Pedra"}],
		"rewards": {"gold": 220, "exp": 180, "rep": 10, "items": {"pocao_grande": 1}}},
	"q_loc_solmar": {"name": "Ferrões para o Bazar", "rank": "D", "kind": "local", "npc": true,
		"desc": "O Surfista Caio quer 3 Ferrões de Escorpião para o Bazar das Conchas, na Vila do Pescador.",
		"objectives": [{"type": "collect", "target": "ferrao_de_escorpiao", "count": 3, "text": "Coletar Ferrões de Escorpião"}],
		"rewards": {"gold": 140, "exp": 110, "rep": 8, "items": {"antidoto": 3}}},
	"q_loc_perola": {"name": "Escamas Douradas", "rank": "D", "kind": "local", "npc": true,
		"desc": "Dona Pérola colhe escamas de serpente das dunas para fazer joias. Traga 4.",
		"objectives": [{"type": "collect", "target": "escama_de_serpente", "count": 4, "text": "Coletar Escamas de Serpente"}],
		"rewards": {"gold": 170, "exp": 120, "rep": 8, "items": {"eter": 2}}},
	"q_loc_vigia": {"name": "Ameaça Infernal", "rank": "D", "kind": "local", "npc": true,
		"desc": "A Sargento Dagna quer 4 Diabretes abatidos antes que cheguem ao acampamento.",
		"objectives": [{"type": "kill", "target": "diabrete", "count": 4, "text": "Derrotar Diabretes"}],
		"rewards": {"gold": 260, "exp": 240, "rep": 12, "items": {"pocao_grande": 2}}},
	"q_loc_kael": {"name": "Olhos no Castelo", "rank": "D", "kind": "local", "npc": true,
		"desc": "O Batedor Kael quer saber se algo mudou perto das muralhas do Castelo Sombrio. Chegue até lá e volte para contar.",
		"objectives": [{"type": "explore", "target": "castelo", "count": 1, "text": "Chegar às muralhas do Castelo Sombrio"}],
		"rewards": {"gold": 200, "exp": 200, "rep": 10, "items": {"eter_grande": 1}}},
	# ---------------- CONTRATOS REPETIVEIS ----------------
	"ctr_cacada": {"name": "Contrato de Caça", "rank": "D", "kind": "repeatable", "desc": "Contrato diário: derrote 10 monstros de qualquer tipo.",
		"objectives": [{"type": "kill", "target": "*", "count": 10, "text": "Derrotar monstros"}],
		"rewards": {"gold": 90, "exp": 0, "rep": 2, "items": {}}},
	"ctr_gosma": {"name": "Contrato de Coleta", "rank": "D", "kind": "repeatable", "desc": "Contrato diário: entregue 6 Gosmas de Slime.",
		"objectives": [{"type": "collect", "target": "gosma", "count": 6, "text": "Coletar Gosma de Slime"}],
		"rewards": {"gold": 60, "exp": 0, "rep": 2, "items": {}}},
}

static func get_quest(id: String) -> Dictionary:
	if QUESTS.has(id):
		var q: Dictionary = QUESTS[id].duplicate(true)
		q["id"] = id
		return q
	return {}

static func rank_index(rank: String) -> int:
	return RANKS.find(rank)

static func next_rank(rank: String) -> String:
	var i := rank_index(rank)
	if i < 0 or i >= RANKS.size() - 1:
		return ""
	return RANKS[i + 1]

static func ids_for_rank_and_below(rank: String) -> Array:
	var out: Array = []
	var ri := rank_index(rank)
	for id in QUESTS:
		if rank_index(QUESTS[id]["rank"]) <= ri:
			out.append(id)
	return out
