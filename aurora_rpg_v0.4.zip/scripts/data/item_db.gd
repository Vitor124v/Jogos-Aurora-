class_name ItemDB
extends RefCounted
## Banco de itens. Equipamentos sao gerados de tabelas compactas (ver _build).
## type: weapon | armor | accessory | consumable | material
## stats: bonus de atributos (str,int,vit,agi,def,dex,faith) + hp/mp maximos.

const RARITY := {
	"common": {"name": "Comum", "color": Color(0.82, 0.82, 0.82), "price_mult": 1.0},
	"uncommon": {"name": "Incomum", "color": Color(0.35, 0.85, 0.4), "price_mult": 1.6},
	"rare": {"name": "Raro", "color": Color(0.3, 0.65, 1.0), "price_mult": 2.6},
	"epic": {"name": "Épico", "color": Color(0.75, 0.4, 1.0), "price_mult": 4.0},
	"legendary": {"name": "Lendário", "color": Color(1.0, 0.7, 0.15), "price_mult": 7.0},
}

const SLOT_NAMES := {"weapon": "Arma", "armor": "Armadura", "accessory": "Acessório"}
const STAT_NAMES := {"str": "FOR", "int": "INT", "vit": "VIT", "agi": "AGI", "def": "DEF", "dex": "DES", "faith": "FÉ", "hp": "HP", "mp": "MP"}

# weapons: [id, nome, rar, lvl, preco, stats]
const WEAPONS := {
	"guerreiro": [
		["espada_enferrujada", "Espada Enferrujada", "common", 1, 15, {"str": 2}],
		["espada_de_ferro", "Espada de Ferro", "common", 2, 90, {"str": 5}],
		["espada_de_aco", "Espada de Aço", "uncommon", 4, 240, {"str": 8, "dex": 1}],
		["espada_runica", "Espada Rúnica", "rare", 6, 600, {"str": 12, "vit": 3}],
		["lamina_do_cavaleiro", "Lâmina do Cavaleiro", "epic", 8, 1400, {"str": 17, "dex": 4, "vit": 4}],
		["lamina_do_rei_caido", "Lâmina do Rei Caído", "legendary", 10, 3000, {"str": 24, "vit": 8, "dex": 5}],
	],
	"mago": [
		["cajado_de_galho", "Cajado de Galho", "common", 1, 15, {"int": 3}],
		["cajado_de_carvalho", "Cajado de Carvalho", "common", 2, 90, {"int": 6, "mp": 5}],
		["cajado_arcano", "Cajado Arcano", "uncommon", 4, 240, {"int": 10, "mp": 12}],
		["cajado_glacial", "Cajado Glacial", "rare", 6, 600, {"int": 14, "mp": 22}],
		["cajado_do_vazio", "Cajado do Vazio", "epic", 8, 1400, {"int": 20, "mp": 32, "agi": 3}],
		["cajado_estelar", "Cajado Estelar", "legendary", 10, 3000, {"int": 28, "mp": 50, "faith": 4}],
	],
	"assassino": [
		["adaga_gasta", "Adaga Gasta", "common", 1, 15, {"agi": 2, "dex": 1}],
		["adaga_de_ferro", "Adaga de Ferro", "common", 2, 90, {"dex": 4, "agi": 2, "str": 1}],
		["adaga_envenenada", "Adaga Envenenada", "uncommon", 4, 240, {"dex": 7, "agi": 3, "str": 2}],
		["laminas_da_sombra", "Lâminas da Sombra", "rare", 6, 600, {"dex": 10, "agi": 6, "str": 3}],
		["presa_de_vibora", "Presa de Víbora", "epic", 8, 1400, {"dex": 14, "agi": 8, "str": 5}],
		["ceifadora_noturna", "Ceifadora Noturna", "legendary", 10, 3000, {"dex": 20, "agi": 12, "str": 8}],
	],
	"paladino": [
		["maca_de_madeira", "Maça de Madeira", "common", 1, 15, {"faith": 2, "str": 1}],
		["maca_de_ferro", "Maça de Ferro", "common", 2, 90, {"faith": 3, "str": 4}],
		["maca_abencoada", "Maça Abençoada", "uncommon", 4, 240, {"faith": 7, "str": 3}],
		["martelo_sagrado", "Martelo Sagrado", "rare", 6, 600, {"faith": 10, "str": 6, "vit": 2}],
		["martelo_da_aurora", "Martelo da Aurora", "epic", 8, 1400, {"faith": 15, "str": 8, "vit": 4}],
		["martelo_celestial", "Martelo Celestial", "legendary", 10, 3000, {"faith": 22, "str": 12, "vit": 7}],
	],
}

const ARMORS := {
	"pesada": {"classes": ["guerreiro", "paladino"], "items": [
		["gibao_acolchoado", "Gibão Acolchoado", "common", 1, 12, {"def": 3, "vit": 1}],
		["cota_de_malha", "Cota de Malha", "common", 3, 120, {"def": 6, "vit": 2}],
		["armadura_de_aco", "Armadura de Aço", "uncommon", 5, 300, {"def": 10, "vit": 4}],
		["couraca_runica", "Couraça Rúnica", "rare", 7, 700, {"def": 15, "vit": 6, "hp": 20}],
		["armadura_do_dragao", "Armadura do Dragão", "epic", 9, 1600, {"def": 21, "vit": 8, "hp": 40}],
		["armadura_celestial", "Armadura Celestial", "legendary", 11, 3400, {"def": 28, "vit": 12, "hp": 70}],
	]},
	"leve": {"classes": ["assassino"], "items": [
		["roupa_de_couro", "Roupa de Couro", "common", 1, 12, {"def": 2, "agi": 1}],
		["couro_reforcado", "Couro Reforçado", "common", 3, 120, {"def": 4, "agi": 2}],
		["manto_sombrio", "Manto Sombrio", "uncommon", 5, 300, {"def": 6, "agi": 4, "dex": 2}],
		["traje_da_noite", "Traje da Noite", "rare", 7, 700, {"def": 9, "agi": 6, "dex": 4}],
		["veste_espectral", "Veste Espectral", "epic", 9, 1600, {"def": 12, "agi": 9, "dex": 6}],
		["manto_da_lua_negra", "Manto da Lua Negra", "legendary", 11, 3400, {"def": 16, "agi": 12, "dex": 9}],
	]},
	"manto": {"classes": ["mago"], "items": [
		["tunica_simples", "Túnica Simples", "common", 1, 12, {"def": 1, "int": 1, "mp": 5}],
		["manto_de_aprendiz", "Manto de Aprendiz", "common", 3, 120, {"def": 2, "int": 2, "mp": 10}],
		["manto_arcano", "Manto Arcano", "uncommon", 5, 300, {"def": 4, "int": 5, "mp": 20}],
		["veste_glacial", "Veste Glacial", "rare", 7, 700, {"def": 6, "int": 8, "mp": 30}],
		["manto_estelar", "Manto Estelar", "epic", 9, 1600, {"def": 8, "int": 12, "mp": 45}],
		["veste_do_arquimago", "Veste do Arquimago", "legendary", 11, 3400, {"def": 11, "int": 17, "mp": 70}],
	]},
}

const ACCESSORIES := [
	["anel_de_cobre", "Anel de Cobre", "common", 1, 60, {"def": 1}],
	["amuleto_de_vida", "Amuleto de Vida", "uncommon", 3, 180, {"hp": 25}],
	["amuleto_de_mana", "Amuleto de Mana", "uncommon", 3, 180, {"mp": 20}],
	["anel_de_forca", "Anel de Força", "uncommon", 4, 220, {"str": 3}],
	["anel_do_sabio", "Anel do Sábio", "uncommon", 4, 220, {"int": 4}],
	["anel_de_agilidade", "Anel de Agilidade", "uncommon", 4, 220, {"agi": 3, "dex": 1}],
	["bracelete_da_sorte", "Bracelete da Sorte", "rare", 5, 480, {"dex": 5, "agi": 2}],
	["amuleto_da_fe", "Amuleto da Fé", "rare", 5, 480, {"faith": 5, "vit": 1}],
	["colar_do_guardiao", "Colar do Guardião", "rare", 7, 800, {"def": 5, "hp": 40}],
	["anel_do_rei", "Anel do Rei", "epic", 9, 1800, {"str": 4, "int": 4, "vit": 4, "agi": 4, "dex": 4, "faith": 4}],
	["coroa_antiga", "Coroa Antiga", "legendary", 11, 4000, {"str": 6, "int": 6, "vit": 6, "agi": 6, "dex": 6, "faith": 6, "hp": 60, "mp": 30}],
]

const CONSUMABLES := {
	"pocao_pequena": {"name": "Poção Pequena", "price": 20, "desc": "Restaura 40 HP.", "use": {"heal_hp": 40}, "icon": "potion_red", "shop": true},
	"pocao": {"name": "Poção", "price": 55, "desc": "Restaura 100 HP.", "use": {"heal_hp": 100}, "icon": "potion_red", "shop": true, "rarity": "uncommon"},
	"pocao_grande": {"name": "Poção Grande", "price": 140, "desc": "Restaura 260 HP.", "use": {"heal_hp": 260}, "icon": "potion_red", "shop": true, "rarity": "rare"},
	"eter": {"name": "Éter", "price": 45, "desc": "Restaura 30 MP.", "use": {"heal_mp": 30}, "icon": "potion_blue", "shop": true},
	"eter_grande": {"name": "Éter Grande", "price": 120, "desc": "Restaura 80 MP.", "use": {"heal_mp": 80}, "icon": "potion_blue", "shop": true, "rarity": "uncommon"},
	"antidoto": {"name": "Antídoto", "price": 18, "desc": "Cura envenenamento.", "use": {"cure": ["poison"]}, "icon": "potion_green", "shop": true},
	"bomba": {"name": "Bomba de Fogo", "price": 40, "desc": "Causa dano de fogo a um inimigo (só em batalha).", "use": {"damage": 70, "element": "fire"}, "icon": "bomb", "shop": true, "battle_only": true},
	"pergaminho_retorno": {"name": "Pergaminho de Retorno", "price": 70, "desc": "Teletransporta para a cidade (só fora de batalha).", "use": {"town_return": true}, "icon": "scroll", "shop": true, "field_only": true, "rarity": "uncommon"},
	"elixir": {"name": "Elixir", "price": 300, "desc": "Restaura todo o HP e MP.", "use": {"heal_hp": 99999, "heal_mp": 99999}, "icon": "potion_gold", "rarity": "epic"},
}

const MATERIALS := {
	"erva_curativa": {"name": "Erva Curativa", "price": 8, "desc": "Erva medicinal colhida na floresta.", "icon": "herb"},
	"gosma": {"name": "Gosma de Slime", "price": 4, "desc": "Material viscoso.", "icon": "goo"},
	"asa_de_morcego": {"name": "Asa de Morcego", "price": 7, "desc": "Asa membranosa.", "icon": "wing"},
	"orelha_de_goblin": {"name": "Orelha de Goblin", "price": 9, "desc": "Prova de caça de goblins.", "icon": "ear"},
	"cogumelo_azul": {"name": "Cogumelo Azul", "price": 11, "desc": "Cogumelo brilhante.", "icon": "mushroom"},
	"presa_de_lobo": {"name": "Presa de Lobo", "price": 14, "desc": "Presa afiada.", "icon": "fang"},
	"osso_antigo": {"name": "Osso Antigo", "price": 16, "desc": "Osso de morto-vivo.", "icon": "bone"},
	"seda_de_aranha": {"name": "Seda de Aranha", "price": 20, "desc": "Fio resistente.", "icon": "silk"},
	"pedra_runica": {"name": "Pedra Rúnica", "price": 36, "desc": "Pedra com runas antigas.", "icon": "rune"},
	"essencia_eterea": {"name": "Essência Etérea", "price": 40, "desc": "Energia condensada.", "icon": "essence"},
	"nucleo_de_slime": {"name": "Núcleo de Slime Real", "price": 120, "desc": "Troféu do Rei Slime.", "icon": "core"},
	"ferrao_de_escorpiao": {"name": "Ferrão de Escorpião", "price": 18, "desc": "Ferrão cheio de veneno seco.", "icon": "fang"},
	"escama_de_serpente": {"name": "Escama de Serpente", "price": 16, "desc": "Escama dourada das dunas.", "icon": "silk"},
	"pele_de_sapo": {"name": "Pele de Sapo", "price": 15, "desc": "Pele viscosa do pântano.", "icon": "silk"},
	"pelo_gelado": {"name": "Pelo Gelado", "price": 22, "desc": "Pelo que nunca descongela.", "icon": "silk"},
	"chifre_de_diabrete": {"name": "Chifre de Diabrete", "price": 28, "desc": "Chifre quente ao toque.", "icon": "bone"},
	"brasa_infernal": {"name": "Brasa Infernal", "price": 34, "desc": "Brasa que não se apaga.", "icon": "essence"},
	"coroa_das_dunas": {"name": "Coroa das Dunas", "price": 150, "desc": "Troféu do Rei Escorpião.", "icon": "core"},
	"coroa_do_brejo": {"name": "Coroa do Brejo", "price": 160, "desc": "Troféu do Senhor do Brejo.", "icon": "core"},
	"presa_do_yeti": {"name": "Presa do Yeti Ancestral", "price": 170, "desc": "Troféu do Yeti Ancestral.", "icon": "core"},
	"coracao_demoniaco": {"name": "Coração Demoníaco", "price": 400, "desc": "Troféu de Azrakhel, Lorde do Castelo Sombrio.", "icon": "core"},
}

static var _items: Dictionary = {}
static var _built := false

static func _build() -> void:
	if _built:
		return
	_built = true
	for cls in WEAPONS:
		for w in WEAPONS[cls]:
			_add_gear(w, "weapon", "weapon", [cls], cls)
	for kind in ARMORS:
		var a: Dictionary = ARMORS[kind]
		for it in a["items"]:
			_add_gear(it, "armor", "armor", a["classes"], kind)
	for it in ACCESSORIES:
		_add_gear(it, "accessory", "accessory", [], "accessory")
	for id in CONSUMABLES:
		var c: Dictionary = CONSUMABLES[id].duplicate(true)
		c["id"] = id
		c["type"] = "consumable"
		c["rarity"] = c.get("rarity", "common")
		_items[id] = c
	for id in MATERIALS:
		var m: Dictionary = MATERIALS[id].duplicate(true)
		m["id"] = id
		m["type"] = "material"
		m["rarity"] = "common"
		_items[id] = m

static func _add_gear(row: Array, type: String, slot: String, classes: Array, family: String) -> void:
	var rar: String = row[2]
	var d := {
		"id": row[0], "name": row[1], "type": type, "slot": slot, "rarity": rar, "req_level": row[3],
		"price": row[4], "stats": row[5], "classes": classes, "family": family, "icon": "%s_%s" % [type, family],
		"shop": (rar == "common" or rar == "uncommon") and int(row[3]) <= 5 and not (type == "accessory" and rar == "uncommon" and int(row[3]) > 4),
	}
	d["desc"] = "%s %s" % [SLOT_NAMES[slot], RARITY[rar]["name"]]
	_items[row[0]] = d

static func get_item(id: String) -> Dictionary:
	_build()
	return _items.get(id, {})

static func exists(id: String) -> bool:
	_build()
	return _items.has(id)

static func all_ids() -> Array:
	_build()
	return _items.keys()

static func all_items() -> Dictionary:
	_build()
	return _items

static func is_equipment(id: String) -> bool:
	var it := get_item(id)
	return it.get("type", "") in ["weapon", "armor", "accessory"]

static func rarity_color(id: String) -> Color:
	var it := get_item(id)
	return RARITY.get(it.get("rarity", "common"), RARITY["common"])["color"]

static func can_equip(id: String, class_id: String, level: int) -> Dictionary:
	var it := get_item(id)
	if it.is_empty() or not is_equipment(id):
		return {"ok": false, "reason": "Item não equipável."}
	var cls: Array = it.get("classes", [])
	if cls.size() > 0 and not (class_id in cls):
		return {"ok": false, "reason": "Sua classe não pode usar este item."}
	if level < int(it.get("req_level", 1)):
		return {"ok": false, "reason": "Requer nível %d." % int(it["req_level"])}
	return {"ok": true, "reason": ""}

static func sell_price(id: String) -> int:
	var it := get_item(id)
	return maxi(1, int(floor(float(it.get("price", 0)) * Balance.SELL_RATIO)))

static func buy_price(id: String) -> int:
	return int(get_item(id).get("price", 0))

## Perfis de loja por cidade: tipos vendidos, consumiveis especificos e faixa de nivel dos equipamentos.
const SHOP_PROFILES := {
	"aurora": {"types": ["consumable", "weapon", "armor"], "consumables": ["pocao_pequena", "pocao", "antidoto", "eter", "pergaminho_retorno"], "max_req": 2},
	"pinheiral": {"types": ["consumable", "weapon", "armor"], "consumables": ["pocao_pequena", "pocao", "antidoto", "bomba"], "max_req": 3, "min_req": 2},
	"porto": {"types": ["consumable", "accessory"], "consumables": ["pocao_pequena", "pocao", "pocao_grande", "eter", "antidoto", "bomba", "pergaminho_retorno"], "max_req": 5},
	"nevasca": {"types": ["consumable", "armor"], "consumables": ["pocao", "pocao_grande", "eter", "eter_grande", "antidoto"], "max_req": 5, "min_req": 3},
	"pedralta": {"types": ["weapon", "armor"], "consumables": [], "max_req": 5, "min_req": 4},
	"solmar": {"types": ["consumable", "accessory", "weapon"], "consumables": ["pocao", "eter", "antidoto", "bomba"], "max_req": 4, "min_req": 1},
}

static func shop_stock(profile: String = "") -> Array:
	_build()
	var out: Array = []
	var prof: Dictionary = SHOP_PROFILES.get(profile, {})
	for id in _items:
		var it: Dictionary = _items[id]
		if not it.get("shop", false):
			continue
		if not prof.is_empty():
			var t: String = String(it["type"])
			if not (t in prof["types"]):
				continue
			if t == "consumable":
				if not (id in prof["consumables"]):
					continue
			else:
				var rl := int(it.get("req_level", 1))
				if rl > int(prof.get("max_req", 99)) or rl < int(prof.get("min_req", 0)):
					continue
		out.append(id)
	out.sort_custom(func(a, b):
		var ia = _items[a]
		var ib = _items[b]
		var order = {"consumable": 0, "weapon": 1, "armor": 2, "accessory": 3, "material": 4}
		if order[ia["type"]] != order[ib["type"]]:
			return order[ia["type"]] < order[ib["type"]]
		if ia["price"] != ib["price"]:
			return ia["price"] < ib["price"]
		return String(a) < String(b))
	return out

## Equipamento de uma classe numa raridade (para recompensas de chefes).
static func class_gear(class_id: String, slot: String, rarity: String) -> String:
	_build()
	for id in _items:
		var it: Dictionary = _items[id]
		if it["type"] == slot and it["rarity"] == rarity:
			var cls: Array = it.get("classes", [])
			if cls.size() == 0 or class_id in cls:
				if slot != "accessory":
					return id
	return ""

static func stats_text(id: String) -> String:
	var it := get_item(id)
	var parts: Array = []
	for k in it.get("stats", {}):
		parts.append("%s %+d" % [STAT_NAMES.get(k, k), int(it["stats"][k])])
	return ", ".join(parts)

static func gear_pool(rarity: String, class_id: String) -> Array:
	_build()
	var out: Array = []
	for id in _items:
		var it: Dictionary = _items[id]
		if it["type"] in ["weapon", "armor", "accessory"] and it["rarity"] == rarity:
			var cls: Array = it.get("classes", [])
			if cls.size() == 0 or class_id in cls:
				out.append(id)
	return out
