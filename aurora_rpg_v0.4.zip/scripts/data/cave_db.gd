class_name CaveDB
extends RefCounted
## Grutas e criptas da ilha (mini-masmorras de um andar). A entrada de cada uma e colocada
## em tempo de execucao dentro das regioes indicadas (ver MapDB._place_caves).
## look = "andar" usado so para a paleta das paredes; chest_floor escala o tesouro.

const CAVES := {
	"gruta_dunas": {"name": "Gruta dos Escorpiões", "regions": ["dunas"], "pool": ["escorpiao", "serpente", "golem"], "level": 5,
		"look": 9, "chest_floor": 9, "tint": Color(1.0, 0.93, 0.78),
		"intro": "O ar é seco e quente. Ferrões raspam nas rochas à frente..."},
	"gruta_gelo": {"name": "Caverna Cristalina", "regions": ["geladas", "gelida"], "pool": ["lobo_gelido", "golem_gelo", "yeti"], "level": 5,
		"look": 12, "chest_floor": 12, "tint": Color(0.82, 0.92, 1.0),
		"intro": "Cristais de gelo brilham nas paredes. Algo grande respira lá dentro."},
	"gruta_brejo": {"name": "Gruta do Brejo", "regions": ["pantano"], "pool": ["sapo", "lodo", "serpente", "aranha"], "level": 6,
		"look": 10, "chest_floor": 11, "tint": Color(0.82, 1.0, 0.82),
		"intro": "Água turva goteja do teto. O coaxar ecoa pelos corredores."},
	"gruta_infernal": {"name": "Cripta Infernal", "regions": ["carmesim", "sombrias"], "pool": ["diabrete", "cao_infernal", "esqueleto"], "level": 8,
		"look": 18, "chest_floor": 16, "tint": Color(1.0, 0.82, 0.82),
		"intro": "O calor é sufocante. Runas vermelhas pulsam no chão."},
}

static func ids() -> Array:
	return CAVES.keys()

static func exists(id: String) -> bool:
	return CAVES.has(id)
