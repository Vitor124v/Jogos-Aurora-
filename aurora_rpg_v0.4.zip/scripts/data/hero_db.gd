class_name HeroDB
extends RefCounted
## Definicao de classes (e subclasses planejadas). Dados puros: balancear aqui.

const CLASS_ORDER := ["guerreiro", "mago", "assassino", "paladino"]

const CLASSES := {
	"guerreiro": {
		"name": "Guerreiro",
		"role": "Combate fisico e resistencia",
		"desc": "Forte e resistente. Habilidades fisicas baratas, provoca inimigos e atinge varios alvos.",
		"focus": "Forca e Vitalidade",
		"colors": {"primary": Color(0.78, 0.2, 0.2), "secondary": Color(0.6, 0.6, 0.65), "hair": Color(0.45, 0.28, 0.12), "skin": Color(0.95, 0.74, 0.58)},
		"look": "warrior",
		"base": {"str": 9, "int": 2, "vit": 9, "agi": 4, "def": 4, "dex": 5, "faith": 1},
		"growth": {"str": 2.0, "int": 0.3, "vit": 1.9, "agi": 0.7, "def": 1.3, "dex": 0.8, "faith": 0.2},
		"hp_base": 45, "hp_level": 9, "mp_base": 14, "mp_level": 2,
		"crit_bonus": 0.0, "crit_mult": 1.5,
		"basic": {"name": "Golpe de Espada", "kind": "phys", "weights": {"str": 1.5}, "power": 1.0, "hits": 1, "fx": "slash"},
		"skills": [["golpe_poderoso", 1], ["provocacao", 1], ["corte_giratorio", 1], ["investida", 5], ["grito_de_guerra", 8], ["terremoto", 11]],
		"start_equipment": {"weapon": "espada_enferrujada", "armor": "gibao_acolchoado"},
		"subclasses": ["berserker", "guardiao"],
	},
	"mago": {
		"name": "Mago",
		"role": "Dano magico e fraquezas elementais",
		"desc": "Fragil, mas devastador. Explora fraquezas de fogo e gelo e se protege com barreiras.",
		"focus": "Inteligencia e Mana",
		"colors": {"primary": Color(0.25, 0.35, 0.85), "secondary": Color(0.95, 0.85, 0.3), "hair": Color(0.85, 0.85, 0.9), "skin": Color(0.95, 0.74, 0.58)},
		"look": "mage",
		"base": {"str": 2, "int": 10, "vit": 4, "agi": 5, "def": 1, "dex": 6, "faith": 3},
		"growth": {"str": 0.3, "int": 2.1, "vit": 0.9, "agi": 0.8, "def": 0.5, "dex": 0.9, "faith": 0.5},
		"hp_base": 28, "hp_level": 5, "mp_base": 30, "mp_level": 7,
		"crit_bonus": 0.02, "crit_mult": 1.5,
		"basic": {"name": "Pancada de Cajado", "kind": "magic", "weights": {"int": 1.1}, "power": 0.9, "hits": 1, "fx": "arcane"},
		"skills": [["bola_de_fogo", 1], ["lanca_de_gelo", 1], ["barreira_arcana", 1], ["chuva_de_fogo", 5], ["relampago", 8], ["meteoro", 11]],
		"start_equipment": {"weapon": "cajado_de_galho", "armor": "tunica_simples"},
		"subclasses": ["elementalista", "arcanista"],
	},
	"assassino": {
		"name": "Assassino",
		"role": "Criticos, velocidade e efeitos negativos",
		"desc": "Age primeiro, golpeia duas vezes e acerta criticos. Envenena e esquiva.",
		"focus": "Agilidade e Destreza",
		"colors": {"primary": Color(0.22, 0.2, 0.3), "secondary": Color(0.55, 0.15, 0.55), "hair": Color(0.1, 0.1, 0.12), "skin": Color(0.9, 0.7, 0.55)},
		"look": "rogue",
		"base": {"str": 6, "int": 2, "vit": 5, "agi": 9, "def": 2, "dex": 9, "faith": 1},
		"growth": {"str": 1.1, "int": 0.3, "vit": 1.0, "agi": 1.6, "def": 0.7, "dex": 1.6, "faith": 0.1},
		"hp_base": 34, "hp_level": 6, "mp_base": 20, "mp_level": 3,
		"crit_bonus": 0.12, "crit_mult": 1.8,
		"basic": {"name": "Laminas Gemeas", "kind": "phys", "weights": {"str": 0.7, "dex": 0.8}, "power": 0.55, "hits": 2, "fx": "slash"},
		"skills": [["ataque_furtivo", 1], ["veneno", 1], ["passo_sombrio", 1], ["danca_das_laminas", 5], ["nevoa_venenosa", 8], ["golpe_mortal", 11]],
		"start_equipment": {"weapon": "adaga_gasta", "armor": "roupa_de_couro"},
		"subclasses": ["algoz", "espectro"],
	},
	"paladino": {
		"name": "Paladino",
		"role": "Resistencia, cura e dano sagrado",
		"desc": "Equilibrado e duradouro. Cura a si mesmo e causa dano sagrado, forte contra mortos-vivos.",
		"focus": "Vitalidade e Fe",
		"colors": {"primary": Color(0.92, 0.92, 0.95), "secondary": Color(0.95, 0.78, 0.2), "hair": Color(0.85, 0.7, 0.3), "skin": Color(0.95, 0.74, 0.58)},
		"look": "paladin",
		"base": {"str": 6, "int": 3, "vit": 8, "agi": 3, "def": 5, "dex": 4, "faith": 9},
		"growth": {"str": 1.3, "int": 0.5, "vit": 1.6, "agi": 0.5, "def": 1.2, "dex": 0.6, "faith": 1.9},
		"hp_base": 42, "hp_level": 8, "mp_base": 24, "mp_level": 4,
		"crit_bonus": 0.0, "crit_mult": 1.5,
		"basic": {"name": "Golpe de Maca", "kind": "phys", "weights": {"str": 1.2, "faith": 0.4}, "power": 1.0, "hits": 1, "fx": "blunt"},
		"skills": [["golpe_sagrado", 1], ["cura", 1], ["escudo_divino", 1], ["julgamento", 5], ["martelo_divino", 8], ["bencao_da_aurora", 11]],
		"start_equipment": {"weapon": "maca_de_madeira", "armor": "gibao_acolchoado"},
		"subclasses": ["templario", "inquisidor"],
	},
}

## Subclasses: arquitetura pronta (desbloqueio em atualizacao futura). Cada uma pode
## adicionar bonus de atributos, habilidades e modificar a "basic" sem reescrever classes.
const SUBCLASSES := {
	"berserker": {"name": "Berserker", "parent": "guerreiro", "desc": "Maior potencial ofensivo.", "bonus": {"str": 4}, "skills": [], "unlocked": false},
	"guardiao": {"name": "Guardiao", "parent": "guerreiro", "desc": "Maior defesa e protecao.", "bonus": {"def": 4, "vit": 2}, "skills": [], "unlocked": false},
	"elementalista": {"name": "Elementalista", "parent": "mago", "desc": "Dano elemental.", "bonus": {"int": 4}, "skills": [], "unlocked": false},
	"arcanista": {"name": "Arcanista", "parent": "mago", "desc": "Controle e efeitos magicos.", "bonus": {"int": 2, "dex": 2}, "skills": [], "unlocked": false},
	"algoz": {"name": "Algoz", "parent": "assassino", "desc": "Dano concentrado.", "bonus": {"str": 3, "dex": 2}, "skills": [], "unlocked": false},
	"espectro": {"name": "Espectro", "parent": "assassino", "desc": "Evasao e efeitos negativos.", "bonus": {"agi": 4}, "skills": [], "unlocked": false},
	"templario": {"name": "Templario", "parent": "paladino", "desc": "Defesa e combate.", "bonus": {"def": 3, "str": 2}, "skills": [], "unlocked": false},
	"inquisidor": {"name": "Inquisidor", "parent": "paladino", "desc": "Dano sagrado e enfraquecimento.", "bonus": {"faith": 4}, "skills": [], "unlocked": false},
}

## Classes especiais desbloqueadas por chefes/missoes/segredos (apenas registro na v0.1).
const SPECIAL_CLASSES := {
	"cavaleiro_da_aurora": {"name": "Cavaleiro da Aurora", "desc": "Desbloqueada ao derrotar o Guardiao Ancião. (Em breve)", "unlock": "boss:boss_elder_treant"},
	"sombra_ancestral": {"name": "Sombra Ancestral", "desc": "Desbloqueada ao derrotar o Cavaleiro Espectral. (Em breve)", "unlock": "boss:boss_ghost_knight"},
}

static func get_class_data(id: String) -> Dictionary:
	return CLASSES.get(id, {})

static func class_exists(id: String) -> bool:
	return CLASSES.has(id)

static func subclass_bonus(sub_id: String) -> Dictionary:
	if sub_id == "" or not SUBCLASSES.has(sub_id):
		return {}
	return SUBCLASSES[sub_id]["bonus"]

static func skills_for(class_id: String, level: int) -> Array:
	var out: Array = []
	for entry in CLASSES.get(class_id, {}).get("skills", []):
		if level >= int(entry[1]):
			out.append(String(entry[0]))
	return out
