class_name Balance
extends RefCounted
## Todos os numeros de balanceamento ficam aqui (e nos bancos de dados *_db.gd).

const TILE := 16
const GAME_VERSION := "0.4.0"
const SAVE_VERSION := 1

# --- Inventario ---
const INVENTORY_LIMIT := 30      # numero maximo de pilhas diferentes
const STACK_LIMIT := 99
const START_GOLD := 150
const SELL_RATIO := 0.4          # preco de venda = preco * SELL_RATIO

# --- Progressao ---
const MAX_LEVEL := 55
const EXP_BASE := 20.0
const EXP_POWER := 1.6
const LEVEL_UP_FULL_RESTORE := true   # subir de nivel restaura HP/MP

# --- Combate ---
const DEF_K := 30.0              # dano = bruto * K / (K + defesa)
const LEVEL_ATK_BONUS := 1.0     # bonus de dano bruto por nivel
const DAMAGE_VARIANCE := 0.10    # +/-10%
const BASE_HIT := 0.92
const HIT_PER_POINT := 0.012     # (dex atacante - agi defensor) * isto
const HIT_MIN := 0.45
const HIT_MAX := 0.99
const CRIT_BASE := 0.05
const CRIT_PER_DEX := 0.006
const CRIT_MAX := 0.65
const CRIT_MULT := 1.5
const WEAK_MULT := 1.5
const RESIST_MULT := 0.5
const GUARD_MULT := 0.5          # acao Defender
const HP_PER_VIT := 3
const MP_PER_INT := 2
const MP_PER_FAITH := 1
const INITIATIVE_RANDOM := 0.25  # fracao da agilidade somada aleatoriamente
const FLEE_BASE := 0.5
const FLEE_PER_AGI := 0.02
const FLEE_MIN := 0.15
const FLEE_MAX := 0.9
const FLEE_IMMUNITY_SECONDS := 2.5
const POISON_PCT_MAX_HP := 0.0   # veneno usa potencia propria (ver skill)
const ENEMY_STAT_SCALE := 0.17   # crescimento dos inimigos por nivel
const BOSS_STAT_SCALE := 0.10    # crescimento de chefes (nivel fixo) por nivel
const ENEMY_REWARD_SCALE := 0.15
const EXP_LEVEL_DIFF_STEP := 0.12
const EXP_LEVEL_DIFF_MIN := 0.3
const EXP_LEVEL_DIFF_MAX := 1.8

# --- Mundo ---
const MONSTER_RESPAWN_SECONDS := 240.0
const BUSH_RESPAWN_SECONDS := 150.0
const DEATH_GOLD_PENALTY := 0.10
const STEP_SECONDS := 0.16
const MONSTER_STEP_MIN := 0.7
const MONSTER_STEP_MAX := 1.6
const CHASE_RANGE := 4

# --- Masmorra ---
const DUNGEON_FLOORS := 20
const BOSS_FLOORS := [5, 10, 15, 20]

# --- Raridade / loot ---
const RARITY_ORDER := ["common", "uncommon", "rare", "epic", "legendary"]
# peso de cada raridade por "tier" de andar (0: 1-4, 1: 6-9, 2: 11-14, 3: 16-19) e andar minimo
const CHEST_RARITY := {
	"common": {"weights": [60, 35, 20, 10], "min_floor": 1},
	"uncommon": {"weights": [35, 45, 45, 35], "min_floor": 1},
	"rare": {"weights": [5, 18, 28, 35], "min_floor": 3},
	"epic": {"weights": [0, 2, 6, 17], "min_floor": 8},
	"legendary": {"weights": [0, 0, 1, 3], "min_floor": 14},
}
const MONSTER_GEAR_DROP_CHANCE := 0.04
const MONSTER_RARITY_CAP := "rare"   # monstros comuns nunca dropam acima disso

static func floor_tier(floor_n: int) -> int:
	if floor_n <= 5:
		return 0
	if floor_n <= 10:
		return 1
	if floor_n <= 15:
		return 2
	return 3

static func monster_level_for_floor(floor_n: int) -> int:
	return clampi(int(round(1.0 + (floor_n - 1) * 0.42)), 1, 9)
