class_name SkillDB
extends RefCounted
## Habilidades de heroi e de inimigos. kind: phys | magic | holy | heal | buff | debuff
## target: foe | all_foes | self | ally | all_allies   (relativo a quem usa)
## effects[]: {status, chance, turns, value, scale_weights, scale, who: "target"|"self"}

const STATUS_INFO := {
	"poison": {"name": "Veneno", "color": Color(0.6, 0.2, 0.8), "bad": true},
	"defup": {"name": "Defesa+", "color": Color(0.3, 0.6, 1.0), "bad": false},
	"defdown": {"name": "Defesa-", "color": Color(0.8, 0.4, 0.2), "bad": true},
	"atkup": {"name": "Ataque+", "color": Color(1.0, 0.5, 0.2), "bad": false},
	"atkdown": {"name": "Ataque-", "color": Color(0.7, 0.5, 0.2), "bad": true},
	"agiup": {"name": "Agil+", "color": Color(0.4, 0.9, 0.4), "bad": false},
	"agidown": {"name": "Lento", "color": Color(0.5, 0.7, 0.9), "bad": true},
	"evade": {"name": "Esquiva", "color": Color(0.7, 0.7, 0.9), "bad": false},
	"shield": {"name": "Barreira", "color": Color(0.5, 0.8, 1.0), "bad": false},
	"guard": {"name": "Protecao", "color": Color(1.0, 0.9, 0.4), "bad": false},
	"regen": {"name": "Regen", "color": Color(0.4, 1.0, 0.5), "bad": false},
	"stun": {"name": "Atordoado", "color": Color(1.0, 1.0, 0.3), "bad": true},
	"taunt": {"name": "Provocando", "color": Color(1.0, 0.3, 0.3), "bad": false},
	"focus": {"name": "Foco", "color": Color(0.9, 0.3, 0.9), "bad": false},
}

const SKILLS := {
	# ---------------- GUERREIRO ----------------
	"golpe_poderoso": {"name": "Golpe Poderoso", "kind": "phys", "target": "foe", "mp": 5, "power": 2.0, "accuracy": 0.95, "element": "physical", "fx": "slash_heavy", "weights": {"str": 1.5}, "desc": "Golpe pesado que causa grande dano fisico."},
	"provocacao": {"name": "Provocacao", "kind": "buff", "target": "self", "mp": 4, "fx": "buff", "desc": "Atrai ataques inimigos e aumenta a Defesa por 3 turnos.",
		"effects": [{"status": "defup", "turns": 3, "value": 0.4, "who": "self"}, {"status": "taunt", "turns": 3, "value": 1, "who": "self"}]},
	"corte_giratorio": {"name": "Corte Giratorio", "kind": "phys", "target": "all_foes", "mp": 8, "power": 1.1, "accuracy": 0.95, "element": "physical", "fx": "spin", "weights": {"str": 1.5}, "desc": "Atinge todos os inimigos."},
	"investida": {"name": "Investida Brutal", "kind": "phys", "target": "foe", "mp": 12, "power": 2.8, "accuracy": 0.85, "element": "physical", "fx": "slash_heavy", "weights": {"str": 1.5}, "desc": "Ataque devastador, mas menos preciso."},
	# ---------------- MAGO ----------------
	"bola_de_fogo": {"name": "Bola de Fogo", "kind": "magic", "target": "foe", "mp": 6, "power": 1.9, "accuracy": 1.0, "element": "fire", "fx": "fire", "weights": {"int": 1.8}, "desc": "Esfera de fogo. Forte contra criaturas fracas ao fogo."},
	"lanca_de_gelo": {"name": "Lanca de Gelo", "kind": "magic", "target": "foe", "mp": 5, "power": 1.6, "accuracy": 1.0, "element": "ice", "fx": "ice", "weights": {"int": 1.8}, "desc": "Dano de gelo; pode reduzir a agilidade do alvo.",
		"effects": [{"status": "agidown", "chance": 0.35, "turns": 3, "value": 0.3, "who": "target"}]},
	"barreira_arcana": {"name": "Barreira Arcana", "kind": "buff", "target": "self", "mp": 8, "fx": "shield", "desc": "Cria uma barreira que absorve dano por 4 turnos.",
		"effects": [{"status": "shield", "turns": 4, "scale_weights": {"int": 2.2}, "scale": 1.0, "base": 8, "who": "self"}]},
	"chuva_de_fogo": {"name": "Chuva de Fogo", "kind": "magic", "target": "all_foes", "mp": 14, "power": 1.2, "accuracy": 1.0, "element": "fire", "fx": "fire_rain", "weights": {"int": 1.8}, "desc": "Chamas atingem todos os inimigos."},
	# ---------------- ASSASSINO ----------------
	"ataque_furtivo": {"name": "Ataque Furtivo", "kind": "phys", "target": "foe", "mp": 5, "power": 2.4, "accuracy": 1.0, "crit_bonus": 0.35, "element": "physical", "fx": "stab", "weights": {"str": 0.8, "dex": 1.0}, "desc": "Alta chance de critico."},
	"veneno": {"name": "Veneno", "kind": "debuff", "target": "foe", "mp": 6, "accuracy": 1.0, "fx": "poison", "desc": "Envenena o alvo por 4 turnos.",
		"effects": [{"status": "poison", "chance": 1.0, "turns": 4, "scale_weights": {"dex": 0.7}, "scale": 0.6, "base": 0, "who": "target"}]},
	"passo_sombrio": {"name": "Passo Sombrio", "kind": "buff", "target": "self", "mp": 7, "fx": "shadow", "desc": "Aumenta a esquiva e garante o proximo golpe critico.",
		"effects": [{"status": "evade", "turns": 3, "value": 0.35, "who": "self"}, {"status": "focus", "turns": 3, "value": 1, "who": "self"}]},
	"danca_das_laminas": {"name": "Danca das Laminas", "kind": "phys", "target": "foe", "mp": 12, "power": 0.6, "hits": 4, "accuracy": 0.95, "element": "physical", "fx": "stab", "weights": {"str": 0.7, "dex": 0.8}, "desc": "Quatro golpes rapidos."},
	# ---------------- PALADINO ----------------
	"golpe_sagrado": {"name": "Golpe Sagrado", "kind": "holy", "target": "foe", "mp": 6, "power": 1.8, "accuracy": 1.0, "element": "holy", "fx": "holy", "weights": {"faith": 1.2, "str": 0.8}, "desc": "Dano sagrado. Fatal contra mortos-vivos."},
	"cura": {"name": "Cura", "kind": "heal", "target": "self", "mp": 7, "power": 2.2, "fx": "heal", "weights": {"faith": 2.0}, "desc": "Restaura HP com base na Fe."},
	"escudo_divino": {"name": "Escudo Divino", "kind": "buff", "target": "self", "mp": 8, "fx": "holy_shield", "desc": "Reduz o dano recebido em 40% por 3 turnos.",
		"effects": [{"status": "guard", "turns": 3, "value": 0.4, "who": "self"}, {"status": "defup", "turns": 3, "value": 0.2, "who": "self"}]},
	"julgamento": {"name": "Julgamento", "kind": "holy", "target": "foe", "mp": 14, "power": 2.4, "accuracy": 1.0, "element": "holy", "fx": "holy_big", "weights": {"faith": 1.2, "str": 0.8}, "desc": "Dano sagrado e reduz o ataque do alvo.",
		"effects": [{"status": "atkdown", "chance": 1.0, "turns": 3, "value": 0.25, "who": "target"}]},

	# ---------------- HABILIDADES AVANCADAS (nivel 8 e 11) ----------------
	"grito_de_guerra": {"name": "Grito de Guerra", "kind": "buff", "target": "self", "mp": 10, "fx": "buff", "desc": "Aumenta Ataque e Defesa por 3 turnos.",
		"effects": [{"status": "atkup", "turns": 3, "value": 0.4, "who": "self"}, {"status": "defup", "turns": 3, "value": 0.25, "who": "self"}]},
	"terremoto": {"name": "Terremoto", "kind": "phys", "target": "all_foes", "mp": 20, "power": 1.8, "accuracy": 0.95, "element": "physical", "fx": "blunt", "weights": {"str": 1.5}, "desc": "Abala o chao e esmaga todos os inimigos."},
	"relampago": {"name": "Relâmpago Arcano", "kind": "magic", "target": "foe", "mp": 12, "power": 2.6, "accuracy": 1.0, "element": "physical", "fx": "arcane", "weights": {"int": 1.8}, "desc": "Descarga arcana que ignora fraquezas e resistências."},
	"meteoro": {"name": "Meteoro", "kind": "magic", "target": "all_foes", "mp": 26, "power": 2.2, "accuracy": 1.0, "element": "fire", "fx": "fire_rain", "weights": {"int": 1.8}, "desc": "Um meteoro devastador atinge todos os inimigos."},
	"nevoa_venenosa": {"name": "Névoa Venenosa", "kind": "debuff", "target": "all_foes", "mp": 12, "accuracy": 1.0, "fx": "poison", "desc": "Envenena todos os inimigos por 4 turnos.",
		"effects": [{"status": "poison", "chance": 1.0, "turns": 4, "scale_weights": {"dex": 0.6}, "scale": 0.6, "base": 0, "who": "target"}]},
	"golpe_mortal": {"name": "Golpe Mortal", "kind": "phys", "target": "foe", "mp": 18, "power": 3.6, "accuracy": 0.9, "crit_bonus": 0.5, "element": "physical", "fx": "stab", "weights": {"str": 0.8, "dex": 1.2}, "desc": "Golpe fulminante com enorme chance de crítico."},
	"martelo_divino": {"name": "Martelo Divino", "kind": "holy", "target": "all_foes", "mp": 14, "power": 1.4, "accuracy": 1.0, "element": "holy", "fx": "holy_big", "weights": {"faith": 1.2, "str": 0.8}, "desc": "Luz sagrada atinge todos os inimigos."},
	"bencao_da_aurora": {"name": "Bênção da Aurora", "kind": "heal", "target": "self", "mp": 20, "power": 4.0, "fx": "heal", "weights": {"faith": 2.0}, "desc": "Cura muito e reduz o dano recebido por 3 turnos.",
		"effects": [{"status": "guard", "turns": 3, "value": 0.3, "who": "self"}]},

	# ---------------- INIMIGOS ----------------
	"e_acid_spit": {"name": "Cuspe Acido", "kind": "magic", "target": "foe", "power": 1.0, "accuracy": 0.95, "element": "physical", "fx": "poison", "weights": {"int": 1.6}, "msg": "{u} cospe acido em {t}!",
		"effects": [{"status": "defdown", "chance": 0.5, "turns": 3, "value": 0.25, "who": "target"}]},
	"e_club_smash": {"name": "Pancada Brutal", "kind": "phys", "target": "foe", "power": 1.4, "accuracy": 0.85, "element": "physical", "fx": "blunt", "weights": {"str": 1.5}, "msg": "{u} golpeia {t} com forca!"},
	"e_screech": {"name": "Grito Agudo", "kind": "debuff", "target": "foe", "accuracy": 1.0, "fx": "arcane", "msg": "{u} solta um grito agudo!",
		"effects": [{"status": "agidown", "chance": 1.0, "turns": 3, "value": 0.3, "who": "target"}]},
	"e_howl": {"name": "Uivo", "kind": "buff", "target": "self", "fx": "buff", "msg": "{u} uiva ferozmente!",
		"effects": [{"status": "atkup", "turns": 3, "value": 0.3, "who": "self"}]},
	"e_bone_throw": {"name": "Arremesso de Osso", "kind": "phys", "target": "foe", "power": 1.2, "accuracy": 0.95, "element": "physical", "fx": "stab", "weights": {"str": 1.5}, "msg": "{u} arremessa um osso em {t}!"},
	"e_stomp": {"name": "Pisada Sismica", "kind": "phys", "target": "foe", "power": 1.7, "accuracy": 0.8, "element": "physical", "fx": "blunt", "weights": {"str": 1.5}, "msg": "{u} esmaga {t}!"},
	"e_poison_bite": {"name": "Mordida Venenosa", "kind": "phys", "target": "foe", "power": 0.9, "accuracy": 1.0, "element": "physical", "fx": "poison", "weights": {"str": 1.5}, "msg": "{u} morde {t}!",
		"effects": [{"status": "poison", "chance": 0.6, "turns": 3, "value": 4, "scale": 0, "who": "target"}]},
	"e_spore": {"name": "Esporos Toxicos", "kind": "debuff", "target": "foe", "accuracy": 0.95, "fx": "poison", "msg": "{u} libera esporos!",
		"effects": [{"status": "poison", "chance": 0.8, "turns": 3, "value": 3, "scale": 0, "who": "target"}, {"status": "atkdown", "chance": 0.5, "turns": 3, "value": 0.2, "who": "target"}]},
	"e_wisp_flame": {"name": "Chama Fatua", "kind": "magic", "target": "foe", "power": 1.3, "accuracy": 1.0, "element": "fire", "fx": "fire", "weights": {"int": 1.8}, "msg": "{u} lanca uma chama em {t}!"},

	# --- Rei Slime ---
	"e_slam": {"name": "Esmagar", "kind": "phys", "target": "foe", "power": 1.3, "accuracy": 0.95, "element": "physical", "fx": "blunt", "weights": {"str": 1.5}, "msg": "{u} se joga sobre {t}!"},
	"e_acid_wave": {"name": "Onda Acida", "kind": "magic", "target": "all_foes", "power": 0.9, "accuracy": 1.0, "element": "physical", "fx": "poison", "weights": {"int": 1.6}, "msg": "{u} libera uma onda acida!",
		"effects": [{"status": "defdown", "chance": 0.7, "turns": 3, "value": 0.25, "who": "target"}]},
	"e_gel_burst": {"name": "Explosao Gelatinosa", "kind": "phys", "target": "foe", "power": 2.1, "accuracy": 0.9, "element": "physical", "fx": "blunt", "weights": {"str": 1.5}, "msg": "{u} explode em gosma sobre {t}!"},
	# --- Matriarca Aranha ---
	"e_web": {"name": "Teia Pegajosa", "kind": "debuff", "target": "foe", "accuracy": 1.0, "fx": "arcane", "msg": "{u} lanca uma teia em {t}!",
		"effects": [{"status": "agidown", "chance": 1.0, "turns": 3, "value": 0.4, "who": "target"}, {"status": "defdown", "chance": 1.0, "turns": 3, "value": 0.2, "who": "target"}]},
	"e_venom_fang": {"name": "Presa Venenosa", "kind": "phys", "target": "foe", "power": 1.2, "accuracy": 1.0, "element": "physical", "fx": "poison", "weights": {"str": 1.5}, "msg": "{u} crava as presas em {t}!",
		"effects": [{"status": "poison", "chance": 0.9, "turns": 4, "value": 6, "scale": 0, "who": "target"}]},
	"e_fang_flurry": {"name": "Rajada de Garras", "kind": "phys", "target": "foe", "power": 0.75, "hits": 3, "accuracy": 0.95, "element": "physical", "fx": "stab", "weights": {"str": 1.5}, "msg": "{u} ataca {t} em uma rajada!"},
	# --- Cavaleiro Espectral ---
	"e_spectral_slash": {"name": "Corte Espectral", "kind": "phys", "target": "foe", "power": 1.4, "accuracy": 0.95, "element": "dark", "fx": "slash_heavy", "weights": {"str": 1.5}, "msg": "{u} corta {t} com sua lamina espectral!"},
	"e_dark_wave": {"name": "Onda Sombria", "kind": "magic", "target": "foe", "power": 1.2, "accuracy": 1.0, "element": "dark", "fx": "dark", "weights": {"int": 1.8}, "msg": "{u} libera uma onda sombria!",
		"effects": [{"status": "atkdown", "chance": 0.6, "turns": 3, "value": 0.25, "who": "target"}]},
	"e_devastating_charge": {"name": "Carga Devastadora", "kind": "phys", "target": "foe", "power": 3.4, "accuracy": 1.0, "element": "dark", "fx": "slash_heavy", "weights": {"str": 1.5}, "msg": "{u} avanca com a CARGA DEVASTADORA!"},
	# --- Guardiao Ancião ---
	"e_root_whip": {"name": "Chicote de Raizes", "kind": "phys", "target": "foe", "power": 1.3, "accuracy": 0.95, "element": "physical", "fx": "blunt", "weights": {"str": 1.5}, "msg": "{u} açoita {t} com raizes!",
		"effects": [{"status": "agidown", "chance": 0.5, "turns": 3, "value": 0.3, "who": "target"}]},
	"e_thorn_rain": {"name": "Chuva de Espinhos", "kind": "phys", "target": "all_foes", "power": 0.85, "accuracy": 0.95, "element": "physical", "fx": "stab", "weights": {"str": 1.5}, "msg": "{u} faz chover espinhos!"},
	"e_sap_heal": {"name": "Seiva Vital", "kind": "heal", "target": "self", "power": 0.0, "pct": 0.08, "fx": "heal", "msg": "{u} absorve seiva e se regenera!"},
	"e_vine_crush": {"name": "Aperto de Trepadeiras", "kind": "phys", "target": "foe", "power": 2.2, "accuracy": 0.9, "element": "physical", "fx": "blunt", "weights": {"str": 1.5}, "msg": "{u} esmaga {t} com trepadeiras!"},
	"e_spore_cloud": {"name": "Nuvem de Esporos", "kind": "debuff", "target": "all_foes", "accuracy": 0.95, "fx": "poison", "msg": "{u} libera uma nuvem de esporos!",
		"effects": [{"status": "poison", "chance": 0.85, "turns": 4, "value": 7, "scale": 0, "who": "target"}]},
	"e_nature_wrath": {"name": "Furia da Natureza", "kind": "magic", "target": "all_foes", "power": 1.5, "accuracy": 1.0, "element": "physical", "fx": "fire_rain", "weights": {"int": 1.8}, "msg": "{u} desperta a FURIA DA NATUREZA!"},
	# --- bioma: dunas / pantano / gelo / inferno ---
	"e_sting": {"name": "Ferroada", "kind": "phys", "target": "foe", "power": 1.1, "accuracy": 0.95, "element": "physical", "fx": "poison", "weights": {"str": 1.5}, "msg": "{u} fere {t} com o ferrão!",
		"effects": [{"status": "poison", "chance": 0.7, "turns": 3, "value": 5, "scale": 0, "who": "target"}]},
	"e_sand_blast": {"name": "Rajada de Areia", "kind": "magic", "target": "all_foes", "power": 0.9, "accuracy": 0.95, "element": "physical", "fx": "arcane", "weights": {"int": 1.6}, "msg": "{u} levanta uma tempestade de areia!",
		"effects": [{"status": "atkdown", "chance": 0.5, "turns": 3, "value": 0.2, "who": "target"}]},
	"e_pincer": {"name": "Pinça Esmagadora", "kind": "phys", "target": "foe", "power": 1.8, "accuracy": 0.9, "element": "physical", "fx": "blunt", "weights": {"str": 1.5}, "msg": "{u} agarra {t} com a pinça!"},
	"e_tongue": {"name": "Língua Pegajosa", "kind": "phys", "target": "foe", "power": 1.0, "accuracy": 0.95, "element": "physical", "fx": "stab", "weights": {"str": 1.5}, "msg": "{u} chicoteia {t} com a língua!",
		"effects": [{"status": "agidown", "chance": 0.6, "turns": 3, "value": 0.3, "who": "target"}]},
	"e_toxic_bog": {"name": "Lodo Tóxico", "kind": "debuff", "target": "all_foes", "accuracy": 0.95, "fx": "poison", "msg": "{u} cospe lodo tóxico em todos!",
		"effects": [{"status": "poison", "chance": 0.85, "turns": 4, "value": 6, "scale": 0, "who": "target"}, {"status": "defdown", "chance": 0.5, "turns": 3, "value": 0.2, "who": "target"}]},
	"e_croak": {"name": "Coaxar Sombrio", "kind": "debuff", "target": "foe", "accuracy": 1.0, "fx": "dark", "msg": "{u} coaxa de forma sinistra!",
		"effects": [{"status": "atkdown", "chance": 1.0, "turns": 3, "value": 0.3, "who": "target"}]},
	"e_ice_smash": {"name": "Soco Glacial", "kind": "phys", "target": "foe", "power": 1.6, "accuracy": 0.9, "element": "ice", "fx": "blunt", "weights": {"str": 1.5}, "msg": "{u} esmaga {t} com punhos de gelo!",
		"effects": [{"status": "agidown", "chance": 0.5, "turns": 3, "value": 0.3, "who": "target"}]},
	"e_blizzard": {"name": "Nevasca", "kind": "magic", "target": "all_foes", "power": 1.1, "accuracy": 1.0, "element": "ice", "fx": "ice", "weights": {"int": 1.8}, "msg": "{u} invoca uma nevasca!"},
	"e_roar": {"name": "Rugido Ancestral", "kind": "buff", "target": "self", "fx": "buff", "msg": "{u} ruge e sua pelagem eriça!",
		"effects": [{"status": "atkup", "turns": 3, "value": 0.35, "who": "self"}]},
	"e_hellfire": {"name": "Fogo Infernal", "kind": "magic", "target": "all_foes", "power": 1.3, "accuracy": 1.0, "element": "fire", "fx": "fire_rain", "weights": {"int": 1.8}, "msg": "{u} faz chover fogo infernal!"},
	"e_fire_bite": {"name": "Mordida Flamejante", "kind": "phys", "target": "foe", "power": 1.3, "accuracy": 0.95, "element": "fire", "fx": "fire", "weights": {"str": 1.5}, "msg": "{u} morde {t} com presas em chamas!"},
	"e_dark_blade": {"name": "Lâmina das Trevas", "kind": "phys", "target": "foe", "power": 2.0, "accuracy": 0.95, "element": "dark", "fx": "slash_heavy", "weights": {"str": 1.5}, "msg": "{u} golpeia {t} com a lâmina das trevas!"},
	"e_curse": {"name": "Maldição Demoníaca", "kind": "debuff", "target": "all_foes", "accuracy": 1.0, "fx": "dark", "msg": "{u} lança uma maldição sobre todos!",
		"effects": [{"status": "atkdown", "chance": 1.0, "turns": 3, "value": 0.25, "who": "target"}, {"status": "defdown", "chance": 1.0, "turns": 3, "value": 0.25, "who": "target"}]},
	# acao especial: preparar carga (nao causa dano)
	"e_prepare": {"name": "Postura Sombria", "kind": "buff", "target": "self", "fx": "dark", "msg": "{u} assume uma postura sombria... algo terrivel vem a seguir!", "charge": "e_devastating_charge"},
}

static func get_skill(id: String) -> Dictionary:
	if SKILLS.has(id):
		var d: Dictionary = SKILLS[id].duplicate(true)
		d["id"] = id
		return d
	return {}

static func exists(id: String) -> bool:
	return SKILLS.has(id)

static func status_name(id: String) -> String:
	return String(STATUS_INFO.get(id, {}).get("name", id))
