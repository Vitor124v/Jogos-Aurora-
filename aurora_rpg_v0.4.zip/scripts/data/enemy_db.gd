class_name EnemyDB
extends RefCounted
## Inimigos comuns, minions e chefes. Tudo definido por dados.
## base: atributos no nivel 1 (escalam por nivel). Chefes tem "level" fixo.
## ai.weights: [[acao, peso]...] - "attack" = ataque basico.
## phases (chefes): [{hp_below, pattern[], on_enter{msg, heal_pct, summon[], status[]}}]

const ENEMIES := {
	"slime": {
		"name": "Slime Verde", "sprite": "slime", "color": Color(0.35, 0.8, 0.35), "size": 24,
		"base": {"hp": 22, "str": 5, "int": 3, "def": 2, "mdef": 2, "agi": 3, "dex": 3},
		"exp": 6, "gold": [2, 5], "floors": [1, 6], "weak": ["fire"], "resist": ["ice"],
		"drops": [{"item": "gosma", "chance": 0.55}, {"item": "pocao_pequena", "chance": 0.05}],
		"ai": {"weights": [["attack", 100]]}, "attack_name": "Investida", "behavior": "wander",
	},
	"morcego": {
		"name": "Morcego Sombrio", "sprite": "bat", "color": Color(0.45, 0.3, 0.6), "size": 24,
		"base": {"hp": 16, "str": 5, "int": 2, "def": 1, "mdef": 1, "agi": 9, "dex": 6},
		"exp": 8, "gold": [2, 6], "floors": [1, 9], "weak": ["holy", "ice"], "resist": ["dark"],
		"drops": [{"item": "asa_de_morcego", "chance": 0.5}],
		"ai": {"weights": [["attack", 65], ["e_screech", 35]]}, "attack_name": "Mordida", "behavior": "chase",
	},
	"goblin": {
		"name": "Goblin", "sprite": "goblin", "color": Color(0.45, 0.65, 0.25), "size": 24,
		"base": {"hp": 30, "str": 7, "int": 2, "def": 3, "mdef": 1, "agi": 5, "dex": 5},
		"exp": 12, "gold": [4, 10], "floors": [2, 10], "weak": ["fire"], "resist": [],
		"drops": [{"item": "orelha_de_goblin", "chance": 0.5}, {"item": "pocao_pequena", "chance": 0.08}],
		"ai": {"weights": [["attack", 70], ["e_club_smash", 30]]}, "attack_name": "Facada", "behavior": "wander",
	},
	"cogumelo": {
		"name": "Cogumelo Tóxico", "sprite": "mushroom", "color": Color(0.35, 0.45, 0.9), "size": 24,
		"base": {"hp": 26, "str": 4, "int": 6, "def": 3, "mdef": 4, "agi": 3, "dex": 4},
		"exp": 11, "gold": [3, 8], "floors": [3, 12], "weak": ["fire"], "resist": ["dark"],
		"drops": [{"item": "cogumelo_azul", "chance": 0.5}, {"item": "antidoto", "chance": 0.08}],
		"ai": {"weights": [["attack", 50], ["e_spore", 50]]}, "attack_name": "Cabeçada", "behavior": "wander",
	},
	"lobo": {
		"name": "Lobo Cinzento", "sprite": "wolf", "color": Color(0.55, 0.55, 0.6), "size": 24,
		"base": {"hp": 34, "str": 9, "int": 1, "def": 3, "mdef": 2, "agi": 9, "dex": 7},
		"exp": 16, "gold": [5, 12], "floors": [6, 14], "weak": ["fire"], "resist": [],
		"drops": [{"item": "presa_de_lobo", "chance": 0.5}, {"item": "pocao", "chance": 0.05}],
		"ai": {"weights": [["attack", 70], ["e_howl", 30]]}, "attack_name": "Mordida", "behavior": "chase",
	},
	"aranha": {
		"name": "Aranha Venenosa", "sprite": "spider", "color": Color(0.55, 0.2, 0.55), "size": 24,
		"base": {"hp": 38, "str": 9, "int": 3, "def": 4, "mdef": 3, "agi": 7, "dex": 8},
		"exp": 22, "gold": [6, 14], "floors": [7, 20], "weak": ["fire"], "resist": ["dark"],
		"drops": [{"item": "seda_de_aranha", "chance": 0.5}, {"item": "antidoto", "chance": 0.1}],
		"ai": {"weights": [["attack", 40], ["e_poison_bite", 60]]}, "attack_name": "Picada", "behavior": "wander",
	},
	"esqueleto": {
		"name": "Esqueleto", "sprite": "skeleton", "color": Color(0.9, 0.9, 0.8), "size": 24,
		"base": {"hp": 42, "str": 11, "int": 2, "def": 6, "mdef": 3, "agi": 4, "dex": 5},
		"exp": 24, "gold": [8, 16], "floors": [11, 20], "weak": ["holy", "fire"], "resist": ["ice", "dark"],
		"drops": [{"item": "osso_antigo", "chance": 0.55}, {"item": "pocao", "chance": 0.07}],
		"ai": {"weights": [["attack", 60], ["e_bone_throw", 40]]}, "attack_name": "Espadada", "behavior": "wander",
	},
	"golem": {
		"name": "Golem de Pedra", "sprite": "golem", "color": Color(0.55, 0.5, 0.45), "size": 24,
		"base": {"hp": 70, "str": 13, "int": 1, "def": 12, "mdef": 4, "agi": 2, "dex": 3},
		"exp": 36, "gold": [12, 24], "floors": [13, 20], "weak": ["ice"], "resist": ["fire", "dark"],
		"drops": [{"item": "pedra_runica", "chance": 0.5}, {"item": "pocao_grande", "chance": 0.04}],
		"ai": {"weights": [["attack", 55], ["e_stomp", 45]]}, "attack_name": "Soco", "behavior": "slow",
	},
	"fogo_fatuo": {
		"name": "Fogo-Fátuo", "sprite": "wisp", "color": Color(0.5, 0.8, 1.0), "size": 24,
		"base": {"hp": 30, "str": 3, "int": 12, "def": 1, "mdef": 8, "agi": 8, "dex": 7},
		"exp": 30, "gold": [10, 20], "floors": [15, 20], "weak": ["ice", "holy"], "resist": ["fire", "physical"],
		"drops": [{"item": "essencia_eterea", "chance": 0.5}, {"item": "eter", "chance": 0.1}],
		"ai": {"weights": [["attack", 30], ["e_wisp_flame", 70]]}, "attack_name": "Toque Gélido", "behavior": "chase",
	},

	# ---------- inimigos de bioma (so aparecem na ilha; "floors" 0 = fora das masmorras) ----------
	"escorpiao": {
		"name": "Escorpião Dourado", "sprite": "scorpion", "color": Color(0.85, 0.65, 0.25), "size": 24,
		"base": {"hp": 40, "str": 10, "int": 2, "def": 5, "mdef": 2, "agi": 6, "dex": 7},
		"exp": 24, "gold": [8, 16], "floors": [0, 0], "weak": ["ice"], "resist": ["fire"],
		"drops": [{"item": "ferrao_de_escorpiao", "chance": 0.5}, {"item": "antidoto", "chance": 0.08}],
		"ai": {"weights": [["attack", 40], ["e_sting", 60]]}, "attack_name": "Pinça", "behavior": "wander",
	},
	"serpente": {
		"name": "Serpente das Dunas", "sprite": "snake", "color": Color(0.75, 0.62, 0.25), "size": 24,
		"base": {"hp": 32, "str": 9, "int": 2, "def": 3, "mdef": 3, "agi": 9, "dex": 9},
		"exp": 20, "gold": [6, 14], "floors": [0, 0], "weak": ["ice"], "resist": [],
		"drops": [{"item": "escama_de_serpente", "chance": 0.5}, {"item": "antidoto", "chance": 0.1}],
		"ai": {"weights": [["attack", 40], ["e_poison_bite", 60]]}, "attack_name": "Bote", "behavior": "chase",
	},
	"sapo": {
		"name": "Sapo do Brejo", "sprite": "toad", "color": Color(0.35, 0.5, 0.25), "size": 24,
		"base": {"hp": 44, "str": 9, "int": 4, "def": 4, "mdef": 4, "agi": 4, "dex": 5},
		"exp": 22, "gold": [6, 14], "floors": [0, 0], "weak": ["fire"], "resist": ["ice"],
		"drops": [{"item": "pele_de_sapo", "chance": 0.55}, {"item": "antidoto", "chance": 0.1}],
		"ai": {"weights": [["attack", 40], ["e_tongue", 60]]}, "attack_name": "Salto", "behavior": "wander",
	},
	"lodo": {
		"name": "Lodo Vivo", "sprite": "slime", "color": Color(0.38, 0.32, 0.18), "size": 24,
		"base": {"hp": 46, "str": 9, "int": 5, "def": 4, "mdef": 4, "agi": 3, "dex": 4},
		"exp": 20, "gold": [5, 12], "floors": [0, 0], "weak": ["fire"], "resist": ["dark"],
		"drops": [{"item": "gosma", "chance": 0.6}, {"item": "cogumelo_azul", "chance": 0.1}],
		"ai": {"weights": [["attack", 50], ["e_acid_spit", 50]]}, "attack_name": "Investida", "behavior": "slow",
	},
	"lobo_gelido": {
		"name": "Lobo Glacial", "sprite": "wolf", "color": Color(0.8, 0.9, 1.0), "size": 24,
		"base": {"hp": 38, "str": 10, "int": 2, "def": 4, "mdef": 3, "agi": 9, "dex": 7},
		"exp": 22, "gold": [7, 14], "floors": [0, 0], "weak": ["fire"], "resist": ["ice"],
		"drops": [{"item": "pelo_gelado", "chance": 0.5}, {"item": "presa_de_lobo", "chance": 0.3}],
		"ai": {"weights": [["attack", 65], ["e_howl", 35]]}, "attack_name": "Mordida Gélida", "behavior": "chase",
	},
	"golem_gelo": {
		"name": "Golem de Gelo", "sprite": "golem", "color": Color(0.6, 0.8, 0.95), "size": 24,
		"base": {"hp": 72, "str": 12, "int": 1, "def": 11, "mdef": 4, "agi": 2, "dex": 3},
		"exp": 34, "gold": [12, 24], "floors": [0, 0], "weak": ["fire"], "resist": ["ice"],
		"drops": [{"item": "pedra_runica", "chance": 0.4}, {"item": "pelo_gelado", "chance": 0.2}],
		"ai": {"weights": [["attack", 55], ["e_ice_smash", 45]]}, "attack_name": "Soco", "behavior": "slow",
	},
	"yeti": {
		"name": "Yeti", "sprite": "yeti", "color": Color(0.93, 0.96, 1.0), "size": 24,
		"base": {"hp": 66, "str": 13, "int": 3, "def": 7, "mdef": 4, "agi": 5, "dex": 5},
		"exp": 40, "gold": [14, 26], "floors": [0, 0], "weak": ["fire"], "resist": ["ice"],
		"drops": [{"item": "pelo_gelado", "chance": 0.6}, {"item": "pocao_grande", "chance": 0.05}],
		"ai": {"weights": [["attack", 40], ["e_ice_smash", 40], ["e_roar", 20]]}, "attack_name": "Garras", "behavior": "wander",
	},
	"diabrete": {
		"name": "Diabrete", "sprite": "imp", "color": Color(0.75, 0.2, 0.2), "size": 24,
		"base": {"hp": 44, "str": 11, "int": 9, "def": 5, "mdef": 6, "agi": 9, "dex": 8},
		"exp": 34, "gold": [12, 24], "floors": [0, 0], "weak": ["holy", "ice"], "resist": ["fire", "dark"],
		"drops": [{"item": "chifre_de_diabrete", "chance": 0.5}, {"item": "eter", "chance": 0.08}],
		"ai": {"weights": [["attack", 40], ["e_wisp_flame", 60]]}, "attack_name": "Garra", "behavior": "chase",
	},
	"cao_infernal": {
		"name": "Cão Infernal", "sprite": "hellhound", "color": Color(0.25, 0.12, 0.12), "size": 24,
		"base": {"hp": 62, "str": 14, "int": 4, "def": 6, "mdef": 5, "agi": 9, "dex": 8},
		"exp": 44, "gold": [16, 30], "floors": [0, 0], "weak": ["ice", "holy"], "resist": ["fire", "dark"],
		"drops": [{"item": "brasa_infernal", "chance": 0.5}, {"item": "pocao_grande", "chance": 0.05}],
		"ai": {"weights": [["attack", 45], ["e_fire_bite", 55]]}, "attack_name": "Mordida", "behavior": "chase",
	},

	# ---------- minions (invocados por chefes; nao aparecem no mapa) ----------
	"slime_mini": {
		"name": "Slimezinho", "sprite": "slime", "color": Color(0.5, 0.9, 0.5), "size": 16, "minion": true,
		"base": {"hp": 12, "str": 5, "int": 2, "def": 1, "mdef": 1, "agi": 4, "dex": 3},
		"exp": 2, "gold": [0, 1], "floors": [0, 0], "weak": ["fire"], "resist": [], "drops": [],
		"ai": {"weights": [["attack", 100]]}, "attack_name": "Investida",
	},
	"broto": {
		"name": "Broto Vivo", "sprite": "sapling", "color": Color(0.35, 0.65, 0.25), "size": 20, "minion": true,
		"base": {"hp": 26, "str": 8, "int": 2, "def": 4, "mdef": 3, "agi": 5, "dex": 5},
		"exp": 6, "gold": [1, 3], "floors": [0, 0], "weak": ["fire"], "resist": ["ice"], "drops": [],
		"ai": {"weights": [["attack", 70], ["e_root_whip", 30]]}, "attack_name": "Arranhão",
	},

	"escorpiao_mini": {
		"name": "Escorpiãozinho", "sprite": "scorpion", "color": Color(0.9, 0.7, 0.3), "size": 16, "minion": true,
		"base": {"hp": 16, "str": 7, "int": 2, "def": 2, "mdef": 1, "agi": 6, "dex": 6},
		"exp": 3, "gold": [0, 1], "floors": [0, 0], "weak": ["ice"], "resist": [], "drops": [],
		"ai": {"weights": [["attack", 60], ["e_sting", 40]]}, "attack_name": "Pinça",
	},
	"sapo_mini": {
		"name": "Girino Gigante", "sprite": "toad", "color": Color(0.4, 0.58, 0.28), "size": 16, "minion": true,
		"base": {"hp": 18, "str": 7, "int": 2, "def": 2, "mdef": 2, "agi": 5, "dex": 5},
		"exp": 3, "gold": [0, 1], "floors": [0, 0], "weak": ["fire"], "resist": [], "drops": [],
		"ai": {"weights": [["attack", 70], ["e_tongue", 30]]}, "attack_name": "Salto",
	},
	"diabrete_mini": {
		"name": "Chama Maligna", "sprite": "imp", "color": Color(0.85, 0.3, 0.2), "size": 20, "minion": true,
		"base": {"hp": 30, "str": 10, "int": 8, "def": 4, "mdef": 5, "agi": 8, "dex": 7},
		"exp": 8, "gold": [1, 3], "floors": [0, 0], "weak": ["holy", "ice"], "resist": ["fire"], "drops": [],
		"ai": {"weights": [["attack", 40], ["e_wisp_flame", 60]]}, "attack_name": "Garra",
	},

	# ---------- CHEFES ----------
	"boss_slime_king": {
		"name": "Rei Slime", "sprite": "slime_king", "color": Color(0.3, 0.75, 0.55), "size": 48, "boss": true, "level": 4, "map_scale": 0.6,
		"base": {"hp": 150, "str": 8, "int": 5, "def": 4, "mdef": 3, "agi": 4, "dex": 5},
		"exp": 130, "gold": [70, 90], "weak": ["fire"], "resist": ["ice"], "drops": [{"item": "nucleo_de_slime", "chance": 1.0}, {"item": "pocao", "chance": 1.0}],
		"loot": [{"class_gear": "weapon", "rarity": "rare"}],
		"attack_name": "Investida",
		"phases": [
			{"hp_below": 1.0, "pattern": ["e_slam", "attack", "e_acid_wave"]},
			{"hp_below": 0.5, "pattern": ["e_slam", "e_acid_wave", "e_gel_burst", "attack"],
				"on_enter": {"msg": "O Rei Slime se parte e se regenera!", "heal_pct": 0.2, "summon": ["slime_mini", "slime_mini"]}},
		],
	},
	"boss_spider_queen": {
		"name": "Matriarca Aranha", "sprite": "spider_queen", "color": Color(0.5, 0.15, 0.5), "size": 48, "boss": true, "level": 6, "map_scale": 0.6,
		"base": {"hp": 190, "str": 11, "int": 4, "def": 6, "mdef": 4, "agi": 11, "dex": 9},
		"exp": 280, "gold": [130, 170], "weak": ["fire"], "resist": ["dark"], "drops": [{"item": "seda_de_aranha", "chance": 1.0}, {"item": "pocao_grande", "chance": 1.0}],
		"loot": [{"class_gear": "armor", "rarity": "rare"}],
		"attack_name": "Garras",
		"phases": [
			{"hp_below": 1.0, "pattern": ["e_venom_fang", "e_web", "e_fang_flurry", "e_venom_fang", "attack"]},
			{"hp_below": 0.35, "pattern": ["e_fang_flurry", "e_venom_fang", "e_fang_flurry"],
				"on_enter": {"msg": "A Matriarca enlouquece de fúria!", "status": [{"status": "atkup", "turns": 99, "value": 0.35}]}},
		],
	},
	"boss_ghost_knight": {
		"name": "Cavaleiro Espectral", "sprite": "ghost_knight", "color": Color(0.5, 0.5, 0.85), "size": 48, "boss": true, "level": 8, "map_scale": 0.6,
		"base": {"hp": 230, "str": 15, "int": 8, "def": 9, "mdef": 7, "agi": 8, "dex": 8},
		"exp": 560, "gold": [220, 280], "weak": ["holy", "fire"], "resist": ["dark", "ice"], "drops": [{"item": "osso_antigo", "chance": 1.0}, {"item": "elixir", "chance": 1.0}],
		"loot": [{"class_gear": "weapon", "rarity": "epic"}],
		"unlock": {"class": "sombra_ancestral"},
		"attack_name": "Lâmina Espectral",
		"phases": [
			{"hp_below": 1.0, "pattern": ["e_spectral_slash", "e_prepare", "e_spectral_slash", "e_dark_wave"]},
			{"hp_below": 0.4, "pattern": ["e_spectral_slash", "e_prepare", "e_dark_wave"],
				"on_enter": {"msg": "O Cavaleiro ergue sua lâmina — seus olhos brilham em vermelho!", "status": [{"status": "atkup", "turns": 99, "value": 0.25}]}},
		],
	},
	"boss_elder_treant": {
		"name": "Guardião Ancião", "sprite": "treant", "color": Color(0.4, 0.55, 0.25), "size": 48, "boss": true, "level": 10, "map_scale": 0.65,
		"base": {"hp": 270, "str": 13, "int": 9, "def": 9, "mdef": 6, "agi": 4, "dex": 7},
		"exp": 1200, "gold": [500, 600], "weak": ["fire"], "resist": ["ice"], "drops": [{"item": "elixir", "chance": 1.0}, {"item": "pocao_grande", "chance": 1.0}],
		"loot": [{"class_gear": "weapon", "rarity": "legendary"}, {"class_gear": "armor", "rarity": "epic"}],
		"unlock": {"class": "cavaleiro_da_aurora"},
		"attack_name": "Galhada",
		"phases": [
			{"hp_below": 1.0, "pattern": ["e_root_whip", "e_thorn_rain", "attack", "e_sap_heal"]},
			{"hp_below": 0.66, "pattern": ["e_root_whip", "e_vine_crush", "e_spore_cloud", "e_thorn_rain"],
				"on_enter": {"msg": "O Guardião chama seus brotos em auxílio!", "summon": ["broto", "broto"]}},
			{"hp_below": 0.33, "pattern": ["e_vine_crush", "e_nature_wrath", "e_root_whip", "e_vine_crush"],
				"on_enter": {"msg": "A floresta inteira estremece de fúria!", "status": [{"status": "atkup", "turns": 99, "value": 0.35}]}},
		],
	},
	# ---------- chefes regionais (ilha) ----------
	"boss_scorpion_king": {
		"name": "Rei Escorpião", "sprite": "scorpion_king", "color": Color(0.85, 0.6, 0.2), "size": 48, "boss": true, "level": 7, "map_scale": 0.6,
		"base": {"hp": 230, "str": 13, "int": 5, "def": 8, "mdef": 4, "agi": 9, "dex": 9},
		"exp": 420, "gold": [180, 240], "weak": ["ice"], "resist": ["fire"], "drops": [{"item": "coroa_das_dunas", "chance": 1.0}, {"item": "pocao_grande", "chance": 1.0}],
		"loot": [{"class_gear": "weapon", "rarity": "epic"}],
		"attack_name": "Pinça",
		"phases": [
			{"hp_below": 1.0, "pattern": ["e_sting", "e_pincer", "e_sand_blast", "attack"]},
			{"hp_below": 0.5, "pattern": ["e_pincer", "e_sting", "e_sand_blast", "e_sting"],
				"on_enter": {"msg": "O Rei Escorpião convoca sua ninhada!", "summon": ["escorpiao_mini", "escorpiao_mini"]}},
		],
	},
	"boss_toad_king": {
		"name": "Senhor do Brejo", "sprite": "toad_king", "color": Color(0.3, 0.5, 0.22), "size": 48, "boss": true, "level": 8, "map_scale": 0.6,
		"base": {"hp": 260, "str": 12, "int": 9, "def": 8, "mdef": 7, "agi": 5, "dex": 6},
		"exp": 520, "gold": [220, 280], "weak": ["fire"], "resist": ["ice", "dark"], "drops": [{"item": "coroa_do_brejo", "chance": 1.0}, {"item": "elixir", "chance": 1.0}],
		"loot": [{"class_gear": "armor", "rarity": "epic"}],
		"attack_name": "Salto Esmagador",
		"phases": [
			{"hp_below": 1.0, "pattern": ["e_tongue", "e_toxic_bog", "attack", "e_croak"]},
			{"hp_below": 0.5, "pattern": ["e_toxic_bog", "e_tongue", "e_croak", "e_toxic_bog"],
				"on_enter": {"msg": "O Senhor do Brejo chama os girinos do pântano!", "summon": ["sapo_mini", "sapo_mini"], "heal_pct": 0.1}},
		],
	},
	"boss_yeti_king": {
		"name": "Yeti Ancestral", "sprite": "yeti_king", "color": Color(0.9, 0.95, 1.0), "size": 48, "boss": true, "level": 8, "map_scale": 0.65,
		"base": {"hp": 300, "str": 15, "int": 8, "def": 9, "mdef": 6, "agi": 6, "dex": 6},
		"exp": 560, "gold": [240, 300], "weak": ["fire"], "resist": ["ice"], "drops": [{"item": "presa_do_yeti", "chance": 1.0}, {"item": "elixir", "chance": 1.0}],
		"loot": [{"class_gear": "weapon", "rarity": "epic"}],
		"attack_name": "Garras Gélidas",
		"phases": [
			{"hp_below": 1.0, "pattern": ["e_ice_smash", "attack", "e_blizzard", "e_roar"]},
			{"hp_below": 0.4, "pattern": ["e_ice_smash", "e_blizzard", "e_ice_smash", "e_blizzard"],
				"on_enter": {"msg": "O Yeti Ancestral desperta a fúria da montanha!", "status": [{"status": "atkup", "turns": 99, "value": 0.3}]}},
		],
	},
	"boss_demon_lord": {
		"name": "Azrakhel, Lorde Demoníaco", "sprite": "demon_lord", "color": Color(0.55, 0.1, 0.18), "size": 48, "boss": true, "level": 12, "map_scale": 0.7,
		"base": {"hp": 520, "str": 18, "int": 14, "def": 12, "mdef": 10, "agi": 8, "dex": 9},
		"exp": 2500, "gold": [900, 1100], "weak": ["holy", "ice"], "resist": ["fire", "dark"], "drops": [{"item": "coracao_demoniaco", "chance": 1.0}, {"item": "elixir", "chance": 1.0}],
		"loot": [{"class_gear": "weapon", "rarity": "legendary"}, {"class_gear": "armor", "rarity": "legendary"}],
		"attack_name": "Garra Demoníaca",
		"phases": [
			{"hp_below": 1.0, "pattern": ["e_dark_blade", "e_curse", "e_hellfire", "attack"]},
			{"hp_below": 0.66, "pattern": ["e_dark_blade", "e_prepare", "e_hellfire", "e_dark_blade"],
				"on_enter": {"msg": "Azrakhel invoca suas chamas malignas!", "summon": ["diabrete_mini", "diabrete_mini"]}},
			{"hp_below": 0.33, "pattern": ["e_hellfire", "e_dark_blade", "e_curse", "e_devastating_charge"],
				"on_enter": {"msg": "O castelo inteiro treme: Azrakhel liberta todo o seu poder!", "status": [{"status": "atkup", "turns": 99, "value": 0.35}]}},
		],
	},
}

# bosses regionais (id -> onde aparecem na ilha); o chefe final e o Lorde Demoníaco
const OVERWORLD_BOSSES := ["boss_scorpion_king", "boss_toad_king", "boss_yeti_king", "boss_demon_lord"]

# regiao da ilha -> inimigos comuns que aparecem nela
const REGION_POOLS := {
	"campos": ["slime", "goblin"], "costa": ["slime", "morcego"],
	"sussurrante": ["slime", "goblin", "cogumelo", "lobo"], "verdejante": ["slime", "goblin", "cogumelo"],
	"vale": ["goblin", "cogumelo", "lobo"], "pinhal": ["lobo", "goblin", "aranha"],
	"mata_escura": ["aranha", "esqueleto", "morcego", "lobo"], "brumas": ["fogo_fatuo", "esqueleto", "cogumelo"],
	"nebuloso": ["fogo_fatuo", "cogumelo", "aranha"], "gelida": ["lobo_gelido", "golem_gelo", "fogo_fatuo"],
	"geladas": ["lobo_gelido", "golem_gelo", "yeti"], "carmesim": ["diabrete", "cao_infernal", "esqueleto"],
	"sombrias": ["diabrete", "cao_infernal", "golem"], "castelo": ["diabrete", "cao_infernal"],
	"pantano": ["sapo", "lodo", "serpente", "aranha"], "dunas": ["escorpiao", "serpente", "golem"],
	"serra": ["golem", "lobo", "esqueleto"],
}

static func pool_for_region(region_id: String) -> Array:
	return REGION_POOLS.get(region_id, [])

# andar -> id do chefe
const BOSS_BY_FLOOR := {5: "boss_slime_king", 10: "boss_spider_queen", 15: "boss_ghost_knight", 20: "boss_elder_treant"}

static func get_enemy(id: String) -> Dictionary:
	return ENEMIES.get(id, {})

static func exists(id: String) -> bool:
	return ENEMIES.has(id)

static func is_boss(id: String) -> bool:
	return ENEMIES.get(id, {}).get("boss", false)

## Inimigos comuns que podem aparecer num andar.
static func pool_for_floor(floor_n: int) -> Array:
	var out: Array = []
	for id in ENEMIES:
		var e: Dictionary = ENEMIES[id]
		if e.get("minion", false) or e.get("boss", false):
			continue
		var f: Array = e["floors"]
		if floor_n >= int(f[0]) and floor_n <= int(f[1]):
			out.append(id)
	return out

static func common_ids() -> Array:
	var out: Array = []
	for id in ENEMIES:
		var e: Dictionary = ENEMIES[id]
		if not e.get("minion", false) and not e.get("boss", false):
			out.append(id)
	return out

static func boss_ids() -> Array:
	return BOSS_BY_FLOOR.values()
