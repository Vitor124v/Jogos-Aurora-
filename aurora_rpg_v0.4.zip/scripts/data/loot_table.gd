class_name LootTable
extends RefCounted
## Sorteio de loot de baus e monstros. Probabilidades em Balance.CHEST_RARITY.

static func rarity_weights(floor_n: int, cap: String = "legendary") -> Dictionary:
	var tier := Balance.floor_tier(floor_n)
	var out := {}
	var cap_i := Balance.RARITY_ORDER.find(cap)
	for r in Balance.RARITY_ORDER:
		if Balance.RARITY_ORDER.find(r) > cap_i:
			continue
		var cfg: Dictionary = Balance.CHEST_RARITY[r]
		if floor_n < int(cfg["min_floor"]):
			continue
		var w := float(cfg["weights"][tier])
		if w > 0.0:
			out[r] = w
	return out

static func roll_rarity(rng: RandomNumberGenerator, floor_n: int, cap: String = "legendary") -> String:
	var w := rarity_weights(floor_n, cap)
	var total := 0.0
	for k in w:
		total += float(w[k])
	if total <= 0.0:
		return "common"
	var roll := rng.randf() * total
	for k in w:
		roll -= float(w[k])
		if roll <= 0.0:
			return k
	return "common"

## Sorteia um equipamento utilizavel pela classe (ou acessorio).
static func roll_gear(rng: RandomNumberGenerator, floor_n: int, class_id: String, cap: String = "legendary") -> String:
	var rarity := roll_rarity(rng, floor_n, cap)
	var pool := ItemDB.gear_pool(rarity, class_id)
	while pool.is_empty() and rarity != "common":
		rarity = Balance.RARITY_ORDER[maxi(0, Balance.RARITY_ORDER.find(rarity) - 1)]
		pool = ItemDB.gear_pool(rarity, class_id)
	if pool.is_empty():
		return ""
	return String(pool[rng.randi() % pool.size()])

## Conteudo de um bau: {gold, items{}}
static func roll_chest(rng: RandomNumberGenerator, floor_n: int, class_id: String) -> Dictionary:
	var tier := Balance.floor_tier(floor_n)
	var items := {}
	var gold := rng.randi_range(15 + floor_n * 6, 35 + floor_n * 14)
	var potions := ["pocao_pequena", "pocao", "pocao", "pocao_grande"]
	items[potions[tier]] = rng.randi_range(1, 2)
	if rng.randf() < 0.5:
		items["eter" if tier < 2 else "eter_grande"] = 1
	if rng.randf() < 0.55:
		var g := roll_gear(rng, floor_n, class_id)
		if g != "":
			items[g] = int(items.get(g, 0)) + 1
	return {"gold": gold, "items": items}
