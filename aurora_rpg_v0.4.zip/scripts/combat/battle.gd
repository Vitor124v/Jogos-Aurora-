class_name Battle
extends RefCounted
## Motor de combate por turnos, independente do mapa e da interface.
## A UI consome "events" (Dictionaries) retornados por cada acao.

var allies: Array = []        # Combatant
var enemies: Array = []       # Combatant
var rng := RandomNumberGenerator.new()
var inventory: Dictionary = {}   # referencia ao inventario do jogador (id -> qtd)
var context: Dictionary = {}     # {floor, class_id, can_flee}
var round_number: int = 0
var order: Array = []
var order_index: int = 0
var finished: bool = false
var result: String = ""          # victory | defeat | fled
var rewards: Dictionary = {}
var rewards_computed: bool = false
var hp_override: int = 0
var claimed: bool = false          # recompensas ja aplicadas ao jogador
var can_flee: bool = true
var acting: Combatant = null
var _uid_counter: int = 0
var log_lines: Array = []

# ---------------------------------------------------------------- criacao
func setup(p_allies: Array, p_enemies: Array, p_context: Dictionary = {}, seed_value: int = -1) -> void:
	if seed_value >= 0:
		rng.seed = seed_value
	else:
		rng.randomize()
	context = p_context
	allies = p_allies
	enemies = p_enemies
	for c in allies + enemies:
		_uid_counter += 1
		c.uid = _uid_counter
	can_flee = bool(context.get("can_flee", true))
	for e in enemies:
		if e.is_boss:
			can_flee = false
	round_number = 0
	finished = false
	result = ""

static func make_hero(class_id: String, level: int, stats: Dictionary, name: String, hp: int, mp: int) -> Combatant:
	var c := Combatant.new()
	var cd := HeroDB.get_class_data(class_id)
	c.is_player = true
	c.class_id = class_id
	c.display_name = name
	c.level = level
	c.stats = stats.duplicate()
	c.max_hp = int(stats["max_hp"])
	c.max_mp = int(stats["max_mp"])
	c.hp = clampi(hp, 1, c.max_hp)
	c.mp = clampi(mp, 0, c.max_mp)
	c.basic = cd["basic"].duplicate(true)
	c.skills = HeroDB.skills_for(class_id, level)
	c.sprite_id = class_id
	c.color = cd["colors"]["primary"]
	return c

static func make_enemy(enemy_id: String, level: int = -1) -> Combatant:
	var t: Dictionary = EnemyDB.get_enemy(enemy_id)
	var c := Combatant.new()
	c.template = t
	c.template_id = enemy_id
	c.display_name = t["name"]
	c.is_boss = t.get("boss", false)
	c.is_minion = t.get("minion", false)
	c.level = int(t["level"]) if t.has("level") else maxi(1, level)
	c.stats = Formulas.enemy_stats(t, c.level)
	c.max_hp = int(c.stats["max_hp"])
	c.max_mp = int(c.stats["max_mp"])
	c.hp = c.max_hp
	c.mp = c.max_mp
	c.weak = t.get("weak", [])
	c.resist = t.get("resist", [])
	c.immune = t.get("immune", [])
	c.sprite_id = t["sprite"]
	c.color = t["color"]
	c.size = int(t.get("size", 24))
	return c

func all_living() -> Array:
	var out: Array = []
	for c in allies + enemies:
		if c.alive():
			out.append(c)
	return out

func living(list: Array) -> Array:
	var out: Array = []
	for c in list:
		if c.alive():
			out.append(c)
	return out

func side_of(c: Combatant) -> Array:
	return allies if c in allies else enemies

func foes_of(c: Combatant) -> Array:
	return enemies if c in allies else allies

# ---------------------------------------------------------------- turnos
func start_round() -> void:
	round_number += 1
	order.clear()
	var scored: Array = []
	for c in all_living():
		scored.append({"c": c, "i": Formulas.initiative(c.stat("agi"), rng)})
	scored.sort_custom(func(a, b): return a["i"] > b["i"])
	for s in scored:
		order.append(s["c"])
	order_index = 0

## Proximo combatente vivo da rodada, ou null se a rodada acabou.
func next_actor() -> Combatant:
	while order_index < order.size():
		var c: Combatant = order[order_index]
		order_index += 1
		if c.alive():
			return c
	return null

## Inicio do turno: efeitos de status. Retorna {events, skip}.
func begin_turn(actor: Combatant) -> Dictionary:
	acting = actor
	var ev: Array = []
	var skip := false
	actor.defending = false
	actor.turn_count += 1
	var p := actor.get_status("poison")
	if not p.is_empty():
		var dmg := maxi(1, int(round(float(p["value"]))))
		var r := actor.take_damage(dmg)
		ev.append({"t": "msg", "text": "%s sofre %d de dano do veneno!" % [actor.display_name, dmg]})
		ev.append({"t": "hit", "target": actor, "amount": int(r["dealt"]), "absorbed": int(r["absorbed"]), "crit": false, "element": "poison", "hp_after": actor.hp, "dot": true})
		if not actor.alive():
			ev.append({"t": "down", "target": actor})
	var rg := actor.get_status("regen")
	if not rg.is_empty() and actor.alive():
		var h := actor.heal_hp(maxi(1, int(round(float(actor.max_hp) * float(rg["value"])))))
		ev.append({"t": "heal", "target": actor, "amount": h, "what": "hp", "hp_after": actor.hp, "mp_after": actor.mp})
	if actor.alive() and actor.has_status("stun"):
		skip = true
		ev.append({"t": "msg", "text": "%s está atordoado e perde o turno!" % actor.display_name})
	if actor.alive() and not actor.is_player:
		ev.append_array(_update_phase(actor))
	return {"events": ev, "skip": skip or not actor.alive()}

## Fim do turno: reduz duracao dos status. Verifica fim de batalha.
func end_turn(actor: Combatant) -> Array:
	var ev: Array = []
	for i in range(actor.statuses.size() - 1, -1, -1):
		var s: Dictionary = actor.statuses[i]
		if s.get("fresh", false):
			s["fresh"] = false
			continue
		s["turns"] = int(s["turns"]) - 1
		if int(s["turns"]) <= 0:
			var sid: String = s["id"]
			actor.statuses.remove_at(i)
			ev.append({"t": "status_end", "target": actor, "status": sid})
	acting = null
	check_end()
	return ev

func check_end() -> void:
	if finished:
		return
	if living(enemies).is_empty():
		finished = true
		result = "victory"
	elif living(allies).is_empty():
		finished = true
		result = "defeat"

# ---------------------------------------------------------------- acoes do jogador
func skill_error(actor: Combatant, skill_id: String) -> String:
	if not (skill_id in actor.skills):
		return "Habilidade desconhecida."
	var sk := SkillDB.get_skill(skill_id)
	if sk.is_empty():
		return "Habilidade inválida."
	if actor.mp < int(sk.get("mp", 0)):
		return "MP insuficiente!"
	return ""

func act_attack(actor: Combatant, target: Combatant) -> Dictionary:
	if finished or not actor.alive():
		return {"ok": false, "error": "Ação inválida.", "events": []}
	var tgt := _valid_foe(actor, target)
	if tgt == null:
		return {"ok": false, "error": "Alvo inválido.", "events": []}
	var b: Dictionary = actor.basic
	var skill := {"id": "_basic", "name": b.get("name", "Ataque"), "kind": b.get("kind", "phys"), "target": "foe", "power": b.get("power", 1.0),
		"hits": b.get("hits", 1), "weights": b.get("weights", {"str": 1.5}), "fx": b.get("fx", "slash"), "accuracy": 1.0,
		"element": b.get("element", "physical"), "mp": 0, "msg": b.get("msg", "")}
	var ev := _execute(actor, skill, tgt)
	check_end()
	return {"ok": true, "error": "", "events": ev}

func act_skill(actor: Combatant, skill_id: String, target: Combatant) -> Dictionary:
	if finished or not actor.alive():
		return {"ok": false, "error": "Ação inválida.", "events": []}
	var err := skill_error(actor, skill_id)
	if err != "":
		return {"ok": false, "error": err, "events": []}
	var sk := SkillDB.get_skill(skill_id)
	var tt: String = sk.get("target", "foe")
	var tgt: Combatant = target
	if tt == "foe":
		tgt = _valid_foe(actor, target)
		if tgt == null:
			return {"ok": false, "error": "Alvo inválido.", "events": []}
	elif tt == "ally":
		if target == null or not target.alive() or not (target in side_of(actor)):
			tgt = actor
	actor.mp -= int(sk.get("mp", 0))
	var ev := _execute(actor, sk, tgt)
	check_end()
	return {"ok": true, "error": "", "events": ev}

func act_defend(actor: Combatant) -> Dictionary:
	if finished or not actor.alive():
		return {"ok": false, "error": "Ação inválida.", "events": []}
	actor.defending = true
	var ev: Array = [{"t": "msg", "text": "%s se prepara para defender!" % actor.display_name}, {"t": "anim", "fx": "buff", "src": actor, "dst": [actor]}]
	return {"ok": true, "error": "", "events": ev}

func act_flee(actor: Combatant) -> Dictionary:
	if finished or not actor.alive():
		return {"ok": false, "error": "Ação inválida.", "events": []}
	if not can_flee:
		return {"ok": false, "error": "Não é possível fugir desta batalha!", "events": []}
	var avg := 0.0
	var foes := living(enemies)
	for e in foes:
		avg += e.stat("agi")
	avg = avg / float(maxi(1, foes.size()))
	var chance := Formulas.flee_chance(actor.stat("agi"), avg)
	var ev: Array = []
	if rng.randf() < chance:
		ev.append({"t": "msg", "text": "%s fugiu da batalha!" % actor.display_name})
		ev.append({"t": "flee"})
		finished = true
		result = "fled"
	else:
		ev.append({"t": "msg", "text": "%s tentou fugir, mas não conseguiu!" % actor.display_name})
	return {"ok": true, "error": "", "events": ev}

func act_item(actor: Combatant, item_id: String, target: Combatant) -> Dictionary:
	if finished or not actor.alive():
		return {"ok": false, "error": "Ação inválida.", "events": []}
	var it := ItemDB.get_item(item_id)
	if it.is_empty() or it.get("type", "") != "consumable":
		return {"ok": false, "error": "Item inválido.", "events": []}
	if it.get("field_only", false):
		return {"ok": false, "error": "Não pode ser usado em batalha.", "events": []}
	if int(inventory.get(item_id, 0)) <= 0:
		return {"ok": false, "error": "Você não tem este item.", "events": []}
	var use: Dictionary = it["use"]
	var ev: Array = []
	if use.has("damage"):
		var tgt := _valid_foe(actor, target)
		if tgt == null:
			return {"ok": false, "error": "Alvo inválido.", "events": []}
		ev.append({"t": "msg", "text": "%s usa %s!" % [actor.display_name, it["name"]]})
		ev.append({"t": "anim", "fx": "fire", "src": actor, "dst": [tgt]})
		var elem: String = use.get("element", "physical")
		var mult := Formulas.element_multiplier(elem, tgt.weak, tgt.resist, tgt.immune)
		var dmg := int(round(float(use["damage"]) * mult))
		var r := tgt.take_damage(dmg)
		ev.append({"t": "hit", "target": tgt, "amount": int(r["dealt"]), "absorbed": int(r["absorbed"]), "crit": false, "element": elem, "hp_after": tgt.hp, "weak": mult > 1.0, "resisted": mult < 1.0 and mult > 0.0})
		if not tgt.alive():
			ev.append({"t": "down", "target": tgt})
	else:
		var tgt: Combatant = actor
		if target != null and target.alive() and target in side_of(actor):
			tgt = target
		ev.append({"t": "msg", "text": "%s usa %s!" % [actor.display_name, it["name"]]})
		ev.append({"t": "anim", "fx": "heal", "src": actor, "dst": [tgt]})
		var healed_hp := 0
		var healed_mp := 0
		if use.has("heal_hp"):
			healed_hp = tgt.heal_hp(int(use["heal_hp"]))
		if use.has("heal_mp"):
			healed_mp = tgt.heal_mp(int(use["heal_mp"]))
		if use.has("cure"):
			for st in use["cure"]:
				if tgt.has_status(st):
					tgt.remove_status(st)
					ev.append({"t": "status_end", "target": tgt, "status": st, "cured": true})
		ev.append({"t": "heal", "target": tgt, "amount": healed_hp, "what": "hp", "hp_after": tgt.hp, "mp_after": tgt.mp, "mp_amount": healed_mp})
	inventory[item_id] = int(inventory[item_id]) - 1
	if int(inventory[item_id]) <= 0:
		inventory.erase(item_id)
	check_end()
	return {"ok": true, "error": "", "events": ev}

func _valid_foe(actor: Combatant, target: Combatant) -> Combatant:
	if target != null and target.alive() and target in foes_of(actor):
		return target
	return null

# ---------------------------------------------------------------- execucao
func _targets_for(user: Combatant, skill: Dictionary, chosen: Combatant) -> Array:
	match String(skill.get("target", "foe")):
		"self":
			return [user]
		"ally":
			return [chosen if chosen != null else user]
		"all_foes":
			return living(foes_of(user))
		"all_allies":
			return living(side_of(user))
		_:
			if chosen != null and chosen.alive():
				return [chosen]
			var f := living(foes_of(user))
			return [f[0]] if f.size() > 0 else []

func _execute(user: Combatant, skill: Dictionary, chosen: Combatant) -> Array:
	var ev: Array = []
	var targets := _targets_for(user, skill, chosen)
	if targets.is_empty():
		return ev
	var main_t: Combatant = targets[0]
	var kind: String = skill.get("kind", "phys")
	var custom: String = skill.get("msg", "")
	if custom != "":
		ev.append({"t": "msg", "text": custom.format({"u": user.display_name, "t": main_t.display_name})})
	elif skill["id"] == "_basic":
		ev.append({"t": "msg", "text": "%s usa %s!" % [user.display_name, skill["name"]] if user.is_player else "%s ataca %s!" % [user.display_name, main_t.display_name]})
	else:
		ev.append({"t": "msg", "text": "%s usa %s!" % [user.display_name, skill["name"]]})
	# preparar carga (chefes)
	if skill.has("charge"):
		user.charging = String(skill["charge"])
		ev.append({"t": "anim", "fx": skill.get("fx", "dark"), "src": user, "dst": [user]})
		ev.append({"t": "charge", "target": user})
		return ev
	ev.append({"t": "anim", "fx": skill.get("fx", "slash"), "src": user, "dst": targets, "kind": kind})
	match kind:
		"phys", "magic", "holy":
			for t in targets:
				ev.append_array(_damage_target(user, t, skill))
		"heal":
			for t in targets:
				var amount := 0
				if skill.has("pct"):
					amount = int(round(float(t.max_hp) * float(skill["pct"])))
				else:
					amount = Formulas.heal_amount(user.stats, skill.get("weights", {"faith": 2.0}), user.level, float(skill.get("power", 1.0)))
				var h: int = t.heal_hp(amount)
				ev.append({"t": "heal", "target": t, "amount": h, "what": "hp", "hp_after": t.hp, "mp_after": t.mp})
		"buff", "debuff":
			for t in targets:
				if kind == "debuff":
					var acc := float(skill.get("accuracy", 1.0))
					var hc := Formulas.hit_chance(user.stat("dex"), t.stat("agi") * 0.4, acc, t.evasion())
					if rng.randf() > hc:
						ev.append({"t": "miss", "target": t})
						continue
				ev.append_array(_apply_effects(user, t, skill))
	return ev

func _damage_target(user: Combatant, t: Combatant, skill: Dictionary) -> Array:
	var ev: Array = []
	var kind: String = skill.get("kind", "phys")
	var hits := int(skill.get("hits", 1))
	var any_hit := false
	for h in range(hits):
		if not t.alive():
			break
		var acc := float(skill.get("accuracy", 1.0))
		var agi_ref: float = t.stat("agi") if kind == "phys" else t.stat("agi") * 0.4
		var hc := Formulas.hit_chance(user.stat("dex"), agi_ref, acc, t.evasion())
		if rng.randf() > hc:
			ev.append({"t": "miss", "target": t})
			continue
		any_hit = true
		var weights: Dictionary = skill.get("weights", {})
		if weights.is_empty():
			weights = {"str": 1.5} if kind == "phys" else ({"int": 1.8} if kind == "magic" else {"faith": 1.6, "str": 0.6})
		var raw := Formulas.raw_attack(user.stats, weights, user.level) * float(skill.get("power", 1.0)) * user.attack_mult()
		var elem: String = skill.get("element", "physical")
		var em := Formulas.element_multiplier(elem, t.weak, t.resist, t.immune)
		var defense: float = t.stat("def") if kind == "phys" else t.stat("mdef")
		var dmg := Formulas.mitigate(raw, defense) * em
		dmg *= 1.0 + rng.randf_range(-Balance.DAMAGE_VARIANCE, Balance.DAMAGE_VARIANCE)
		var crit := false
		var focus := user.has_status("focus")
		var cc := Formulas.crit_chance(user.stat("dex"), float(user.stats.get("crit_bonus", 0.0)) + float(skill.get("crit_bonus", 0.0)))
		if (focus and kind == "phys") or rng.randf() < cc:
			crit = true
			dmg *= float(user.stats.get("crit_mult", Balance.CRIT_MULT))
			if focus:
				user.remove_status("focus")
		if t.has_status("guard"):
			dmg *= 1.0 - t.status_value("guard")
		if t.defending:
			dmg *= Balance.GUARD_MULT
		var final_dmg := 0 if em <= 0.0 else maxi(1, int(round(dmg)))
		var r := t.take_damage(final_dmg)
		ev.append({"t": "hit", "target": t, "amount": int(r["dealt"]), "absorbed": int(r["absorbed"]), "crit": crit, "element": elem,
			"hp_after": t.hp, "weak": em > 1.0, "resisted": em < 1.0 and em > 0.0, "immune": em <= 0.0})
		if not t.alive():
			ev.append({"t": "down", "target": t})
			break
	if any_hit and t.alive():
		ev.append_array(_apply_effects(user, t, skill))
	return ev

func _apply_effects(user: Combatant, t: Combatant, skill: Dictionary) -> Array:
	var ev: Array = []
	for eff in skill.get("effects", []):
		var who: Combatant = user if eff.get("who", "target") == "self" else t
		if not who.alive():
			continue
		if rng.randf() > float(eff.get("chance", 1.0)):
			continue
		var value := float(eff.get("value", 0.0))
		if eff.has("scale_weights"):
			value = Formulas.raw_attack(user.stats, eff["scale_weights"], user.level) * float(eff.get("scale", 1.0)) + float(eff.get("base", 0))
		var sid: String = eff["status"]
		who.add_status(sid, int(eff.get("turns", 3)), value, who == acting)
		ev.append({"t": "status", "target": who, "status": sid, "value": value})
	return ev

# ---------------------------------------------------------------- IA de inimigos
func _update_phase(actor: Combatant) -> Array:
	var ev: Array = []
	var phases: Array = actor.template.get("phases", [])
	if phases.is_empty():
		return ev
	var ratio := actor.hp_ratio()
	var idx := 0
	for i in range(phases.size()):
		if ratio <= float(phases[i]["hp_below"]) + 0.0001:
			idx = i
	while actor.phase_index < idx:
		actor.phase_index += 1
		actor.pattern_i = 0
		var ph: Dictionary = phases[actor.phase_index]
		if ph.has("on_enter"):
			ev.append_array(_phase_enter(actor, ph["on_enter"]))
	return ev

func _phase_enter(actor: Combatant, oe: Dictionary) -> Array:
	var ev: Array = []
	if oe.has("msg"):
		ev.append({"t": "msg", "text": oe["msg"]})
	if oe.has("heal_pct"):
		var h := actor.heal_hp(int(round(float(actor.max_hp) * float(oe["heal_pct"]))))
		ev.append({"t": "anim", "fx": "heal", "src": actor, "dst": [actor]})
		ev.append({"t": "heal", "target": actor, "amount": h, "what": "hp", "hp_after": actor.hp, "mp_after": actor.mp})
	if oe.has("status"):
		for s in oe["status"]:
			actor.add_status(s["status"], int(s.get("turns", 3)), float(s.get("value", 0.0)), false)
			ev.append({"t": "status", "target": actor, "status": s["status"], "value": float(s.get("value", 0.0))})
	if oe.has("summon"):
		for sid in oe["summon"]:
			if enemies.size() >= 5:
				break
			var m := Battle.make_enemy(sid, maxi(1, actor.level - 2))
			_uid_counter += 1
			m.uid = _uid_counter
			enemies.append(m)
			ev.append({"t": "summon", "combatant": m})
	return ev

func enemy_choose(actor: Combatant) -> Dictionary:
	var action := "attack"
	if actor.charging != "":
		action = actor.charging
		actor.charging = ""
	else:
		var phases: Array = actor.template.get("phases", [])
		if not phases.is_empty():
			var pat: Array = phases[maxi(0, actor.phase_index)]["pattern"]
			action = String(pat[actor.pattern_i % pat.size()])
			actor.pattern_i += 1
		else:
			var weights: Array = actor.template.get("ai", {}).get("weights", [["attack", 100]])
			var total := 0.0
			for w in weights:
				total += float(w[1])
			var roll := rng.randf() * total
			for w in weights:
				roll -= float(w[1])
				if roll <= 0.0:
					action = String(w[0])
					break
	return {"action": action, "target": _enemy_target(actor)}

func _enemy_target(actor: Combatant) -> Combatant:
	var foes := living(foes_of(actor))
	if foes.is_empty():
		return null
	for f in foes:
		if f.has_status("taunt") and rng.randf() < 0.8:
			return f
	return foes[rng.randi() % foes.size()]

## Executa o turno completo de um inimigo (apos begin_turn, se nao "skip").
func act_enemy(actor: Combatant) -> Array:
	var ch := enemy_choose(actor)
	var tgt: Combatant = ch["target"]
	if tgt == null:
		return []
	var ev: Array
	if ch["action"] == "attack":
		var skill := {"id": "_basic", "name": actor.template.get("attack_name", "Ataque"), "kind": "phys", "target": "foe", "power": 1.0, "hits": 1,
			"weights": {"str": 1.5}, "fx": "slash", "accuracy": 1.0, "element": "physical"}
		ev = _execute(actor, skill, tgt)
	else:
		var sk := SkillDB.get_skill(ch["action"])
		if sk.is_empty():
			return []
		ev = _execute(actor, sk, tgt)
	check_end()
	return ev

# ---------------------------------------------------------------- recompensas
## Calcula recompensas UMA vez. rewards: {exp, gold, items{}, kills{}, bosses[], unlocks[]}
func compute_rewards(player_level: int) -> Dictionary:
	if rewards_computed:
		return rewards
	rewards_computed = true
	var r := {"exp": 0, "gold": 0, "items": {}, "kills": {}, "bosses": [], "unlocks": []}
	if result != "victory":
		rewards = r
		return r
	var floor_n := int(context.get("floor", 1))
	var class_id: String = context.get("class_id", "guerreiro")
	for e in enemies:
		if e.alive():
			continue
		var t: Dictionary = e.template
		r["exp"] += Formulas.exp_reward(int(t.get("exp", 1)), e.level, player_level)
		r["gold"] += Formulas.gold_reward(t.get("gold", [0, 0]), e.level, rng)
		r["kills"][e.template_id] = int(r["kills"].get(e.template_id, 0)) + 1
		for d in t.get("drops", []):
			if rng.randf() < float(d["chance"]):
				r["items"][d["item"]] = int(r["items"].get(d["item"], 0)) + 1
		for l in t.get("loot", []):
			if l.has("class_gear"):
				var gid := ItemDB.class_gear(class_id, l["class_gear"], l["rarity"])
				if gid != "":
					r["items"][gid] = int(r["items"].get(gid, 0)) + 1
		if e.is_boss:
			r["bosses"].append(e.template_id)
			if t.has("unlock"):
				r["unlocks"].append(t["unlock"])
		elif not e.is_minion and rng.randf() < Balance.MONSTER_GEAR_DROP_CHANCE:
			var gid2 := LootTable.roll_gear(rng, floor_n, class_id, Balance.MONSTER_RARITY_CAP)
			if gid2 != "":
				r["items"][gid2] = int(r["items"].get(gid2, 0)) + 1
	rewards = r
	return r

## Usado em testes: desfaz o avanco do padrao feito por enemy_choose() quando so se queria "espiar".
func pattern_rewind(actor: Combatant) -> void:
	if actor.template.get("phases", []).size() > 0 and actor.pattern_i > 0 and actor.charging == "":
		actor.pattern_i -= 1
