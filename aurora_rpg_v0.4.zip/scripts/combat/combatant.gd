class_name Combatant
extends RefCounted
## Participante de uma batalha (heroi, aliado futuro ou inimigo). Sem dependencia de cenas.

var uid: int = 0
var template_id: String = ""
var display_name: String = ""
var is_player: bool = false
var is_boss: bool = false
var is_minion: bool = false
var level: int = 1
var stats: Dictionary = {}
var hp: int = 1
var mp: int = 0
var max_hp: int = 1
var max_mp: int = 0
var weak: Array = []
var resist: Array = []
var immune: Array = []
var statuses: Array = []      # [{id, turns, value, fresh}]
var skills: Array = []        # ids de habilidades conhecidas
var basic: Dictionary = {}
var sprite_id: String = ""
var color: Color = Color.WHITE
var size: int = 24
var defending: bool = false
var charging: String = ""     # habilidade preparada (chefes)
var turn_count: int = 0
var pattern_i: int = 0
var phase_index: int = -1
var template: Dictionary = {}
var class_id: String = ""
var defeated_reported: bool = false

func alive() -> bool:
	return hp > 0

func hp_ratio() -> float:
	return float(hp) / float(maxi(1, max_hp))

func get_status(id: String) -> Dictionary:
	for s in statuses:
		if s["id"] == id:
			return s
	return {}

func has_status(id: String) -> bool:
	return not get_status(id).is_empty()

func remove_status(id: String) -> void:
	for i in range(statuses.size() - 1, -1, -1):
		if statuses[i]["id"] == id:
			statuses.remove_at(i)

func add_status(id: String, turns: int, value: float, fresh: bool = false) -> void:
	var cur := get_status(id)
	if cur.is_empty():
		statuses.append({"id": id, "turns": turns, "value": value, "fresh": fresh})
	else:
		cur["turns"] = maxi(int(cur["turns"]), turns)
		cur["value"] = maxf(float(cur["value"]), value) if id != "shield" else value
		cur["fresh"] = fresh

func status_value(id: String) -> float:
	var s := get_status(id)
	return float(s["value"]) if not s.is_empty() else 0.0

## Atributo com modificadores de status aplicados.
func stat(name: String) -> float:
	var base: float = float(stats.get(name, 0))
	match name:
		"def", "mdef":
			return base * maxf(0.1, 1.0 + status_value("defup") - status_value("defdown"))
		"agi":
			return base * maxf(0.1, 1.0 + status_value("agiup") - status_value("agidown"))
	return base

func attack_mult() -> float:
	return maxf(0.2, 1.0 + status_value("atkup") - status_value("atkdown"))

func evasion() -> float:
	return status_value("evade")

func heal_hp(amount: int) -> int:
	var before := hp
	hp = clampi(hp + amount, 0, max_hp)
	return hp - before

func heal_mp(amount: int) -> int:
	var before := mp
	mp = clampi(mp + amount, 0, max_mp)
	return mp - before

## Aplica dano considerando barreira. Retorna {dealt, absorbed}.
func take_damage(amount: int) -> Dictionary:
	var absorbed := 0
	var sh := get_status("shield")
	if not sh.is_empty() and amount > 0:
		var pool := int(sh["value"])
		absorbed = mini(pool, amount)
		sh["value"] = pool - absorbed
		amount -= absorbed
		if int(sh["value"]) <= 0:
			remove_status("shield")
	hp = maxi(0, hp - amount)
	if hp == 0:
		statuses.clear()
		charging = ""
	return {"dealt": amount, "absorbed": absorbed}
