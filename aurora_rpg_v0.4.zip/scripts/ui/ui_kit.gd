class_name UIKit
extends RefCounted
## Tema retro (estilo GBA) e construtores de widgets reutilizaveis.

const C_BG := Color(0.07, 0.09, 0.20, 0.96)
const C_BG2 := Color(0.12, 0.15, 0.32, 1.0)
const C_BORDER := Color(0.92, 0.92, 1.0, 1.0)
const C_BORDER_DK := Color(0.45, 0.50, 0.75, 1.0)
const C_TEXT := Color(1, 1, 1, 1)
const C_DIM := Color(0.65, 0.70, 0.85, 1)
const C_GOLD := Color(1.0, 0.85, 0.25, 1)
const C_HP := Color(0.35, 0.85, 0.40, 1)
const C_HP_LOW := Color(0.95, 0.30, 0.25, 1)
const C_MP := Color(0.35, 0.55, 1.0, 1)
const C_EXP := Color(0.85, 0.65, 0.95, 1)
const C_BAD := Color(1.0, 0.45, 0.4, 1)
const FONT_SIZE := 14

static var _theme: Theme = null

static func box(bg: Color, border: Color, bw: int = 2, radius: int = 3, pad: int = 6) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(bw)
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = pad + 2
	sb.content_margin_right = pad + 2
	sb.content_margin_top = pad
	sb.content_margin_bottom = pad
	return sb

static func theme() -> Theme:
	if _theme != null:
		return _theme
	var t := Theme.new()
	t.default_font_size = FONT_SIZE
	t.set_color("font_color", "Label", C_TEXT)
	t.set_color("font_outline_color", "Label", Color(0.03, 0.03, 0.1, 1))
	t.set_constant("outline_size", "Label", 2)
	t.set_stylebox("panel", "PanelContainer", box(C_BG, C_BORDER, 2, 4, 6))
	t.set_stylebox("panel", "Panel", box(C_BG, C_BORDER, 2, 4, 6))
	# botoes
	t.set_stylebox("normal", "Button", box(C_BG2, C_BORDER_DK, 2, 3, 4))
	t.set_stylebox("hover", "Button", box(Color(0.20, 0.25, 0.50), C_GOLD, 2, 3, 4))
	t.set_stylebox("pressed", "Button", box(Color(0.30, 0.35, 0.65), C_GOLD, 2, 3, 4))
	t.set_stylebox("focus", "Button", box(Color(0.22, 0.28, 0.55), C_GOLD, 2, 3, 4))
	t.set_stylebox("disabled", "Button", box(Color(0.10, 0.11, 0.18), Color(0.25, 0.27, 0.38), 2, 3, 4))
	t.set_color("font_color", "Button", C_TEXT)
	t.set_color("font_hover_color", "Button", C_GOLD)
	t.set_color("font_focus_color", "Button", C_GOLD)
	t.set_color("font_pressed_color", "Button", C_GOLD)
	t.set_color("font_disabled_color", "Button", Color(0.5, 0.52, 0.62))
	t.set_constant("h_separation", "Button", 6)
	t.set_font_size("font_size", "Button", FONT_SIZE)
	# barras de rolagem finas
	var grab := StyleBoxFlat.new()
	grab.bg_color = C_BORDER_DK
	grab.set_corner_radius_all(2)
	t.set_stylebox("grabber", "VScrollBar", grab)
	t.set_stylebox("grabber_highlight", "VScrollBar", grab)
	t.set_stylebox("grabber_pressed", "VScrollBar", grab)
	var sc := StyleBoxFlat.new()
	sc.bg_color = Color(0, 0, 0, 0.3)
	t.set_stylebox("scroll", "VScrollBar", sc)
	t.set_constant("minimum_grab_thickness", "VScrollBar", 10)
	# sliders
	var sl := StyleBoxFlat.new()
	sl.bg_color = Color(0.15, 0.17, 0.30)
	sl.set_corner_radius_all(3)
	sl.content_margin_top = 4
	sl.content_margin_bottom = 4
	t.set_stylebox("slider", "HSlider", sl)
	var sla := StyleBoxFlat.new()
	sla.bg_color = C_GOLD
	sla.set_corner_radius_all(3)
	t.set_stylebox("grabber_area", "HSlider", sla)
	t.set_stylebox("grabber_area_highlight", "HSlider", sla)
	t.set_color("font_color", "CheckBox", C_TEXT)
	t.set_color("font_color", "LineEdit", C_TEXT)
	t.set_stylebox("normal", "LineEdit", box(Color(0.05, 0.06, 0.14), C_BORDER_DK, 2, 3, 4))
	t.set_stylebox("focus", "LineEdit", box(Color(0.05, 0.06, 0.14), C_GOLD, 2, 3, 4))
	t.set_color("font_color", "ItemList", C_TEXT)
	_theme = t
	return t

static func label(text: String, size: int = FONT_SIZE, color: Color = C_TEXT, align: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.horizontal_alignment = align as HorizontalAlignment
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

static func button(text: String, min_w: int = 0, min_h: int = 26) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(min_w, min_h)
	b.focus_mode = Control.FOCUS_ALL
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.clip_text = true
	return b

static func panel(min_size: Vector2 = Vector2.ZERO) -> PanelContainer:
	var p := PanelContainer.new()
	p.custom_minimum_size = min_size
	return p

static func clear(node: Node) -> void:
	for c in node.get_children():
		node.remove_child(c)
		c.queue_free()

## Barra (HP/MP/EXP) desenhada com ColorRects.
class Bar extends Control:
	var value: float = 1.0
	var maxv: float = 1.0
	var fill: Color = Color(0.35, 0.85, 0.4)
	var show_text: bool = true
	var _txt: String = ""
	var shown: float = 1.0
	func setup(w: int, h: int, c: Color, with_text: bool = true) -> Bar:
		custom_minimum_size = Vector2(w, h)
		size = Vector2(w, h)
		fill = c
		show_text = with_text
		mouse_filter = Control.MOUSE_FILTER_IGNORE
		return self
	func set_values(v: float, m: float, animate: bool = false) -> void:
		value = clampf(v, 0.0, maxf(m, 1.0))
		maxv = maxf(m, 1.0)
		_txt = "%d/%d" % [int(value), int(maxv)]
		if animate and is_inside_tree():
			var tw := create_tween()
			tw.tween_property(self, "shown", value / maxv, 0.35)
			tw.parallel().tween_method(func(_x): queue_redraw(), 0.0, 1.0, 0.35)
		else:
			shown = value / maxv
		queue_redraw()
	func _draw() -> void:
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.02, 0.08, 1))
		draw_rect(Rect2(Vector2.ZERO, size), UIKit.C_BORDER_DK, false, 1.0)
		var w := (size.x - 2.0) * clampf(shown, 0.0, 1.0)
		var c := fill
		if fill == UIKit.C_HP and shown < 0.25:
			c = UIKit.C_HP_LOW
		draw_rect(Rect2(1, 1, w, size.y - 2), c)
		draw_rect(Rect2(1, 1, w, maxf(1.0, (size.y - 2) * 0.35)), Color(1, 1, 1, 0.22))
		if show_text:
			var f := ThemeDB.fallback_font
			var fs := int(minf(11.0, size.y - 1.0))
			var ts := f.get_string_size(_txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
			var pos := Vector2((size.x - ts.x) / 2.0, (size.y + ts.y) / 2.0 - 3.0)
			draw_string_outline(f, pos, _txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, 3, Color(0, 0, 0, 0.9))
			draw_string(f, pos, _txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1))

static func bar(w: int, h: int, c: Color, with_text: bool = true) -> Bar:
	return Bar.new().setup(w, h, c, with_text)

static func icon_rect(tex: Texture2D, px: int = 24) -> TextureRect:
	var r := TextureRect.new()
	r.texture = tex
	r.custom_minimum_size = Vector2(px, px)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r

static func rarity_color(rarity: String) -> Color:
	return ItemDB.RARITY.get(rarity, ItemDB.RARITY["common"])["color"]

static func item_name_rich(id: String) -> String:
	var it := ItemDB.get_item(id)
	return String(it.get("name", id))

static func stat_line(stats: Dictionary) -> String:
	var parts: Array = []
	for k in ["str", "int", "vit", "agi", "def", "dex", "faith", "hp", "mp"]:
		if stats.has(k) and int(stats[k]) != 0:
			parts.append("%s %+d" % [ItemDB.STAT_NAMES[k], int(stats[k])])
	return "  ".join(parts)

## Reserva espaco a esquerda do botao (para um icone) sem depender de espacos no texto.
static func pad_button(b: Button, left: int) -> void:
	for st in ["normal", "hover", "pressed", "focus", "disabled"]:
		var sb: StyleBoxFlat = theme().get_stylebox(st, "Button").duplicate()
		sb.content_margin_left = left
		b.add_theme_stylebox_override(st, sb)
