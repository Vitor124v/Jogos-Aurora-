class_name ShopUI
extends Modal
## Loja: comprar e vender com validacao de ouro e inventario.

var tab: String = "buy"
var list_box: VBoxContainer
var detail: RichTextLabel
var actions: HBoxContainer
var tab_buy: Button
var tab_sell: Button
var _sel: String = ""
var shop_name: String = "Loja do Borin"
var profile: String = ""      # id do perfil de estoque (ItemDB.SHOP_PROFILES)

func _init() -> void:
	super._init("Loja do Borin", true)

func _build() -> void:
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 4)
	root.size = Vector2(596, 296)
	body.add_child(root)
	var tabs := HBoxContainer.new()
	tab_buy = UIKit.button("Comprar", 110, 24)
	tab_sell = UIKit.button("Vender", 110, 24)
	tab_buy.pressed.connect(func(): _set_tab("buy"))
	tab_sell.pressed.connect(func(): _set_tab("sell"))
	tabs.add_child(tab_buy)
	tabs.add_child(tab_sell)
	root.add_child(tabs)
	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 8)
	root.add_child(cols)
	var lst := make_list(310, 262)
	cols.add_child(lst[0])
	list_box = lst[1]
	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(270, 0)
	right.add_theme_constant_override("separation", 4)
	cols.add_child(right)
	detail = RichTextLabel.new()
	detail.bbcode_enabled = true
	detail.custom_minimum_size = Vector2(270, 180)
	detail.add_theme_font_size_override("normal_font_size", 12)
	detail.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_child(detail)
	actions = HBoxContainer.new()
	actions.add_theme_constant_override("separation", 4)
	right.add_child(actions)

func on_open() -> void:
	title_lbl.text = shop_name
	_set_tab("buy")

func on_changed() -> void:
	_refresh(false)

func _set_tab(t: String) -> void:
	tab = t
	_sel = ""
	_refresh(true)

func _refresh(focus: bool) -> void:
	UIKit.clear(list_box)
	UIKit.clear(actions)
	tab_buy.disabled = tab == "buy"
	tab_sell.disabled = tab == "sell"
	var ids: Array = ItemDB.shop_stock(profile) if tab == "buy" else _sellable()
	if tab == "sell":
		ids.sort_custom(func(a, b): return String(ItemDB.get_item(a)["name"]) < String(ItemDB.get_item(b)["name"]))
	var gold := int(Game.s["gold"])
	var first: Button = null
	var keep: Button = null
	for id in ids:
		var it := ItemDB.get_item(id)
		var price := ItemDB.buy_price(id) if tab == "buy" else ItemDB.sell_price(id)
		var label := "%s" % it["name"]
		if tab == "sell":
			label += "  x%d" % Game.item_count(id)
		var b := UIKit.button("%s\t%d" % [label, price], 0, 24)
		b.text = label
		UIKit.pad_button(b, 30)
		b.add_theme_font_size_override("font_size", 13)
		var afford := tab == "sell" or gold >= price
		b.add_theme_color_override("font_color", ItemDB.rarity_color(id) if afford else Color(0.55, 0.45, 0.45))
		var ic := UIKit.icon_rect(PixelArt.item_icon(id), 20)
		ic.position = Vector2(4, 2)
		b.add_child(ic)
		var pl := UIKit.label("%d" % price, 12, UIKit.C_GOLD if afford else UIKit.C_BAD, HORIZONTAL_ALIGNMENT_RIGHT)
		pl.size = Vector2(60, 20)
		pl.set_anchors_preset(Control.PRESET_RIGHT_WIDE)
		pl.position = Vector2(b.custom_minimum_size.x, 3)
		pl.anchor_left = 1.0
		pl.anchor_right = 1.0
		pl.offset_left = -64
		pl.offset_right = -6
		pl.offset_top = 3
		b.add_child(pl)
		var iid: String = id
		b.focus_entered.connect(func(): _select(iid))
		b.mouse_entered.connect(func(): _select(iid))
		b.pressed.connect(func(): _select(iid))
		list_box.add_child(b)
		if first == null:
			first = b
		if iid == _sel:
			keep = b
	if ids.is_empty():
		detail.text = "Você não tem nada para vender." if tab == "sell" else "Sem estoque."
	else:
		var target: Button = keep if keep != null else first
		if focus and target != null:
			target.call_deferred("grab_focus")
		_select(String(ids[0]) if keep == null else _sel)

func _sellable() -> Array:
	var out: Array = []
	for id in Game.s["inventory"]:
		out.append(String(id))
	return out

func _select(id: String) -> void:
	_sel = id
	var it := ItemDB.get_item(id)
	if it.is_empty():
		return
	var rc: Color = ItemDB.rarity_color(id)
	var t := "[color=#%s][b]%s[/b][/color]\n" % [rc.to_html(false), it["name"]]
	var typ: String = it["type"]
	if typ in ["weapon", "armor", "accessory"]:
		t += "[color=#8fb0ff]%s • %s[/color]\n" % [ItemDB.SLOT_NAMES[it["slot"]], ItemDB.RARITY[it["rarity"]]["name"]]
		t += "%s\n" % UIKit.stat_line(it["stats"])
		t += "Nível requerido: %d\n" % int(it["req_level"])
		var chk := ItemDB.can_equip(id, String(Game.s["class_id"]), int(Game.s["level"]))
		if not chk["ok"]:
			t += "[color=#ff8a7a]%s[/color]\n" % chk["reason"]
		var cur: String = Game.s["equipment"].get(it["slot"], "")
		if cur != "" and cur != id:
			var diff := ""
			for k in it["stats"]:
				var d := int(it["stats"][k]) - int(ItemDB.get_item(cur)["stats"].get(k, 0))
				if d != 0:
					diff += "%s%s %+d  " % ["[color=#7fe08a]" if d > 0 else "[color=#ff8a7a]", ItemDB.STAT_NAMES[k], d] + "[/color]"
			t += "Em relação ao equipado: %s\n" % diff
	else:
		t += "%s\n" % it.get("desc", "")
	if tab == "buy":
		t += "\n[color=#ffd84a]Preço: %d[/color]   (você tem %d)" % [ItemDB.buy_price(id), int(Game.s["gold"])]
		if Game.item_count(id) > 0:
			t += "\nNa mochila: %d" % Game.item_count(id)
	else:
		t += "\n[color=#ffd84a]Venda: %d cada[/color]" % ItemDB.sell_price(id)
	detail.text = t
	UIKit.clear(actions)
	if tab == "buy":
		var b1 := UIKit.button("Comprar", 90, 26)
		b1.pressed.connect(func(): _buy(id, 1))
		actions.add_child(b1)
		if typ in ["consumable", "material"]:
			var b5 := UIKit.button("Comprar x5", 90, 26)
			b5.pressed.connect(func(): _buy(id, 5))
			actions.add_child(b5)
	else:
		var s1 := UIKit.button("Vender 1", 90, 26)
		s1.pressed.connect(func(): _sell(id, 1))
		actions.add_child(s1)
		if Game.item_count(id) > 1:
			var sa := UIKit.button("Vender tudo", 100, 26)
			sa.pressed.connect(func(): _sell(id, Game.item_count(id)))
			actions.add_child(sa)

func _buy(id: String, n: int) -> void:
	var r := Game.buy(id, n)
	Game.say(String(r["msg"]), UIKit.C_TEXT if r["ok"] else UIKit.C_BAD)
	Audio.sfx("coin" if r["ok"] else "cancel")

func _sell(id: String, n: int) -> void:
	var eq_ids: Array = Game.s["equipment"].values()
	var r := Game.sell(id, n)
	Game.say(String(r["msg"]), UIKit.C_TEXT if r["ok"] else UIKit.C_BAD)
	Audio.sfx("coin" if r["ok"] else "cancel")
