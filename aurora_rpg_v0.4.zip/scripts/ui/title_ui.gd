class_name TitleUI
extends Control
## Menu principal, selecao de classe e opcoes iniciais.

signal new_game_requested(class_id: String, hero_name: String)
signal continue_requested
signal quit_requested

var menu_panel: PanelContainer
var menu_box: VBoxContainer
var continue_btn: Button
var info_lbl: Label
var warn_lbl: Label
var class_panel: PanelContainer
var class_list: VBoxContainer
var class_detail: RichTextLabel
var class_portrait: TextureRect
var name_edit: LineEdit
var opt_panel: PanelContainer
var credits_panel: PanelContainer
var title_lbl: Label
var sub: Label
var sel_class: String = "guerreiro"
var bg: TextureRect
var sprites: Control
var _t: float = 0.0

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	theme = UIKit.theme()
	mouse_filter = Control.MOUSE_FILTER_STOP
	bg = TextureRect.new()
	bg.texture = PixelArt.battle_background("field", 640, 360)
	bg.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	bg.size = Vector2(640, 360)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)
	sprites = Control.new()
	sprites.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(sprites)
	for i in range(4):
		var tr := TextureRect.new()
		tr.texture = PixelArt.hero_battle_texture(HeroDB.CLASS_ORDER[i])
		tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		tr.size = Vector2(110, 110)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.position = Vector2([20.0, 110.0, 430.0, 520.0][i], 190)
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		sprites.add_child(tr)
	title_lbl = UIKit.label("CRÔNICAS DE AURORA", 30, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	title_lbl.size = Vector2(640, 40)
	title_lbl.position = Vector2(0, 28)
	title_lbl.add_theme_constant_override("outline_size", 8)
	add_child(title_lbl)
	sub = UIKit.label("Um RPG de fantasia em pixel art", 14, Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER)
	sub.size = Vector2(640, 20)
	sub.position = Vector2(0, 70)
	add_child(sub)
	var ver := UIKit.label("v%s" % Balance.GAME_VERSION, 11, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_RIGHT)
	ver.size = Vector2(80, 14)
	ver.position = Vector2(556, 342)
	add_child(ver)
	_build_menu()
	_build_class_select()
	_build_options()
	_build_credits()

func _process(delta: float) -> void:
	_t += delta
	var i := 0
	for s in sprites.get_children():
		s.position.y = 200.0 + sin(_t * 2.0 + float(i)) * 2.0
		i += 1

# ------------------------------------------------------------------ menu
func _build_menu() -> void:
	menu_panel = UIKit.panel()
	menu_panel.position = Vector2(240, 104)
	add_child(menu_panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	menu_panel.add_child(v)
	menu_box = v
	var b1 := UIKit.button("Nova Partida", 160, 30)
	b1.alignment = HORIZONTAL_ALIGNMENT_CENTER
	b1.pressed.connect(show_class_select)
	v.add_child(b1)
	continue_btn = UIKit.button("Continuar", 160, 30)
	continue_btn.alignment = HORIZONTAL_ALIGNMENT_CENTER
	continue_btn.pressed.connect(_on_continue)
	v.add_child(continue_btn)
	var b3 := UIKit.button("Opções", 160, 30)
	b3.alignment = HORIZONTAL_ALIGNMENT_CENTER
	b3.pressed.connect(func(): _show_panel("options"))
	v.add_child(b3)
	var b5 := UIKit.button("Créditos", 160, 30)
	b5.alignment = HORIZONTAL_ALIGNMENT_CENTER
	b5.pressed.connect(func(): _show_panel("credits"))
	v.add_child(b5)
	if not OS.has_feature("web") and not OS.has_feature("android") and not OS.has_feature("ios"):
		var b4 := UIKit.button("Sair", 160, 30)
		b4.alignment = HORIZONTAL_ALIGNMENT_CENTER
		b4.pressed.connect(func(): quit_requested.emit())
		v.add_child(b4)
	info_lbl = UIKit.label("", 11, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_CENTER)
	info_lbl.custom_minimum_size = Vector2(170, 28)
	info_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(info_lbl)
	warn_lbl = UIKit.label("", 11, UIKit.C_BAD, HORIZONTAL_ALIGNMENT_CENTER)
	warn_lbl.custom_minimum_size = Vector2(170, 0)
	warn_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(warn_lbl)

func show_menu() -> void:
	visible = true
	_show_panel("menu")
	warn_lbl.text = ""
	if SaveSystem.has_save():
		var r := SaveSystem.read()
		if r["ok"]:
			var s: Dictionary = r["state"]
			continue_btn.disabled = false
			info_lbl.text = "%s Nv%d • Rank %s\n%s" % [HeroDB.get_class_data(String(s["class_id"]))["name"], int(s["level"]), s["guild"]["rank"], _fmt_time(float(s["play_time"]))]
		else:
			continue_btn.disabled = true
			info_lbl.text = ""
			warn_lbl.text = "Save inválido: %s" % r["error"]
	else:
		continue_btn.disabled = true
		info_lbl.text = "Nenhuma partida salva."
	(menu_box.get_child(0) as Button).call_deferred("grab_focus") if continue_btn.disabled else continue_btn.call_deferred("grab_focus")

func _fmt_time(sec: float) -> String:
	var t := int(sec)
	return "Tempo: %02d:%02d:%02d" % [t / 3600, (t / 60) % 60, t % 60]

func _show_panel(which: String) -> void:
	menu_panel.visible = which == "menu"
	class_panel.visible = which == "class"
	opt_panel.visible = which == "options"
	credits_panel.visible = which == "credits"
	sprites.visible = which == "menu"
	title_lbl.visible = which != "class"
	sub.visible = which != "class"
	if which == "menu":
		(menu_box.get_child(0) as Button).call_deferred("grab_focus")

func _on_continue() -> void:
	var r := Game.load_game()
	if not r["ok"]:
		warn_lbl.text = String(r["error"])
		Audio.sfx("cancel")
		return
	Audio.sfx("confirm")
	if r["warnings"].size() > 0:
		warn_lbl.text = String(r["warnings"][0])
	continue_requested.emit()

# ------------------------------------------------------------------ selecao de classe
func _build_class_select() -> void:
	class_panel = UIKit.panel()
	class_panel.position = Vector2(12, 8)
	class_panel.size = Vector2(616, 344)
	class_panel.visible = false
	add_child(class_panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 4)
	class_panel.add_child(root)
	root.add_child(UIKit.label("Escolha sua classe", 16, UIKit.C_GOLD))
	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 10)
	root.add_child(cols)
	class_list = VBoxContainer.new()
	class_list.add_theme_constant_override("separation", 4)
	class_list.custom_minimum_size = Vector2(140, 0)
	cols.add_child(class_list)
	for cid in HeroDB.CLASS_ORDER:
		var cd := HeroDB.get_class_data(cid)
		var b := UIKit.button(String(cd["name"]), 140, 44)
		b.add_theme_font_size_override("font_size", 15)
		UIKit.pad_button(b, 48)
		var ic := UIKit.icon_rect(PixelArt.portrait(cid), 38)
		ic.position = Vector2(5, 3)
		b.add_child(ic)
		var c2: String = cid
		b.focus_entered.connect(func(): _select_class(c2))
		b.mouse_entered.connect(func(): _select_class(c2))
		b.pressed.connect(func(): _select_class(c2))
		class_list.add_child(b)
	var nr := HBoxContainer.new()
	nr.add_child(UIKit.label("Nome:", 12))
	name_edit = LineEdit.new()
	name_edit.text = "Herói"
	name_edit.max_length = 14
	name_edit.custom_minimum_size = Vector2(90, 24)
	nr.add_child(name_edit)
	class_list.add_child(nr)
	var go := UIKit.button("▶ Começar", 140, 34)
	go.alignment = HORIZONTAL_ALIGNMENT_CENTER
	go.pressed.connect(func():
		Audio.sfx("confirm")
		new_game_requested.emit(sel_class, name_edit.text))
	class_list.add_child(go)
	var back := UIKit.button("« Voltar", 140, 26)
	back.alignment = HORIZONTAL_ALIGNMENT_CENTER
	back.pressed.connect(func(): _show_panel("menu"))
	class_list.add_child(back)
	var right := HBoxContainer.new()
	right.add_theme_constant_override("separation", 8)
	cols.add_child(right)
	class_portrait = UIKit.icon_rect(PixelArt.portrait("guerreiro"), 72)
	class_portrait.custom_minimum_size = Vector2(72, 72)
	right.add_child(class_portrait)
	class_detail = RichTextLabel.new()
	class_detail.bbcode_enabled = true
	class_detail.custom_minimum_size = Vector2(390, 292)
	class_detail.add_theme_font_size_override("normal_font_size", 11)
	class_detail.scroll_active = true
	class_detail.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_child(class_detail)

func show_class_select() -> void:
	_show_panel("class")
	_select_class(sel_class)
	(class_list.get_child(HeroDB.CLASS_ORDER.find(sel_class)) as Button).call_deferred("grab_focus")
	Audio.sfx("select")

func _select_class(cid: String) -> void:
	sel_class = cid
	var cd := HeroDB.get_class_data(cid)
	class_portrait.texture = PixelArt.portrait(cid)
	var st := Formulas.hero_stats(cid, 1, _start_bonus(cid))
	var t := "[color=#ffd84a][b]%s[/b][/color]  —  %s\n%s\n\n" % [cd["name"], cd["role"], cd["desc"]]
	t += "[color=#8fb0ff]Atributos iniciais[/color]\n"
	t += "HP %d   MP %d   FOR %d   INT %d   VIT %d\nAGI %d   DEF %d   DES %d   FÉ %d\n\n" % [st["max_hp"], st["max_mp"], st["str"], st["int"], st["vit"], st["agi"], st["def"], st["dex"], st["faith"]]
	t += "[color=#8fb0ff]Habilidades[/color]\n"
	for e in cd["skills"]:
		var sk := SkillDB.get_skill(String(e[0]))
		t += "• [color=#ffd84a]%s[/color] (%d MP)%s — %s\n" % [sk["name"], int(sk.get("mp", 0)), "" if int(e[1]) <= 1 else " [Nv %d]" % int(e[1]), sk.get("desc", "")]
	var subs: Array = []
	for s in cd["subclasses"]:
		subs.append(HeroDB.SUBCLASSES[s]["name"])
	t += "\n[color=#8fb0ff]Equipamento inicial:[/color] %s, %s\n" % [ItemDB.get_item(cd["start_equipment"]["weapon"])["name"], ItemDB.get_item(cd["start_equipment"]["armor"])["name"]]
	t += "[color=#8fb0ff]Subclasses futuras:[/color] %s" % ", ".join(subs)
	class_detail.text = t

func _start_bonus(cid: String) -> Dictionary:
	var b := {}
	var cd := HeroDB.get_class_data(cid)
	for slot in cd["start_equipment"]:
		var it := ItemDB.get_item(String(cd["start_equipment"][slot]))
		for k in it.get("stats", {}):
			b[k] = int(b.get(k, 0)) + int(it["stats"][k])
	return b

# ------------------------------------------------------------------ opcoes
func _build_options() -> void:
	opt_panel = UIKit.panel()
	opt_panel.position = Vector2(150, 110)
	opt_panel.visible = false
	add_child(opt_panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	opt_panel.add_child(root)
	root.add_child(UIKit.label("Opções", 16, UIKit.C_GOLD))
	for r in [["Volume da música", "music"], ["Volume dos efeitos", "sfx"]]:
		var hb := HBoxContainer.new()
		var l := UIKit.label(r[0], 13)
		l.custom_minimum_size = Vector2(140, 0)
		hb.add_child(l)
		var sl := HSlider.new()
		sl.min_value = 0
		sl.max_value = 1
		sl.step = 0.05
		sl.value = float(Game.settings[r[1]])
		sl.custom_minimum_size = Vector2(160, 22)
		var key: String = r[1]
		sl.value_changed.connect(func(v: float):
			if key == "music":
				Audio.set_music_volume(v)
			else:
				Audio.set_sfx_volume(v)
				Audio.sfx("select")
			Game.save_settings())
		hb.add_child(sl)
		root.add_child(hb)
	var th := HBoxContainer.new()
	var tl := UIKit.label("Controles de toque", 13)
	tl.custom_minimum_size = Vector2(140, 0)
	th.add_child(tl)
	var ob := OptionButton.new()
	ob.add_item("Automático", 0)
	ob.add_item("Sempre ligado", 1)
	ob.add_item("Desligado", 2)
	ob.selected = int(Game.settings["touch"])
	ob.item_selected.connect(func(i: int):
		Game.settings["touch"] = i
		Game.save_settings()
		Controls.refresh_touch_setting())
	th.add_child(ob)
	root.add_child(th)
	var cb := CheckBox.new()
	cb.text = "Escala inteira (pixels mais nítidos)"
	cb.button_pressed = bool(Game.settings["integer_scale"])
	cb.toggled.connect(func(v: bool):
		Game.settings["integer_scale"] = v
		Game.save_settings()
		get_window().content_scale_stretch = Window.CONTENT_SCALE_STRETCH_INTEGER if v else Window.CONTENT_SCALE_STRETCH_FRACTIONAL)
	root.add_child(cb)
	var back := UIKit.button("« Voltar", 120, 28)
	back.alignment = HORIZONTAL_ALIGNMENT_CENTER
	back.pressed.connect(func(): _show_panel("menu"))
	root.add_child(back)
	Controls.cancel_pressed.connect(func():
		if visible and (class_panel.visible or opt_panel.visible or credits_panel.visible):
			_show_panel("menu"))

# ------------------------------------------------------------------ creditos
func _build_credits() -> void:
	credits_panel = UIKit.panel()
	credits_panel.position = Vector2(110, 96)
	credits_panel.visible = false
	add_child(credits_panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 6)
	credits_panel.add_child(root)
	root.add_child(UIKit.label("Créditos", 16, UIKit.C_GOLD))
	var lines := [
		["Crônicas de Aurora  v%s" % Balance.GAME_VERSION, 13, Color(1, 1, 1)],
		["Criação, design e direção: o desenvolvedor do jogo", 12, UIKit.C_TEXT],
		["Código, arte procedural e áudio gerados por código com ajuda de IA", 12, UIKit.C_TEXT],
		["(Claude, Gemini e ChatGPT)", 11, UIKit.C_DIM],
		["Motor: Godot Engine 4 (licença MIT, godotengine.org)", 12, UIKit.C_TEXT],
		["Nenhum recurso gráfico ou sonoro de terceiros é usado nesta versão:", 12, UIKit.C_TEXT],
		["todos os sprites, tiles e sons são criados por código no próprio projeto.", 12, UIKit.C_TEXT],
		["Inspirado na clareza dos RPGs clássicos de GBA/DS.", 11, UIKit.C_DIM],
	]
	for l in lines:
		root.add_child(UIKit.label(String(l[0]), int(l[1]), l[2]))
	var back := UIKit.button("« Voltar", 120, 28)
	back.alignment = HORIZONTAL_ALIGNMENT_CENTER
	back.pressed.connect(func(): _show_panel("menu"))
	root.add_child(back)
