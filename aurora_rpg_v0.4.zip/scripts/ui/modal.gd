class_name Modal
extends Control
## Base para telas modais (menu, loja, guilda): fundo escurecido, painel, titulo, ouro e botao fechar.
## Uso: await modal.run()

signal closed

var panel: PanelContainer
var body: Control
var title_lbl: Label
var gold_lbl: Label
var close_btn: Button
var _open: bool = false
var _title: String = ""
var show_gold: bool = true

func _init(title: String = "", with_gold: bool = true) -> void:
	_title = title
	show_gold = with_gold

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	theme = UIKit.theme()
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(dim)
	panel = UIKit.panel()
	panel.position = Vector2(12, 8)
	panel.size = Vector2(616, 344)
	add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	panel.add_child(v)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 8)
	v.add_child(head)
	title_lbl = UIKit.label(_title, 16, UIKit.C_GOLD)
	title_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title_lbl)
	gold_lbl = UIKit.label("", 14, UIKit.C_GOLD)
	gold_lbl.visible = show_gold
	head.add_child(gold_lbl)
	close_btn = UIKit.button("✕ Fechar", 0, 24)
	close_btn.pressed.connect(close)
	head.add_child(close_btn)
	var sep := HSeparator.new()
	v.add_child(sep)
	body = Control.new()
	body.custom_minimum_size = Vector2(596, 296)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(body)
	_build()
	Controls.cancel_pressed.connect(_on_cancel)
	Controls.menu_pressed.connect(_on_menu_key)
	Game.changed.connect(_on_game_changed)

func _build() -> void:
	pass

func _on_game_changed() -> void:
	if _open:
		update_gold()
		on_changed()

func on_changed() -> void:
	pass

func on_open() -> void:
	pass

func update_gold() -> void:
	gold_lbl.text = "Ouro: %d" % int(Game.s.get("gold", 0))

func _on_cancel() -> void:
	if _open and visible and _open_frame != Engine.get_process_frames() and _top_most():
		cancel_action()

var menu_closes: bool = false
var _open_frame: int = -1

func _on_menu_key() -> void:
	if _open and visible and menu_closes and _open_frame != Engine.get_process_frames():
		close()

func cancel_action() -> void:
	close()

func _top_most() -> bool:
	return true

func run() -> void:
	if _open:
		return
	_open = true
	_open_frame = Engine.get_process_frames()
	Game.ui_lock += 1
	visible = true
	update_gold()
	on_open()
	Audio.sfx("select")
	await closed

func close() -> void:
	if not _open:
		return
	_open = false
	visible = false
	Game.ui_lock -= 1
	Game.ui_closed_frame = Engine.get_process_frames()
	Audio.sfx("cancel")
	closed.emit()

func is_open() -> bool:
	return _open

## Cria [ScrollContainer, VBoxContainer] para listas.
func make_list(w: int, h: int) -> Array:
	var sc := ScrollContainer.new()
	sc.custom_minimum_size = Vector2(w, h)
	sc.size = Vector2(w, h)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	vb.custom_minimum_size = Vector2(w - 12, 0)
	sc.add_child(vb)
	return [sc, vb]

func focus_first(container: Node) -> void:
	for c in container.get_children():
		if c is Button and not (c as Button).disabled:
			(c as Button).call_deferred("grab_focus")
			return
