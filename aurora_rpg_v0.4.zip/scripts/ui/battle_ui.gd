class_name BattleUI
extends Control
## Interface e apresentacao do combate. A logica fica em Battle (independente de cenas).
## Uso: var outcome = await battle_ui.start(group, context)

signal _cmd(name: String)
signal _picked(value)
signal _acknowledged

const FIELD_H := 238
const ANIMS_DEATH_LEN := 0.5

var battle: Battle
var hero: Combatant
var field: Control
var fx_layer: Node2D
var bg: TextureRect
var vis: Dictionary = {}          # uid -> {node, tex, bar, status, name}
var hero_panel: PanelContainer
var hero_name_lbl: Label
var hero_hp_bar: UIKit.Bar
var hero_mp_bar: UIKit.Bar
var hero_status_lbl: RichTextLabel
var log_panel: PanelContainer
var log_lbl: RichTextLabel
var cmd_panel: PanelContainer
var cmd_box: VBoxContainer
var sub_panel: PanelContainer
var sub_list: VBoxContainer
var sub_scroll: ScrollContainer
var sub_desc: RichTextLabel
var sub_title: Label
var marker: Label
var banner: Label
var result_panel: PanelContainer
var result_lbl: RichTextLabel
var log_lines: Array = []
var _busy: bool = false
var _hero_node: TextureRect
var _hero_frames: Dictionary = {}
var _hero_busy: bool = false      # animacao unica em andamento (ataque, skill, dano, morte)
var _hero_dead: bool = false
var _running: bool = false     # batalha em andamento (serializa chamadas a start)
var _hero_t: float = 0.0
var _awaiting_ack: bool = false
var awaiting_cmd: bool = false
var awaiting_pick: bool = false

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	theme = UIKit.theme()
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	_build()
	Controls.confirm_pressed.connect(func():
		if _awaiting_ack:
			_acknowledged.emit())

func _build() -> void:
	var solid := ColorRect.new()
	solid.color = Color(0.02, 0.03, 0.09, 1)
	solid.set_anchors_preset(Control.PRESET_FULL_RECT)
	solid.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(solid)
	field = Control.new()
	field.position = Vector2.ZERO
	field.size = Vector2(640, FIELD_H)
	field.clip_contents = true
	field.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(field)
	bg = TextureRect.new()
	bg.size = Vector2(640, FIELD_H)
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	field.add_child(bg)
	fx_layer = Node2D.new()
	fx_layer.z_index = 50
	field.add_child(fx_layer)
	banner = UIKit.label("", 16, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	banner.size = Vector2(640, 24)
	banner.position = Vector2(0, 6)
	banner.z_index = 60
	field.add_child(banner)
	marker = UIKit.label("▼", 16, UIKit.C_GOLD)
	marker.visible = false
	marker.z_index = 55
	field.add_child(marker)
	# painel do heroi
	hero_panel = UIKit.panel(Vector2(176, 112))
	hero_panel.position = Vector2(6, 242)
	hero_panel.size = Vector2(176, 112)
	add_child(hero_panel)
	var hv := VBoxContainer.new()
	hv.add_theme_constant_override("separation", 3)
	hero_panel.add_child(hv)
	hero_name_lbl = UIKit.label("", 14, UIKit.C_GOLD)
	hv.add_child(hero_name_lbl)
	var hr := HBoxContainer.new()
	hr.add_child(UIKit.label("HP", 12, UIKit.C_HP))
	hero_hp_bar = UIKit.bar(130, 14, UIKit.C_HP)
	hr.add_child(hero_hp_bar)
	hv.add_child(hr)
	var mr := HBoxContainer.new()
	mr.add_child(UIKit.label("MP", 12, UIKit.C_MP))
	hero_mp_bar = UIKit.bar(130, 14, UIKit.C_MP)
	mr.add_child(hero_mp_bar)
	hv.add_child(mr)
	hero_status_lbl = RichTextLabel.new()
	hero_status_lbl.bbcode_enabled = true
	hero_status_lbl.fit_content = true
	hero_status_lbl.custom_minimum_size = Vector2(160, 30)
	hero_status_lbl.add_theme_font_size_override("normal_font_size", 11)
	hero_status_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hv.add_child(hero_status_lbl)
	# log
	log_panel = UIKit.panel(Vector2(262, 112))
	log_panel.position = Vector2(188, 242)
	log_panel.size = Vector2(262, 112)
	add_child(log_panel)
	log_lbl = RichTextLabel.new()
	log_lbl.bbcode_enabled = true
	log_lbl.scroll_active = false
	log_lbl.add_theme_font_size_override("normal_font_size", 13)
	log_lbl.custom_minimum_size = Vector2(240, 96)
	log_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	log_panel.add_child(log_lbl)
	# comandos
	cmd_panel = UIKit.panel(Vector2(184, 112))
	cmd_panel.position = Vector2(454, 242)
	cmd_panel.size = Vector2(184, 112)
	add_child(cmd_panel)
	cmd_box = VBoxContainer.new()
	cmd_box.add_theme_constant_override("separation", 1)
	cmd_panel.add_child(cmd_box)
	for pair in [["Atacar", "attack"], ["Habilidades", "skill"], ["Itens", "item"], ["Defender", "defend"], ["Fugir", "flee"]]:
		var b := UIKit.button(pair[0], 0, 18)
		b.add_theme_font_size_override("font_size", 12)
		for stn in ["normal", "hover", "pressed", "focus", "disabled"]:
			var sbx: StyleBoxFlat = UIKit.theme().get_stylebox(stn, "Button").duplicate()
			sbx.content_margin_top = 0
			sbx.content_margin_bottom = 0
			b.add_theme_stylebox_override(stn, sbx)
		var nm: String = pair[1]
		b.pressed.connect(func(): _cmd.emit(nm))
		cmd_box.add_child(b)
	# sub painel (habilidades / itens / alvos)
	sub_panel = UIKit.panel(Vector2(446, 112))
	sub_panel.position = Vector2(192, 242)
	sub_panel.size = Vector2(446, 112)
	sub_panel.visible = false
	sub_panel.z_index = 5
	add_child(sub_panel)
	var sh := HBoxContainer.new()
	sh.add_theme_constant_override("separation", 6)
	sub_panel.add_child(sh)
	sub_scroll = ScrollContainer.new()
	sub_scroll.custom_minimum_size = Vector2(250, 98)
	sub_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sh.add_child(sub_scroll)
	sub_list = VBoxContainer.new()
	sub_list.add_theme_constant_override("separation", 1)
	sub_list.custom_minimum_size = Vector2(238, 0)
	sub_scroll.add_child(sub_list)
	var rv := VBoxContainer.new()
	sh.add_child(rv)
	sub_title = UIKit.label("", 12, UIKit.C_GOLD)
	rv.add_child(sub_title)
	sub_desc = RichTextLabel.new()
	sub_desc.bbcode_enabled = true
	sub_desc.custom_minimum_size = Vector2(170, 80)
	sub_desc.add_theme_font_size_override("normal_font_size", 12)
	sub_desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rv.add_child(sub_desc)
	# resultado
	result_panel = UIKit.panel(Vector2(360, 200))
	result_panel.position = Vector2(140, 40)
	result_panel.size = Vector2(360, 200)
	result_panel.visible = false
	result_panel.z_index = 70
	add_child(result_panel)
	result_lbl = RichTextLabel.new()
	result_lbl.bbcode_enabled = true
	result_lbl.fit_content = true
	result_lbl.custom_minimum_size = Vector2(340, 180)
	result_lbl.add_theme_font_size_override("normal_font_size", 14)
	result_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	result_panel.add_child(result_lbl)
	result_panel.gui_input.connect(func(ev: InputEvent):
		if _awaiting_ack and ev is InputEventMouseButton and ev.pressed:
			_acknowledged.emit())

# ================================================================= fluxo principal
## group: [{enemy:id, level:n}, ...]; retorna o resultado de Game.finish_battle + "result".
func start(group: Array, context: Dictionary = {}) -> Dictionary:
	while _running:
		await get_tree().process_frame
	_running = true
	Game.in_battle = true
	Game.ui_lock += 1
	visible = true
	hero = Game.make_hero_combatant()
	var enemies: Array = []
	for g in group:
		enemies.append(Battle.make_enemy(String(g["enemy"]), int(g.get("level", 1))))
	battle = Battle.new()
	var ctx := context.duplicate()
	ctx["class_id"] = Game.s["class_id"]
	battle.setup([hero], enemies, ctx)
	battle.inventory = Game.s["inventory"]
	_setup_visuals(String(context.get("bg", "field")))
	var boss := false
	for e in enemies:
		if e.is_boss:
			boss = true
	var final_boss := false
	for e2 in enemies:
		if e2.template_id == "boss_demon_lord":
			final_boss = true
	Audio.play_music("final" if final_boss else ("boss" if boss else "battle"))
	Audio.sfx("encounter")
	await _fade_in()
	var names := {}
	for e in enemies:
		names[e.display_name] = int(names.get(e.display_name, 0)) + 1
	var parts: Array = []
	for n in names:
		parts.append("%s%s" % [n, (" x%d" % names[n]) if names[n] > 1 else ""])
	_log("[color=#ffd84a]%s apareceu!%s[/color]" % [", ".join(parts), "  (Chefe)" if boss else ""], true)
	await _wait(0.7)
	await _loop()
	var outcome := Game.finish_battle(battle, hero)
	Game.in_battle = true     # mantem ate a interface fechar (evita nova batalha durante o resultado)
	await _show_result(outcome)
	await _fade_out()
	visible = false
	Game.in_battle = false
	_running = false
	Game.ui_lock -= 1
	outcome["context"] = context
	return outcome

func _loop() -> void:
	while not battle.finished:
		battle.start_round()
		var a: Combatant = battle.next_actor()
		while a != null and not battle.finished:
			var t := battle.begin_turn(a)
			await _play(t["events"])
			_refresh_all()
			if battle.finished:
				break
			if not t["skip"]:
				if a.is_player:
					await _player_turn(a)
				else:
					var ev := battle.act_enemy(a)
					await _play(ev)
			if battle.result == "fled":
				return
			var ev2 := battle.end_turn(a)
			await _play(ev2)
			_refresh_all()
			if battle.finished:
				break
			a = battle.next_actor()
	battle.check_end()

# ================================================================= preparacao visual
func _setup_visuals(bg_kind: String) -> void:
	for k in vis:
		vis[k]["node"].queue_free()
	vis.clear()
	if _hero_node != null:
		_hero_node.queue_free()
	log_lines.clear()
	log_lbl.text = ""
	result_panel.visible = false
	sub_panel.visible = false
	cmd_panel.visible = true
	log_panel.visible = true
	bg.texture = PixelArt.battle_background(bg_kind, 640, FIELD_H)
	bg.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_hero_node = TextureRect.new()
	_hero_frames = HeroArt.frames(String(Game.s["class_id"]))
	_hero_busy = false
	_hero_dead = false
	_hero_t = 0.0
	_hero_node.texture = _hero_frames["idle"][0]
	_hero_node.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_hero_node.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_hero_node.stretch_mode = TextureRect.STRETCH_SCALE
	_hero_node.position = Vector2(34, 104)
	_hero_node.size = Vector2(88, 88)
	_hero_node.mouse_filter = Control.MOUSE_FILTER_IGNORE
	field.add_child(_hero_node)
	for e in battle.enemies:
		_add_enemy_visual(e)
	_layout_enemies()
	_refresh_all()

func _enemy_px(e: Combatant) -> int:
	if e.is_boss:
		return 112
	if e.is_minion:
		return 48
	return 64

func _add_enemy_visual(e: Combatant) -> void:
	var px := _enemy_px(e)
	var n := Control.new()
	n.size = Vector2(px, px)
	n.mouse_filter = Control.MOUSE_FILTER_STOP
	var tr := TextureRect.new()
	tr.texture = PixelArt.enemy_texture(e.sprite_id, e.color, px)
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	tr.size = Vector2(px, px)
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	n.add_child(tr)
	var nm := UIKit.label(e.display_name, 11, UIKit.C_GOLD if e.is_boss else UIKit.C_TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	nm.size = Vector2(px + 40, 14)
	nm.position = Vector2(-20, -30)
	n.add_child(nm)
	var bar := UIKit.bar(maxi(56, int(px * 0.9)), 8, UIKit.C_HP, false)
	bar.position = Vector2((px - bar.size.x) / 2.0, -14)
	n.add_child(bar)
	var st := RichTextLabel.new()
	st.bbcode_enabled = true
	st.fit_content = true
	st.scroll_active = false
	st.size = Vector2(px + 40, 14)
	st.position = Vector2(-20, px + 1)
	st.add_theme_font_size_override("normal_font_size", 10)
	st.mouse_filter = Control.MOUSE_FILTER_IGNORE
	n.add_child(st)
	field.add_child(n)
	vis[e.uid] = {"node": n, "tex": tr, "bar": bar, "status": st, "name": nm, "c": e}

func _layout_enemies() -> void:
	var list: Array = []
	for e in battle.enemies:
		if vis.has(e.uid):
			list.append(e)
	var n := list.size()
	for i in range(n):
		var e: Combatant = list[i]
		var node: Control = vis[e.uid]["node"]
		var px := _enemy_px(e)
		var cols := mini(n, 3)
		var row := i / 3 if n > 3 else 0
		var col := i % 3 if n > 3 else i
		var cols_in_row := cols if n <= 3 else (3 if row == 0 else n - 3)
		var spacing := 96.0 if n > 1 else 0.0
		var cx := 440.0 + (float(col) - float(cols_in_row - 1) / 2.0) * spacing
		var base_y := 150.0 - float(px) * 0.5
		if n > 3:
			base_y = 110.0 + float(row) * 56.0 - float(px) * 0.5 + 20.0
		elif n > 1:
			base_y = 140.0 - float(px) * 0.5 + float((i % 2)) * 14.0
		node.position = Vector2(cx - float(px) / 2.0, base_y)
		node.set_meta("home", node.position)

func _fade_in() -> void:
	modulate = Color(1, 1, 1, 0)
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 1.0, 0.25)
	await tw.finished

func _fade_out() -> void:
	var tw := create_tween()
	tw.tween_property(self, "modulate:a", 0.0, 0.25)
	await tw.finished
	modulate = Color(1, 1, 1, 1)

func _wait(sec: float) -> void:
	await get_tree().create_timer(sec).timeout

# ================================================================= atualizacao de barras / log
func _status_text(c: Combatant) -> String:
	var parts: Array = []
	for s in c.statuses:
		var info: Dictionary = SkillDB.STATUS_INFO.get(s["id"], {})
		var col: Color = info.get("color", Color.WHITE)
		parts.append("[color=#%s]%s%d[/color]" % [col.to_html(false), info.get("name", s["id"]), int(s["turns"])])
	return " ".join(parts)

func _refresh_all() -> void:
	if hero == null:
		return
	hero_name_lbl.text = "%s  Nv %d" % [hero.display_name, hero.level]
	hero_hp_bar.set_values(hero.hp, hero.max_hp)
	hero_mp_bar.set_values(hero.mp, hero.max_mp)
	hero_status_lbl.text = _status_text(hero) + ("  [color=#ffd84a]Defendendo[/color]" if hero.defending else "")
	for uid in vis:
		var v: Dictionary = vis[uid]
		var e: Combatant = v["c"]
		v["bar"].set_values(e.hp, e.max_hp)
		v["status"].text = "[center]%s[/center]" % _status_text(e)
		if e.charging != "":
			v["tex"].modulate = Color(1.4, 0.8, 0.8)
		elif e.alive():
			v["tex"].modulate = Color(1, 1, 1)

func _log(text: String, clear_old: bool = false) -> void:
	if clear_old:
		log_lines.clear()
	log_lines.append(text)
	while log_lines.size() > 5:
		log_lines.pop_front()
	log_lbl.text = "\n".join(log_lines)

# ================================================================= reproducao de eventos
func _process(delta: float) -> void:
	if not visible or _hero_node == null or _hero_busy or _hero_dead or _hero_frames.is_empty():
		return
	_hero_t += delta
	var arr: Array = _hero_frames["idle"]
	var f := int(_hero_t * float(HeroArt.FPS["idle"])) % arr.size()
	_hero_node.texture = arr[f]

## Toca uma animacao unica do heroi (attack, skill, damage, death) e volta ao idle.
func _hero_play(anim: String) -> void:
	if _hero_node == null or _hero_frames.is_empty() or _hero_dead:
		return
	if _hero_busy and anim == "damage":
		return
	_hero_busy = true
	var arr: Array = _hero_frames[anim]
	for tx in arr:
		if _hero_node == null or not is_instance_valid(_hero_node):
			return
		_hero_node.texture = tx
		await get_tree().create_timer(1.0 / float(HeroArt.FPS[anim])).timeout
	if anim == "death":
		_hero_dead = true
	_hero_busy = false

func _node_of(c: Combatant) -> Control:
	if c == hero or c.is_player:
		return _hero_node
	if vis.has(c.uid):
		return vis[c.uid]["node"]
	return null

func _center_of(c: Combatant) -> Vector2:
	var n := _node_of(c)
	if n == null:
		return Vector2(320, 120)
	return n.position + n.size / 2.0

func _play(events: Array) -> void:
	for ev in events:
		match String(ev["t"]):
			"msg":
				_log(String(ev["text"]))
				await _wait(0.5)
			"anim":
				await _play_fx(String(ev.get("fx", "slash")), ev.get("src"), ev.get("dst", []), String(ev.get("kind", "phys")))
			"hit":
				await _on_hit(ev)
			"heal":
				_on_heal(ev)
				await _wait(0.4)
			"miss":
				var t: Combatant = ev["target"]
				_float_text(_center_of(t), "Errou!", Color(0.8, 0.8, 0.9))
				Audio.sfx("miss")
				await _wait(0.3)
			"status":
				var t2: Combatant = ev["target"]
				var info: Dictionary = SkillDB.STATUS_INFO.get(ev["status"], {})
				_log("%s: [color=#%s]%s[/color]!" % [t2.display_name, Color(info.get("color", Color.WHITE)).to_html(false), info.get("name", ev["status"])])
				_float_text(_center_of(t2) + Vector2(0, -20), String(info.get("name", "")), info.get("color", Color.WHITE))
				_refresh_all()
				await _wait(0.35)
			"status_end":
				var t3: Combatant = ev["target"]
				if ev.get("cured", false):
					_log("%s foi curado de %s." % [t3.display_name, SkillDB.status_name(String(ev["status"]))])
				else:
					_log("%s: %s acabou." % [t3.display_name, SkillDB.status_name(String(ev["status"]))])
				_refresh_all()
				await _wait(0.2)
			"down":
				await _on_down(ev["target"])
			"summon":
				var m: Combatant = ev["combatant"]
				_add_enemy_visual(m)
				_layout_enemies()
				var nd: Control = vis[m.uid]["node"]
				nd.modulate.a = 0.0
				create_tween().tween_property(nd, "modulate:a", 1.0, 0.4)
				_log("%s surgiu!" % m.display_name)
				_refresh_all()
				await _wait(0.5)
			"charge":
				_refresh_all()
				await _wait(0.4)
			"flee":
				var tw := create_tween()
				tw.tween_property(_hero_node, "position:x", -80.0, 0.4)
				await tw.finished
	_refresh_all()

func _on_hit(ev: Dictionary) -> void:
	var t: Combatant = ev["target"]
	var n := _node_of(t)
	var amount := int(ev["amount"])
	var absorbed := int(ev.get("absorbed", 0))
	var crit: bool = ev.get("crit", false)
	if bool(ev.get("immune", false)):
		_float_text(_center_of(t), "Imune!", Color(0.8, 0.8, 0.9))
	else:
		var col := Color(1, 0.35, 0.3) if t.is_player else Color(1, 1, 1)
		if ev.get("weak", false):
			col = Color(1, 0.9, 0.3)
		var txt := str(amount)
		if crit:
			txt = "%d!" % amount
		if absorbed > 0 and amount == 0:
			txt = "Bloqueado"
			col = Color(0.5, 0.8, 1.0)
		_float_text(_center_of(t), txt, col, crit or ev.get("weak", false))
		if ev.get("weak", false):
			_log("[color=#ffd84a]Fraqueza elemental![/color]")
		elif ev.get("resisted", false):
			_log("[color=#9ab]Resistiu...[/color]")
		if crit:
			_log("[color=#ffd84a]Golpe crítico![/color]")
	Audio.sfx("crit" if crit else "hit")
	if t.is_player and not bool(ev.get("immune", false)) and amount > 0 and t.alive():
		_hero_play("damage")
	if n != null:
		var home: Vector2 = n.get_meta("home") if n.has_meta("home") else n.position
		var tw := create_tween()
		for i in range(3):
			tw.tween_property(n, "modulate", Color(2, 2, 2), 0.04)
			tw.tween_property(n, "modulate", Color(1, 1, 1), 0.04)
		if t.alive() or true:
			var off := 4.0 if not crit else 8.0
			var tw2 := create_tween()
			tw2.tween_property(n, "position:x", n.position.x + off, 0.04)
			tw2.tween_property(n, "position:x", n.position.x - off, 0.04)
			tw2.tween_property(n, "position:x", n.position.x, 0.04)
	if crit or t.is_player:
		_shake(3.0 if not crit else 6.0)
	_refresh_all()
	await _wait(0.35)

func _on_heal(ev: Dictionary) -> void:
	var t: Combatant = ev["target"]
	var parts: Array = []
	if int(ev.get("amount", 0)) > 0:
		_float_text(_center_of(t), "+%d" % int(ev["amount"]), UIKit.C_HP, true)
	if int(ev.get("mp_amount", 0)) > 0:
		_float_text(_center_of(t) + Vector2(0, 14), "+%d MP" % int(ev["mp_amount"]), UIKit.C_MP)
	if int(ev.get("amount", 0)) == 0 and int(ev.get("mp_amount", 0)) == 0:
		_float_text(_center_of(t), "—", Color(0.8, 0.8, 0.9))
	Audio.sfx("heal")
	_refresh_all()

func _on_down(t: Combatant) -> void:
	_log("[color=#ff9a8a]%s foi derrotado![/color]" % t.display_name)
	var n := _node_of(t)
	if n != null:
		var tw := create_tween()
		if t.is_player:
			_hero_busy = false
			_hero_play("death")
			tw.tween_interval(float(ANIMS_DEATH_LEN))
		else:
			tw.tween_property(n, "modulate:a", 0.0, 0.5)
			tw.parallel().tween_property(n, "scale", Vector2(1.0, 0.1), 0.5)
			n.pivot_offset = Vector2(n.size.x / 2.0, n.size.y)
		await tw.finished
		if not t.is_player:
			n.visible = false
	_refresh_all()
	await _wait(0.2)

func _shake(amount: float) -> void:
	var tw := create_tween()
	for i in range(4):
		tw.tween_property(field, "position", Vector2(randf_range(-amount, amount), randf_range(-amount, amount)), 0.03)
	tw.tween_property(field, "position", Vector2.ZERO, 0.03)

func _float_text(pos: Vector2, text: String, color: Color, big: bool = false) -> void:
	var l := UIKit.label(text, 20 if big else 16, color, HORIZONTAL_ALIGNMENT_CENTER)
	l.add_theme_constant_override("outline_size", 4)
	l.size = Vector2(90, 24)
	l.position = pos - Vector2(45, 44)
	l.z_index = 80
	field.add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "position:y", l.position.y - 22.0, 0.7)
	tw.parallel().tween_property(l, "modulate:a", 0.0, 0.7).set_delay(0.3)
	tw.tween_callback(l.queue_free)

# ================================================================= efeitos visuais
func _spawn_particle(pos: Vector2, color: Color, size: float, vel: Vector2, life: float, shape: String = "rect") -> void:
	var p: Node2D
	if shape == "rect":
		var r := ColorRect.new()
		r.color = color
		r.size = Vector2(size, size)
		r.position = -r.size / 2.0
		var holder := Node2D.new()
		holder.add_child(r)
		p = holder
	else:
		var poly := Polygon2D.new()
		var pts := PackedVector2Array()
		for i in range(8):
			var a := TAU * float(i) / 8.0
			pts.append(Vector2(cos(a), sin(a)) * size * 0.5)
		poly.polygon = pts
		poly.color = color
		p = poly
	p.position = pos
	fx_layer.add_child(p)
	var tw := create_tween()
	tw.tween_property(p, "position", pos + vel, life)
	tw.parallel().tween_property(p, "modulate:a", 0.0, life).set_delay(life * 0.4)
	tw.tween_callback(p.queue_free)

func _burst(pos: Vector2, color: Color, count: int, radius: float, life: float, size: float = 5.0, shape: String = "rect") -> void:
	for i in range(count):
		var a := TAU * float(i) / float(count) + randf() * 0.4
		var v := Vector2(cos(a), sin(a)) * radius * randf_range(0.6, 1.0)
		_spawn_particle(pos, color, size * randf_range(0.7, 1.2), v, life, shape)

func _streak(from: Vector2, to: Vector2, color: Color, width: float, life: float) -> void:
	var l := Line2D.new()
	l.width = width
	l.default_color = color
	l.add_point(from)
	l.add_point(to)
	fx_layer.add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "modulate:a", 0.0, life)
	tw.tween_callback(l.queue_free)

func _ring(pos: Vector2, color: Color, r0: float, r1: float, life: float) -> void:
	var l := Line2D.new()
	l.width = 3
	l.default_color = color
	for i in range(25):
		var a := TAU * float(i) / 24.0
		l.add_point(Vector2(cos(a), sin(a)) * r0)
	l.position = pos
	fx_layer.add_child(l)
	var tw := create_tween()
	tw.tween_property(l, "scale", Vector2.ONE * (r1 / r0), life)
	tw.parallel().tween_property(l, "modulate:a", 0.0, life)
	tw.tween_callback(l.queue_free)

func _lunge(src: Combatant, dst_pos: Vector2) -> void:
	var n := _node_of(src)
	if n == null:
		return
	var home: Vector2 = n.position
	var dir := (dst_pos - (n.position + n.size / 2.0)).normalized()
	var tw := create_tween()
	tw.tween_property(n, "position", home + dir * 22.0, 0.1)
	tw.tween_property(n, "position", home, 0.12)

func _play_fx(fx: String, src: Combatant, dsts: Array, kind: String) -> void:
	var targets: Array = []
	for d in dsts:
		targets.append(d)
	if targets.is_empty():
		return
	var src_pos := _center_of(src) if src != null else Vector2(320, 80)
	var dur := 0.4
	if src != null and src.is_player:
		_hero_play("attack" if fx in ["slash", "slash_heavy", "stab", "blunt", "spin"] else "skill")
	match fx:
		"slash", "slash_heavy", "stab", "blunt", "spin":
			Audio.sfx("hit")
			if src != null and not (src in targets):
				_lunge(src, _center_of(targets[0]))
			await _wait(0.1)
			for t in targets:
				var c := _center_of(t)
				match fx:
					"slash":
						_streak(c + Vector2(-18, -18), c + Vector2(18, 18), Color(1, 1, 1), 3, 0.25)
					"slash_heavy":
						_streak(c + Vector2(-26, -26), c + Vector2(26, 26), Color(1, 0.95, 0.6), 6, 0.3)
						_streak(c + Vector2(26, -26), c + Vector2(-26, 26), Color(1, 0.8, 0.4), 4, 0.3)
					"stab":
						for k in range(3):
							var o := Vector2(randf_range(-10, 10), randf_range(-10, 10))
							_streak(c + o + Vector2(-12, 0), c + o + Vector2(12, 0), Color(0.9, 0.9, 1), 2, 0.2)
					"blunt":
						_ring(c, Color(1, 0.9, 0.7), 4, 26, 0.3)
					"spin":
						_ring(c, Color(1, 1, 1), 6, 30, 0.3)
						_streak(c + Vector2(-28, 0), c + Vector2(28, 0), Color(1, 1, 1), 3, 0.25)
			await _wait(0.3)
		"fire", "fire_rain":
			Audio.sfx("magic")
			for t in targets:
				var c2 := _center_of(t)
				if fx == "fire":
					for k in range(5):
						_spawn_particle(src_pos, Color(1.0, randf_range(0.4, 0.8), 0.1), 9, c2 - src_pos, 0.3, "circle")
					await _wait(0.3)
					_burst(c2, Color(1, 0.6, 0.15), 14, 38, 0.4, 7, "circle")
				else:
					for k in range(8):
						var sx := c2.x + randf_range(-22, 22)
						_spawn_particle(Vector2(sx, c2.y - 90), Color(1, 0.5, 0.1), 8, Vector2(0, 90), 0.35, "circle")
					_burst(c2, Color(1, 0.6, 0.15), 10, 34, 0.5, 6, "circle")
			await _wait(0.5)
		"ice":
			Audio.sfx("magic")
			for t in targets:
				var c3 := _center_of(t)
				for k in range(4):
					_spawn_particle(src_pos, Color(0.6, 0.9, 1.0), 7, c3 - src_pos, 0.28)
				await _wait(0.28)
				_burst(c3, Color(0.75, 0.95, 1.0), 14, 34, 0.4, 5)
				_ring(c3, Color(0.6, 0.9, 1.0), 4, 22, 0.3)
			await _wait(0.3)
		"holy", "holy_big":
			Audio.sfx("magic")
			for t in targets:
				var c4 := _center_of(t)
				var w := 14.0 if fx == "holy" else 28.0
				var col := Color(1, 0.95, 0.55, 0.85)
				var beam := ColorRect.new()
				beam.color = col
				beam.size = Vector2(w, 160)
				beam.position = Vector2(c4.x - w / 2.0, c4.y - 160)
				fx_layer.add_child(beam)
				var tw := create_tween()
				tw.tween_property(beam, "modulate:a", 0.0, 0.5)
				tw.tween_callback(beam.queue_free)
				_burst(c4, Color(1, 1, 0.7), 12, 30, 0.5, 5, "circle")
			await _wait(0.5)
		"poison", "dark", "arcane":
			Audio.sfx("magic")
			var col2: Color = {"poison": Color(0.65, 0.25, 0.85), "dark": Color(0.35, 0.15, 0.5), "arcane": Color(0.7, 0.55, 1.0)}[fx]
			for t in targets:
				var c5 := _center_of(t)
				for k in range(6):
					_spawn_particle(c5 + Vector2(randf_range(-16, 16), randf_range(0, 16)), col2, 7, Vector2(randf_range(-8, 8), -30), 0.6, "circle")
				_ring(c5, col2, 4, 24, 0.4)
			await _wait(0.5)
		"heal":
			Audio.sfx("heal")
			for t in targets:
				var c6 := _center_of(t)
				for k in range(7):
					_spawn_particle(c6 + Vector2(randf_range(-18, 18), randf_range(0, 20)), Color(0.4, 1.0, 0.5), 6, Vector2(0, -34), 0.7, "circle")
			await _wait(0.5)
		"buff", "shield", "holy_shield", "shadow":
			Audio.sfx("heal")
			var colb: Color = {"buff": Color(1, 0.8, 0.3), "shield": Color(0.5, 0.8, 1), "holy_shield": Color(1, 0.95, 0.5), "shadow": Color(0.5, 0.3, 0.7)}[fx]
			for t in targets:
				_ring(_center_of(t), colb, 8, 34, 0.5)
				_burst(_center_of(t), colb, 8, 22, 0.5, 4, "circle")
			await _wait(0.5)
		_:
			await _wait(0.2)

# ================================================================= turno do jogador
func _player_turn(actor: Combatant) -> void:
	while true:
		var cmd := await _ask_command()
		var res: Dictionary = {}
		match cmd:
			"attack":
				var tgt: Combatant = await _pick_target()
				if tgt == null:
					continue
				res = battle.act_attack(actor, tgt)
			"skill":
				var sid: String = await _pick_skill(actor)
				if sid == "":
					continue
				var sk := SkillDB.get_skill(sid)
				var tgt2: Combatant = null
				if sk["target"] == "foe":
					tgt2 = await _pick_target()
					if tgt2 == null:
						continue
				elif sk["target"] == "all_foes":
					tgt2 = battle.living(battle.enemies)[0]
				else:
					tgt2 = actor
				res = battle.act_skill(actor, sid, tgt2)
			"item":
				var iid: String = await _pick_item()
				if iid == "":
					continue
				var it := ItemDB.get_item(iid)
				var tgt3: Combatant = actor
				if it["use"].has("damage"):
					tgt3 = await _pick_target()
					if tgt3 == null:
						continue
				res = battle.act_item(actor, iid, tgt3)
			"defend":
				res = battle.act_defend(actor)
			"flee":
				res = battle.act_flee(actor)
		if res.is_empty():
			continue
		if not res["ok"]:
			_log("[color=#ff9a8a]%s[/color]" % res["error"])
			Audio.sfx("cancel")
			continue
		_set_menu_visible(false)
		await _play(res["events"])
		return

func _set_menu_visible(v: bool) -> void:
	cmd_panel.visible = v
	if not v:
		sub_panel.visible = false

func _ask_command() -> String:
	sub_panel.visible = false
	cmd_panel.visible = true
	log_panel.visible = true
	marker.visible = false
	_refresh_all()
	var first := cmd_box.get_child(0) as Button
	first.grab_focus()
	awaiting_cmd = true
	var r: String = await _cmd
	awaiting_cmd = false
	Audio.sfx("select")
	return r

func _pick_target() -> Combatant:
	var living := battle.living(battle.enemies)
	if living.size() == 1:
		return living[0]
	_open_sub("Alvo", "Escolha o inimigo.")
	var first: Button = null
	for e in living:
		var b := UIKit.button("%s  HP %d/%d" % [e.display_name, e.hp, e.max_hp], 0, 22)
		b.add_theme_font_size_override("font_size", 13)
		var ec: Combatant = e
		b.pressed.connect(func(): _picked.emit(ec))
		b.focus_entered.connect(func(): _mark(ec))
		b.mouse_entered.connect(func(): _mark(ec))
		sub_list.add_child(b)
		if first == null:
			first = b
	_add_back_button()
	first.grab_focus()
	_mark(living[0])
	# permite clicar diretamente no inimigo
	var click_conns: Array = []
	for e in living:
		var nd: Control = vis[e.uid]["node"]
		var ec2: Combatant = e
		var cb := func(ev: InputEvent):
			if ev is InputEventMouseButton and ev.pressed:
				_picked.emit(ec2)
		nd.gui_input.connect(cb)
		click_conns.append([nd, cb])
	awaiting_pick = true
	var r = await _picked
	awaiting_pick = false
	for pair in click_conns:
		if pair[0].gui_input.is_connected(pair[1]):
			pair[0].gui_input.disconnect(pair[1])
	marker.visible = false
	_close_sub()
	return r as Combatant

func _mark(e: Combatant) -> void:
	if not vis.has(e.uid):
		return
	var nd: Control = vis[e.uid]["node"]
	marker.visible = true
	marker.position = nd.position + Vector2(nd.size.x / 2.0 - 7.0, -46.0)

func _open_sub(title: String, desc: String) -> void:
	UIKit.clear(sub_list)
	sub_title.text = title
	sub_desc.text = desc
	sub_panel.visible = true
	cmd_panel.visible = false
	log_panel.visible = false
	sub_scroll.scroll_vertical = 0

func _close_sub() -> void:
	sub_panel.visible = false
	cmd_panel.visible = true
	log_panel.visible = true

func _add_back_button() -> void:
	var b := UIKit.button("« Voltar", 0, 22)
	b.add_theme_font_size_override("font_size", 13)
	b.pressed.connect(func(): _picked.emit(null))
	sub_list.add_child(b)

func _pick_skill(actor: Combatant) -> String:
	_open_sub("Habilidades", "")
	var first: Button = null
	for sid in actor.skills:
		var sk := SkillDB.get_skill(sid)
		var b := UIKit.button("%s   %d MP" % [sk["name"], int(sk.get("mp", 0))], 0, 22)
		b.add_theme_font_size_override("font_size", 13)
		var sid2: String = sid
		b.disabled = actor.mp < int(sk.get("mp", 0))
		b.pressed.connect(func(): _picked.emit(sid2))
		var show := func():
			sub_title.text = String(sk["name"])
			var tgt_txt: String = {"foe": "1 inimigo", "all_foes": "Todos inimigos", "self": "Você", "ally": "Aliado"}.get(sk.get("target", "foe"), "")
			sub_desc.text = "%s\n[color=#8fb0ff]Custo:[/color] %d MP\n[color=#8fb0ff]Alvo:[/color] %s" % [sk.get("desc", ""), int(sk.get("mp", 0)), tgt_txt]
		b.focus_entered.connect(show)
		b.mouse_entered.connect(show)
		sub_list.add_child(b)
		if first == null and not b.disabled:
			first = b
	_add_back_button()
	if first == null:
		first = sub_list.get_child(sub_list.get_child_count() - 1)
	first.grab_focus()
	var cancel_cb := func(): _picked.emit(null)
	Controls.cancel_pressed.connect(cancel_cb)
	awaiting_pick = true
	var r = await _picked
	awaiting_pick = false
	Controls.cancel_pressed.disconnect(cancel_cb)
	_close_sub()
	return String(r) if r != null else ""

func _pick_item() -> String:
	_open_sub("Itens", "")
	var first: Button = null
	var ids: Array = []
	for id in Game.s["inventory"]:
		var it := ItemDB.get_item(String(id))
		if it.get("type", "") == "consumable" and not it.get("field_only", false):
			ids.append(String(id))
	ids.sort()
	for id in ids:
		var it2 := ItemDB.get_item(id)
		var b := UIKit.button("%s  x%d" % [it2["name"], Game.item_count(id)], 0, 22)
		b.add_theme_font_size_override("font_size", 13)
		var id2: String = id
		b.pressed.connect(func(): _picked.emit(id2))
		var show := func():
			sub_title.text = String(it2["name"])
			sub_desc.text = String(it2["desc"])
		b.focus_entered.connect(show)
		b.mouse_entered.connect(show)
		sub_list.add_child(b)
		if first == null:
			first = b
	if ids.is_empty():
		sub_desc.text = "Você não tem itens utilizáveis."
	_add_back_button()
	if first == null:
		first = sub_list.get_child(sub_list.get_child_count() - 1)
	first.grab_focus()
	var cancel_cb := func(): _picked.emit(null)
	Controls.cancel_pressed.connect(cancel_cb)
	awaiting_pick = true
	var r = await _picked
	awaiting_pick = false
	Controls.cancel_pressed.disconnect(cancel_cb)
	_close_sub()
	return String(r) if r != null else ""

# ================================================================= resultado
func _show_result(outcome: Dictionary) -> void:
	cmd_panel.visible = false
	sub_panel.visible = false
	var res: String = String(outcome["result"])
	var text := ""
	match res:
		"victory":
			Audio.sfx("victory")
			banner.text = "VITÓRIA!"
			text = "[center][color=#ffd84a][b]Vitória![/b][/color][/center]\n"
			for m in outcome["messages"]:
				var s := String(m)
				var col := "#ffffff"
				if s.begins_with("Subiu"):
					col = "#ffd84a"
				elif s.begins_with("Obteve"):
					col = "#8fe0ff"
				text += "[color=%s]%s[/color]\n" % [col, s]
			if int(outcome.get("levels", 0)) > 0:
				Audio.sfx("levelup")
			for b in outcome["bosses"]:
				text += "[color=#ff9a4a]Chefe derrotado: %s![/color]\n" % EnemyDB.get_enemy(String(b))["name"]
		"defeat":
			Audio.sfx("defeat")
			banner.text = "DERROTA"
			text = "[center][color=#ff6a5a][b]Você foi derrotado...[/b][/color][/center]\n"
			for m in outcome["messages"]:
				text += "%s\n" % m
		"fled":
			text = "[center][b]Você fugiu![/b][/center]\n"
	result_lbl.text = text + "\n[center][color=#8fb0ff]Toque ou pressione Confirmar[/color][/center]"
	result_panel.visible = true
	_refresh_all()
	await _wait(0.25)
	_awaiting_ack = true
	await _acknowledged
	_awaiting_ack = false
	result_panel.visible = false
	banner.text = ""
