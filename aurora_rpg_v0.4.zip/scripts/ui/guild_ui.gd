class_name GuildUI
extends Modal
## Guilda: quadro de missoes, minhas missoes (entrega) e promocao de rank.

var tab: String = "board"
var tab_btns: Dictionary = {}
var list_box: VBoxContainer
var detail: RichTextLabel
var actions: VBoxContainer
var _sel: String = ""
var initial_tab: String = "board"

func _init() -> void:
	super._init("Guilda dos Aventureiros", true)

func _build() -> void:
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 4)
	root.size = Vector2(596, 296)
	body.add_child(root)
	var tabs := HBoxContainer.new()
	for pair in [["Quadro de missões", "board"], ["Minhas missões", "mine"], ["Rank / Promoção", "rank"]]:
		var b := UIKit.button(pair[0], 140, 24)
		var t: String = pair[1]
		b.pressed.connect(func(): _set_tab(t))
		tabs.add_child(b)
		tab_btns[t] = b
	root.add_child(tabs)
	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 8)
	root.add_child(cols)
	var lst := make_list(280, 262)
	cols.add_child(lst[0])
	list_box = lst[1]
	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(304, 0)
	right.add_theme_constant_override("separation", 4)
	cols.add_child(right)
	detail = RichTextLabel.new()
	detail.bbcode_enabled = true
	detail.custom_minimum_size = Vector2(304, 200)
	detail.add_theme_font_size_override("normal_font_size", 12)
	detail.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_child(detail)
	actions = VBoxContainer.new()
	actions.add_theme_constant_override("separation", 3)
	right.add_child(actions)

func on_open() -> void:
	_set_tab(initial_tab)
	initial_tab = "board"

func on_changed() -> void:
	_refresh(false)

func _set_tab(t: String) -> void:
	tab = t
	_sel = ""
	_refresh(true)

static func reward_text(rw: Dictionary) -> String:
	var parts: Array = []
	if int(rw.get("gold", 0)) > 0:
		parts.append("%d ouro" % int(rw["gold"]))
	if int(rw.get("exp", 0)) > 0:
		parts.append("%d EXP" % int(rw["exp"]))
	if int(rw.get("rep", 0)) > 0:
		parts.append("%d reputação" % int(rw["rep"]))
	for id in rw.get("items", {}):
		parts.append("%s x%d" % [ItemDB.get_item(String(id))["name"], int(rw["items"][id])])
	return ", ".join(parts)

func _refresh(focus: bool) -> void:
	UIKit.clear(list_box)
	UIKit.clear(actions)
	for t in tab_btns:
		tab_btns[t].disabled = (t == tab)
	var header := "Rank %s — %s   •   Reputação: %d" % [GuildSystem.rank(), QuestDB.RANK_TITLES[GuildSystem.rank()], GuildSystem.reputation()]
	list_box.add_child(UIKit.label(header, 11, UIKit.C_GOLD))
	if tab == "rank":
		_rank_page(focus)
		return
	var ids: Array = []
	for qid in QuestDB.QUESTS:
		var st := QuestSystem.state_of(qid)
		var q: Dictionary = QuestDB.QUESTS[qid]
		if tab == "board":
			if q.get("npc", false):
				continue
			if st == "available" or (st == "locked" and q.get("kind", "") != "eval"):
				ids.append(qid)
		elif tab == "mine":
			if st == "active":
				ids.append(qid)
	ids.sort_custom(func(a, b):
		var ra := QuestDB.rank_index(QuestDB.QUESTS[a]["rank"])
		var rb := QuestDB.rank_index(QuestDB.QUESTS[b]["rank"])
		if ra != rb:
			return ra < rb
		return String(a) < String(b))
	var first: Button = null
	var keep: Button = null
	for qid in ids:
		var q: Dictionary = QuestDB.QUESTS[qid]
		var st2 := QuestSystem.state_of(qid)
		var mark := ""
		if tab == "mine" and QuestSystem.is_ready(qid):
			mark = " ✔"
		elif q.get("kind", "") == "eval":
			mark = " ★"
		elif q.get("kind", "") == "repeatable":
			mark = " ↻"
		var b := UIKit.button("[%s] %s%s" % [q["rank"], q["name"], mark], 0, 24)
		b.add_theme_font_size_override("font_size", 13)
		if st2 == "locked":
			b.add_theme_color_override("font_color", Color(0.5, 0.5, 0.58))
		elif mark == " ✔":
			b.add_theme_color_override("font_color", UIKit.C_HP)
		var qq: String = qid
		b.focus_entered.connect(func(): _select(qq))
		b.mouse_entered.connect(func(): _select(qq))
		b.pressed.connect(func(): _select(qq))
		list_box.add_child(b)
		if first == null:
			first = b
		if qq == _sel:
			keep = b
	if ids.is_empty():
		detail.text = "Nenhuma missão ativa.\nAceite missões no Quadro." if tab == "mine" else "Nenhuma missão disponível no momento."
		return
	var target: Button = keep if keep != null else first
	if focus and target != null:
		target.call_deferred("grab_focus")
	_select(String(ids[0]) if keep == null else _sel)

func _select(qid: String) -> void:
	_sel = qid
	var q := QuestDB.get_quest(qid)
	if q.is_empty():
		return
	var st := QuestSystem.state_of(qid)
	var t := "[color=#ffd84a][b]%s[/b][/color]  [color=#8fb0ff]Rank %s%s[/color]\n" % [q["name"], q["rank"], " • Prova de avaliação" if q.get("kind", "") == "eval" else (" • Contrato repetível" if q.get("kind", "") == "repeatable" else "")]
	t += "%s\n\n" % q["desc"]
	t += "[color=#8fb0ff]Objetivos[/color]\n"
	if st == "active":
		t += QuestSystem.progress_text(qid) + "\n"
	else:
		for o in q["objectives"]:
			t += "• %s%s\n" % [o["text"], (" (%d)" % int(o["count"])) if int(o["count"]) > 1 else ""]
	t += "\n[color=#8fb0ff]Recompensa[/color]\n%s" % reward_text(q["rewards"])
	if st == "locked":
		t += "\n\n[color=#ff8a7a]Bloqueada: %s[/color]" % QuestSystem.lock_reason(qid)
	detail.text = t
	UIKit.clear(actions)
	if st == "available":
		var b := UIKit.button("Aceitar missão", 150, 26)
		b.pressed.connect(func():
			var r := QuestSystem.accept(qid)
			Game.say(String(r["msg"]), UIKit.C_TEXT if r["ok"] else UIKit.C_BAD)
			Audio.sfx("confirm" if r["ok"] else "cancel"))
		actions.add_child(b)
	elif st == "active":
		var ready := QuestSystem.is_ready(qid)
		var bt := UIKit.button("Entregar / receber recompensa" if ready else "Objetivos incompletos", 220, 26)
		bt.disabled = not ready
		bt.pressed.connect(func():
			var r := QuestSystem.turn_in(qid)
			if r["ok"]:
				Audio.sfx("levelup" if "Subiu" in " ".join(r["messages"]) else "confirm")
				Game.say(String(r["msg"]), UIKit.C_GOLD)
				for m in r["messages"]:
					Game.say(String(m))
			else:
				Game.say(String(r["msg"]), UIKit.C_BAD)
				Audio.sfx("cancel"))
		actions.add_child(bt)
		var ba := UIKit.button("Abandonar", 110, 22)
		ba.pressed.connect(func():
			var r := QuestSystem.abandon(qid)
			Game.say(String(r["msg"])))
		actions.add_child(ba)

func _rank_page(focus: bool) -> void:
	var r := GuildSystem.requirements()
	var t := "[color=#ffd84a][b]Rank atual: %s — %s[/b][/color]\n\n" % [GuildSystem.rank(), QuestDB.RANK_TITLES[GuildSystem.rank()]]
	t += "Os ranks vão de D até SS. A reputação vem de missões e é independente do seu nível.\n\n"
	if r.get("max", false):
		t += "[color=#7fe08a]Você alcançou o rank máximo![/color]"
		detail.text = t
		return
	t += "[color=#8fb0ff]Para o rank %s:[/color]\n" % r["target"]
	t += "%s Reputação: %d / %d\n" % [_ck(r["rep_ok"]), r["rep_have"], r["rep_req"]]
	t += "%s Nível: %d / %d\n" % [_ck(r["level_ok"]), r["level_have"], r["level_req"]]
	var q := QuestDB.get_quest(String(r["quest_id"]))
	t += "%s Prova: %s\n" % [_ck(r["quest_done"]), q["name"]]
	t += "   [color=#9ab]%s[/color]\n" % q["desc"]
	t += "\n[color=#ffd84a]Bônus de promoção: %d ouro[/color]" % int(r["bonus_gold"])
	detail.text = t
	UIKit.clear(actions)
	var qid: String = r["quest_id"]
	var qst: String = r["quest_state"]
	var btn: Button
	if r["ok"]:
		btn = UIKit.button("★ Promover para o rank %s" % r["target"], 230, 28)
		btn.pressed.connect(func():
			var pr := GuildSystem.promote()
			Game.say(String(pr["msg"]), UIKit.C_GOLD if pr["ok"] else UIKit.C_BAD)
			Audio.sfx("levelup" if pr["ok"] else "cancel"))
	elif qst == "available":
		btn = UIKit.button("Aceitar prova de avaliação", 230, 28)
		btn.pressed.connect(func():
			var ar := QuestSystem.accept(qid)
			Game.say(String(ar["msg"]), UIKit.C_TEXT if ar["ok"] else UIKit.C_BAD))
	elif qst == "active":
		btn = UIKit.button("Prova em andamento (veja 'Minhas missões')", 300, 28)
		btn.disabled = true
	else:
		btn = UIKit.button("Requisitos pendentes", 200, 28)
		btn.disabled = true
	actions.add_child(btn)
	if focus:
		btn.call_deferred("grab_focus")

func _ck(ok: bool) -> String:
	return "[color=#7fe08a]✔[/color]" if ok else "[color=#ff8a7a]✘[/color]"
