class_name DialogUI
extends Control
## Caixa de dialogo (maquina de escrever), escolhas e avisos (toasts). Uso com await:
##   await dialog.say("Lia", ["Ola!", "Como posso ajudar?"])
##   var i = await dialog.choose(["Sim", "Nao"], "Titulo")

signal _advanced
signal _chosen(index: int)

var box: PanelContainer
var name_label: Label
var text_label: RichTextLabel
var arrow: Label
var choice_panel: PanelContainer
var choice_box: VBoxContainer
var toast_box: VBoxContainer
var _typing: bool = false
var _full_text: String = ""
var _active: bool = false
var _choosing: bool = false
var _skip_requested: bool = false

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = UIKit.theme()
	box = UIKit.panel(Vector2(600, 84))
	box.position = Vector2(20, 264)
	box.size = Vector2(600, 84)
	box.visible = false
	box.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(box)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	box.add_child(vb)
	name_label = UIKit.label("", 13, UIKit.C_GOLD)
	vb.add_child(name_label)
	text_label = RichTextLabel.new()
	text_label.bbcode_enabled = true
	text_label.fit_content = false
	text_label.scroll_active = false
	text_label.custom_minimum_size = Vector2(570, 38)
	text_label.add_theme_font_size_override("normal_font_size", 14)
	text_label.add_theme_color_override("default_color", UIKit.C_TEXT)
	text_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(text_label)
	arrow = UIKit.label("▼", 12, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_RIGHT)
	arrow.visible = false
	arrow.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_child(arrow)
	box.gui_input.connect(_on_box_input)
	choice_panel = UIKit.panel()
	choice_panel.visible = false
	add_child(choice_panel)
	choice_box = VBoxContainer.new()
	choice_box.add_theme_constant_override("separation", 3)
	choice_panel.add_child(choice_box)
	toast_box = VBoxContainer.new()
	toast_box.position = Vector2(170, 240)
	toast_box.size = Vector2(300, 100)
	toast_box.alignment = BoxContainer.ALIGNMENT_END
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(toast_box)
	Controls.confirm_pressed.connect(_on_confirm)
	Game.toast.connect(show_toast)

func _on_box_input(ev: InputEvent) -> void:
	if (ev is InputEventMouseButton and ev.pressed) or (ev is InputEventScreenTouch and ev.pressed):
		_on_confirm()

func _on_confirm() -> void:
	if not _active or _choosing:
		return
	if _typing:
		_skip_requested = true
	else:
		_advanced.emit()

func is_active() -> bool:
	return _active

func say(speaker: String, lines: Array) -> void:
	Game.ui_lock += 1
	_active = true
	box.visible = true
	name_label.text = speaker
	name_label.visible = speaker != ""
	for line in lines:
		await _type(String(line))
		arrow.visible = true
		await _advanced
		arrow.visible = false
	box.visible = false
	_active = false
	Game.ui_lock -= 1
	Game.ui_closed_frame = Engine.get_process_frames()

func _type(text: String) -> void:
	_typing = true
	_skip_requested = false
	_full_text = text
	text_label.text = text
	text_label.visible_characters = 0
	var total := text_label.get_total_character_count()
	var i := 0
	while i < total and not _skip_requested:
		i += 1
		text_label.visible_characters = i
		if i % 2 == 0:
			await get_tree().create_timer(0.016).timeout
	text_label.visible_characters = -1
	_typing = false

## Mostra uma lista de opcoes; retorna o indice escolhido (-1 se cancelar e allow_cancel).
func choose(options: Array, title: String = "", allow_cancel: bool = false, pos: Vector2 = Vector2(430, 150)) -> int:
	Game.ui_lock += 1
	_choosing = true
	UIKit.clear(choice_box)
	if title != "":
		choice_box.add_child(UIKit.label(title, 12, UIKit.C_GOLD))
	var first: Button = null
	for i in range(options.size()):
		var b := UIKit.button(String(options[i]), 150, 28)
		b.pressed.connect(func(): _chosen.emit(i))
		choice_box.add_child(b)
		if first == null:
			first = b
	choice_panel.visible = true
	choice_panel.reset_size()
	choice_panel.position = Vector2(clampf(pos.x, 4.0, 636.0 - choice_panel.size.x), clampf(pos.y - choice_panel.size.y, 4.0, 340.0 - choice_panel.size.y))
	if first:
		first.grab_focus()
	var cancel_cb := func():
		if allow_cancel:
			_chosen.emit(-1)
	Controls.cancel_pressed.connect(cancel_cb)
	var idx: int = await _chosen
	Controls.cancel_pressed.disconnect(cancel_cb)
	choice_panel.visible = false
	_choosing = false
	Game.ui_lock -= 1
	return idx

func show_toast(text: String, color: Color = Color.WHITE) -> void:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UIKit.box(Color(0.05, 0.07, 0.18, 0.92), UIKit.C_BORDER_DK, 1, 3, 3))
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l := UIKit.label(text, 13, color)
	p.add_child(l)
	toast_box.add_child(p)
	var tw := create_tween()
	tw.tween_interval(2.4)
	tw.tween_property(p, "modulate:a", 0.0, 0.5)
	tw.tween_callback(p.queue_free)
	while toast_box.get_child_count() > 6:
		toast_box.get_child(0).queue_free()
		toast_box.remove_child(toast_box.get_child(0))
