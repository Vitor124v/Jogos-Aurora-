class_name UIRoot
extends CanvasLayer
## Camada de interface: agrupa HUD, dialogo, menus, loja, guilda, batalha, fade e controles de toque.

var hud: Hud
var dialog: DialogUI
var pause: PauseMenu
var shop: ShopUI
var guild: GuildUI
var battle: BattleUI
var touch: TouchControls
var fade_rect: ColorRect
var title_holder: Control

func _ready() -> void:
	layer = 10
	title_holder = Control.new()
	title_holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	title_holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(title_holder)
	hud = Hud.new()
	add_child(hud)
	touch = TouchControls.new()
	add_child(touch)
	battle = BattleUI.new()
	add_child(battle)
	pause = PauseMenu.new()
	add_child(pause)
	shop = ShopUI.new()
	add_child(shop)
	guild = GuildUI.new()
	add_child(guild)
	dialog = DialogUI.new()
	add_child(dialog)
	pause.set_meta("dialog", dialog)
	fade_rect = ColorRect.new()
	fade_rect.color = Color(0, 0, 0, 1)
	fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade_rect.modulate.a = 0.0
	fade_rect.z_index = 100
	add_child(fade_rect)

func fade(to_alpha: float, dur: float = 0.3) -> void:
	var tw := create_tween()
	tw.tween_property(fade_rect, "modulate:a", to_alpha, dur)
	await tw.finished

func set_game_ui(on: bool) -> void:
	hud.visible = on
	if on:
		hud.refresh()
