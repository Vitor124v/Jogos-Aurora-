class_name TouchControls
extends Control
## Controles virtuais com multitoque real (direcional + A/B + Menu). Tambem aceita mouse (para testes).

const PAD_C := Vector2(64, 290)
const PAD_R := 46.0
const A_C := Vector2(588, 296)
const B_C := Vector2(538, 322)
const MENU_RECT := Rect2(584, 6, 52, 24)

var touches: Dictionary = {}     # index -> "pad" | "a" | "b" | "menu"
var pad_vec: Vector2i = Vector2i.ZERO
var pad_knob: Vector2 = Vector2.ZERO

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	Game.changed.connect(queue_redraw)

func _process(_d: float) -> void:
	var want := Controls.touch_enabled and Game.has_game and Game.ui_lock == 0 and not Game.in_battle
	if visible != want:
		visible = want
		if not want:
			_release_all()

func _release_all() -> void:
	touches.clear()
	pad_vec = Vector2i.ZERO
	Controls.touch_dir = Vector2i.ZERO
	pad_knob = Vector2.ZERO
	queue_redraw()

func _region(p: Vector2) -> String:
	if p.distance_to(PAD_C) <= PAD_R + 22.0:
		return "pad"
	if p.distance_to(A_C) <= 30.0:
		return "a"
	if p.distance_to(B_C) <= 26.0:
		return "b"
	if MENU_RECT.grow(8).has_point(p):
		return "menu"
	return ""

func _input(ev: InputEvent) -> void:
	if not visible:
		return
	var idx := -99
	var pos := Vector2.ZERO
	var pressed := false
	var is_drag := false
	if ev is InputEventScreenTouch:
		idx = ev.index
		pos = _to_local(ev.position)
		pressed = ev.pressed
	elif ev is InputEventScreenDrag:
		idx = ev.index
		pos = _to_local(ev.position)
		is_drag = true
	elif ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT and not Controls.is_touch_device:
		idx = -1
		pos = _to_local(ev.position)
		pressed = ev.pressed
	elif ev is InputEventMouseMotion and touches.has(-1) and (ev.button_mask & MOUSE_BUTTON_MASK_LEFT) != 0:
		idx = -1
		pos = _to_local(ev.position)
		is_drag = true
	else:
		return
	if is_drag:
		if touches.get(idx, "") == "pad":
			_update_pad(pos)
		return
	if pressed:
		var r := _region(pos)
		if r == "":
			return
		touches[idx] = r
		match r:
			"pad": _update_pad(pos)
			"a": Controls.virtual_press("confirm")
			"b": Controls.virtual_press("cancel")
			"menu": Controls.virtual_press("menu")
		queue_redraw()
	else:
		if touches.get(idx, "") == "pad":
			pad_vec = Vector2i.ZERO
			Controls.touch_dir = Vector2i.ZERO
			pad_knob = Vector2.ZERO
		touches.erase(idx)
		queue_redraw()

func _to_local(screen_pos: Vector2) -> Vector2:
	# converte coordenadas da janela para o espaco 640x360 do canvas
	# eventos do viewport ja chegam em coordenadas 640x360; so desfaz a transformacao do canvas
	return get_global_transform_with_canvas().affine_inverse() * screen_pos

func _update_pad(p: Vector2) -> void:
	var d := p - PAD_C
	pad_knob = d.limit_length(PAD_R)
	var dir := Vector2i.ZERO
	if d.length() > 12.0:
		if absf(d.x) > absf(d.y):
			dir = Vector2i(1 if d.x > 0 else -1, 0)
		else:
			dir = Vector2i(0, 1 if d.y > 0 else -1)
	pad_vec = dir
	Controls.touch_dir = dir
	queue_redraw()

func _draw() -> void:
	var a := 0.38
	draw_circle(PAD_C, PAD_R + 6.0, Color(0.05, 0.07, 0.18, a))
	draw_arc(PAD_C, PAD_R + 6.0, 0, TAU, 40, Color(1, 1, 1, a + 0.15), 2.0)
	for d in [Vector2(0, -1), Vector2(0, 1), Vector2(-1, 0), Vector2(1, 0)]:
		var tip: Vector2 = PAD_C + d * 30.0
		var side := Vector2(-d.y, d.x) * 8.0
		draw_colored_polygon(PackedVector2Array([tip + d * 8.0, tip - d * 2.0 + side, tip - d * 2.0 - side]), Color(1, 1, 1, 0.6))
	draw_circle(PAD_C + pad_knob, 15.0, Color(1, 1, 1, 0.35 if pad_vec == Vector2i.ZERO else 0.6))
	var font := ThemeDB.fallback_font
	var a_on := touches.values().has("a")
	var b_on := touches.values().has("b")
	draw_circle(A_C, 26.0, Color(0.2, 0.55, 0.3, 0.75 if a_on else 0.45))
	draw_arc(A_C, 26.0, 0, TAU, 32, Color(1, 1, 1, 0.7), 2.0)
	draw_string(font, A_C + Vector2(-5, 6), "A", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(1, 1, 1, 0.95))
	draw_circle(B_C, 21.0, Color(0.6, 0.25, 0.25, 0.75 if b_on else 0.45))
	draw_arc(B_C, 21.0, 0, TAU, 32, Color(1, 1, 1, 0.7), 2.0)
	draw_string(font, B_C + Vector2(-5, 6), "B", HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1, 1, 1, 0.95))
	draw_rect(MENU_RECT, Color(0.1, 0.12, 0.3, 0.7 if touches.values().has("menu") else 0.5))
	draw_rect(MENU_RECT, Color(1, 1, 1, 0.7), false, 1.5)
	draw_string(font, MENU_RECT.position + Vector2(8, 17), "MENU", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(1, 1, 1, 0.95))
