class_name Hud
extends Control
## HUD de exploracao: nome, HP/MP, ouro, local e indicador de missao pronta.

var panel: PanelContainer
var name_lbl: Label
var hp_bar: UIKit.Bar
var mp_bar: UIKit.Bar
var gold_lbl: Label
var loc_lbl: Label
var quest_lbl: Label
var banner: Label
var _banner_tween: Tween

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = UIKit.theme()
	panel = UIKit.panel()
	panel.position = Vector2(4, 4)
	panel.add_theme_stylebox_override("panel", UIKit.box(Color(0.05, 0.07, 0.18, 0.82), UIKit.C_BORDER_DK, 1, 3, 3))
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 1)
	panel.add_child(v)
	name_lbl = UIKit.label("", 12, UIKit.C_GOLD)
	v.add_child(name_lbl)
	var r1 := HBoxContainer.new()
	r1.add_theme_constant_override("separation", 3)
	r1.add_child(UIKit.label("HP", 10, UIKit.C_HP))
	hp_bar = UIKit.bar(96, 11, UIKit.C_HP)
	r1.add_child(hp_bar)
	v.add_child(r1)
	var r2 := HBoxContainer.new()
	r2.add_theme_constant_override("separation", 3)
	r2.add_child(UIKit.label("MP", 10, UIKit.C_MP))
	mp_bar = UIKit.bar(96, 11, UIKit.C_MP)
	r2.add_child(mp_bar)
	v.add_child(r2)
	gold_lbl = UIKit.label("", 11, UIKit.C_GOLD)
	v.add_child(gold_lbl)
	loc_lbl = UIKit.label("", 11, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_RIGHT)
	loc_lbl.position = Vector2(440, 6)
	loc_lbl.size = Vector2(196, 16)
	loc_lbl.add_theme_constant_override("outline_size", 3)
	add_child(loc_lbl)
	quest_lbl = UIKit.label("", 11, UIKit.C_HP, HORIZONTAL_ALIGNMENT_RIGHT)
	quest_lbl.position = Vector2(400, 22)
	quest_lbl.size = Vector2(236, 16)
	add_child(quest_lbl)
	banner = UIKit.label("", 18, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	banner.position = Vector2(120, 60)
	banner.size = Vector2(400, 28)
	banner.add_theme_constant_override("outline_size", 5)
	banner.modulate.a = 0.0
	add_child(banner)
	Game.changed.connect(refresh)
	visible = false

func refresh() -> void:
	if not Game.has_game or Game.s.is_empty():
		return
	name_lbl.text = "%s  Nv%d" % [Game.s["hero_name"], int(Game.s["level"])]
	hp_bar.set_values(int(Game.s["hp"]), Game.max_hp())
	mp_bar.set_values(int(Game.s["mp"]), Game.max_mp())
	gold_lbl.text = "Ouro %d" % int(Game.s["gold"])
	var ready := QuestSystem.ready_ids()
	quest_lbl.text = "✔ %d missão(ões) pronta(s) — entregue na Guilda" % ready.size() if ready.size() > 0 else ""

func set_location(text: String) -> void:
	loc_lbl.text = text

func show_banner(text: String) -> void:
	banner.text = text
	if _banner_tween:
		_banner_tween.kill()
	banner.modulate.a = 0.0
	_banner_tween = create_tween()
	_banner_tween.tween_property(banner, "modulate:a", 1.0, 0.3)
	_banner_tween.tween_interval(1.6)
	_banner_tween.tween_property(banner, "modulate:a", 0.0, 0.6)
