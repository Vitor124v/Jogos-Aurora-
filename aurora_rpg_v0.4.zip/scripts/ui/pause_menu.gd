class_name PauseMenu
extends Modal
## Menu principal em jogo: status, inventario, equipamentos, habilidades, missoes, salvar, opcoes.

signal request_town
signal request_title

var nav: VBoxContainer
var content: Control
var page: String = "status"
var in_dungeon: bool = false
var _sel_item: String = ""

func _init() -> void:
	super._init("Menu", true)
	menu_closes = true

func _top_most() -> bool:
	var d: DialogUI = get_meta("dialog") if has_meta("dialog") else null
	return d == null or not d._choosing

func _build() -> void:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	h.size = Vector2(596, 296)
	body.add_child(h)
	nav = VBoxContainer.new()
	nav.add_theme_constant_override("separation", 2)
	nav.custom_minimum_size = Vector2(116, 0)
	h.add_child(nav)
	content = Control.new()
	content.custom_minimum_size = Vector2(472, 296)
	h.add_child(content)

func on_open() -> void:
	_build_nav()
	_show_page("status")
	focus_first(nav)

func on_changed() -> void:
	if page in ["status", "inventory", "equipment", "skills", "quests"]:
		_show_page(page, false)

func _build_nav() -> void:
	UIKit.clear(nav)
	var entries := [["Status", "status"], ["Itens", "inventory"], ["Equipar", "equipment"], ["Habilidades", "skills"], ["Missões", "quests"], ["Mapa", "map"], ["Salvar", "save"], ["Opções", "options"]]
	for e in entries:
		var b := UIKit.button(e[0], 116, 26)
		var pid: String = e[1]
		b.pressed.connect(func(): _show_page(pid))
		b.focus_entered.connect(func(): if pid not in ["save"]: _show_page(pid))
		nav.add_child(b)
	if in_dungeon:
		var bt := UIKit.button("Voltar à vila", 116, 26)
		bt.pressed.connect(_ask_town)
		nav.add_child(bt)
	var bm := UIKit.button("Menu principal", 116, 26)
	bm.pressed.connect(_ask_title)
	nav.add_child(bm)

func _ask_town() -> void:
	var d: DialogUI = get_meta("dialog")
	var r := await d.choose(["Sim, voltar", "Cancelar"], "Retornar à Vila Aurora?", true, Vector2(300, 220))
	if r == 0:
		close()
		request_town.emit()

func _ask_title() -> void:
	var d: DialogUI = get_meta("dialog")
	var r := await d.choose(["Salvar e sair", "Sair sem salvar", "Cancelar"], "Voltar ao menu principal?", true, Vector2(300, 240))
	if r == 0:
		var s := Game.save_game()
		if not s["ok"]:
			Game.say(String(s["error"]), UIKit.C_BAD)
			return
		close()
		request_title.emit()
	elif r == 1:
		close()
		request_title.emit()

func _show_page(p: String, grab: bool = true) -> void:
	page = p
	UIKit.clear(content)
	match p:
		"status": _page_status()
		"inventory": _page_inventory()
		"equipment": _page_equipment()
		"skills": _page_skills()
		"quests": _page_quests()
		"map": _page_map()
		"save": _page_save()
		"options": _page_options()

# ------------------------------------------------------------------ mapa da ilha
func _page_map() -> void:
	var im := MapDB.get_map(MapDB.HUB)
	var cur := String(Game.s["world"]["map"])
	var on_island := cur == MapDB.HUB
	var img := IslandArt.minimap_image(im)
	var marker := Vector2i(-1, -1)
	if on_island:
		marker = Vector2i(int(Game.s["world"]["x"]), int(Game.s["world"]["y"]))
	elif cur == "forest" or cur.begins_with("dg_"):
		marker = IlhaData.TRAIN_PORTAL
	if marker.x >= 0:
		for dy in range(-1, 2):
			for dx in range(-1, 2):
				var c := Color(1, 1, 1) if (dx == 0 and dy == 0) else Color(0.9, 0.1, 0.1)
				if marker.x + dx >= 0 and marker.y + dy >= 0 and marker.x + dx < img.get_width() and marker.y + dy < img.get_height():
					img.set_pixel(marker.x + dx, marker.y + dy, c)
	img.resize(img.get_width() * 2, img.get_height() * 2, Image.INTERPOLATE_NEAREST)
	var holder := Control.new()
	holder.position = Vector2(0, 2)
	holder.custom_minimum_size = Vector2(img.get_width(), img.get_height())
	content.add_child(holder)
	var tr := TextureRect.new()
	tr.texture = ImageTexture.create_from_image(img)
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	holder.add_child(tr)
	for c2 in IlhaData.CITIES:
		var lb := UIKit.label(String(c2["name"]), 9, Color(1, 1, 1))
		lb.add_theme_constant_override("outline_size", 4)
		lb.add_theme_color_override("font_outline_color", Color(0, 0, 0))
		lb.position = Vector2(float(c2["x"]) * 2.0 - 6.0 * float(String(c2["name"]).length()) / 2.0 * 0.8, float(c2["y"]) * 2.0 - 6.0)
		holder.add_child(lb)
	var side := VBoxContainer.new()
	side.position = Vector2(img.get_width() + 6, 4)
	content.add_child(side)
	side.add_child(UIKit.label("Ilha de Aurora", 12, UIKit.C_GOLD))
	if marker.x >= 0:
		side.add_child(UIKit.label("● Você", 11, Color(1.0, 0.4, 0.4)))
	if not on_island:
		side.add_child(UIKit.label("(fora da ilha)", 10, UIKit.C_DIM))

# ------------------------------------------------------------------ status
func _page_status() -> void:
	var s := Game.s
	var st := Game.stats()
	var eq := Game.equipment_bonus()
	var cd := HeroDB.get_class_data(String(s["class_id"]))
	var root := HBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	content.add_child(root)
	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(190, 0)
	left.add_theme_constant_override("separation", 3)
	root.add_child(left)
	var top := HBoxContainer.new()
	top.add_child(UIKit.icon_rect(PixelArt.portrait(String(s["class_id"])), 56))
	var tv := VBoxContainer.new()
	tv.add_child(UIKit.label(String(s["hero_name"]), 16, UIKit.C_GOLD))
	tv.add_child(UIKit.label("%s  Nv %d" % [cd["name"], int(s["level"])], 13))
	tv.add_child(UIKit.label("Rank %s • %d rep." % [GuildSystem.rank(), GuildSystem.reputation()], 12, UIKit.C_DIM))
	top.add_child(tv)
	left.add_child(top)
	var hp := UIKit.bar(180, 14, UIKit.C_HP)
	hp.set_values(int(s["hp"]), Game.max_hp())
	left.add_child(UIKit.label("HP", 11, UIKit.C_HP))
	left.add_child(hp)
	var mp := UIKit.bar(180, 14, UIKit.C_MP)
	mp.set_values(int(s["mp"]), Game.max_mp())
	left.add_child(UIKit.label("MP", 11, UIKit.C_MP))
	left.add_child(mp)
	var ex := Game.exp_progress()
	var xb := UIKit.bar(180, 14, UIKit.C_EXP)
	xb.set_values(ex.x, maxi(ex.y, 1))
	left.add_child(UIKit.label("EXP" if ex.y > 0 else "EXP (nível máx.)", 11, UIKit.C_EXP))
	left.add_child(xb)
	left.add_child(UIKit.label("Ouro: %d" % int(s["gold"]), 13, UIKit.C_GOLD))
	left.add_child(UIKit.label("Tempo: %s" % Game.format_play_time(), 12, UIKit.C_DIM))
	var kills := 0
	for k in s["kills"]:
		kills += int(s["kills"][k])
	left.add_child(UIKit.label("Monstros derrotados: %d" % kills, 12, UIKit.C_DIM))
	left.add_child(UIKit.label("Foco: %s" % cd["focus"], 12, UIKit.C_DIM))
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 1)
	root.add_child(right)
	right.add_child(UIKit.label("Atributos", 14, UIKit.C_GOLD))
	var rows := [["Força", "str"], ["Inteligência", "int"], ["Vitalidade", "vit"], ["Agilidade", "agi"], ["Defesa", "def"], ["Destreza", "dex"], ["Fé", "faith"]]
	for r in rows:
		var hb := HBoxContainer.new()
		var l := UIKit.label(r[0], 13)
		l.custom_minimum_size = Vector2(96, 0)
		hb.add_child(l)
		var v := UIKit.label(str(int(st[r[1]])), 13, UIKit.C_TEXT)
		v.custom_minimum_size = Vector2(32, 0)
		hb.add_child(v)
		var bonus := int(eq.get(r[1], 0))
		if bonus != 0:
			hb.add_child(UIKit.label("(%+d equip.)" % bonus, 11, UIKit.C_HP if bonus > 0 else UIKit.C_BAD))
		right.add_child(hb)
	right.add_child(UIKit.label("HP máx.: %d   MP máx.: %d" % [Game.max_hp(), Game.max_mp()], 12, UIKit.C_DIM))
	right.add_child(UIKit.label("Def. mágica: %d   Crítico: %d%%" % [int(st["mdef"]), int(Formulas.crit_chance(float(st["dex"]), float(st["crit_bonus"])) * 100.0)], 12, UIKit.C_DIM))
	var unlocked: Array = s["unlocks"]["classes"]
	if unlocked.size() > 0:
		var names: Array = []
		for u in unlocked:
			names.append(HeroDB.SPECIAL_CLASSES[u]["name"])
		right.add_child(UIKit.label("Classes especiais desbloqueadas:\n%s" % ", ".join(names), 11, UIKit.C_GOLD))

# ------------------------------------------------------------------ inventario
func _page_inventory() -> void:
	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 8)
	content.add_child(cols)
	var lst := make_list(250, 292)
	cols.add_child(lst[0])
	var list: VBoxContainer = lst[1]
	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(206, 0)
	right.add_theme_constant_override("separation", 3)
	cols.add_child(right)
	var detail := RichTextLabel.new()
	detail.bbcode_enabled = true
	detail.fit_content = true
	detail.custom_minimum_size = Vector2(206, 150)
	detail.add_theme_font_size_override("normal_font_size", 12)
	detail.mouse_filter = Control.MOUSE_FILTER_IGNORE
	right.add_child(detail)
	var actions := VBoxContainer.new()
	right.add_child(actions)
	var ids: Array = Game.s["inventory"].keys()
	ids.sort_custom(func(a, b):
		var order := {"consumable": 0, "weapon": 1, "armor": 2, "accessory": 3, "material": 4}
		var ia := ItemDB.get_item(a)
		var ib := ItemDB.get_item(b)
		if order[ia["type"]] != order[ib["type"]]:
			return order[ia["type"]] < order[ib["type"]]
		return String(ia["name"]) < String(ib["name"]))
	list.add_child(UIKit.label("Inventário  %d/%d" % [ids.size(), Balance.INVENTORY_LIMIT], 12, UIKit.C_DIM))
	if ids.is_empty():
		detail.text = "Seu inventário está vazio."
	var focus_target: Button = null
	for id in ids:
		var it := ItemDB.get_item(id)
		var b := UIKit.button("%s  x%d" % [it["name"], Game.item_count(id)], 0, 24)
		UIKit.pad_button(b, 30)
		b.add_theme_font_size_override("font_size", 13)
		b.add_theme_color_override("font_color", ItemDB.rarity_color(id))
		var ic := UIKit.icon_rect(PixelArt.item_icon(id), 20)
		ic.position = Vector2(4, 2)
		b.add_child(ic)
		var iid: String = id
		b.focus_entered.connect(func(): _item_detail(iid, detail, actions))
		b.mouse_entered.connect(func(): _item_detail(iid, detail, actions))
		b.pressed.connect(func(): _item_detail(iid, detail, actions))
		list.add_child(b)
		if _sel_item == id or (focus_target == null and _sel_item == ""):
			focus_target = b
	if focus_target == null and list.get_child_count() > 1:
		focus_target = list.get_child(1) as Button
	if focus_target != null:
		_item_detail(String(ids[maxi(0, list.get_children().find(focus_target) - 1)]), detail, actions)

func _item_detail(id: String, detail: RichTextLabel, actions: VBoxContainer) -> void:
	_sel_item = id
	var it := ItemDB.get_item(id)
	if it.is_empty():
		return
	var rc: Color = ItemDB.rarity_color(id)
	var t := "[color=#%s][b]%s[/b][/color]\n" % [rc.to_html(false), it["name"]]
	t += "[color=#8fb0ff]%s[/color]\n" % _type_label(it)
	if it["type"] in ["weapon", "armor", "accessory"]:
		t += "%s\n" % UIKit.stat_line(it["stats"])
		var req := int(it.get("req_level", 1))
		var chk := ItemDB.can_equip(id, String(Game.s["class_id"]), int(Game.s["level"]))
		if not chk["ok"]:
			t += "[color=#ff8a7a]%s[/color]\n" % chk["reason"]
		else:
			var cur: String = Game.s["equipment"].get(it["slot"], "")
			if cur != "":
				t += "[color=#8fb0ff]Equipado:[/color] %s\n" % ItemDB.get_item(cur)["name"]
		t += "Nível requerido: %d\n" % req
	else:
		t += "%s\n" % it.get("desc", "")
	t += "[color=#ffd84a]Valor de venda: %d[/color]" % ItemDB.sell_price(id)
	detail.text = t
	UIKit.clear(actions)
	if it["type"] == "consumable":
		var b := UIKit.button("Usar", 0, 24)
		b.disabled = bool(it.get("battle_only", false))
		b.pressed.connect(func(): _use_item(id))
		actions.add_child(b)
	elif it["type"] in ["weapon", "armor", "accessory"]:
		var chk2 := ItemDB.can_equip(id, String(Game.s["class_id"]), int(Game.s["level"]))
		var be := UIKit.button("Equipar", 0, 24)
		be.disabled = not chk2["ok"]
		be.pressed.connect(func():
			var r := Game.equip(id)
			Game.say(String(r["msg"]), UIKit.C_TEXT if r["ok"] else UIKit.C_BAD)
			Audio.sfx("confirm" if r["ok"] else "cancel"))
		actions.add_child(be)

func _type_label(it: Dictionary) -> String:
	var rar: String = ItemDB.RARITY[it["rarity"]]["name"]
	match it["type"]:
		"weapon": return "Arma • %s" % rar
		"armor": return "Armadura • %s" % rar
		"accessory": return "Acessório • %s" % rar
		"consumable": return "Consumível"
		_: return "Material"

func _use_item(id: String) -> void:
	var r := Game.use_item_field(id)
	Game.say(String(r["msg"]), UIKit.C_TEXT if r["ok"] else UIKit.C_BAD)
	Audio.sfx("heal" if r["ok"] else "cancel")
	if r["ok"] and r.get("action", "") == "town_return":
		Game.remove_item(id, 1)
		close()
		request_town.emit()

# ------------------------------------------------------------------ equipamentos
func _page_equipment() -> void:
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 4)
	content.add_child(root)
	root.add_child(UIKit.label("Equipamentos (os bônus alteram seus atributos)", 13, UIKit.C_GOLD))
	for slot in ["weapon", "armor", "accessory"]:
		var id: String = Game.s["equipment"][slot]
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 6)
		var sl := UIKit.label(ItemDB.SLOT_NAMES[slot], 13, UIKit.C_DIM)
		sl.custom_minimum_size = Vector2(76, 0)
		hb.add_child(sl)
		if id != "":
			hb.add_child(UIKit.icon_rect(PixelArt.item_icon(id), 22))
			var nl := UIKit.label(ItemDB.get_item(id)["name"], 13, ItemDB.rarity_color(id))
			nl.custom_minimum_size = Vector2(150, 0)
			hb.add_child(nl)
			hb.add_child(UIKit.label(UIKit.stat_line(ItemDB.get_item(id)["stats"]), 11, UIKit.C_DIM))
		else:
			hb.add_child(UIKit.label("— vazio —", 13, UIKit.C_DIM))
		root.add_child(hb)
		var rb := HBoxContainer.new()
		var bt := UIKit.button("Trocar %s" % ItemDB.SLOT_NAMES[slot], 150, 22)
		bt.pressed.connect(func(): _equip_picker(slot))
		rb.add_child(bt)
		if id != "":
			var br := UIKit.button("Remover", 90, 22)
			br.pressed.connect(func():
				var r := Game.unequip(slot)
				Game.say(String(r["msg"]), UIKit.C_TEXT if r["ok"] else UIKit.C_BAD))
			rb.add_child(br)
		root.add_child(rb)

func _equip_picker(slot: String) -> void:
	UIKit.clear(content)
	var root := VBoxContainer.new()
	content.add_child(root)
	root.add_child(UIKit.label("Escolha: %s" % ItemDB.SLOT_NAMES[slot], 13, UIKit.C_GOLD))
	var lst := make_list(460, 236)
	root.add_child(lst[0])
	var list: VBoxContainer = lst[1]
	var any := false
	for id in Game.s["inventory"]:
		var it := ItemDB.get_item(id)
		if it.get("slot", "") != slot:
			continue
		any = true
		var chk := ItemDB.can_equip(id, String(Game.s["class_id"]), int(Game.s["level"]))
		var b := UIKit.button("%s   %s" % [it["name"], UIKit.stat_line(it["stats"])], 0, 24)
		UIKit.pad_button(b, 30)
		b.add_theme_font_size_override("font_size", 12)
		b.add_theme_color_override("font_color", ItemDB.rarity_color(id) if chk["ok"] else Color(0.5, 0.5, 0.55))
		b.add_child(UIKit.icon_rect(PixelArt.item_icon(id), 20))
		b.get_child(0).position = Vector2(4, 2)
		var iid: String = id
		b.pressed.connect(func():
			var r := Game.equip(iid)
			Game.say(String(r["msg"]), UIKit.C_TEXT if r["ok"] else UIKit.C_BAD)
			if r["ok"]:
				_show_page("equipment"))
		if not chk["ok"]:
			b.tooltip_text = chk["reason"]
			b.text += "  [Nv %d]" % int(it["req_level"]) if "Nível" in chk["reason"] else "  [classe]"
		list.add_child(b)
	if not any:
		list.add_child(UIKit.label("Nenhum item deste tipo no inventário.", 12, UIKit.C_DIM))
	var back := UIKit.button("« Voltar", 100, 24)
	back.pressed.connect(func(): _show_page("equipment"))
	root.add_child(back)
	focus_first(list)

# ------------------------------------------------------------------ habilidades
func _page_skills() -> void:
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 3)
	content.add_child(root)
	root.add_child(UIKit.label("Habilidades de %s" % Game.class_name_text(), 14, UIKit.C_GOLD))
	var known := Game.skills_known()
	for sid in known:
		var sk := SkillDB.get_skill(sid)
		var hb := HBoxContainer.new()
		var n := UIKit.label(sk["name"], 13)
		n.custom_minimum_size = Vector2(130, 0)
		hb.add_child(n)
		var m := UIKit.label("%d MP" % int(sk.get("mp", 0)), 12, UIKit.C_MP)
		m.custom_minimum_size = Vector2(50, 0)
		hb.add_child(m)
		hb.add_child(UIKit.label(String(sk.get("desc", "")), 11, UIKit.C_DIM))
		root.add_child(hb)
	for entry in HeroDB.get_class_data(String(Game.s["class_id"]))["skills"]:
		if int(entry[1]) > int(Game.s["level"]):
			var sk2 := SkillDB.get_skill(String(entry[0]))
			root.add_child(UIKit.label("🔒 %s — no nível %d" % [sk2["name"], int(entry[1])], 12, UIKit.C_DIM))

# ------------------------------------------------------------------ missoes
func _page_quests() -> void:
	var lst := make_list(468, 292)
	content.add_child(lst[0])
	var list: VBoxContainer = lst[1]
	list.add_child(UIKit.label("Missões ativas", 14, UIKit.C_GOLD))
	var n := 0
	for qid in Game.s["quests"]:
		if Game.s["quests"][qid]["state"] != "active":
			continue
		n += 1
		var q: Dictionary = QuestDB.QUESTS[qid]
		var ready := QuestSystem.is_ready(qid)
		list.add_child(UIKit.label("%s  [Rank %s]%s" % [q["name"], q["rank"], "  ✔ Pronta! Entregue na guilda" if ready else ""], 13, UIKit.C_HP if ready else UIKit.C_TEXT))
		list.add_child(UIKit.label(QuestSystem.progress_text(qid), 12, UIKit.C_DIM))
	if n == 0:
		list.add_child(UIKit.label("Nenhuma missão ativa. Visite a Guilda na vila.", 12, UIKit.C_DIM))

# ------------------------------------------------------------------ salvar
func _page_save() -> void:
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 6)
	content.add_child(root)
	root.add_child(UIKit.label("Salvar partida", 14, UIKit.C_GOLD))
	root.add_child(UIKit.label("O jogo salva a classe, nível, atributos, itens, equipamentos,\nmissões, guilda, progresso da masmorra e sua posição.", 12, UIKit.C_DIM))
	var status := UIKit.label("", 13, UIKit.C_HP)
	var b := UIKit.button("Salvar agora", 160, 28)
	b.pressed.connect(func():
		var r := Game.save_game()
		if r["ok"]:
			status.text = "Jogo salvo com sucesso!"
			status.add_theme_color_override("font_color", UIKit.C_HP)
			Audio.sfx("confirm")
		else:
			status.text = String(r["error"])
			status.add_theme_color_override("font_color", UIKit.C_BAD))
	root.add_child(b)
	root.add_child(status)
	b.call_deferred("grab_focus")

# ------------------------------------------------------------------ opcoes
func _page_options() -> void:
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	content.add_child(root)
	root.add_child(UIKit.label("Opções", 14, UIKit.C_GOLD))
	var rows := [["Volume da música", "music"], ["Volume dos efeitos", "sfx"]]
	for r in rows:
		var hb := HBoxContainer.new()
		var l := UIKit.label(r[0], 13)
		l.custom_minimum_size = Vector2(150, 0)
		hb.add_child(l)
		var sl := HSlider.new()
		sl.min_value = 0
		sl.max_value = 1
		sl.step = 0.05
		sl.value = float(Game.settings[r[1]])
		sl.custom_minimum_size = Vector2(200, 22)
		var key: String = r[1]
		sl.value_changed.connect(func(v: float):
			if key == "music":
				Audio.set_music_volume(v)
			else:
				Audio.set_sfx_volume(v)
				Audio.sfx("select")
			Game.save_settings())
		hb.add_child(sl)
		root.add_child(hb)
	var th := HBoxContainer.new()
	var tl := UIKit.label("Controles de toque", 13)
	tl.custom_minimum_size = Vector2(150, 0)
	th.add_child(tl)
	var ob := OptionButton.new()
	ob.add_item("Automático", 0)
	ob.add_item("Sempre ligado", 1)
	ob.add_item("Desligado", 2)
	ob.selected = int(Game.settings["touch"])
	ob.item_selected.connect(func(i: int):
		Game.settings["touch"] = i
		Game.save_settings()
		Controls.refresh_touch_setting()
		Game.changed.emit())
	th.add_child(ob)
	root.add_child(th)
	var cb := CheckBox.new()
	cb.text = "Escala inteira (pixels mais nítidos, com bordas pretas)"
	cb.button_pressed = bool(Game.settings["integer_scale"])
	cb.toggled.connect(func(v: bool):
		Game.settings["integer_scale"] = v
		Game.save_settings()
		get_window().content_scale_stretch = Window.CONTENT_SCALE_STRETCH_INTEGER if v else Window.CONTENT_SCALE_STRETCH_FRACTIONAL)
	root.add_child(cb)
	root.add_child(UIKit.label("Teclado: setas/WASD mover • Z/Enter/Espaço confirmar • X/Esc cancelar • Tab menu • Shift correr", 11, UIKit.C_DIM))
