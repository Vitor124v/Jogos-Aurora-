extends Node2D
func _ready() -> void:
	await get_tree().process_frame
	var bg := ColorRect.new()
	bg.color = Color(0.2, 0.2, 0.25)
	bg.size = Vector2(640, 360)
	add_child(bg)
	# tiles
	var chars := ".,pTwWRD_cbr#:x<>Sho"
	for i in range(chars.length()):
		var s := Sprite2D.new()
		s.texture = ImageTexture.create_from_image(PixelArt.tile_image(chars[i], i, 3, 5))
		s.centered = false
		s.position = Vector2(8 + i * 17, 8)
		add_child(s)
	# personagens
	var looks := ["warrior", "mage", "rogue", "paladin", "elder", "villager_f", "guard", "shopkeeper"]
	for i in range(looks.size()):
		var fr := PixelArt.char_frames(PixelArt.look_for(looks[i]))
		for d in range(4):
			var s := Sprite2D.new()
			s.texture = fr[["down", "up", "left", "right"][d]][0]
			s.centered = false
			s.position = Vector2(8 + i * 70 + d * 16, 34)
			add_child(s)
	# inimigos
	var ids := EnemyDB.ENEMIES.keys()
	for i in range(ids.size()):
		var e: Dictionary = EnemyDB.ENEMIES[ids[i]]
		var sz := 48 if not e.get("boss", false) else 64
		var s := Sprite2D.new()
		s.texture = PixelArt.enemy_texture(e["sprite"], e["color"], sz)
		s.centered = false
		s.position = Vector2(8 + (i % 8) * 78, 70 + (i / 8) * 70)
		add_child(s)
	# objetos e icones
	var objs := ["chest", "bush", "rest", "stone", "sign", "board"]
	for i in range(objs.size()):
		var s := Sprite2D.new()
		s.texture = PixelArt.object_texture(objs[i], "")
		s.centered = false
		s.position = Vector2(8 + i * 18, 215)
		add_child(s)
	var items := ["espada_de_ferro", "cajado_arcano", "adaga_gasta", "maca_abencoada", "cota_de_malha", "roupa_de_couro", "tunica_simples", "amuleto_de_vida", "pocao", "eter", "bomba", "pergaminho_retorno", "erva_curativa", "osso_antigo", "pedra_runica", "nucleo_de_slime"]
	for i in range(items.size()):
		var s := Sprite2D.new()
		s.texture = PixelArt.item_icon(items[i])
		s.centered = false
		s.position = Vector2(8 + i * 18, 240)
		add_child(s)
	var bgt := Sprite2D.new()
	bgt.texture = PixelArt.battle_background("forest", 320, 100)
	bgt.centered = false
	bgt.position = Vector2(8, 262)
	add_child(bgt)
	var bgt2 := Sprite2D.new()
	bgt2.texture = PixelArt.battle_background("dungeon", 320, 100)
	bgt2.centered = false
	bgt2.position = Vector2(332, 262)
	add_child(bgt2)
	for i in range(4):
		var s := Sprite2D.new()
		s.texture = PixelArt.hero_battle_texture(HeroDB.CLASS_ORDER[i])
		s.centered = false
		s.position = Vector2(480 + (i % 2) * 52, 70 + (i / 2) * 75)
		add_child(s)
	for i in range(8):
		await get_tree().process_frame
	var img := get_viewport().get_texture().get_image()
	img.save_png("/tmp/art_preview.png")
	get_tree().quit()
