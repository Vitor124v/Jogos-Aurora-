extends Node
func _ready() -> void:
	var out := OS.get_environment("OUT_DIR")
	if out == "":
		out = "/tmp"
	var sheet := Image.create(12 * 64, 4 * 96, false, Image.FORMAT_RGBA8)
	sheet.fill(Color(0.35, 0.55, 0.38))
	var row := 0
	for cid in HeroDB.CLASS_ORDER:
		var fr := PixelArt.char_frames(PixelArt.look_for(String(HeroDB.get_class_data(cid)["look"])))
		var col := 0
		for dir in ["down", "up", "left", "right"]:
			for f in range(3):
				var im: Image = fr[dir][f].get_image()
				im.resize(64, 96, Image.INTERPOLATE_NEAREST)
				sheet.blend_rect(im, Rect2i(0, 0, 64, 96), Vector2i(col * 64, row * 96))
				col += 1
		row += 1
	sheet.save_png(out + "/walk_sheet.png")
	get_tree().quit()
