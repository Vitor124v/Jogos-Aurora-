extends Node
## Folha com todos os inimigos (uso: OUT_DIR=/tmp godot --path . res://tests/render_monsters.tscn)
func _ready() -> void:
	var out := OS.get_environment("OUT_DIR")
	if out == "":
		out = "/tmp"
	var ids: Array = EnemyDB.ENEMIES.keys()
	var cols := 8
	var rows := int(ceil(float(ids.size()) / float(cols)))
	var sheet := Image.create(cols * 120, rows * 120, false, Image.FORMAT_RGBA8)
	sheet.fill(Color(0.3, 0.45, 0.35))
	for i in range(ids.size()):
		var ed: Dictionary = EnemyDB.ENEMIES[ids[i]]
		var px := 48 if ed.get("boss", false) else 48
		var tex := PixelArt.enemy_texture(String(ed["sprite"]), ed["color"], px)
		var im := tex.get_image()
		im.resize(96, 96, Image.INTERPOLATE_NEAREST)
		sheet.blend_rect(im, Rect2i(0, 0, 96, 96), Vector2i((i % cols) * 120 + 12, (i / cols) * 120 + 12))
	sheet.save_png(out + "/monsters_sheet.png")
	print("ok ", ids)
	get_tree().quit()
