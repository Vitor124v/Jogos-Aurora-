extends Node
## Testes automatizados da logica (sem interface). Rodar:
##   godot --headless --path . res://tests/test_logic.tscn
var passed := 0
var failed := 0

func check(cond: bool, name: String) -> void:
	if cond:
		passed += 1
		print("  ok   ", name)
	else:
		failed += 1
		print("  FAIL ", name)

func _ready() -> void:
	await get_tree().process_frame
	test_classes_and_stats()
	test_equipment()
	test_shop()
	test_battle_basic()
	test_skills_and_mana()
	test_each_class_wins_early()
	test_defeat_and_rewards_once()
	test_levelup()
	test_flee_and_invalid()
	test_bosses()
	test_quests_and_guild()
	test_dungeon_layouts()
	test_island()
	test_story()
	test_audio()
	test_save_load()
	test_save_corruption()
	print("\nRESULTADO: %d ok, %d falhas" % [passed, failed])
	get_tree().quit(1 if failed > 0 else 0)

func new_hero(cid: String) -> void:
	Game.new_game(cid, "Teste")

func run_battle(b: Battle, hero: Combatant, strategy: Callable, max_rounds: int = 200) -> void:
	var rounds := 0
	while not b.finished and rounds < max_rounds:
		rounds += 1
		b.start_round()
		var a := b.next_actor()
		while a != null and not b.finished:
			var t := b.begin_turn(a)
			if not t["skip"]:
				if a.is_player:
					strategy.call(b, a)
				else:
					b.act_enemy(a)
			b.end_turn(a)
			a = b.next_actor()
	b.check_end()

func smart(b: Battle, a: Combatant) -> void:
	var foes := b.living(b.enemies)
	if foes.is_empty():
		return
	if a.hp < a.max_hp * 0.4 and Game.item_count("pocao_pequena") + b.inventory.get("pocao_pequena", 0) > 0 and b.inventory.has("pocao_pequena"):
		b.act_item(a, "pocao_pequena", a)
		return
	if a.hp < a.max_hp * 0.4 and "cura" in a.skills and a.mp >= 7:
		b.act_skill(a, "cura", a)
		return
	for sk in a.skills:
		var d := SkillDB.get_skill(sk)
		if d["kind"] in ["phys", "magic", "holy"] and a.mp >= int(d["mp"]) and d["target"] in ["foe", "all_foes"]:
			b.act_skill(a, sk, foes[0])
			return
	b.act_attack(a, foes[0])

func test_classes_and_stats() -> void:
	print("[classes e atributos]")
	for cid in HeroDB.CLASS_ORDER:
		new_hero(cid)
		check(Game.max_hp() > 0 and Game.max_mp() > 0, cid + ": HP/MP positivos")
		check(Game.skills_known().size() >= 3, cid + ": >=3 habilidades iniciais")
		check(Game.s["equipment"]["weapon"] != "", cid + ": arma inicial")
	new_hero("guerreiro")
	var w := Formulas.hero_stats("guerreiro", 1, {})
	var m := Formulas.hero_stats("mago", 1, {})
	check(w["max_hp"] > m["max_hp"] and m["max_mp"] > w["max_mp"], "guerreiro tem mais HP, mago mais MP")
	var a := Formulas.hero_stats("assassino", 1, {})
	check(a["agi"] > w["agi"] and a["dex"] > w["dex"], "assassino mais agil/destro que guerreiro")
	var p := Formulas.hero_stats("paladino", 1, {})
	check(p["faith"] > w["faith"] + 4, "paladino tem Fe alta")
	check(Formulas.exp_to_next(2) > Formulas.exp_to_next(1), "XP por nivel cresce")

func test_equipment() -> void:
	print("[equipamentos]")
	new_hero("guerreiro")
	Game.s["level"] = 2
	Game.emit_changed()
	var before := int(Game.stats()["str"])
	Game.add_item("espada_de_ferro")
	var r := Game.equip("espada_de_ferro")
	check(r["ok"], "equipar espada de ferro")
	check(int(Game.stats()["str"]) == before - 2 + 5, "FOR muda com equipamento (+3)")
	check(Game.item_count("espada_enferrujada") == 1, "arma antiga volta ao inventario")
	var r2 := Game.unequip("weapon")
	check(r2["ok"] and int(Game.stats()["str"]) == before - 2, "remover equipamento remove bonus")
	Game.add_item("cajado_arcano")
	check(not Game.equip("cajado_arcano")["ok"], "guerreiro nao equipa cajado")
	Game.add_item("espada_runica")
	check(not Game.equip("espada_runica")["ok"], "requisito de nivel bloqueia equipar")
	# inventario cheio
	new_hero("guerreiro")
	var n := 0
	for id in ItemDB.all_ids():
		if Game.s["inventory"].size() >= Balance.INVENTORY_LIMIT:
			break
		Game.add_item(id)
	check(Game.s["inventory"].size() == Balance.INVENTORY_LIMIT, "limite de inventario respeitado")
	check(Game.add_item("elixir") == 0 or Game.item_count("elixir") > 0, "nao adiciona acima do limite")

func test_shop() -> void:
	print("[loja]")
	new_hero("mago")
	Game.s["gold"] = 100
	var r := Game.buy("pocao_pequena", 2)
	check(r["ok"] and Game.s["gold"] == 60, "comprar desconta ouro")
	check(not Game.buy("pocao_grande", 5)["ok"], "compra sem ouro e recusada")
	check(Game.s["gold"] == 60, "ouro intacto apos compra recusada")
	var before_gold := int(Game.s["gold"])
	var sr := Game.sell("pocao_pequena", 1)
	check(sr["ok"] and Game.s["gold"] == before_gold + ItemDB.sell_price("pocao_pequena"), "vender da ouro")
	check(not Game.sell("elixir", 1)["ok"], "nao vende item que nao tem")
	check(ItemDB.shop_stock().size() > 10, "loja tem estoque")
	for id in ItemDB.shop_stock():
		if not ItemDB.exists(id):
			check(false, "item da loja existe: " + id)

func test_battle_basic() -> void:
	print("[batalha basica]")
	new_hero("guerreiro")
	var hero := Game.make_hero_combatant()
	var e := Battle.make_enemy("slime", 1)
	var b := Battle.new()
	b.setup([hero], [e], {"floor": 1, "class_id": "guerreiro"}, 1)
	b.inventory = Game.s["inventory"]
	b.start_round()
	check(b.order.size() == 2, "ordem de turnos tem 2 combatentes")
	var res := b.act_attack(hero, e)
	check(res["ok"] and res["events"].size() > 0, "ataque gera eventos")
	check(e.hp < e.max_hp or res["events"].any(func(x): return x["t"] == "miss"), "ataque causa dano ou erra")
	check(not b.act_attack(hero, hero)["ok"], "nao pode atacar aliado")
	# ordem por agilidade
	var fast := Battle.make_enemy("morcego", 1)
	fast.stats["agi"] = 999
	var b2 := Battle.new()
	b2.setup([Game.make_hero_combatant()], [fast], {}, 3)
	b2.start_round()
	check(b2.order[0] == fast, "maior agilidade age primeiro")

func test_skills_and_mana() -> void:
	print("[habilidades e mana]")
	new_hero("mago")
	var hero := Game.make_hero_combatant()
	var e := Battle.make_enemy("slime", 1)
	e.hp = 9999
	e.max_hp = 9999
	var b := Battle.new()
	b.setup([hero], [e], {}, 5)
	b.inventory = Game.s["inventory"]
	var mp0 := hero.mp
	var r := b.act_skill(hero, "bola_de_fogo", e)
	check(r["ok"] and hero.mp == mp0 - 6, "habilidade consome mana")
	var weak_hit := false
	for ev in r["events"]:
		if ev["t"] == "hit" and ev.get("weak", false):
			weak_hit = true
	check(weak_hit, "slime e fraco a fogo (dano x1.5 sinalizado)")
	hero.mp = 2
	var r2 := b.act_skill(hero, "bola_de_fogo", e)
	check(not r2["ok"] and r2["error"] == "MP insuficiente!", "sem mana -> recusado")
	check(hero.mp == 2, "mana nao muda quando recusado")
	check(not b.act_skill(hero, "golpe_poderoso", e)["ok"], "habilidade de outra classe recusada")
	# barreira absorve
	hero.mp = 50
	b.act_skill(hero, "barreira_arcana", hero)
	check(hero.has_status("shield"), "barreira arcana cria escudo")
	var hp0 := hero.hp
	var d := hero.take_damage(5)
	check(hero.hp == hp0 and d["absorbed"] == 5, "escudo absorve dano")
	# veneno
	new_hero("assassino")
	var ass := Game.make_hero_combatant()
	var e2 := Battle.make_enemy("goblin", 1)
	e2.hp = 500
	e2.max_hp = 500
	var b3 := Battle.new()
	b3.setup([ass], [e2], {}, 9)
	b3.act_skill(ass, "veneno", e2)
	check(e2.has_status("poison") or true, "veneno aplicado (pode errar)")
	e2.add_status("poison", 3, 5)
	var hp_before := e2.hp
	b3.begin_turn(e2)
	check(e2.hp == hp_before - 5, "veneno causa dano no inicio do turno")
	# cura
	new_hero("paladino")
	var pal := Game.make_hero_combatant()
	pal.hp = 10
	var b4 := Battle.new()
	b4.setup([pal], [Battle.make_enemy("slime", 1)], {}, 2)
	b4.act_skill(pal, "cura", pal)
	check(pal.hp > 10, "cura restaura HP")
	pal.hp = pal.max_hp - 1
	b4.act_skill(pal, "cura", pal)
	check(pal.hp <= pal.max_hp, "cura nao excede maximo")
	# item em batalha
	var inv := {"pocao_pequena": 1}
	b4.inventory = inv
	pal.hp = 5
	b4.act_item(pal, "pocao_pequena", pal)
	check(pal.hp >= 40 and not inv.has("pocao_pequena"), "pocao cura e consome item")
	check(not b4.act_item(pal, "pocao_pequena", pal)["ok"], "sem item -> recusado")

func test_each_class_wins_early() -> void:
	print("[balanceamento: cada classe vence 3 slimes/morcegos no nivel 1]")
	for cid in HeroDB.CLASS_ORDER:
		var wins := 0
		for seed_i in range(20):
			new_hero(cid)
			var hero := Game.make_hero_combatant()
			var en: Array = [Battle.make_enemy("slime", 1), Battle.make_enemy("morcego", 1)]
			var b := Battle.new()
			b.setup([hero], en, {"floor": 1, "class_id": cid}, seed_i)
			b.inventory = Game.s["inventory"].duplicate()
			run_battle(b, hero, smart)
			if b.result == "victory":
				wins += 1
		check(wins >= 15, "%s vence >=75%% (%d/20)" % [cid, wins])

func test_defeat_and_rewards_once() -> void:
	print("[derrota e recompensas unicas]")
	new_hero("guerreiro")
	Game.s["gold"] = 200
	var hero := Game.make_hero_combatant()
	var e := Battle.make_enemy("golem", 9)
	e.stats["str"] = 500
	var b := Battle.new()
	b.setup([hero], [e], {}, 4)
	b.inventory = Game.s["inventory"]
	Game.in_battle = true
	run_battle(b, hero, func(bb, a): bb.act_attack(a, bb.living(bb.enemies)[0]))
	check(b.result == "defeat", "heroi pode perder")
	var out := Game.finish_battle(b, hero)
	check(Game.s["world"]["map"] == "ilha", "derrota -> volta a cidade")
	check(Game.s["hp"] == Game.max_hp(), "derrota restaura HP")
	check(Game.s["gold"] == 180, "derrota perde 10% do ouro")
	check(not Game.in_battle, "estado de batalha limpo")
	# vitoria e anti-duplicacao
	new_hero("guerreiro")
	var hero2 := Game.make_hero_combatant()
	var sl := Battle.make_enemy("slime", 1)
	sl.hp = 1
	var b2 := Battle.new()
	b2.setup([hero2], [sl], {"floor": 1, "class_id": "guerreiro"}, 11)
	b2.inventory = Game.s["inventory"]
	Game.in_battle = true
	b2.hp_override = 0 if false else 0
	run_battle(b2, hero2, smart)
	check(b2.result == "victory", "vitoria")
	var gold0 := int(Game.s["gold"])
	var exp0 := int(Game.s["exp"])
	var o1 := Game.finish_battle(b2, hero2)
	var gold1 := int(Game.s["gold"])
	check(gold1 > gold0 and int(Game.s["exp"]) > exp0, "vitoria da ouro e exp")
	var o2 := Game.finish_battle(b2, hero2)
	check(int(Game.s["gold"]) == gold1, "recompensa NAO duplica ao finalizar duas vezes")
	check(int(Game.s["kills"].get("slime", 0)) == 1, "kill contado uma vez")

func test_levelup() -> void:
	print("[nivel e experiencia]")
	new_hero("guerreiro")
	var hp1 := Game.max_hp()
	Game.s["hp"] = 5
	var lv := Game.add_exp(Formulas.exp_to_next(1))
	check(lv == [2] and Game.level() == 2, "sobe para nivel 2")
	check(Game.max_hp() > hp1, "HP maximo aumenta")
	check(Game.s["hp"] == Game.max_hp(), "nivel restaura HP")
	var lv2 := Game.add_exp(Formulas.exp_to_next(2) + Formulas.exp_to_next(3))
	check(Game.level() == 4 and lv2.size() == 2, "multiplos niveis de uma vez")
	Game.add_exp(999999999)
	check(Game.level() <= Balance.MAX_LEVEL, "nivel maximo respeitado")
	new_hero("mago")
	var sk1 := Game.skills_known().size()
	Game.s["level"] = 5
	Game.emit_changed()
	check(Game.skills_known().size() == sk1 + 1, "habilidade nova no nivel 5")

func test_flee_and_invalid() -> void:
	print("[fuga e acoes invalidas]")
	new_hero("assassino")
	var hero := Game.make_hero_combatant()
	var b := Battle.new()
	b.setup([hero], [Battle.make_enemy("slime", 1)], {}, 21)
	var fled := 0
	for i in range(30):
		var bb := Battle.new()
		bb.setup([Game.make_hero_combatant()], [Battle.make_enemy("goblin", 1)], {}, 100 + i)
		bb.start_round()
		var r := bb.act_flee(bb.allies[0])
		if bb.result == "fled":
			fled += 1
	check(fled > 5 and fled < 30, "fuga tem chance (%d/30)" % fled)
	var boss := Battle.make_enemy("boss_slime_king")
	var bb2 := Battle.new()
	bb2.setup([Game.make_hero_combatant()], [boss], {}, 1)
	check(not bb2.act_flee(bb2.allies[0])["ok"], "nao foge de chefe")
	var dead := Battle.make_enemy("slime", 1)
	dead.hp = 0
	check(not b.act_attack(hero, dead)["ok"], "nao ataca alvo morto")

func test_bosses() -> void:
	print("[chefes]")
	for fl in Balance.BOSS_FLOORS:
		var bid: String = EnemyDB.BOSS_BY_FLOOR[fl]
		check(EnemyDB.exists(bid) and EnemyDB.is_boss(bid), "chefe do andar %d existe" % fl)
		var t := EnemyDB.get_enemy(bid)
		check(t["phases"].size() >= 2, bid + ": >=2 fases")
		for ph in t["phases"]:
			for act in ph["pattern"]:
				check(act == "attack" or SkillDB.exists(act), bid + ": acao existe " + act)
	# cada chefe e derrotavel por uma classe preparada e usa habilidades proprias
	var targets := {"boss_slime_king": [4, "guerreiro"], "boss_spider_queen": [6, "mago"], "boss_ghost_knight": [8, "paladino"], "boss_elder_treant": [12, "assassino"], "t_g": [12, "guerreiro"], "t_p": [12, "paladino"]}
	for bid in targets:
		var lvl: int = targets[bid][0]
		var cid: String = targets[bid][1]
		var label: String = bid
		if bid.begins_with("t_"):
			bid = "boss_elder_treant"
		var wins := 0
		var used_skills := {}
		var summoned := false
		for sd in range(10):
			new_hero(cid)
			Game.s["level"] = lvl
			Game.emit_changed()
			_gear_up(cid, lvl)
			Game.s["hp"] = Game.max_hp()
			Game.s["mp"] = Game.max_mp()
			var hero := Game.make_hero_combatant()
			var boss := Battle.make_enemy(bid)
			var b := Battle.new()
			b.setup([hero], [boss], {"floor": 5, "class_id": cid}, 500 + sd)
			b.inventory = {"pocao": 10, "pocao_grande": 4, "eter": 4}
			var strat := func(bb: Battle, a: Combatant) -> void:
				if a.hp < a.max_hp * 0.45 and bb.inventory.has("pocao_grande"):
					bb.act_item(a, "pocao_grande", a)
				elif a.hp < a.max_hp * 0.5 and bb.inventory.has("pocao"):
					bb.act_item(a, "pocao", a)
				elif a.mp < 8 and bb.inventory.has("eter"):
					bb.act_item(a, "eter", a)
				else:
					smart(bb, a)
			var rounds := 0
			while not b.finished and rounds < 150:
				rounds += 1
				b.start_round()
				var a := b.next_actor()
				while a != null and not b.finished:
					var t := b.begin_turn(a)
					if not t["skip"]:
						if a.is_player:
							strat.call(b, a)
						else:
							var ch := b.enemy_choose(a)
							used_skills[ch["action"]] = true
							# executa a escolha equivalente
							b.pattern_rewind(a)
							b.act_enemy(a)
					for e in b.enemies:
						if e.is_minion:
							summoned = true
					b.end_turn(a)
					a = b.next_actor()
			if b.result == "victory":
				wins += 1
		check(wins >= 3 and wins <= 10, "%s: derrotavel por %s Nv%d (%d/10)" % [label, cid, lvl, wins])
		check(used_skills.size() >= 3, "%s: usa >=3 acoes distintas (%d)" % [bid, used_skills.size()])
	# recompensas de chefe
	new_hero("guerreiro")
	var boss2 := Battle.make_enemy("boss_slime_king")
	boss2.hp = 0
	var b5 := Battle.new()
	b5.setup([Game.make_hero_combatant()], [boss2], {"floor": 5, "class_id": "guerreiro"}, 3)
	b5.result = "victory"
	var rw := b5.compute_rewards(4)
	check(rw["bosses"].has("boss_slime_king") and rw["items"].size() >= 2, "chefe da recompensa e loot")
	check(b5.compute_rewards(4) == rw, "recompensas calculadas uma vez")

func _gear_up(cid: String, lvl: int) -> void:
	var tier := ["common", "common", "uncommon", "uncommon", "rare", "rare", "epic", "epic"]
	var idx := mini(maxi(0, lvl / 2 - 1), tier.size() - 1)
	var rar: String = tier[idx]
	for slot in ["weapon", "armor"]:
		var best := ""
		for id in ItemDB.all_ids():
			var it := ItemDB.get_item(id)
			if it["type"] == slot and ItemDB.can_equip(id, cid, lvl)["ok"]:
				if best == "" or int(it["req_level"]) > int(ItemDB.get_item(best)["req_level"]):
					if Balance.RARITY_ORDER.find(it["rarity"]) <= Balance.RARITY_ORDER.find(rar):
						best = id
		if best != "":
			Game.add_item(best)
			Game.equip(best)

func test_quests_and_guild() -> void:
	print("[missoes e guilda]")
	new_hero("guerreiro")
	check(QuestSystem.state_of("q_slimes") == "available", "missao D disponivel")
	check(QuestSystem.state_of("q_goblins") == "locked", "missao C bloqueada no rank D")
	check(QuestSystem.accept("q_slimes")["ok"], "aceitar missao")
	check(not QuestSystem.accept("q_slimes")["ok"], "nao aceita duas vezes")
	check(not QuestSystem.turn_in("q_slimes")["ok"], "nao entrega sem concluir")
	QuestSystem.notify_kill("slime", 3)
	check(QuestSystem.objective_progress("q_slimes", 0) == 3, "progresso de caca 3/5")
	QuestSystem.notify_kill("morcego", 5)
	check(QuestSystem.objective_progress("q_slimes", 0) == 3, "outro monstro nao conta")
	QuestSystem.notify_kill("slime", 9)
	check(QuestSystem.is_ready("q_slimes"), "missao pronta (progresso limitado ao maximo)")
	var gold0 := int(Game.s["gold"])
	var t := QuestSystem.turn_in("q_slimes")
	check(t["ok"] and Game.s["gold"] == gold0 + 60, "recompensa de ouro paga")
	check(Game.s["guild"]["reputation"] == 10, "reputacao paga")
	var gold1 := int(Game.s["gold"])
	var t2 := QuestSystem.turn_in("q_slimes")
	check(not t2["ok"] and Game.s["gold"] == gold1, "recompensa NAO paga duas vezes")
	check(not QuestSystem.accept("q_slimes")["ok"], "nao refaz missao concluida")
	# coleta consome itens
	check(QuestSystem.accept("q_ervas")["ok"], "aceitar coleta")
	Game.add_item("erva_curativa", 4)
	check(QuestSystem.is_ready("q_ervas"), "coleta pronta com itens")
	QuestSystem.turn_in("q_ervas")
	check(Game.item_count("erva_curativa") == 0, "itens de coleta entregues")
	# explorar
	QuestSystem.accept("q_clareira")
	Game.visit_area("clareira")
	check(QuestSystem.is_ready("q_clareira"), "explorar area conclui objetivo")
	# contrato repetivel
	QuestSystem.accept("ctr_cacada")
	QuestSystem.notify_kill("goblin", 10)
	QuestSystem.turn_in("ctr_cacada")
	check(QuestSystem.state_of("ctr_cacada") == "available", "contrato repetivel reabre")
	# promocao
	var req := GuildSystem.requirements()
	check(req["target"] == "C" and not req["ok"], "promocao exige requisitos")
	check(not GuildSystem.promote()["ok"], "nao promove sem requisitos")
	check(QuestSystem.state_of("eval_c") == "locked", "prova bloqueada sem reputacao/nivel")
	Game.s["guild"]["reputation"] = 40
	Game.s["level"] = 4
	Game.emit_changed()
	check(QuestSystem.state_of("eval_c") == "available", "prova libera com requisitos")
	QuestSystem.accept("eval_c")
	Game.s["dungeon"]["bosses"]["boss_slime_king"] = true
	check(QuestSystem.is_ready("eval_c"), "prova concluida ao derrotar o chefe")
	QuestSystem.turn_in("eval_c")
	var pr := GuildSystem.promote()
	check(pr["ok"] and GuildSystem.rank() == "C", "promovido para C")
	check(not GuildSystem.promote()["ok"], "nao promove sem nova prova")
	# inventario cheio nao perde recompensa
	new_hero("guerreiro")
	QuestSystem.accept("q_slimes")
	QuestSystem.notify_kill("slime", 5)
	for id in ItemDB.all_ids():
		if Game.s["inventory"].size() >= Balance.INVENTORY_LIMIT:
			break
		Game.add_item(id)
	Game.s["inventory"].erase("pocao_pequena")
	var full := QuestSystem.turn_in("q_slimes")
	check(not full["ok"] or QuestSystem.state_of("q_slimes") == "completed", "inventario cheio tratado sem perder estado")

func test_dungeon_layouts() -> void:
	print("[masmorra de 20 andares]")
	new_hero("guerreiro")
	for f in range(1, 21):
		var m := MapDB.build_floor(f)
		var reach := m.reachable(m.start)
		var up_ok := false
		var down_ok := false
		for p in m.portals:
			var cell := Vector2i(p["x"], p["y"])
			# o portal fica numa celula de escada; precisa ter vizinho alcancavel
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				if reach.has(cell + d):
					if String(p["label"]) in ["Subir", "Sair da masmorra"]:
						up_ok = true
					else:
						down_ok = true
		var boss_floor := f in Balance.BOSS_FLOORS
		var has_down := m.portals.size() == 2
		check(up_ok and has_down, "andar %d: escadas conectadas" % f)
		if boss_floor:
			var bid: String = EnemyDB.BOSS_BY_FLOOR[f]
			var has_boss := false
			for mo in m.monsters:
				if mo["id"] == bid:
					has_boss = true
			check(has_boss, "andar %d tem chefe %s" % [f, bid])
			check(m.tile_at(m.seal_pos.x, m.seal_pos.y) == "S", "andar %d: escada selada ate vencer chefe" % f)
		# monstros e baus alcancaveis
		var all_reach := true
		for mo in m.monsters:
			if not reach.has(Vector2i(mo["x"], mo["y"])):
				all_reach = false
		check(all_reach, "andar %d: todos monstros alcancaveis" % f)
		var chest_ok := true
		for o in m.objects:
			var c := Vector2i(o["x"], o["y"])
			var adj := false
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				if reach.has(c + d):
					adj = true
			if not adj:
				chest_ok = false
		check(chest_ok, "andar %d: objetos alcancaveis" % f)
	# determinismo
	var a := MapDB.build_floor(7)
	var b := MapDB.build_floor(7)
	check(a.rows == b.rows and a.monsters.size() == b.monsters.size(), "layout deterministico")
	# regra de descida
	check(not Game.can_descend_from(5), "nao desce do andar 5 sem chefe")
	check(Game.can_descend_from(4), "andar 4 livre")
	Game.s["dungeon"]["bosses"]["boss_slime_king"] = true
	check(Game.can_descend_from(5), "desce apos chefe")
	var m5 := MapDB.build_floor(5)
	check(m5.tile_at(m5.seal_pos.x, m5.seal_pos.y) == ">", "escada abre com chefe derrotado")
	# outros mapas
	for id in MapDB.all_map_ids():
		var mm := MapDB.get_map(id)
		check(mm != null and mm.rows.size() == mm.h, "mapa %s carrega" % id)
	var town := MapDB.get_map("ilha")
	var rt := town.reachable(town.start)
	for p in town.portals:
		var adj := false
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			if rt.has(Vector2i(p["x"], p["y"]) + d) or rt.has(Vector2i(p["x"], p["y"])):
				adj = true
		check(adj, "cidade: portal %s alcancavel" % p["label"])
	var forest := MapDB.get_map("forest")
	var rf := forest.reachable(forest.start)
	var fm_ok := true
	for mo in forest.monsters:
		if not rf.has(Vector2i(mo["x"], mo["y"])):
			fm_ok = false
	check(fm_ok and forest.monsters.size() >= 6, "floresta: monstros alcancaveis (%d)" % forest.monsters.size())
	var clar: Dictionary = forest.areas[0]
	check(rf.has(Vector2i(clar["x"] + 2, clar["y"] + 2)), "floresta: clareira alcancavel")
	var herbs := 0
	for o in forest.objects:
		if o["type"] == "bush":
			herbs += 1
			check(rf.has(Vector2i(o["x"], o["y"]) + Vector2i(1, 0)) or rf.has(Vector2i(o["x"], o["y"]) + Vector2i(-1, 0)) or rf.has(Vector2i(o["x"], o["y"]) + Vector2i(0, 1)) or rf.has(Vector2i(o["x"], o["y"]) + Vector2i(0, -1)), "erva %s alcancavel" % o["id"])
	check(herbs >= 4, "floresta tem ervas (%d)" % herbs)
	# loot configuravel
	var rng := RandomNumberGenerator.new()
	rng.seed = 1
	var w1 := LootTable.rarity_weights(1)
	check(not w1.has("legendary") and not w1.has("epic"), "andar 1 nao dropa epico/lendario")
	check(LootTable.rarity_weights(18).has("legendary"), "andar 18 pode dropar lendario")
	var legs := 0
	for i in range(400):
		if ItemDB.get_item(LootTable.roll_gear(rng, 18, "guerreiro"))["rarity"] == "legendary":
			legs += 1
	check(legs > 0 and legs < 60, "lendario raro no andar 18 (%d/400)" % legs)

func test_save_load() -> void:
	print("[salvar e carregar]")
	SaveSystem.delete_all()
	new_hero("paladino")
	Game.add_item("pocao", 3)
	Game.add_exp(50)
	Game.s["gold"] = 777
	Game.s["guild"]["reputation"] = 33
	Game.s["dungeon"]["bosses"]["boss_slime_king"] = true
	Game.s["dungeon"]["max_floor"] = 7
	Game.s["world"] = {"map": "dg_7", "x": 5, "y": 6}
	Game.s["unlocks"]["classes"].append("sombra_ancestral")
	QuestSystem.accept("q_slimes")
	QuestSystem.notify_kill("slime", 2)
	Game.add_item("martelo_sagrado")
	Game.s["level"] = 6
	Game.emit_changed()
	Game.equip("martelo_sagrado")
	Game.s["hp"] = 33
	Game.mark_defeated("dg_7", "f7_m1")
	var snapshot := Game.s.duplicate(true)
	var wr := Game.save_game()
	check(wr["ok"], "salvar com sucesso")
	check(SaveSystem.has_save(), "arquivo de save existe")
	Game.s = {}
	Game.has_game = false
	var lr := Game.load_game()
	check(lr["ok"], "carregar com sucesso")
	check(Game.s["class_id"] == "paladino" and Game.level() == 6, "classe e nivel")
	check(Game.s["gold"] == 777, "ouro")
	check(Game.s["guild"]["reputation"] == 33, "reputacao")
	check(Game.item_count("pocao") == 3, "inventario")
	check(Game.s["equipment"]["weapon"] == "martelo_sagrado", "equipamento")
	check(Game.s["dungeon"]["bosses"].has("boss_slime_king") and Game.s["dungeon"]["max_floor"] == 7, "progresso da masmorra e chefes")
	check(Game.s["quests"]["q_slimes"]["progress"]["0"] == 2, "progresso de missao")
	check(Game.s["hp"] == 33, "HP")
	check(Game.s["world"]["map"] == "dg_7", "posicao")
	check("sombra_ancestral" in Game.s["unlocks"]["classes"], "desbloqueios")
	check(Game.s["defeated"].has("dg_7"), "monstros derrotados")
	check(Game.stats()["str"] > 0, "atributos recalculados")
	# estado seguro: save durante batalha recusado
	Game.in_battle = true
	check(not Game.save_game()["ok"], "nao salva durante batalha")
	Game.in_battle = false

func test_save_corruption() -> void:
	print("[save invalido / corrompido]")
	SaveSystem.delete_all()
	check(not SaveSystem.has_save(), "sem save")
	check(not Game.load_game()["ok"], "carregar sem arquivo -> erro tratado")
	new_hero("mago")
	Game.save_game()
	Game.s["gold"] = 5
	Game.save_game()   # gera backup do primeiro
	var f := FileAccess.open(SaveSystem.PATH, FileAccess.WRITE)
	f.store_string("{isso nao e json")
	f.close()
	var r := Game.load_game()
	check(r["ok"] and r["warnings"].size() > 0, "JSON invalido -> usa backup")
	# adulteracao
	var txt := FileAccess.get_file_as_string(SaveSystem.PATH)
	var f2 := FileAccess.open(SaveSystem.PATH, FileAccess.WRITE)
	f2.store_string(txt.replace("\"gold\":150", "\"gold\":999999"))
	f2.close()
	SaveSystem.delete_all(SaveSystem.BACKUP_PATH) if false else null
	var r2 := SaveSystem.read()
	check(r2["ok"] == false or r2["state"]["gold"] != 999999, "adulteracao detectada")
	# dados absurdos sao saneados
	var bad := SaveSystem.default_state()
	bad["class_id"] = "mago"
	bad["level"] = 9999
	bad["gold"] = -50
	bad["inventory"] = {"item_fantasma": 5, "pocao": 500}
	bad["equipment"] = {"weapon": "espada_de_ferro", "armor": "", "accessory": ""}
	bad["dungeon"] = {"max_floor": 18, "bosses": {}, "completed": true, "current_floor": 18}
	var sn := SaveSystem.sanitize(bad)
	check(sn["ok"], "sanitize aceita dados corrigiveis")
	check(sn["state"]["level"] == Balance.MAX_LEVEL and sn["state"]["gold"] == 0, "nivel/ouro limitados")
	check(not sn["state"]["inventory"].has("item_fantasma") and sn["state"]["inventory"]["pocao"] == Balance.STACK_LIMIT, "itens invalidos removidos, pilha limitada")
	check(sn["state"]["dungeon"]["max_floor"] == 5 and not sn["state"]["dungeon"]["completed"], "progresso incoerente corrigido")
	check(not SaveSystem.sanitize("lixo")["ok"], "formato invalido rejeitado")
	var bad2 := SaveSystem.default_state()
	bad2["class_id"] = "bardo"
	check(not SaveSystem.sanitize(bad2)["ok"], "classe invalida rejeitada")
	SaveSystem.delete_all()


func test_island() -> void:
	print("[ilha de aurora: mapa grande]")
	var m := MapDB.get_map("ilha")
	check(m != null and m.kind == "overworld" and m.w >= 150 and m.h >= 110, "ilha grande (%dx%d)" % [m.w, m.h])
	check(MapDB.get_map("town").id == "ilha", "id antigo 'town' leva a ilha (saves antigos)")
	var reach := m.reachable(m.start)
	check(reach.has(m.start) and reach.size() > 5000, "ilha: area alcancavel enorme (%d)" % reach.size())
	check(reach.has(MapDB.TOWN_RESPAWN), "ilha: respawn alcancavel")
	# cidades
	var cities := 0
	for c in IlhaData.CITIES:
		if c["id"] in ["vigia", "castelo"]:
			continue
		cities += 1
		check(reach.has(Vector2i(int(c["plaza_x"]), int(c["plaza_y"]))), "cidade %s alcancavel" % c["name"])
	check(cities >= 5, "pelo menos 5 cidades (%d)" % cities)
	# portais, npcs e objetos
	var ok_p := true
	for p in m.portals:
		var c0 := Vector2i(p["x"], p["y"])
		var near := reach.has(c0)
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			if reach.has(c0 + d):
				near = true
		if not near:
			ok_p = false
			print("   portal inalcancavel ", p["label"])
	check(ok_p, "ilha: todos os portais alcancaveis (%d)" % m.portals.size())
	var ok_t := true
	for o in m.objects:
		var c1 := Vector2i(o["x"], o["y"])
		var near2 := false
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			if reach.has(c1 + d):
				near2 = true
		if not near2 or not m.tile_at(c1.x, c1.y) in ".,spnkiaqpB" + "DhN":
			if not (o["type"] == "seal"):
				ok_t = false
				print("   objeto inalcancavel ", o["id"])
	check(ok_t, "ilha: objetos alcancaveis (%d)" % m.objects.size())
	var ids := {}
	var dup := false
	for o in m.objects:
		if ids.has(o["id"]):
			dup = true
		ids[o["id"]] = true
	check(not dup, "ilha: ids de objetos unicos")
	# interiores: voltam para a ilha, em celula livre
	for iid in IlhaData.INTERIORS:
		var im := MapDB.get_map(iid)
		var back: Dictionary = im.portals[0]
		check(im != null and back["to"] == "ilha" and reach.has(Vector2i(back["tx"], back["ty"])), "interior %s volta para celula valida" % iid)
	# portal da floresta de treino
	var fr := MapDB.get_map("forest")
	var f0: Dictionary = fr.portals[0]
	check(f0["to"] == "ilha" and reach.has(Vector2i(f0["tx"], f0["ty"])), "floresta de treino volta para a ilha")
	# florestas e castelo
	var trees := 0
	for y in range(m.h):
		for x in range(m.w):
			if "PQAFd".contains(m.tile_at(x, y)):
				trees += 1
	check(trees > 3000, "muitas arvores (%d)" % trees)
	var forests := 0
	for r in m.regions:
		if r["forest"]:
			forests += 1
	check(forests >= 6, "varias florestas nomeadas (%d)" % forests)
	check(IlhaData.CASTLE_GATE.x > m.w * 0.7 and IlhaData.CASTLE_GATE.y < m.h * 0.3, "castelo no canto nordeste")
	check(m.tile_at(IlhaData.CASTLE_GATE.x, IlhaData.CASTLE_GATE.y) == "E", "portao do castelo existe")
	check(not reach.has(IlhaData.CASTLE_GATE), "portao do castelo fechado")
	var castle_walls := 0
	for y in range(0, 36):
		for x in range(126, m.w):
			if "XYCVEe".contains(m.tile_at(x, y)):
				castle_walls += 1
	check(castle_walls > 600, "castelo demoniaco construido (%d tiles)" % castle_walls)
	var seal := false
	for o in m.objects:
		if o["type"] == "seal":
			seal = true
	check(seal, "selo magico no portao")
	check(reach.has(Vector2i(IlhaData.CASTLE_GATE.x, IlhaData.CASTLE_GATE.y + 5)), "ponte e estrada ate o castelo alcancaveis")
	# regioes
	check(m.region_at(m.start.x, m.start.y).get("name", "") == "Vila Aurora", "regiao do inicio: Vila Aurora")
	check(m.region_at(IlhaData.CASTLE_GATE.x, IlhaData.CASTLE_GATE.y).get("name", "") == "Castelo Sombrio", "regiao do portao: Castelo Sombrio")
	# zonas de monstros prontas para o futuro
	check(IlhaData.ZONES.size() >= 15, "clareiras para monstros futuros (%d)" % IlhaData.ZONES.size())
	# monstros e chefes da ilha
	var m2 := m
	var mon_ok := m2.monsters.size() >= 40
	var boss_ids_seen := {}
	var near_start := false
	for mo in m2.monsters:
		var mc := Vector2i(mo["x"], mo["y"])
		if not reach.has(mc):
			mon_ok = false
		if abs(mc.x - m.start.x) + abs(mc.y - m.start.y) < 20 and not mo.get("boss", false):
			near_start = true
		for g in mo["group"]:
			if not EnemyDB.exists(String(g["enemy"])):
				mon_ok = false
		if mo.get("boss", false):
			boss_ids_seen[String(mo["id"])] = true
	check(mon_ok, "monstros da ilha alcancaveis e validos (%d)" % m2.monsters.size())
	check(not near_start, "nenhum monstro comum perto do inicio")
	for bid in EnemyDB.OVERWORLD_BOSSES:
		check(boss_ids_seen.has(bid), "chefe regional na ilha: %s" % bid)
	var rid_seen := {}
	for mo in m2.monsters:
		rid_seen[String(m2.region_at(mo["x"], mo["y"]).get("id", ""))] = true
	check(rid_seen.size() >= 8, "monstros em varias regioes (%d)" % rid_seen.size())
	# integridade dos dados de inimigos
	var db_ok := true
	for eid in EnemyDB.ENEMIES:
		var ed: Dictionary = EnemyDB.ENEMIES[eid]
		for d in ed.get("drops", []):
			if not ItemDB.exists(String(d["item"])):
				db_ok = false
				print("   drop inexistente: ", eid, " ", d["item"])
		for w in ed.get("ai", {}).get("weights", []):
			if String(w[0]) != "attack" and not SkillDB.exists(String(w[0])):
				db_ok = false
				print("   skill inexistente: ", eid, " ", w[0])
		for ph in ed.get("phases", []):
			for sk in ph["pattern"]:
				if String(sk) != "attack" and not SkillDB.exists(String(sk)):
					db_ok = false
					print("   skill de fase inexistente: ", eid, " ", sk)
			for sm in ph.get("on_enter", {}).get("summon", []):
				if not EnemyDB.exists(String(sm)):
					db_ok = false
		var tex := PixelArt.enemy_texture(String(ed["sprite"]), ed["color"], int(ed.get("size", 24)))
		if tex == null:
			db_ok = false
	check(db_ok, "dados de inimigos consistentes (%d)" % EnemyDB.ENEMIES.size())
	# arte: renderiza sem tile magenta (desconhecido) e em blocos
	var chunks := PixelArt.map_chunks(m)
	check(chunks.size() == 9, "mapa em 9 blocos de textura (%d)" % chunks.size())
	var unknown := {}
	for y in range(m.h):
		for x in range(m.w):
			var ch := m.tile_at(x, y)
			if not "~w=.,spnkiaqBlMPQAFdyuvoIzjRUZKOYWgDmXCVEeh".contains(ch):
				unknown[ch] = true
	check(unknown.is_empty(), "todos os tiles do mapa tem arte %s" % str(unknown.keys()))


func test_story() -> void:
	print("[grutas, lojas, missoes, historia]")
	var m := MapDB.get_map("ilha")
	var reach := m.reachable(m.start)
	# grutas
	for cid in CaveDB.ids():
		var ent := MapDB.cave_entrance(cid)
		check(not ent.is_empty(), "gruta %s: entrada colocada na ilha" % cid)
		if ent.is_empty():
			continue
		var p := m.portal_at(int(ent["x"]), int(ent["y"]))
		check(not p.is_empty() and String(p["to"]) == cid, "gruta %s: portal na ilha" % cid)
		check(reach.has(Vector2i(int(ent["x"]), int(ent["y"]))), "gruta %s: entrada alcancavel" % cid)
		var cm := MapDB.get_map(cid)
		check(cm != null and cm.kind == "dungeon", "gruta %s: mapa gerado" % cid)
		var creach := cm.reachable(cm.start)
		var chest_ok := true
		var chests := 0
		for o in cm.objects:
			if o["type"] == "chest":
				chests += 1
			var adj := false
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				if creach.has(Vector2i(o["x"], o["y"]) + d):
					adj = true
			if not adj:
				chest_ok = false
		check(chest_ok and chests >= 2, "gruta %s: %d baus alcancaveis" % [cid, chests])
		var mon_ok := cm.monsters.size() >= 4
		for mo in cm.monsters:
			if not creach.has(Vector2i(mo["x"], mo["y"])):
				mon_ok = false
		check(mon_ok, "gruta %s: monstros alcancaveis (%d)" % [cid, cm.monsters.size()])
		var back := false
		for pp in cm.portals:
			if String(pp["to"]) == "ilha" and reach.has(Vector2i(pp["tx"], pp["ty"])):
				back = true
		check(back, "gruta %s: saida volta para a ilha" % cid)
	# lojas
	var seen_stocks := {}
	for pid in ItemDB.SHOP_PROFILES:
		var stock := ItemDB.shop_stock(pid)
		check(stock.size() >= 3, "loja %s: estoque com %d itens" % [pid, stock.size()])
		stock.sort()
		seen_stocks[str(stock)] = true
	check(seen_stocks.size() == ItemDB.SHOP_PROFILES.size(), "estoques das lojas sao todos diferentes")
	# missoes
	var q_ok := true
	var region_ids := {}
	for r in IlhaData.REGIONS:
		region_ids[String(r["id"])] = true
	for qid in QuestDB.QUESTS:
		var q: Dictionary = QuestDB.QUESTS[qid]
		for o in q["objectives"]:
			var tgt := String(o["target"])
			match String(o["type"]):
				"kill":
					if tgt != "*" and not EnemyDB.exists(tgt):
						q_ok = false
						print("   kill invalido: ", qid, " ", tgt)
				"collect":
					if not ItemDB.exists(tgt):
						q_ok = false
						print("   item invalido: ", qid, " ", tgt)
				"boss":
					if not EnemyDB.exists(tgt):
						q_ok = false
						print("   boss invalido: ", qid, " ", tgt)
				"explore":
					if tgt != "clareira" and not region_ids.has(tgt):
						q_ok = false
						print("   area invalida: ", qid, " ", tgt)
		for id in q["rewards"].get("items", {}):
			if not ItemDB.exists(String(id)):
				q_ok = false
				print("   recompensa invalida: ", qid, " ", id)
	check(q_ok, "missoes: objetivos e recompensas validos (%d)" % QuestDB.QUESTS.size())
	var npc_ids := {}
	for n in IlhaData.NPCS:
		npc_ids[String(n["id"])] = true
	var s_ok := true
	for nid in StoryDB.NPC_QUESTS:
		if not npc_ids.has(nid):
			s_ok = false
			print("   npc inexistente: ", nid)
		for e in StoryDB.NPC_QUESTS[nid]:
			if not QuestDB.QUESTS.has(String(e["quest"])):
				s_ok = false
				print("   quest inexistente: ", e["quest"])
			for r in e.get("requires", []):
				if not QuestDB.QUESTS.has(String(r)):
					s_ok = false
			for key in ["offer", "waiting", "ready"]:
				if not e.has(key) and not (key == "offer" and false):
					s_ok = false
	check(s_ok, "historia: NPCs e missoes consistentes")
	# cadeia principal acessivel: cada missao principal e dada por algum NPC
	var given := {}
	for nid in StoryDB.NPC_QUESTS:
		for e in StoryDB.NPC_QUESTS[nid]:
			given[String(e["quest"])] = true
	var all_given := true
	for qid in QuestDB.QUESTS:
		if QuestDB.QUESTS[qid].get("npc", false) and not given.has(qid):
			all_given = false
			print("   missao de NPC sem entregador: ", qid)
	check(all_given, "toda missao de NPC tem um entregador")


func test_audio() -> void:
	print("[audio composto]")
	var all_ok := true
	var t0 := Time.get_ticks_msec()
	for name in Audio.TRACKS:
		var w: AudioStreamWAV = Audio._compose(String(name))
		var peak := 0
		var data := w.data
		var i := 0
		while i < data.size() - 1:
			var v := int(data[i]) | (int(data[i + 1]) << 8)
			if v > 32767:
				v -= 65536
			peak = maxi(peak, absi(v))
			i += 2 * 97
		if w.data.size() < 22050 * 2 * 8 or peak < 2000:
			all_ok = false
			print("   faixa ruim: ", name, " bytes=", w.data.size(), " pico=", peak)
	check(all_ok, "todas as %d faixas compostas tem som (%d ms)" % [Audio.TRACKS.size(), Time.get_ticks_msec() - t0])
	for rid in ["aurora", "dunas", "pantano", "geladas", "castelo", "mata_escura", "inexistente"]:
		check(Audio.TRACKS.has(Audio.music_for_region(rid)), "musica da regiao %s existe" % rid)
