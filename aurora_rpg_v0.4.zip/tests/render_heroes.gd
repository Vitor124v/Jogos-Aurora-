extends Node
## Gera folha de sprites dos herois (uso: OUT_DIR=/tmp godot --path . res://tests/render_heroes.tscn)
func _ready() -> void:
	var out := OS.get_environment("OUT_DIR")
	if out == "":
		out = "/tmp"
	var sheet := Image.create(44 * 20 * 2, 88 * 4, false, Image.FORMAT_RGBA8)
	sheet.fill(Color(0.35, 0.55, 0.38))
	var row := 0
	for cid in HeroDB.CLASS_ORDER:
		var col := 0
		for anim in HeroArt.ANIMS:
			for f in range(int(HeroArt.ANIMS[anim])):
				var im := HeroArt.image_of(cid, String(anim), f)
				im.resize(88, 88, Image.INTERPOLATE_NEAREST)
				sheet.blend_rect(im, Rect2i(0, 0, 88, 88), Vector2i(col * 88, row * 88))
				col += 1
		row += 1
	sheet.save_png(out + "/heroes_sheet.png")
	print("ok")
	get_tree().quit()
