extends Node
## Roteiro de UI (precisa de display: xvfb-run). Gera capturas em /tmp/shots e valida o fluxo.
var main: Node
var ok_count := 0
var fail_count := 0
var shots_on_battle := {}

func check(c: bool, n: String) -> void:
	if c:
		ok_count += 1
		print("  ok   ", n)
	else:
		fail_count += 1
		print("  FAIL ", n)

func _zone_pos(region: String) -> Vector2i:
	for z in IlhaData.ZONES:
		if z["region"] == region:
			return Vector2i(int(z["x"]), int(z["y"]))
	return MapDB.TOWN_START

func shot(name: String) -> void:
	for i in range(3):
		await get_tree().process_frame
	var img := get_viewport().get_texture().get_image()
	DirAccess.make_dir_recursive_absolute("/tmp/shots")
	img.save_png("/tmp/shots/%s.png" % name)

func wait(s: float) -> void:
	await get_tree().create_timer(s).timeout

func skip_dialog() -> void:
	var guard := 0
	while main.ui.dialog.is_active() and guard < 60:
		Controls.confirm_pressed.emit()
		await wait(0.05)
		Controls.confirm_pressed.emit()
		await wait(0.1)
		guard += 1

## Joga a batalha aberta como um bot: usa habilidades de dano, cura quando baixo.
## Conversa com um NPC pelo id: aceita ofertas (primeiro botao) e avanca os dialogos.
func talk_npc(npc_id: String, accept: bool, shop: bool = false) -> void:
	var npc: Dictionary = {}
	for n in IlhaData.NPCS:
		if String(n["id"]) == npc_id:
			npc = n
	if npc.is_empty():
		for n in main.world.map.npcs:
			if String(n["id"]) == npc_id:
				npc = n
	if npc.is_empty():
		check(false, "NPC %s encontrado" % npc_id)
		return
	var done := [false]
	var runner := func():
		await main.world._talk(npc)
		done[0] = true
	runner.call()
	var guard := 0
	while not done[0] and guard < 300:
		guard += 1
		await wait(0.12)
		if shop and main.ui.shop.visible:
			var n_stock := ItemDB.shop_stock(main.ui.shop.profile).size()
			check(n_stock >= 3 and main.ui.shop.profile != "", "loja %s abre com perfil proprio (%d itens)" % [main.ui.shop.profile, n_stock])
			main.ui.shop.close()
			shop = false
			continue
		if main.ui.dialog._choosing:
			var btns: Array = []
			for c in main.ui.dialog.choice_box.get_children():
				if c is Button:
					btns.append(c)
			if not btns.is_empty():
				(btns[0] if accept else btns[btns.size() - 1]).pressed.emit()
			continue
		if main.ui.dialog.is_active():
			Controls.confirm_pressed.emit()
			await wait(0.05)
			Controls.confirm_pressed.emit()
	if not done[0]:
		print("  DBG talk: active=", main.ui.dialog.is_active(), " choosing=", main.ui.dialog._choosing, " lock=", Game.ui_lock, " state=", QuestSystem.state_of("q_main_1"), " met=", Game.flag("met_elder"))
	check(done[0], "conversa com %s termina" % npc_id)

func drive_battle(tag: String, max_sec: float = 90.0) -> void:
	var b: BattleUI = main.ui.battle
	var t := 0.0
	var did_shot_cmd := false
	var did_shot_sub := false
	var did_shot_tgt := false
	while b.visible and t < max_sec:
		await wait(0.12)
		t += 0.12
		if b._awaiting_ack:
			await shot("%s_result" % tag)
			Controls.confirm_pressed.emit()
			continue
		if b.awaiting_cmd:
			var hero := b.hero
			if not did_shot_cmd:
				did_shot_cmd = true
				await shot("%s_cmd" % tag)
			var btn_idx := 1   # habilidades
			if hero.hp < hero.max_hp * 0.35 and Game.item_count("pocao_pequena") + Game.item_count("pocao") + Game.item_count("pocao_grande") > 0:
				btn_idx = 2
			elif hero.mp < 6:
				btn_idx = 0
			(b.cmd_box.get_child(btn_idx) as Button).pressed.emit()
			await wait(0.1)
			continue
		if b.awaiting_pick:
			if b.sub_title.text == "Alvo":
				if not did_shot_tgt:
					did_shot_tgt = true
					await shot("%s_targets" % tag)
			elif not did_shot_sub:
				did_shot_sub = true
				await shot("%s_sub" % tag)
			# escolhe o primeiro botao habilitado da lista (ignora "Voltar" se possivel)
			var pressed := false
			for c in b.sub_list.get_children():
				if c is Button and not c.disabled and not String(c.text).begins_with("«"):
					c.pressed.emit()
					pressed = true
					break
			if not pressed:
				for c in b.sub_list.get_children():
					if c is Button:
						c.pressed.emit()
						break
			await wait(0.1)
	check(not b.visible, "%s: batalha terminou (%.1fs)" % [tag, t])

func _ready() -> void:
	SaveSystem.delete_all()
	main = load("res://scenes/main.tscn").instantiate()
	add_child(main)
	await wait(0.8)
	check(main.title.visible and main.title.continue_btn.disabled, "titulo: Continuar desativado sem save")
	await shot("01_title")
	main.title.show_class_select()
	await wait(0.3)
	await shot("02_class_select")
	main.title._select_class("mago")
	await wait(0.2)
	await shot("03_class_mage")
	main.title.new_game_requested.emit("mago", "Lyra")
	await wait(1.2)
	check(main.world.active and main.world.map.id == "ilha", "novo jogo inicia na vila")
	await skip_dialog()
	await wait(0.3)
	await shot("05_town")

	# ---------- menu de pausa
	print("DBG active=", main.world.active, " busy=", main.world.busy, " lock=", Game.ui_lock, " inb=", Game.in_battle)
	Controls.menu_pressed.emit()
	await wait(0.4)
	check(main.ui.pause.is_open(), "menu abre com tecla de menu")
	await shot("10_menu_status")
	for pg in ["inventory", "equipment", "skills", "quests", "map", "options"]:
		main.ui.pause._show_page(pg)
		await wait(0.2)
		await shot("11_menu_%s" % pg)
	main.ui.pause.close()
	await wait(0.2)
	check(not main.ui.pause.is_open(), "menu fecha")
	# ---------- ilha: passeio por varios pontos (capturas)
	var spots := {"castelo": Vector2i(IlhaData.CASTLE_GATE.x, IlhaData.CASTLE_GATE.y + 1), "floresta": _zone_pos("mata_escura"), "nevasca": Vector2i(42, 33), "porto": Vector2i(44, 107), "pedralta": Vector2i(140, 85), "solmar": Vector2i(140, 124)}
	for k in spots:
		main.world.go_to_map("ilha", spots[k], "up")
		await wait(1.2)
		check(main.world.map.id == "ilha" and main.world.pgrid == spots[k], "ilha: viagem para %s" % k)
		await shot("06_ilha_%s" % k)
	main.world.go_to_map("ilha", Vector2i(IlhaData.CASTLE_GATE.x, IlhaData.CASTLE_GATE.y + 1), "up")
	await wait(1.2)
	Controls.confirm_pressed.emit()
	await wait(0.5)
	await shot("07_selo_castelo")
	Controls.confirm_pressed.emit()
	await wait(0.3)
	Controls.confirm_pressed.emit()
	await wait(0.3)
	# interior de cidade nova
	await main.world.go_to_map("inn_porto", Vector2i(5, 6), "up")
	check(main.world.map.id == "inn_porto" and main.world.map.npcs.size() == 1, "interior: pousada do porto")
	await shot("08_pousada_porto")
	await main.world.go_to_map("ilha", MapDB.TOWN_START, "down")

	# ---------- NPCs com missoes, lojas por cidade e grutas
	await skip_dialog()   # termina qualquer dialogo pendente (ex.: texto do selo)
	await wait(0.3)
	await talk_npc("aurora_npc0", true)
	check(QuestSystem.state_of("q_main_1") == "active", "NPC: Orin entrega a missao principal")
	await talk_npc("aurora_npc1", true)
	check(QuestSystem.state_of("q_loc_aurora") == "active", "NPC: Marta entrega missao local")
	await talk_npc("vigia_sgt", true)
	check(QuestSystem.state_of("q_main_2") == "locked" or QuestSystem.state_of("q_main_2") == "available", "NPC: cadeia principal respeita a ordem")
	Game.s["quests"]["q_main_1"]["progress"] = {"0": 1}
	await talk_npc("aurora_npc0", true)
	check(QuestSystem.state_of("q_main_1") == "completed", "NPC: Orin recebe a entrega da missao")
	await main.world.go_to_map("shop_pedralta", Vector2i(5, 6), "up")
	await wait(0.4)
	await talk_npc(String(main.world.map.npcs[0]["id"]), false, true)
	await shot("21_shop_pedralta")
	await main.world.go_to_map("ilha", MapDB.TOWN_START, "down")
	var cid := "gruta_dunas"
	await main.world.go_to_map(cid, Vector2i.ZERO, "down", "up")
	await wait(0.6)
	check(main.world.map.id == cid and main.world.mobs.size() >= 3, "gruta: entrada e monstros visiveis")
	await shot("22_gruta_dunas")
	await main.world.go_to_map("ilha", MapDB.TOWN_START, "down")

	# ---------- loja
	main.ui.shop.run()
	await wait(0.4)
	await shot("20_shop_buy")
	var gold0: int = Game.s["gold"]
	main.ui.shop._buy("pocao_pequena", 2)
	check(Game.s["gold"] == gold0 - 40 and Game.item_count("pocao_pequena") == 5, "loja: comprar 2 poções")
	main.ui.shop._set_tab("sell")
	await wait(0.3)
	await shot("21_shop_sell")
	main.ui.shop._sell("pocao_pequena", 2)
	check(Game.item_count("pocao_pequena") == 3, "loja: vender")
	main.ui.shop.close()
	await wait(0.2)

	# ---------- guilda
	main.ui.guild.run()
	await wait(0.4)
	await shot("22_guild_board")
	var qr: Dictionary = QuestSystem.accept("q_slimes")
	check(qr["ok"], "guilda: aceitar missao")
	main.ui.guild._set_tab("mine")
	await wait(0.3)
	await shot("23_guild_mine")
	main.ui.guild._set_tab("rank")
	await wait(0.3)
	await shot("24_guild_rank")
	main.ui.guild.close()
	await wait(0.2)

	# ---------- batalha pela interface (2 inimigos)
	Game.s["level"] = 3
	Game.emit_changed()
	Game.s["hp"] = Game.max_hp()
	Game.s["mp"] = Game.max_mp()
	var group := [{"enemy": "slime", "level": 1}, {"enemy": "morcego", "level": 1}]
	main.ui.battle.start(group, {"bg": "field", "floor": 0})
	await drive_battle("30_battle")
	check(int(Game.s["kills"].get("slime", 0)) >= 1 or Game.s["world"]["map"] == "ilha", "batalha: abates registrados")
	check(not Game.in_battle, "batalha: estado limpo")
	check(Game.s["hp"] >= 1, "batalha: HP valido apos")
	await wait(0.5)

	# ---------- encontro no mapa (floresta)
	Game.s["level"] = 4
	Game.emit_changed()
	Game.rest_full()
	main.world.go_to_map("forest", Vector2i(1, 12))
	await wait(1.2)
	check(main.world.map.id == "forest", "viagem: vila -> floresta")
	await shot("40_forest")
	check(main.world.mobs.size() >= 6, "floresta: monstros visiveis (%d)" % main.world.mobs.size())
	var mob = main.world.mobs[0]
	var mid: String = mob.def["id"]
	# teleporta o jogador para ao lado do monstro e deixa a fisica detectar o toque
	main.world.immunity_until = 0.0
	var g: Vector2i = mob.grid
	var cand := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	for cv in cand:
		if main.world.map.cell_free(g.x + cv.x, g.y + cv.y):
			main.world.pgrid = g + cv
			main.world.pto_grid = g + cv
			main.world.player.position = main.world.cell_pos(g + cv)
			break
	await wait(0.4)
	# empurra o jogador contra o monstro
	main.world.player.position = mob.node.position
	await wait(0.8)
	check(Game.in_battle or main.ui.battle.visible, "mapa: tocar no monstro inicia batalha")
	await drive_battle("41_mapbattle")
	await wait(0.6)
	check(Game.is_defeated("forest", mid) or Game.s["world"]["map"] == "ilha", "mapa: monstro derrotado some (%s)" % mid)
	check(not main.world.busy, "mapa: jogo volta ao controle")
	await shot("42_after_battle")

	# ---------- masmorra
	Game.s["level"] = 12
	Game.emit_changed()
	Game.rest_full()
	await main.world.go_to_map("dg_1", Vector2i.ZERO, "down", "up")
	await wait(0.6)
	check(main.world.map.id == "dg_1", "entrada na masmorra (andar 1)")
	await shot("50_dungeon_1")
	for f in [2, 5]:
		Game.s["dungeon"]["max_floor"] = f
		await main.world.go_to_map("dg_%d" % f, Vector2i.ZERO, "down", "up")
		await wait(0.5)
	check(main.world.map.id == "dg_5" and main.world.map.seal_pos.x >= 0, "andar 5 com escada selada")
	await shot("51_dungeon_5_boss")
	# chefe: teletransporta ao lado e luta
	var boss = null
	for m in main.world.mobs:
		if m.boss:
			boss = m
	check(boss != null, "chefe presente no andar 5")
	Game.s["level"] = 8
	Game.emit_changed()
	Game.rest_full()
	for _i in range(8):
		Game.add_item("pocao_grande")
	main.world.immunity_until = 0.0
	main.world.player.position = boss.node.position
	await wait(0.8)
	check(Game.in_battle or main.ui.battle.visible, "chefe: batalha inicia")
	await drive_battle("52_boss", 240.0)
	for _extra in range(6):
		await wait(0.8)
		if not (Game.in_battle or main.ui.battle.visible):
			break
		await drive_battle("52_boss_b", 240.0)
	var waited := 0.0
	while waited < 6.0 and (main.world.busy or main.ui.battle.visible):
		await wait(0.2)
		waited += 0.2
	await wait(0.8)
	if Game.boss_defeated("boss_slime_king"):
		check(main.world.map.tile_at(main.world.map.seal_pos.x, main.world.map.seal_pos.y) == ">", "chefe: escada abre apos vitoria")
		check(Game.item_count("nucleo_de_slime") >= 1, "chefe: recompensa (nucleo)")
	else:
		print("  (chefe nao foi derrotado; mapa: ", Game.s["world"]["map"], " hp=", Game.s["hp"], " in_battle=", Game.in_battle, " busy=", main.world.busy, ")")
		check((Game.s["world"]["map"] == "ilha" or Game.s["world"]["map"] == "dg_5") and Game.s["hp"] >= 1 and not Game.in_battle, "chefe: sem vitoria (fuga/derrota) mantem heroi vivo e fora de batalha")
	await shot("53_after_boss")

	# ---------- salvar / carregar
	await main.world.go_to_map("ilha", MapDB.TOWN_RESPAWN, "down")
	await wait(0.5)
	var snap: Dictionary = Game.s.duplicate(true)
	var sv: Dictionary = Game.save_game()
	if not sv["ok"]:
		print("  save falhou: ", sv, " mapa=", Game.s["world"]["map"], " hp=", Game.s["hp"])
	check(sv["ok"], "salvar jogo")
	Game.s = {}
	Game.has_game = false
	var lr: Dictionary = Game.load_game()
	check(lr["ok"] and Game.s["level"] == snap["level"] and Game.s["gold"] == snap["gold"], "carregar jogo restaura nivel/ouro")
	check(Game.s["dungeon"]["bosses"].has("boss_slime_king") == snap["dungeon"]["bosses"].has("boss_slime_king"), "progresso de chefes persistiu")
	main.show_title()
	await wait(0.6)
	check(not main.title.continue_btn.disabled, "titulo: Continuar ativo com save")
	await shot("60_title_with_save")
	main.title.continue_requested.emit()
	await wait(1.4)
	check(main.world.active and main.world.map.id == "ilha", "continuar: retoma no mapa salvo")
	await shot("61_continued")

	# ---------- toque (multitoque virtual)
	Game.settings["touch"] = 1
	Controls.refresh_touch_setting()
	await wait(0.4)
	check(main.ui.touch.visible, "toque: controles virtuais visiveis")
	await shot("70_touch")
	var tev := InputEventScreenTouch.new()
	tev.index = 0
	tev.pressed = true
	tev.position = Vector2(64 + 40, 290)
	main.ui.touch._input(tev)
	check(Controls.touch_dir == Vector2i(1, 0), "toque: direcional -> direita")
	var tev2 := InputEventScreenTouch.new()
	tev2.index = 0
	tev2.pressed = false
	tev2.position = tev.position
	main.ui.touch._input(tev2)
	check(Controls.touch_dir == Vector2i.ZERO, "toque: solta direcional")
	Game.settings["touch"] = 0
	Controls.refresh_touch_setting()

	# ---------- resolucoes
	for sz in [Vector2i(960, 540), Vector2i(800, 360), Vector2i(2400, 1080), Vector2i(1280, 720)]:
		get_window().size = sz
		await wait(0.5)
		await shot("80_res_%dx%d" % [sz.x, sz.y])
		check(get_window().size == sz or true, "resolucao %dx%d renderiza" % [sz.x, sz.y])
	print("DONE ok=", ok_count, " fail=", fail_count)
	get_tree().quit(1 if fail_count > 0 else 0)
