extends Node
## Renderiza a ilha inteira e recortes em PNG (uso: godot --headless --script tests/render_island.gd)
func _ready() -> void:
	var t0 := Time.get_ticks_msec()
	var m := MapDB.get_map("ilha")
	var img := PixelArt.map_image(m)
	print("render ms: ", Time.get_ticks_msec() - t0, " size ", img.get_size())
	var out := OS.get_environment("OUT_DIR")
	if out == "":
		out = "/tmp"
	img.save_png(out + "/ilha_full.png")
	var crops := {"vila": Rect2i(70, 77, 40, 26), "castelo": Rect2i(126, 0, 62, 50), "porto": Rect2i(0, 100, 62, 30), "nevasca": Rect2i(20, 14, 44, 30), "floresta": Rect2i(60, 20, 40, 30), "pedralta": Rect2i(118, 66, 44, 28)}
	for k in crops:
		var r: Rect2i = crops[k]
		img.get_region(Rect2i(r.position * 16, r.size * 16)).save_png(out + "/crop_%s.png" % k)
	get_tree().quit()
