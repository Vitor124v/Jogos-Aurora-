#!/usr/bin/env python3
"""Gera o mapa da Ilha de Aurora (192x144 tiles) e escreve scripts/world/ilha_data.gd.

Uso:  python3 tools/gerar_ilha.py          (a partir da pasta do projeto)
      python3 tools/gerar_ilha.py --png    (tambem salva tools/ilha_preview.png)

O mapa e deterministico (mesma semente = mesmo mapa). Para mexer no desenho,
edite as listas CIDADES, FLORESTAS, LAGOS e RIOS abaixo e rode de novo.
"""
import heapq, json, math, os, sys, collections

W, H = 192, 144
SEED = 11
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ------------------------------------------------------------------ ruido
def hsh(ix, iy, s):
    n = (ix * 374761393 + iy * 668265263 + s * 1442695041) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    n ^= n >> 16
    return (n & 0xFFFF) / 65535.0

def vnoise(x, y, s):
    ix, iy = math.floor(x), math.floor(y)
    fx, fy = x - ix, y - iy
    fx = fx * fx * (3 - 2 * fx)
    fy = fy * fy * (3 - 2 * fy)
    a, b = hsh(ix, iy, s), hsh(ix + 1, iy, s)
    c, d = hsh(ix, iy + 1, s), hsh(ix + 1, iy + 1, s)
    return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy

def fbm(x, y, s, octs=4):
    v = tot = 0.0
    a, f = 1.0, 1.0
    for o in range(octs):
        v += a * vnoise(x * f, y * f, s + o * 17)
        tot += a
        a *= 0.5
        f *= 2
    return v / tot

def field(scale, s, octs=4):
    return [[fbm(x / scale, y / scale, s, octs) for x in range(W)] for y in range(H)]

N_A = field(26, SEED + 1)
N_B = field(9, SEED + 2, 3)
N_C = field(5, SEED + 3, 2)
N_D = field(14, SEED + 4)

def smooth(e0, e1, x):
    t = max(0.0, min(1.0, (x - e0) / (e1 - e0)))
    return t * t * (3 - 2 * t)

def rnd(x, y, s):
    return hsh(x, y, s + 900)

# ------------------------------------------------------------------ definicoes
# estilo: roof/wall/ground. Terraco: (topo da casa, y da rua) relativo ao canto da cidade (caixa 40x26).
TERRACES = [(2, 7), (10, 15), (18, 23)]

CIDADES = [
    dict(id="aurora", name="Vila Aurora", cx=90, cy=90, roof="R", wall="W", ground=".", street="p",
         plan={0: {"L": [(8, "guild", "Guilda dos Aventureiros"), (5, "home", "")], "R": [(6, "inn", "Pousada da Aurora"), (6, "shop", "Loja do Borin")]},
               1: {"L": [(6, "home", ""), (5, "home", "")], "R": [(5, "home", ""), (6, "home", "")]},
               2: {"L": [(6, "home", ""), (6, "home", "")], "R": [(5, "home", ""), (6, "home", "")]}},
         inn=("Dona Mara", "Pousada da Aurora"), shop=("Borin", "Loja do Borin")),
    dict(id="pinheiral", name="Pinheiral", cx=50, cy=66, roof="O", wall="W", ground=".", street="p",
         plan={0: {"L": [(6, "home", ""), (7, "inn", "Pousada do Lenhador")], "R": [(6, "shop", "Armazém do Serrote"), (5, "home", "")]},
               1: {"L": [(6, "home", ""), (5, "home", "")], "R": [(6, "home", ""), (5, "home", "")]},
               2: {"L": [(5, "home", ""), (6, "home", "")], "R": [(6, "home", "")]}},
         inn=("Hilda", "Pousada do Lenhador"), shop=("Serrote", "Armazém do Serrote")),
    dict(id="porto", name="Porto Âmbar", cx=44, cy=114, roof="U", wall="W", ground="s", street="p",
         plan={0: {"L": [(6, "home", ""), (6, "shop", "Empório do Capitão")], "R": [(7, "inn", "Estalagem Maré Alta"), (5, "home", "")]},
               1: {"L": [(5, "home", ""), (6, "home", "")], "R": [(6, "home", ""), (5, "home", "")]},
               2: {"L": [(6, "home", "")], "R": [(5, "home", ""), (6, "home", "")]}},
         inn=("Marta Maré", "Estalagem Maré Alta"), shop=("Capitão Brás", "Empório do Capitão")),
    dict(id="nevasca", name="Vila da Neve", cx=42, cy=28, roof="Z", wall="W", ground="n", street="p",
         plan={0: {"L": [(6, "home", ""), (6, "shop", "Peles & Ferragens")], "R": [(7, "inn", "Pousada Lareira"), (5, "home", "")]},
               1: {"L": [(6, "home", ""), (5, "home", "")], "R": [(5, "home", ""), (6, "home", "")]},
               2: {"L": [(6, "home", "")], "R": [(6, "home", ""), (5, "home", "")]}},
         inn=("Ingrid", "Pousada Lareira"), shop=("Olaf", "Peles & Ferragens")),
    dict(id="pedralta", name="Vila do Ferro", cx=140, cy=80, roof="K", wall="g", ground=".", street="p",
         plan={0: {"L": [(6, "home", ""), (6, "inn", "Pousada da Forja")], "R": [(7, "shop", "Ferraria Vila do Ferro"), (5, "home", "")]},
               1: {"L": [(6, "home", ""), (5, "home", "")], "R": [(5, "home", ""), (6, "home", "")]},
               2: {"L": [(5, "home", ""), (6, "home", "")], "R": [(6, "home", "")]}},
         inn=("Brunilda", "Pousada da Forja"), shop=("Thorin", "Ferraria Vila do Ferro")),
    dict(id="solmar", name="Vila do Pescador", cx=140, cy=119, roof="O", wall="W", ground="s", street="p",
         plan={0: {"L": [(6, "home", ""), (6, "shop", "Bazar das Conchas")], "R": [(6, "inn", "Pousada Sol Poente"), (6, "home", "")]},
               1: {"L": [(5, "home", ""), (6, "home", "")], "R": [(6, "home", ""), (5, "home", "")]},
               2: {"L": [(6, "home", "")], "R": [(5, "home", ""), (6, "home", "")]}},
         inn=("Sol", "Pousada Sol Poente"), shop=("Dona Concha", "Bazar das Conchas")),
]
CITY = {c["id"]: c for c in CIDADES}

# Regioes de floresta (cx, cy, rx, ry, tier, arvore: P normal / Q escura)
FLORESTAS = [
    dict(id="sussurrante", name="Floresta de Eldar", cx=50, cy=84, rx=34, ry=28, tier=2, tree="F", dens=0.55),
    dict(id="pinhal", name="Pinhal Antigo", cx=74, cy=116, rx=16, ry=11, tier=2, tree="P", dens=0.55),
    dict(id="mata_escura", name="Mata Escura", cx=94, cy=30, rx=36, ry=20, tier=4, tree="Q", dens=0.60),
    dict(id="gelida", name="Floresta Gélida", cx=20, cy=60, rx=18, ry=24, tier=3, tree="P", dens=0.55),
    dict(id="carmesim", name="Bosque Carmesim", cx=140, cy=36, rx=18, ry=24, tier=5, tree="Q", dens=0.60),
    dict(id="vale", name="Floresta do Vale", cx=114, cy=92, rx=18, ry=20, tier=2, tree="F", dens=0.52),
    dict(id="brumas", name="Mata das Brumas", cx=112, cy=58, rx=15, ry=14, tier=3, tree="P", dens=0.55),
    dict(id="verdejante", name="Floresta Verdejante", cx=80, cy=58, rx=20, ry=16, tier=2, tree="F", dens=0.55),
    dict(id="nebuloso", name="Bosque Encantado", cx=158, cy=104, rx=16, ry=14, tier=3, tree="F", dens=0.52),
    dict(id="pantano", name="Pântano Sombrio", cx=62, cy=100, rx=16, ry=11, tier=4, tree="d", dens=0.50),
]
# Biomas sem arvores densas (so clareiras/zonas): deserto
BIOMAS = [dict(id="dunas", name="Dunas Douradas", cx=96, cy=134, rx=16, ry=8, tier=3)]

LAGOS = [("Lago Cristalino", 108, 62, 8, 5), ("Lago Verde", 70, 86, 6, 4), ("Lago Gelado", 70, 22, 7, 5), ("Lagoa Sul", 98, 108, 5, 3)]
RIOS = [
    [(108, 66), (114, 78), (116, 92), (122, 106), (120, 122), (122, 142)],
    [(70, 26), (72, 40), (68, 54), (66, 70), (62, 84), (56, 100), (60, 116), (62, 142)],
]

# ------------------------------------------------------------------ grade
g = [["~"] * W for _ in range(H)]
reserved = [[None] * W for _ in range(H)]   # cidade/castelo (arvores nao crescem)
objects, npcs, portals, signs = [], [], [], []
zones = []

def inb(x, y):
    return 0 <= x < W and 0 <= y < H

def get(x, y):
    return g[y][x] if inb(x, y) else "~"

def put(x, y, ch):
    if inb(x, y):
        g[y][x] = ch

def fill(x, y, w, h, ch):
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            put(xx, yy, ch)

WATER = "w~"
def is_water(ch):
    return ch in WATER

# ---- 1. terra
def land_value(x, y):
    dx = (x - 96) / 90.0
    dy = (y - 76) / 68.0
    d = (abs(dx) ** 3.0 + abs(dy) ** 3.0) ** (1 / 3.0)
    return (1 - d) + (N_A[y][x] - 0.5) * 0.6

land = [[False] * W for _ in range(H)]
for y in range(H):
    for x in range(W):
        v = land_value(x, y)
        land[y][x] = v > 0.07
# planalto do castelo (canto nordeste)
for y in range(H):
    for x in range(W):
        ex = min(x - 126, 187 - x)
        ey = min(y - 3, 46 - y)
        e = min(ex, ey)
        if e + (N_B[y][x] - 0.5) * 7 > 1.5:
            land[y][x] = True
# enseada do porto
for y in range(H):
    for x in range(W):
        d = math.hypot((x - 6) / 17.0, (y - 114) / 12.0)
        if d + (N_B[y][x] - 0.5) * 0.35 < 1.0:
            land[y][x] = False

def components(mask):
    seen = [[False] * W for _ in range(H)]
    comps = []
    for y in range(H):
        for x in range(W):
            if mask(x, y) and not seen[y][x]:
                q = collections.deque([(x, y)])
                seen[y][x] = True
                cells = []
                while q:
                    cx, cy = q.popleft()
                    cells.append((cx, cy))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = cx + dx, cy + dy
                        if inb(nx, ny) and not seen[ny][nx] and mask(nx, ny):
                            seen[ny][nx] = True
                            q.append((nx, ny))
                comps.append(cells)
    return comps

# suaviza e mantem so o maior continente
for _ in range(2):
    new = [row[:] for row in land]
    for y in range(1, H - 1):
        for x in range(1, W - 1):
            n = sum(land[y + dy][x + dx] for dx in (-1, 0, 1) for dy in (-1, 0, 1) if dx or dy)
            if land[y][x] and n <= 3:
                new[y][x] = False
            elif not land[y][x] and n >= 6:
                new[y][x] = True
    land = new
comps = sorted(components(lambda x, y: land[y][x]), key=len, reverse=True)
keep = set(comps[0])
for y in range(H):
    for x in range(W):
        land[y][x] = (x, y) in keep
# buracos de agua pequenos viram terra
for comp in components(lambda x, y: not land[y][x]):
    if len(comp) < 60 and not any(x in (0, W - 1) or y in (0, H - 1) for x, y in comp):
        for x, y in comp:
            land[y][x] = True

def dist_from(mask_fn, limit=99):
    dist = [[limit] * W for _ in range(H)]
    q = collections.deque()
    for y in range(H):
        for x in range(W):
            if mask_fn(x, y):
                dist[y][x] = 0
                q.append((x, y))
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if inb(nx, ny) and dist[ny][nx] > dist[y][x] + 1:
                dist[ny][nx] = dist[y][x] + 1
                if dist[ny][nx] < limit:
                    q.append((nx, ny))
    return dist

d_land = dist_from(lambda x, y: land[y][x])      # distancia ate a terra (para agua)
d_sea = dist_from(lambda x, y: not land[y][x])   # distancia ate o mar (para terra)

for y in range(H):
    for x in range(W):
        if land[y][x]:
            g[y][x] = "."
        else:
            g[y][x] = "w" if d_land[y][x] <= 2 + (1 if N_C[y][x] > 0.55 else 0) else "~"

# ---- 2. biomas
def in_snow(x, y):
    d = math.hypot((x - 40) / 38.0, (y - 30) / 34.0)
    return d + (N_B[y][x] - 0.5) * 0.45 < 1.0 and land[y][x]

def in_waste(x, y):
    d = math.hypot((x - 158) / 36.0, (y - 26) / 38.0)
    return d + (N_B[y][x] - 0.5) * 0.45 < 1.0 and land[y][x]

SNOW = [[in_snow(x, y) for x in range(W)] for y in range(H)]
WASTE = [[in_waste(x, y) for x in range(W)] for y in range(H)]

def in_desert(x, y):
    d = math.hypot((x - 96) / 17.0, (y - 134) / 9.0)
    return d + (N_B[y][x] - 0.5) * 0.45 < 1.0 and land[y][x] and not SNOW[y][x] and not WASTE[y][x]

def in_swamp(x, y):
    d = math.hypot((x - 62) / 17.0, (y - 101) / 12.0)
    return d + (N_B[y][x] - 0.5) * 0.45 < 1.0 and land[y][x] and not SNOW[y][x] and not WASTE[y][x]

DESERT = [[in_desert(x, y) for x in range(W)] for y in range(H)]
SWAMP = [[in_swamp(x, y) for x in range(W)] for y in range(H)]

def base_ground(x, y):
    return "n" if SNOW[y][x] else ("k" if WASTE[y][x] else ("i" if DESERT[y][x] else ("a" if SWAMP[y][x] else ".")))
for y in range(H):
    for x in range(W):
        if not land[y][x]:
            continue
        if WASTE[y][x]:
            g[y][x] = "k"
        elif SNOW[y][x]:
            g[y][x] = "n"
        elif DESERT[y][x]:
            g[y][x] = "i"
            rim = 1.6 + 2.6 * N_C[y][x] + (1.5 if y > 100 or x < 30 else 0)
            if d_sea[y][x] <= rim:
                g[y][x] = "s"
        elif SWAMP[y][x]:
            g[y][x] = "="  if (N_B[y][x] > 0.60 and d_sea[y][x] > 6) else "a"
        else:
            if rnd(x, y, 1) < 0.10:
                g[y][x] = ","
            rim = 1.6 + 2.6 * N_C[y][x] + (1.5 if y > 100 or x < 30 else 0)
            if d_sea[y][x] <= rim:
                g[y][x] = "s"

# ---- 3. lagos e rios
INLAND = set()
def carve_blob(cx, cy, rx, ry, seed):
    for y in range(max(0, cy - ry - 3), min(H, cy + ry + 4)):
        for x in range(max(0, cx - rx - 3), min(W, cx + rx + 4)):
            d = math.hypot((x - cx) / rx, (y - cy) / ry) + (N_B[y][x] - 0.5) * 0.5
            if d < 1.0 and land[y][x]:
                g[y][x] = "~" if d < 0.55 else "w"
                INLAND.add((x, y))

for name, cx, cy, rx, ry in LAGOS:
    carve_blob(cx, cy, rx, ry, 0)

def carve_river(pts, width):
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        steps = int(max(abs(x1 - x0), abs(y1 - y0)) * 1.5)
        for i in range(steps + 1):
            t = i / max(1, steps)
            x = x0 + (x1 - x0) * t + math.sin(t * 9 + x0) * 2.2
            y = y0 + (y1 - y0) * t
            w = width + (1 if N_C[min(H - 1, int(y))][min(W - 1, int(x))] > 0.6 else 0)
            for yy in range(int(y) - w, int(y) + w + 1):
                for xx in range(int(x) - w, int(x) + w + 1):
                    if inb(xx, yy) and land[yy][xx] and math.hypot(xx - x, yy - y) <= w + 0.3:
                        g[yy][xx] = "w"
                        INLAND.add((xx, yy))

for pts in RIOS:
    carve_river(pts, 1)

# ---- 4. montanhas
def mountain(x, y):
    # macico leste
    d = math.hypot((x - 164) / 24.0, (y - 82) / 34.0)
    ridge = 1 - abs(2 * N_D[y][x] - 1)
    if d + (N_B[y][x] - 0.5) * 0.6 < 1.0 and ridge + (1 - d) * 0.8 > 0.95:
        return True
    # cordilheira norte entre a mata e as terras sombrias
    cx = 128 + math.sin(y / 9.0) * 4
    if 4 < y < 56 and abs(x - cx) < 2.6 + N_C[y][x] * 2.4:
        return True
    # montanhas ao redor de Vila da Neve (oeste/norte)
    if y < 14 and x < 70 and ridge > 0.62:
        return True
    return False

mt = [[mountain(x, y) for x in range(W)] for y in range(H)]
# passagens na cordilheira norte
for gy in (24, 44):
    for y in range(gy - 3, gy + 3):
        for x in range(118, 140):
            mt[y][x] = False

for y in range(H):
    for x in range(W):
        if mt[y][x] and land[y][x] and g[y][x] in ".,sknp":
            g[y][x] = "M"

# ---- 5. reservas: cidades + castelo
CASTLE = dict(cx=159, gate_y=31, moat_y=33)
def reserve(x0, y0, w, h, tag, margin=2):
    for y in range(y0 - margin, y0 + h + margin):
        for x in range(x0 - margin, x0 + w + margin):
            if inb(x, y):
                reserved[y][x] = tag

for c in CIDADES:
    c["x0"], c["y0"] = c["cx"] - 20, c["cy"] - 13
    reserve(c["x0"], c["y0"], 40, 26, c["id"])
reserve(128, 2, 60, 36, "castelo", 0)

# ---- 6. cidades
def city_ground(c, x, y):
    return c["ground"]

def build_city(c):
    x0, y0 = c["x0"], c["y0"]
    cx = c["cx"]
    # limpa caixa (com borda de transicao)
    for y in range(y0 - 1, y0 + 27):
        for x in range(x0 - 1, x0 + 41):
            if inb(x, y):
                edge = x in (x0 - 1, x0 + 40) or y in (y0 - 1, y0 + 26)
                if edge and rnd(x, y, 5) < 0.5:
                    continue
                g[y][x] = c["ground"]
                if c["ground"] in ".s" and rnd(x, y, 6) < 0.07 and c["ground"] == ".":
                    g[y][x] = ","
    street = c["street"]
    # avenida vertical
    fill(cx - 1, y0, 2, 26, street)
    houses = []
    for ti, (ht, sy) in enumerate(TERRACES):
        fill(x0 + 1, y0 + sy, 38, 2, street)
        for side in ("L", "R"):
            items = c["plan"].get(ti, {}).get(side, [])
            if side == "L":
                xs, xe = x0 + 2, cx - 3
            else:
                xs, xe = cx + 2, x0 + 38
            total = sum(w for w, _, _ in items)
            gap = max(1, (xe - xs - total) // (len(items) + 1)) if items else 0
            x = xs + gap
            for w, tag, label in items:
                # telhado
                fill(x, y0 + ht, w, 2, c["roof"])
                fill(x, y0 + ht + 2, w, 2, c["wall"])
                dx = w // 2
                door_x, door_y = x + dx, y0 + ht + 3
                if tag == "home":
                    put(door_x, door_y, "m")  # janela: casa fechada
                    if w >= 6:
                        put(x + 1, door_y - 1, "m")
                else:
                    put(door_x, door_y, "D")
                    if w >= 6:
                        put(x + 1, door_y - 1, "m")
                        put(x + w - 2, door_y - 1, "m")
                # caminho da porta ate a rua
                for yy in range(door_y + 1, y0 + sy):
                    put(door_x, yy, street)
                houses.append(dict(x=x, y=y0 + ht, w=w, tag=tag, label=label, door=(door_x, door_y)))
                x += w + gap
    # praca de pedra
    pcy = y0 + TERRACES[1][1]
    fill(cx - 5, pcy - 1, 10, 4, "q")
    fill(cx - 1, y0 + 2, 2, 24, street)
    fill(cx - 1, pcy - 1, 2, 4, "q")
    c["plaza"] = (cx, pcy)
    c["houses"] = houses
    # poco/fonte na praca
    wx, wy = cx + 3, pcy
    objects.append(dict(id="%s_well" % c["id"], type="well", x=wx, y=wy, text="%s: um poço de pedra, com água fresca e cristalina." % c["name"]))
    # arbustos e arvores decorativas nas bordas
    for x in range(x0 + 1, x0 + 39):
        for y in (y0 + 0, y0 + 25):
            if get(x, y) == c["ground"] or get(x, y) == ",":
                if rnd(x, y, 8) < 0.30:
                    put(x, y, "v" if rnd(x, y, 9) < 0.5 else ({"n": "A", "s": "y"}.get(c["ground"], "P")))
    for y in range(y0 + 1, y0 + 25):
        for x in (x0 + 0, x0 + 39):
            if get(x, y) == c["ground"] or get(x, y) == ",":
                if rnd(x, y, 10) < 0.25:
                    put(x, y, "v")
    # entradas de cada rua: abre a borda
    c["gates"] = dict(W=(x0, y0 + TERRACES[1][1]), E=(x0 + 39, y0 + TERRACES[1][1]),
                      N=(cx - 1, y0), S=(cx - 1, y0 + 25),
                      W3=(x0, y0 + TERRACES[2][1]), E3=(x0 + 39, y0 + TERRACES[2][1]),
                      W1=(x0, y0 + TERRACES[0][1]), E1=(x0 + 39, y0 + TERRACES[0][1]))
    for k, (gx, gy) in c["gates"].items():
        if k in ("W", "E", "W1", "E1", "W3", "E3"):
            fill(gx, gy, 1, 2, street)
        else:
            fill(gx, gy, 2, 1, street)
    # fazenda/decoracao extra por cidade
    if c["id"] == "porto":
        # pier para o mar
        for x in range(c["x0"] - 17, c["x0"] + 1):
            for y in (c["y0"] + 15, c["y0"] + 16):
                put(x, y, "B")
        fill(c["x0"] - 19, c["y0"] + 13, 3, 6, "B")
    if c["id"] == "solmar":
        for x in range(c["x0"] + 8, c["x0"] + 20):
            for y in (c["y0"] + 26, c["y0"] + 27):
                if inb(x, y) and is_water(get(x, y)):
                    put(x, y, "B")

for c in CIDADES:
    build_city(c)

# ---- 7. castelo demoniaco
def tower(cxt, top, hw, wall_bottom, windows=True):
    for r in range(hw * 2):          # telhado alto e pontudo (cada degrau dura 2 linhas)
        k = r // 2
        fill(cxt - k - 1, top + r, 2 * (k + 1), 1, "Y")
    wt = top + hw * 2
    for y in range(wt, wall_bottom + 1):
        fill(cxt - hw, y, 2 * hw, 1, "X")
        if windows and (y - wt) % 4 == 2:
            put(cxt - 1, y, "V")
            put(cxt, y, "V")
    fill(cxt - hw, wt, 2 * hw, 1, "C")

def build_castle():
    cx = CASTLE["cx"]
    # chao de cinzas dentro da caixa do castelo e arredores
    for y in range(2, 46):
        for x in range(126, 188):
            if land[y][x]:
                g[y][x] = "k" if g[y][x] not in "M" or x > 131 else g[y][x]
    # torres do fundo (de tras para a frente)
    tower(cx, 2, 5, 23)                  # torre-mestra
    tower(cx - 14, 9, 3, 23)
    tower(cx + 14, 9, 3, 23)
    tower(cx - 8, 13, 2, 23, False)
    tower(cx + 8, 13, 2, 23, False)
    # muralha frontal
    fill(cx - 24, 24, 49, 1, "C")
    fill(cx - 24, 25, 49, 7, "X")
    for x in range(cx - 22, cx + 23, 5):
        put(x, 27, "V")
    # torres de canto
    tower(cx - 26, 15, 3, 31)
    tower(cx + 26, 15, 3, 31)
    # portao
    gx = cx - 2
    fill(gx, 26, 4, 1, "e")
    fill(gx, 27, 4, 5, "E")
    # fosso de lava e ponte
    fill(cx - 30, 33, 61, 3, "l")
    fill(cx - 2, 33, 4, 3, "B")
    # laterais do fosso: pocas de lava dispersas
    for i in range(14):
        px = int(130 + rnd(i, 1, 40) * 55)
        py = int(38 + rnd(i, 2, 40) * 9)
        if abs(px - cx) < 10:
            continue
        for y in range(py - 1, py + 2):
            for x in range(px - 2, px + 3):
                if inb(x, y) and land[y][x] and g[y][x] == "k" and rnd(x, y, 41) < 0.8:
                    g[y][x] = "l"
    # espinhos de obsidiana e arvores mortas nos arredores
    for y in range(0, 47):
        for x in range(126, 190):
            if inb(x, y) and g[y][x] == "k" and not (cx - 4 <= x <= cx + 3 and y >= 33):
                if (y < 3 or y > 36 or x < 134 or x > 183) and rnd(x, y, 42) < 0.10:
                    g[y][x] = "z"
    # estrada de pedra negra ate a ponte
    fill(cx - 2, 36, 4, 12, "p")

build_castle()

# ---- 8. estradas (A*)
def cell_cost(x, y):
    ch = g[y][x]
    base = 1.0 + N_C[y][x] * 1.6
    if ch == "~":
        return None
    if ch == "w":
        return 15.0 if (x, y) in INLAND else None
    if ch == "M":
        return 22.0
    if ch in "l=":
        return None
    if ch in "XYCVEeRUZKOWgDm":
        return None
    r = reserved[y][x]
    if r is not None and r != "castelo":
        return base + 4.0
    if ch in "pqB":
        return 0.6
    return base

def astar(a, b):
    """A* com estado de direcao: dentro da agua (ponte) nao pode virar -> pontes retas."""
    sx, sy = a
    tx, ty = b
    DIRS = ((1, 0), (-1, 0), (0, 1), (0, -1))
    start = (sx, sy, -1)
    openq = [(0, sx, sy, -1)]
    came = {}
    cost = {start: 0.0}
    goal = None
    while openq:
        _, x, y, d = heapq.heappop(openq)
        if (x, y) == (tx, ty):
            goal = (x, y, d)
            break
        here_water = g[y][x] == "w"
        for nd, (dx, dy) in enumerate(DIRS):
            if here_water and d != -1 and nd != d:
                continue
            nx, ny = x + dx, y + dy
            if not (1 <= nx < W - 1 and 1 <= ny < H - 1):
                continue
            cc = cell_cost(nx, ny)
            if cc is None:
                continue
            nc = cost[(x, y, d)] + cc + (0.35 if (d != -1 and nd != d) else 0.0)
            key = (nx, ny, nd)
            if nc < cost.get(key, 1e18):
                cost[key] = nc
                came[key] = (x, y, d)
                heapq.heappush(openq, (nc + (abs(tx - nx) + abs(ty - ny)) * 0.9, nx, ny, nd))
    if goal is None:
        return []
    path = []
    cur = goal
    while cur != start:
        path.append((cur[0], cur[1]))
        cur = came[cur]
    path.append((sx, sy))
    return path[::-1]

def carve_road(path):
    for (x, y) in path:
        for dx in (0, 1):
            for dy in (0, 1):
                xx, yy = x + dx, y + dy
                if not inb(xx, yy):
                    continue
                ch = g[yy][xx]
                if ch in "XYCVEelm" or ch in "D":
                    continue
                if reserved[yy][xx] == "castelo" and ch not in ".,knspM":
                    continue
                if ch in "w":
                    g[yy][xx] = "B"
                elif ch == "~":
                    continue
                elif ch in "qB":
                    continue
                else:
                    g[yy][xx] = "p"

def road(a, b):
    p = astar(a, b)
    if not p:
        print("AVISO: sem estrada", a, b)
        return
    carve_road(p)

def gate(cid, k):
    return CITY[cid]["gates"][k]

# pontos especiais
TRAIN_PORTAL = (116, 128)       # entrada da Floresta de Treino (sul da vila)
OUTPOST = dict(cx=152, cy=57)   # Acampamento Vigia
reserve(OUTPOST["cx"] - 8, OUTPOST["cy"] - 5, 16, 10, "vigia", 1)

routes = [
    (gate("aurora", "W"), gate("pinheiral", "E")),
    (gate("aurora", "E"), gate("pedralta", "W")),
    (gate("aurora", "S"), gate("solmar", "W3")),
    (gate("pinheiral", "W3"), gate("porto", "N")),
    (gate("aurora", "W3"), gate("porto", "E")),
    (gate("pinheiral", "N"), gate("nevasca", "S")),
    (gate("pedralta", "E1"), (OUTPOST["cx"], OUTPOST["cy"] + 5)),
    (gate("solmar", "N"), gate("pedralta", "S")),
    (gate("nevasca", "E"), (88, 36)),
    ((88, 36), (CASTLE["cx"] - 1, 47)),
    ((OUTPOST["cx"], OUTPOST["cy"] - 5), (CASTLE["cx"] - 1, 47)),
]
for a, b in routes:
    road(a, b)
# trilha ate o portal da Floresta de Treino (ao sul de Vila Aurora)
road(gate("aurora", "S"), TRAIN_PORTAL)

# ---- 9. acampamento Vigia (posto avancado)
def build_outpost():
    cx, cy = OUTPOST["cx"], OUTPOST["cy"]
    for y in range(cy - 5, cy + 5):
        for x in range(cx - 8, cx + 8):
            if inb(x, y) and g[y][x] in "wM~":
                continue
            put(x, y, "k" if WASTE[y][x] else ".")
    for hx, tag in ((cx - 7, "home"), (cx + 2, "home")):
        fill(hx, cy - 4, 5, 2, "K")
        fill(hx, cy - 2, 5, 2, "g")
        put(hx + 2, cy - 1, "m")
    fill(cx - 1, cy - 5, 2, 10, "p")
    fill(cx - 7, cy, 14, 2, "p")
    objects.append(dict(id="vigia_rest", type="rest", x=cx - 3, y=cy + 2))
    objects.append(dict(id="vigia_sign", type="sign", x=cx + 2, y=cy + 2,
                        text="Acampamento Vigia\nÚltimo refúgio antes das Região Vulcânica.\nO Castelo Sombrio fica ao norte — volte quando estiver preparado!"))
    npcs.append(dict(id="vigia_sgt", name="Sargento Dagna", x=cx + 2, y=cy, dir="down", look="guard", role="talk",
                     lines=["Eu vigio o castelo há dez invernos. As luzes vermelhas nunca se apagam.",
                            "Os portões estão selados por magia antiga. Nenhum de nós conseguiu abri-los... ainda."]))
    npcs.append(dict(id="vigia_scout", name="Batedor Kael", x=cx - 5, y=cy + 3, dir="right", look="villager_m", role="talk",
                     lines=["Ao norte ficam o Bosque Carmesim e os rios de lava. Nada de bom vive lá.",
                            "Se precisar descansar, use o cristal ao lado da barraca."]))
build_outpost()

# ---- 10. arvores / florestas
def forest_weight(f, x, y):
    d = math.hypot((x - f["cx"]) / f["rx"], (y - f["cy"]) / f["ry"]) + (N_B[y][x] - 0.5) * 0.55
    return smooth(1.25, 0.45, d)

def region_forest_at(x, y):
    best, bw = None, 0.0
    for f in FLORESTAS:
        w = forest_weight(f, x, y)
        if w > bw:
            best, bw = f, w
    return best, bw

TREEABLE = ".,snksia"
def tree_for(f, x, y, ch):
    if ch == "n":
        return "A"
    if ch == "k":
        return "Q"
    if ch == "a":
        return "d"
    if f["tree"] == "F":
        return "F" if N_C[y][x] > 0.40 else "P"
    if f["tree"] == "d":
        return "d"
    if f["tree"] == "Q":
        return "Q" if N_C[y][x] > 0.30 else "P"
    return "P"

for y in range(H):
    for x in range(W):
        ch = g[y][x]
        if ch not in TREEABLE or reserved[y][x] is not None:
            continue
        f, w = region_forest_at(x, y)
        if f is not None and w > 0.02:
            t = w * 1.0 + (N_C[y][x] - 0.5) * 0.9 + (f["dens"] - 0.5) * 0.4
            if ch == "s" and w < 0.9:
                continue
            if t > 0.30:
                g[y][x] = tree_for(f, x, y, ch)
                continue
        # arvores/arbustos/pedras espalhados
        r = rnd(x, y, 11)
        if ch in ".," and d_sea[y][x] > 4:
            if r < 0.035:
                g[y][x] = "P"
            elif r < 0.048:
                g[y][x] = "v"
            elif r < 0.056:
                g[y][x] = "o"
        elif ch == "n":
            if r < 0.02:
                g[y][x] = "A"
        elif ch == "k":
            if r < 0.045:
                g[y][x] = "Q"
            elif r < 0.06:
                g[y][x] = "z"
        elif ch == "i":
            if r < 0.030:
                g[y][x] = "u"
            elif r < 0.042:
                g[y][x] = "y"
            elif r < 0.054:
                g[y][x] = "o"
        elif ch == "a":
            if r < 0.10:
                g[y][x] = "d"
        elif ch == "s" and d_sea[y][x] <= 6 and r < 0.012:
            g[y][x] = "y"

# gelo: blocos de pedra de gelo na regiao de neve
for i in range(70):
    cx = int(8 + rnd(i, 3, 50) * 80)
    cy = int(6 + rnd(i, 4, 50) * 66)
    if not (inb(cx, cy) and SNOW[cy][cx]) or reserved[cy][cx] is not None:
        continue
    size = 1 + int(rnd(i, 5, 50) * 3)
    for yy in range(cy - size, cy + size + 1):
        for xx in range(cx - size, cx + size + 1):
            if inb(xx, yy) and g[yy][xx] in "nA" and reserved[yy][xx] is None and rnd(xx, yy, 52) < 0.78:
                g[yy][xx] = "I"

# ---- 11. clareiras (zonas futuras de monstros) e trilhas
def carve_glade(cx, cy, r, ground):
    for y in range(cy - r, cy + r + 1):
        for x in range(cx - r, cx + r + 1):
            if inb(x, y) and math.hypot(x - cx, y - cy) <= r + 0.3 and g[y][x] in "PQAFdyuv" + ground + ",o":
                g[y][x] = "," if ground == "." and rnd(x, y, 60) < 0.18 else ground

for f in FLORESTAS + BIOMAS:
    n = 0
    tries = 0
    while n < 4 and tries < 300:
        tries += 1
        x = int(f["cx"] + (rnd(tries, n, 70 + len(f["id"])) - 0.5) * 2 * f["rx"] * 0.8)
        y = int(f["cy"] + (rnd(tries, n, 80 + len(f["id"])) - 0.5) * 2 * f["ry"] * 0.8)
        if not inb(x, y) or reserved[y][x] is not None:
            continue
        if forest_weight(f, x, y) < 0.7 or g[y][x] in "wM~lBpq":
            continue
        if any(math.hypot(x - z["x"], y - z["y"]) < 14 for z in zones):
            continue
        ground = base_ground(x, y)
        carve_glade(x, y, 3, ground)
        zones.append(dict(id="%s_z%d" % (f["id"], n), region=f["id"], x=x, y=y, r=3, tier=f["tier"]))
        n += 1

# ---- 11b. trilhas: liga cada clareira a rede principal por um caminho sinuoso
def trail_to_network(zx, zy, main_set):
    pq = [(0.0, zx, zy)]
    cost = {(zx, zy): 0.0}
    came = {}
    while pq:
        c0, x, y = heapq.heappop(pq)
        if (x, y) in main_set and (x, y) != (zx, zy):
            path = [(x, y)]
            while (x, y) != (zx, zy):
                x, y = came[(x, y)]
                path.append((x, y))
            return path
        if c0 > cost.get((x, y), 1e18):
            continue
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if not (1 <= nx < W - 1 and 1 <= ny < H - 1):
                continue
            ch = g[ny][nx]
            if ch in "w~=MlXYCVEeUZKORWgDmj":
                continue
            cc = 1.0 + N_C[ny][nx] * 1.5 + (2.5 if ch in "PQAFdyuvIoz" else 0.0)
            nc = c0 + cc
            if nc < cost.get((nx, ny), 1e18):
                cost[(nx, ny)] = nc
                came[(nx, ny)] = (x, y)
                heapq.heappush(pq, (nc, nx, ny))
    return None

def walk_set(start):
    seen = {start}
    q = collections.deque([start])
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if (nx, ny) not in seen and inb(nx, ny) and get(nx, ny) in ".,pqsnkiaB_DhN":
                seen.add((nx, ny))
                q.append((nx, ny))
    return seen

_cx, _cy = CITY["aurora"]["plaza"]
main_set = walk_set((_cx - 3, _cy))
for z in zones:
    if (z["x"], z["y"]) in main_set:
        continue
    path = trail_to_network(z["x"], z["y"], main_set)
    if not path:
        continue
    for (x, y) in path:
        if g[y][x] in "PQAFdyuvIoz":
            g[y][x] = base_ground(x, y)
    main_set = walk_set((_cx - 3, _cy))

# ---- 11c. ruinas antigas (circulos de pilares com bau no centro)
RUINAS = [
    dict(id="eldar", x=34, y=92, name="Ruínas de Eldar", text="Ruínas de Eldar\nPilares cobertos de musgo. Diz a lenda que elfos guardavam aqui um tesouro."),
    dict(id="vale", x=128, y=101, name="Ruínas do Vale", text="Ruínas do Vale\nUm antigo posto de vigia da era de Aurora. Alguém esqueceu um baú."),
    dict(id="dunas", x=96, y=131, name="Templo Soterrado", text="Templo Soterrado\nA areia engoliu quase tudo. Quase."),
    dict(id="pantano", x=66, y=100, name="Altar do Pântano", text="Altar do Pântano\nEntalhes antigos mostram uma coroa quebrada."),
    dict(id="escura", x=80, y=24, name="Altar das Corujas", text="Altar das Corujas\nAs corujas daqui observam todos os que passam."),
]
ruins_built = []
def build_ruin(rn):
    cx, cy = rn["x"], rn["y"]
    if not inb(cx, cy) or reserved[cy][cx] is not None or g[cy][cx] in "w~=lMB":
        return
    ground = base_ground(cx, cy)
    for y in range(cy - 4, cy + 5):
        for x in range(cx - 4, cx + 5):
            if inb(x, y) and g[y][x] not in "w~=lMB" and reserved[y][x] is None:
                g[y][x] = ground
    for dx, dy in ((-3, -3), (0, -3), (3, -3), (-3, 0), (3, 0), (-3, 3), (3, 3)):
        put(cx + dx, cy + dy, "j")
    ruins_built.append(rn)
for rn in RUINAS:
    build_ruin(rn)

# ---- 12. conectividade: liga todos os trechos ao continente principal
def walkable(x, y):
    return get(x, y) in ".,pqsnkiaB_DhN"

def main_start():
    cx, cy = CITY["aurora"]["plaza"]
    return (cx - 3, cy)

def connect_all():
    for it in range(60):
        comps = components(walkable)
        comps.sort(key=len, reverse=True)
        main = set(comps[0])
        rest = [c for c in comps[1:] if len(c) > 0]
        if not rest:
            return
        changed = False
        for comp in rest:
            if len(comp) < 25:
                for x, y in comp:
                    if g[y][x] not in "DB":
                        g[y][x] = "P" if not SNOW[y][x] else "A"
                changed = True
                continue
            # tunel ate o ponto mais proximo do principal
            best = None
            cs = comp[::max(1, len(comp) // 40)]
            ms = list(main)[::max(1, len(main) // 3000)]
            for (x, y) in cs:
                for (mx, my) in ms:
                    d = abs(x - mx) + abs(y - my)
                    if best is None or d < best[0]:
                        best = (d, (x, y), (mx, my))
            _, a, b = best
            x, y = a
            while (x, y) != b:
                if x != b[0] and (abs(x - b[0]) >= abs(y - b[1])):
                    x += 1 if b[0] > x else -1
                else:
                    y += 1 if b[1] > y else -1
                if g[y][x] in "PQAFdyuvIoMzl":
                    g[y][x] = "p" if g[y][x] in "M" else base_ground(x, y)
                elif g[y][x] == "w":
                    g[y][x] = "B"
            changed = True
        if not changed:
            return

connect_all()

# ---- 13. objetos
def free_cell(x, y):
    if any(abs(x - z["x"]) <= 1 and abs(y - z["y"]) <= 1 for z in zones):
        return False
    return walkable(x, y) and get(x, y) not in "pqB" and reserved[y][x] is None and not any(o["x"] == x and o["y"] == y for o in objects)

def near_blocked_ok(x, y):
    # evita objetos que fechem passagem: exige 3+ vizinhos livres
    n = 0
    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        if walkable(x + dx, y + dy):
            n += 1
    return n >= 3

region_cache = {}
def tier_at(x, y):
    f, w = region_forest_at(x, y)
    if WASTE[y][x]:
        return 5
    if f is not None and w > 0.3:
        return f["tier"]
    if SNOW[y][x]:
        return 3
    return 1

# cristais de descanso, banners e placas de caminho
def add_rest(rid, x, y):
    for dx in range(-3, 4):
        for dy in range(-3, 4):
            if free_cell(x + dx, y + dy) and near_blocked_ok(x + dx, y + dy):
                objects.append(dict(id=rid, type="rest", x=x + dx, y=y + dy))
                return True
    return False

REST_SPOTS = [(70, 56), (30, 74), (62, 112), (92, 52), (120, 46), (112, 104), (150, 98), (38, 44), (150, 22), (84, 128), (100, 20)]
ri = 0
for (x, y) in REST_SPOTS:
    if add_rest("ilha_rest_%d" % ri, x, y):
        ri += 1

# placas de entrada das cidades
for c in CIDADES:
    gx, gy = c["gates"]["S"]
    for (sx, sy) in ((gx + 3, gy - 1), (gx - 2, gy - 1), (gx + 3, gy), (gx - 2, gy)):
        if get(sx, sy) in ".,sn" and not any(o["x"] == sx and o["y"] == sy for o in objects):
            objects.append(dict(id="%s_sign" % c["id"], type="sign", x=sx, y=sy,
                                text="%s\n%s" % (c["name"], {"aurora": "Sede da Guilda dos Aventureiros.", "pinheiral": "A vila dos lenhadores, no coração da floresta.",
                                                              "porto": "Porto de pescadores — o cais fica a oeste.", "nevasca": "A vila mais fria da ilha. Vista um bom casaco!",
                                                              "pedralta": "Minas e forjas ao pé da serra.", "solmar": "Sol, areia e brisa do mar."}[c["id"]])))
            break

# placas de aviso em cruzamentos importantes
EXTRA_SIGNS = [
    ((97, 62), "Encruzilhada\n↑ Mata das Brumas   → Vila do Ferro\n← Vila Aurora"),
    ((116, 124), "Floresta de Treino\nUm bom lugar para iniciantes."),
    ((158, 49), "⚠ Região Vulcânica\nAo norte fica o Castelo Sombrio.\nSó os mais fortes voltam de lá."),
    ((70, 40), "Mata Escura\nOs lenhadores não entram aqui depois do anoitecer."),
]
for i, ((x, y), text) in enumerate(EXTRA_SIGNS):
    for dx in range(-3, 4):
        placed = False
        for dy in range(-3, 4):
            sx, sy = x + dx, y + dy
            if get(sx, sy) in ".,sknpia" and reserved[sy][sx] is None and near_blocked_ok(sx, sy) and not any(o["x"] == sx and o["y"] == sy for o in objects):
                objects.append(dict(id="ilha_sign_%d" % i, type="sign", x=sx, y=sy, text=text))
                placed = True
                break
        if placed:
            break

# portao selado do castelo
objects.append(dict(id="castelo_selo", type="seal", x=CASTLE["cx"] - 1, y=31,
                    text="Os portões do castelo estão selados por uma magia sombria.\nUma energia vermelha pulsa por trás das portas...\n(O interior do castelo será liberado em uma atualização futura.)"))
# braseiros ao longo da estrada do castelo
for yy in range(37, 47, 3):
    for xx in (CASTLE["cx"] - 4, CASTLE["cx"] + 3):
        if get(xx, yy) in "kp.":
            objects.append(dict(id="braseiro_%d_%d" % (xx, yy), type="brazier", x=xx, y=yy))

# ervas e baus
herb_n = 0
chest_n = 0
cands = [(x, y) for y in range(H) for x in range(W) if free_cell(x, y) and near_blocked_ok(x, y) and get(x, y) in ".,nkia"]
def pick(seed, mind, taken):
    import random
    rng = random.Random(seed)
    rng.shuffle(cands)
    out = []
    for (x, y) in cands:
        if any(abs(x - tx) + abs(y - ty) < mind for tx, ty in taken + out):
            continue
        out.append((x, y))
        yield (x, y)

taken = [(o["x"], o["y"]) for o in objects]
for (x, y) in pick(5, 9, taken):
    if tier_at(x, y) >= 5:
        continue
    f, w = region_forest_at(x, y)
    if w < 0.25 and rnd(x, y, 99) > 0.35:
        continue
    if herb_n >= 46:
        break
    objects.append(dict(id="ilha_h%d" % herb_n, type="bush", x=x, y=y))
    herb_n += 1
taken = [(o["x"], o["y"]) for o in objects]
FLOOR_BY_TIER = {1: 2, 2: 4, 3: 7, 4: 11, 5: 15}
for (x, y) in pick(9, 15, taken):
    if chest_n >= 34:
        break
    t = tier_at(x, y)
    f, w = region_forest_at(x, y)
    if t == 1 and rnd(x, y, 98) > 0.3:
        continue
    objects.append(dict(id="ilha_c%d" % chest_n, type="chest", x=x, y=y, floor=FLOOR_BY_TIER[t]))
    chest_n += 1

# ruinas: bau raro no centro + placa
for rn in ruins_built:
    t = tier_at(rn["x"], rn["y"])
    objects.append(dict(id="ruina_%s_bau" % rn["id"], type="chest", x=rn["x"], y=rn["y"], floor=min(18, FLOOR_BY_TIER[max(1, t)] + 3)))
    objects.append(dict(id="ruina_%s_placa" % rn["id"], type="sign", x=rn["x"] + 2, y=rn["y"] + 2, text=rn["text"]))

# ---- 14. NPCs das cidades
LINES = {
    "aurora": [
        ("Ancião Orin", "elder", "elder", None),
        ("Marta", "villager_f", "villager1", None),
        ("Tobias", "villager_m", "villager2", None),
        ("Guarda Bruno", "guard", "talk", ["Vila Aurora é a cidade mais segura da ilha. Mas além das muralhas...", "Ao sul fica a Floresta de Treino. Para o resto da ilha, siga as estradas!"]),
    ],
    "pinheiral": [
        ("Lenhador Gus", "villager_m", "talk", ["Derrubamos pinheiros desde o tempo do meu avô. A Floresta de Eldar nunca acaba!", "Dizem que ela murmura à noite. Eu prefiro não escutar."]),
        ("Dona Lúcia", "villager_f", "talk", ["Ao norte, a estrada leva a Vila da Neve. Ao sul, ao Porto Âmbar."]),
        ("Pequeno Tomé", "villager_m", "talk", ["Eu vi um lobo enorme perto do Pinhal Antigo! Ninguém acredita em mim..."]),
    ],
    "porto": [
        ("Pescador Zeca", "villager_m", "talk", ["Os peixes sumiram perto da costa nordeste. Algo sombrio acordou lá.", "Se um dia houver barcos, o Capitão Brás saberá navegar."]),
        ("Rita", "villager_f", "talk", ["O Porto Âmbar recebe navios de longe... quando o mar está calmo."]),
        ("Marujo Beto", "guard", "talk", ["Este cais é o mais longo da ilha. Ande até o fim e veja o mar!"]),
    ],
    "nevasca": [
        ("Caçador Ragnar", "villager_m", "talk", ["Na Floresta Gélida há criaturas de pelo branco. Vistam-se bem e levem poções.", "Ao leste, a estrada segue pela Mata Escura até as montanhas."]),
        ("Velha Sigrid", "villager_f", "talk", ["Meu bisavô contava que o castelo no nordeste foi erguido numa só noite, por demônios."]),
        ("Guarda Leif", "guard", "talk", ["O frio mantém os monstros quietos. Na maior parte do tempo."]),
    ],
    "pedralta": [
        ("Mineiro Dolf", "villager_m", "talk", ["A serra tem veios de metal raro. Mas as passagens ao norte levam às Região Vulcânica.", "Siga a estrada nordeste até o Acampamento Vigia — é o último abrigo."]),
        ("Ferreira Hanna", "villager_f", "talk", ["Uma boa espada vale mais que mil palavras. Passe na ferraria!"]),
        ("Capitão Rurik", "guard", "talk", ["O castelo demoníaco se ergue no canto nordeste da ilha. Seus portões estão selados. Por enquanto."]),
    ],
    "solmar": [
        ("Surfista Caio", "villager_m", "talk", ["As ondas de Vila do Pescador são as melhores! Só não vá nadar à noite."]),
        ("Dona Pérola", "villager_f", "talk", ["Colho conchas todo dia. Uma vez achei uma que cantava!"]),
        ("Guarda Nina", "guard", "talk", ["Ao oeste fica Vila Aurora; ao norte, Vila do Ferro. A Selva do Sul tem ervas curativas."]),
    ],
}

def street_cells(c):
    cells = []
    x0, y0, cx = c["x0"], c["y0"], c["cx"]
    for ti, (ht, sy) in enumerate(TERRACES):
        for x in range(x0 + 3, x0 + 37):
            for y in (y0 + sy, y0 + sy + 1):
                if get(x, y) in "pq" and abs(x - cx) > 2:
                    cells.append((x, y))
    return cells

import random
def place_npc(c, nid, name, look, role, lines, cell, extra=None):
    d = dict(id=nid, name=name, x=cell[0], y=cell[1], dir="down", look=look, role=role)
    if lines:
        d["lines"] = lines
    if extra:
        d.update(extra)
    npcs.append(d)

for c in CIDADES:
    rng = random.Random(hash(c["id"]) & 0xFFFF)
    cells = street_cells(c)
    rng.shuffle(cells)
    used = []
    def take():
        for cell in cells:
            if cell in used:
                continue
            if any(abs(cell[0] - u[0]) + abs(cell[1] - u[1]) < 6 for u in used):
                continue
            if any(o["x"] == cell[0] and o["y"] == cell[1] for o in objects):
                continue
            used.append(cell)
            return cell
        return None
    for i, (name, look, role, lines) in enumerate(LINES[c["id"]]):
        cell = take()
        if cell is None:
            continue
        if c["id"] == "aurora" and role == "elder":
            cell = (c["plaza"][0] - 2, c["plaza"][1])
            used.append(cell)
        place_npc(c, "%s_npc%d" % (c["id"], i), name, look, role, lines, cell)

# ---- 15. portais e interiores
interiors = {}
for c in CIDADES:
    for h in c["houses"]:
        if h["tag"] == "home":
            continue
        dx, dy = h["door"]
        if h["tag"] == "guild":
            iid = "guild"
        else:
            iid = "%s_%s" % (h["tag"], c["id"])
        title = h["label"]
        interiors[iid] = dict(kind=h["tag"], title=title, city=c["id"], ret_x=dx, ret_y=dy + 1,
                              npc_name=(c["inn"][0] if h["tag"] == "inn" else (c["shop"][0] if h["tag"] == "shop" else "")),
                              place=title)
        portals.append(dict(x=dx, y=dy, to=iid, tx=5, ty=6, dir="up", label=title))
        if h["tag"] != "guild":
            pass
        # placa na frente
        sx, sy = dx + 2, dy + 1
        if get(sx, sy) in "pq.,sn" and not any(o["x"] == sx and o["y"] == sy for o in objects):
            objects.append(dict(id="sign_%s" % iid, type="sign", x=sx, y=sy, text=title))
# floresta de treino
portals.append(dict(x=TRAIN_PORTAL[0], y=TRAIN_PORTAL[1], to="forest", tx=1, ty=12, dir="right", label="Floresta de Treino"))
portals.append(dict(x=TRAIN_PORTAL[0], y=TRAIN_PORTAL[1] + 1, to="forest", tx=1, ty=13, dir="right", label="Floresta de Treino"))

# ---- 16. entrada da floresta de treino (arco de pedra + caminho)
tx, ty = TRAIN_PORTAL
for yy in range(ty - 3, ty + 5):
    for xx in range(tx - 3, tx + 3):
        if inb(xx, yy) and g[yy][xx] not in "w~":
            g[yy][xx] = "."
fill(tx - 3, ty, 4, 2, "p")
g[ty][tx] = "h"
g[ty + 1][tx] = "h"
put(tx, ty - 1, "o")
put(tx, ty + 2, "o")
# alinha o resultado de A*: garante que o caminho chegue
road(gate("aurora", "S"), (tx - 3, ty))

# ---- 17. regioes (nomes)
REGIONS = [dict(id="campos", name="Campos de Aurora", tier=1, forest=False, bg="field")]
for f in FLORESTAS:
    REGIONS.append(dict(id=f["id"], name=f["name"], tier=f["tier"], forest=True, bg="forest"))
REGIONS += [
    dict(id="geladas", name="Montanha Glacial", tier=3, forest=False, bg="field"),
    dict(id="dunas", name="Dunas Douradas", tier=3, forest=False, bg="field"),
    dict(id="sombrias", name="Região Vulcânica", tier=5, forest=False, bg="dungeon"),
    dict(id="serra", name="Montanhas da Ruína", tier=3, forest=False, bg="field"),
    dict(id="costa", name="Costa Dourada", tier=1, forest=False, bg="field"),
    dict(id="castelo", name="Castelo Sombrio", tier=6, forest=False, bg="dungeon"),
    dict(id="vigia", name="Acampamento Vigia", tier=1, forest=False, bg="field"),
]
for c in CIDADES:
    REGIONS.append(dict(id=c["id"], name=c["name"], tier=0, forest=False, bg="field"))
RID = {r["id"]: i for i, r in enumerate(REGIONS)}
CHARS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

region_rows = []
for y in range(H):
    row = []
    for x in range(W):
        ch = g[y][x]
        if ch in "w~" or (not land[y][x] and ch not in "B"):
            row.append(".")
            continue
        rid = None
        r = reserved[y][x]
        if r == "castelo" and 2 <= y <= 46 and x >= 126:
            rid = "castelo" if (y <= 38) else "sombrias"
        elif r in CITY:
            rid = r
        elif r == "vigia":
            rid = "vigia"
        else:
            f, w = region_forest_at(x, y)
            if DESERT[y][x] and ch in "iyuos" and (f is None or w < 0.6):
                rid = "dunas"
            elif f is not None and w > 0.30:
                rid = f["id"]
            elif WASTE[y][x]:
                rid = "sombrias"
            elif SNOW[y][x]:
                rid = "geladas"
            elif x > 118 and 46 < y < 112 and ch in "M":
                rid = "serra"
            elif d_sea[y][x] <= 5:
                rid = "costa"
            else:
                rid = "campos"
        row.append(CHARS[RID[rid]])
    region_rows.append("".join(row))

# ---- 18. validacao
sx, sy = main_start()
if not walkable(sx, sy):
    for dx in range(-3, 4):
        if walkable(sx + dx, sy):
            sx += dx
            break
START = (sx, sy)
RESPAWN = (CITY["aurora"]["plaza"][0] - 5, CITY["aurora"]["plaza"][1])

def bfs(start):
    seen = {start}
    q = collections.deque([start])
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if (nx, ny) in seen or not inb(nx, ny):
                continue
            blocked_obj = any(o["x"] == nx and o["y"] == ny for o in objects) or any(n["x"] == nx and n["y"] == ny for n in npcs)
            if walkable(nx, ny) and not blocked_obj:
                seen.add((nx, ny))
                q.append((nx, ny))
    return seen

reach = bfs(START)
def _adj(o):
    return any((o['x'] + dx, o['y'] + dy) in reach for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
objects[:] = [o for o in objects if _adj(o)]
zones[:] = [z for z in zones if (z['x'], z['y']) in reach]
problems = 0
def need(label, x, y, adj=False):
    global problems
    ok = (x, y) in reach or (adj and any((x + dx, y + dy) in reach for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))))
    if not ok:
        problems += 1
        print("INALCANCAVEL:", label, x, y)

for p in portals:
    need("portal " + p["label"], p["x"], p["y"], True)
for o in objects:
    need("obj " + o["id"], o["x"], o["y"], True)
for n in npcs:
    need("npc " + n["id"], n["x"], n["y"], True)
for z in zones:
    need("zona " + z["id"], z["x"], z["y"], True)
need("start", *START)
need("respawn", *RESPAWN)
need("castelo_ponte", CASTLE["cx"] - 1, 40)
walk_total = sum(1 for y in range(H) for x in range(W) if walkable(x, y))
print("terra andavel: %d  alcancavel: %d  problemas: %d" % (walk_total, len(reach), problems))
print("floresta: %d arvores" % sum(1 for y in range(H) for x in range(W) if g[y][x] in "PQA"))

# ---- 19. saida
rows = ["".join(r) for r in g]

def gd(v):
    return json.dumps(v, ensure_ascii=False)

def emit():
    out = []
    out.append("class_name IlhaData")
    out.append("extends RefCounted")
    out.append("## GERADO por tools/gerar_ilha.py — nao edite a mao (rode o script de novo).")
    out.append("## Mapa da Ilha de Aurora: terreno, regioes, cidades, portais, NPCs e objetos.")
    out.append("")
    out.append("const W := %d" % W)
    out.append("const H := %d" % H)
    out.append("const START := Vector2i(%d, %d)" % START)
    out.append("const RESPAWN := Vector2i(%d, %d)" % RESPAWN)
    out.append("const TRAIN_PORTAL := Vector2i(%d, %d)" % TRAIN_PORTAL)
    out.append("const CASTLE_GATE := Vector2i(%d, %d)" % (CASTLE["cx"] - 1, 31))
    out.append("")
    out.append("const ROWS: Array = [")
    for r in rows:
        out.append("\t%s," % gd(r))
    out.append("]")
    out.append("")
    out.append("## Uma letra por celula = indice em REGIONS ('.' = mar).")
    out.append("const REGION_CHARS := %s" % gd(CHARS))
    out.append("const REGION_ROWS: Array = [")
    for r in region_rows:
        out.append("\t%s," % gd(r))
    out.append("]")
    out.append("")
    out.append("const REGIONS: Array = %s" % gd(REGIONS))
    cities = [dict(id=c["id"], name=c["name"], x=c["cx"], y=c["cy"], plaza_x=c["plaza"][0], plaza_y=c["plaza"][1]) for c in CIDADES]
    cities.append(dict(id="vigia", name="Acampamento Vigia", x=OUTPOST["cx"], y=OUTPOST["cy"], plaza_x=OUTPOST["cx"], plaza_y=OUTPOST["cy"]))
    cities.append(dict(id="castelo", name="Castelo Sombrio", x=CASTLE["cx"], y=20, plaza_x=CASTLE["cx"], plaza_y=38))
    out.append("const CITIES: Array = %s" % gd(cities))
    out.append("const INTERIORS: Dictionary = %s" % gd(interiors))
    out.append("const PORTALS: Array = %s" % gd(portals))
    out.append("const NPCS: Array = %s" % gd(npcs))
    out.append("const OBJECTS: Array = %s" % gd(objects))
    out.append("## Clareiras de floresta: pontos onde os monstros aparecerao no futuro.")
    out.append("const ZONES: Array = %s" % gd(zones))
    out.append("")
    return "\n".join(out)

dest = os.path.join(ROOT, "scripts", "world", "ilha_data.gd")
with open(dest, "w", encoding="utf-8") as fh:
    fh.write(emit())
print("escrito", dest)

# ---- preview
if "--png" in sys.argv:
    from PIL import Image
    COL = {"~": (20, 50, 110), "w": (40, 100, 190), ".": (84, 150, 70), ",": (110, 160, 80), "s": (222, 204, 140), "n": (236, 242, 250), "k": (70, 50, 70),
           "p": (170, 130, 80), "q": (160, 160, 160), "B": (120, 80, 40), "P": (20, 90, 40), "Q": (10, 40, 40), "A": (150, 200, 190), "M": (110, 100, 100),
           "I": (140, 200, 240), "v": (60, 130, 60), "o": (140, 140, 140), "z": (30, 20, 30), "l": (240, 90, 20), "R": (190, 60, 50), "U": (60, 110, 200),
           "Z": (250, 250, 255), "K": (90, 90, 110), "O": (170, 110, 50), "W": (225, 205, 160), "g": (130, 130, 140), "D": (110, 70, 30), "m": (60, 80, 120),
           "X": (70, 40, 90), "Y": (110, 20, 60), "C": (95, 60, 120), "V": (255, 60, 60), "E": (200, 20, 20), "e": (150, 10, 10), "h": (10, 10, 10), "i": (232, 200, 110), "a": (80, 90, 50), "=": (40, 70, 60), "d": (70, 70, 50), "u": (60, 140, 70), "y": (90, 170, 80), "F": (60, 150, 60), "j": (170, 170, 160)}
    S = 5
    im = Image.new("RGB", (W * S, H * S))
    px = im.load()
    for y in range(H):
        for x in range(W):
            c = COL.get(g[y][x], (255, 0, 255))
            for i in range(S):
                for j in range(S):
                    px[x * S + i, y * S + j] = c
    for o in objects:
        c = {"chest": (255, 215, 0), "rest": (80, 255, 255), "bush": (255, 120, 200), "sign": (255, 255, 255), "seal": (255, 0, 255)}.get(o["type"], None)
        if c:
            for i in range(S):
                for j in range(S):
                    px[o["x"] * S + i, o["y"] * S + j] = c
    im.save(os.path.join(ROOT, "tools", "ilha_preview.png"))
    print("preview salvo")

if "--debug" in sys.argv:
    for z in zones:
        if (z["x"], z["y"]) not in reach:
            x, y = z["x"], z["y"]
            print(z["id"], "char", get(x, y), "in main_set", (x, y) in main_set, "walk", walkable(x, y))
            for yy in range(y - 4, y + 5):
                print("".join(g[yy][xx] if 0 <= xx < W else " " for xx in range(x - 8, x + 9)))
